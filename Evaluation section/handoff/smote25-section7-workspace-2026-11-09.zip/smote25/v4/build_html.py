"""Reading copy of Section 7 (v4) as one self-contained HTML page: English paper text converted from the LaTeX with pandoc
(citations through citeproc, MathML), numbers of sections, tables, figures and equations taken from the compiled preview
(preview/preview.aux), figures embedded as PNG data URIs. A Thai reading version (th/section07-th.md) is added as a second
tab when it exists."""
import re, os, json, base64, subprocess, html
V4 = '/home/claude/smote25/v4/'
AUX = open(V4 + 'preview/preview.aux').read()
NUM = {m.group(1): m.group(2) for m in re.finditer(r'\\newlabel\{([^}]+)\}\{\{([^}]*)\}', AUX)}


def inline_inputs(s):
    return re.sub(r'\\input\{([^}]+)\}', lambda m: inline_inputs(open(V4 + m.group(1) + ('' if m.group(1).endswith('.tex') else '.tex')).read()), s)


def prep(s):
    s = inline_inputs(s)
    s = re.sub(r'(?m)^%.*\n', '', s)
    # number captions of tables and figures from the compiled preview
    def cap(env):
        def f(m):
            body = m.group(0)
            lab = re.search(r'\\label\{((?:tab|fig):[^}]+)\}', body)
            if not lab or lab.group(1) not in NUM:
                return body
            word = 'Table' if lab.group(1).startswith('tab') else 'Figure'
            return body.replace('\\caption{', '\\caption{' + word + ' ' + NUM[lab.group(1)] + '. ', 1)
        return f
    s = re.sub(r'\\begin\{table\}.*?\\end\{table\}', cap('table'), s, flags=re.S)
    s = re.sub(r'\\begin\{figure\}.*?\\end\{figure\}', cap('figure'), s, flags=re.S)
    s = re.sub(r'\\begin\{longtable\}.*?\\end\{longtable\}', cap('table'), s, flags=re.S)
    s = re.sub(r'\\ref\{([^}]+)\}', lambda m: NUM.get(m.group(1), '?'), s)
    def lt(m):  # pandoc cannot read this longtable: rewrite it as a plain table for the HTML copy
        body = m.group(0)
        cap = re.search(r'\\caption\{(.*?)\}\\label\{([^}]+)\}', body)
        rows = body[body.index('\\endfoot') + len('\\endfoot'):body.index('\\end{longtable}')]
        note = ''
        out = []
        for line in rows.strip().split('\\\\\n'):
            line = line.strip().rstrip('\\').strip()
            if not line:
                continue
            g = re.match(r'\\multicolumn\{8\}\{@\{\}l\}\{\\textit\{(.*)\}\}$', line)
            n = re.match(r'\\multicolumn\{8\}\{@\{\}p\{[^}]*\}\}\{\\textit\{(.*)\}\}$', line, re.S)
            if g:
                out.append('\\textit{' + g.group(1) + '} & & & & & & & ')
            elif n:
                note = n.group(1)
            else:
                out.append(line)
        head = 'Measure & --2009 & --2015 & --2020 & --2026 & Trend & Driver & Cause of the change'
        return ('\\begin{table}\n\\caption{' + cap.group(1) + '}\\label{' + cap.group(2) + '}\n\\begin{tabular}{lrrrrlll}\n\\toprule\n' + head + '\\\\\n\\midrule\n' +
                '\\\\\n'.join(out) + '\\\\\n\\bottomrule\n\\end{tabular}\n\\end{table}\n\n' + ('\\textit{' + note + '}\n\n' if note else ''))
    s = re.sub(r'\\begin\{longtable\}.*?\\end\{longtable\}', lt, s, flags=re.S)
    s = s.replace('\\begin{small}', '').replace('\\end{small}', '').replace('\\vspace{-\\baselineskip}', '')
    s = re.sub(r'\\label\{eq:[^}]+\}', '', s)
    pre = '\\newcommand{\\TODO}[1]{\\textbf{[TODO: #1]}}\n\\newcommand{\\Description}[1]{}\n'
    return pre + s


def to_html(tex):
    r = subprocess.run(['pandoc', '-f', 'latex', '-t', 'html5', '--mathml', '--citeproc', '--bibliography', V4 + 'preview/all.bib',
                        '--number-sections', '--number-offset=6', '--section-divs', '--wrap=none'], input=tex, capture_output=True, text=True)
    if r.returncode:
        raise SystemExit(r.stderr)
    if r.stderr.strip():
        print('pandoc:', r.stderr.strip()[:600])
    return r.stdout


def embed_images(h):
    def f(m):
        name = os.path.basename(m.group(1)); p = V4 + 'figures/' + name + ('' if name.endswith('.png') else '.png')
        return 'src="data:image/png;base64,' + base64.b64encode(open(p, 'rb').read()).decode() + '"'
    return re.sub(r'src="([^"]+)"', f, h)


def toc(h, prefix):
    items = []
    for m in re.finditer(r'<h([23]) data-number="([^"]+)"[^>]*>(.*?)</h\1>', h):
        sid = re.search(r'<section id="([^"]+)"', h[:m.start()][::-1][::-1][h[:m.start()].rfind('<section id="'):] or '')
        items.append((m.group(1), m.group(2), re.sub(r'<[^>]+>', '', m.group(3)).strip(), sid.group(1) if sid else ''))
    return items


def build():
    tex = prep(open(V4 + 'sections/07-empirical-comparisons.tex').read())
    en = embed_images(to_html(tex))
    en = en.replace('[TODO:', '<span class="todo">[TODO:').replace('<strong><span class="todo">', '<strong class="todo">')
    en = re.sub(r'<strong class="todo">\[TODO:(.*?)\]</strong>', r'<span class="todo">[TODO:\1]</span>', en)
    th = ''
    if os.path.exists(V4 + 'th/section07-th.md'):
        r = subprocess.run(['pandoc', '-f', 'markdown', '-t', 'html5', '--mathml', '--section-divs', '--wrap=none', '--number-sections', '--number-offset=6'],
                           input=open(V4 + 'th/section07-th.md').read(), capture_output=True, text=True)
        th = embed_images(r.stdout.replace('<section id="', '<section id="th-'))
    return en, th


if __name__ == '__main__':
    en, th = build()
    open(V4 + 'preview/en.html', 'w').write(en)
    if th:
        open(V4 + 'preview/th.html', 'w').write(th)
    print(len(en), len(th))
