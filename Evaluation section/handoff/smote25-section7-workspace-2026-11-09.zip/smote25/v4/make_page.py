"""Bilingual reading page for Section 7 v4: English paper text (from the LaTeX) and the Thai reading version, one tab each,
with a contents rail. Writes the artifact body (no document skeleton) and a complete HTML document for the repository."""
import re, html
import build_html as B

V4 = B.V4
en, th = B.build()


def rail(h, prefix):
    items = []
    for m in re.finditer(r'<section id="([^"]+)" class="level2"[^>]*>\s*<h2 data-number="([^"]+)">(.*?)</h2>', h, re.S):
        title = re.sub(r'<[^>]+>', '', m.group(3)); title = re.sub(r'^\s*[\d.]+\s*', '', title).strip()
        items.append('<li><a href="#' + m.group(1) + '"><span>' + m.group(2) + '</span><span>' + html.escape(title) + '</span></a></li>')
    return '<ol>' + ''.join(items) + '</ol>'


def strip_h1(h):
    return re.sub(r'<h1 data-number="7">.*?</h1>', '', h, count=1, flags=re.S)


CSS = r"""
:root{--bg:#f3f4f2;--paper:#ffffff;--ink:#1b1f23;--ink-2:#4a535c;--muted:#6f7881;--rule:#d8dde2;--rule-2:#ebeef1;--tint:#f6f7f8;
  --accent:#1f5fbf;--accent-soft:#e8eefa;--todo:#b42318;--todo-soft:#fdecea;
  --f-serif:"STIX Two Text","Noto Serif Thai",Georgia,serif;--f-ui:"IBM Plex Sans Thai",system-ui,-apple-system,"Segoe UI",sans-serif;}
@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){--bg:#101316;--paper:#171b1f;--ink:#e6e9ec;--ink-2:#b6bec6;--muted:#8a949d;--rule:#2b3239;--rule-2:#21272d;--tint:#1c2126;
  --accent:#7aaaf0;--accent-soft:#1a2738;--todo:#ff8a80;--todo-soft:#3a1f1d;color-scheme:dark}}
:root[data-theme="dark"]{--bg:#101316;--paper:#171b1f;--ink:#e6e9ec;--ink-2:#b6bec6;--muted:#8a949d;--rule:#2b3239;--rule-2:#21272d;--tint:#1c2126;
  --accent:#7aaaf0;--accent-soft:#1a2738;--todo:#ff8a80;--todo-soft:#3a1f1d;color-scheme:dark}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--ink);font-family:var(--f-serif);font-size:17px;line-height:1.65;
  padding-left:max(16px,env(safe-area-inset-left,0px));padding-right:max(16px,env(safe-area-inset-right,0px));padding-bottom:64px}
.wrap{max-width:1180px;margin:0 auto}
header.top{padding:28px 0 14px;display:grid;gap:8px;font-family:var(--f-ui)}
.eyebrow{font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:var(--muted)}
header h1{font-family:var(--f-serif);font-size:clamp(25px,3.2vw,34px);line-height:1.25;margin:0;font-weight:600;text-wrap:balance}
.lede{font-size:15px;color:var(--ink-2);max-width:78ch;margin:0;line-height:1.6}
.tabs{display:flex;gap:6px;flex-wrap:wrap;margin-top:6px}
.tabs button{font:inherit;font-family:var(--f-ui);font-size:14px;padding:6px 14px;border-radius:999px;border:1px solid var(--rule);background:var(--paper);color:var(--ink-2);cursor:pointer}
.tabs button[aria-selected="true"]{background:var(--accent);border-color:var(--accent);color:#fff;font-weight:600}
.layout{display:grid;grid-template-columns:250px minmax(0,1fr);gap:28px;align-items:start}
nav.rail{position:sticky;top:12px;max-height:calc(100vh - 24px);overflow:auto;font-family:var(--f-ui);font-size:13px;line-height:1.4}
nav.rail ol{list-style:none;margin:0;padding:0;display:grid;gap:2px}
nav.rail a{display:grid;grid-template-columns:36px minmax(0,1fr);gap:4px;padding:5px 6px;border-radius:6px;color:var(--ink-2);text-decoration:none}
nav.rail a:hover{background:var(--paper);color:var(--ink)}
nav.rail a span:first-child{color:var(--muted);font-variant-numeric:tabular-nums}
nav.rail .rl{font-size:11.5px;letter-spacing:.08em;text-transform:uppercase;color:var(--muted);margin:0 0 8px 6px}
main.paper{background:var(--paper);border:1px solid var(--rule);border-radius:12px;padding:12px clamp(18px,4.5vw,56px) 48px;min-width:0}
main.paper > div[hidden]{display:none}
.paper p{margin:0 0 .9em;max-width:72ch;hyphens:auto}
.paper h2{font-size:23px;line-height:1.3;margin:1.8em 0 .6em;font-weight:600;scroll-margin-top:12px;text-wrap:balance}
.paper h2 .header-section-number{color:var(--accent);margin-right:.45em}
.paper section.level2:first-of-type h2{margin-top:1.2em}
.paper h3,.paper h4,.paper h5{font-size:17px;margin:1.2em 0 .4em}
.paper ol,.paper ul{max-width:70ch;padding-left:1.4em;margin:0 0 1em}
.paper li{margin:.25em 0}
.paper a{color:var(--accent)}
.paper .citation{color:var(--ink-2)}
.paper figure{margin:1.4em 0;padding:12px;border:1px solid var(--rule-2);border-radius:10px;background:#fff;max-width:100%}
.paper figure img{display:block;width:100%;height:auto}
.paper figcaption{font-family:var(--f-ui);font-size:13.5px;color:#3a434c;margin-top:8px;line-height:1.45}
.paper table{border-collapse:collapse;font-family:var(--f-ui);font-size:13px;line-height:1.45;margin:1.2em 0;width:100%;font-variant-numeric:tabular-nums}
.paper table caption{caption-side:top;text-align:left;font-size:13.5px;font-weight:600;color:var(--ink);padding-bottom:6px}
.paper thead th,.paper table tr.header th{border-top:1.5px solid var(--ink-2);border-bottom:1px solid var(--ink-2);text-align:left;padding:6px 8px;vertical-align:bottom;font-weight:600}
.paper td{padding:6px 8px;border-bottom:1px solid var(--rule-2);vertical-align:top}
.paper tbody tr:last-child td{border-bottom:1.5px solid var(--ink-2)}
.tbl{overflow-x:auto;margin:1.2em 0}
.tbl table{min-width:640px;margin:0}
.paper math{font-size:1.05em}
.paper math[display="block"]{margin:.8em 0;overflow-x:auto;max-width:100%}
.mathwrap{overflow-x:auto;max-width:100%}
.todo{color:var(--todo);background:var(--todo-soft);border-radius:4px;padding:0 4px;font-family:var(--f-ui);font-size:.86em}
.lede-th{font-family:var(--f-ui);font-size:14px;color:var(--ink-2);background:var(--tint);border-radius:8px;padding:10px 14px;margin:1.2em 0}
.foot{font-family:var(--f-ui);font-size:12.5px;color:var(--muted);margin-top:28px;border-top:1px solid var(--rule-2);padding-top:12px;display:grid;gap:4px}
#refs,.references{font-size:14px}
.references div{margin:0 0 .5em;padding-left:1.4em;text-indent:-1.4em}
:lang(th) p,:lang(th) li{font-family:"Noto Serif Thai",var(--f-serif);line-height:1.8}
@media (max-width:920px){.layout{grid-template-columns:minmax(0,1fr)}nav.rail{position:static;max-height:none}nav.rail details{background:var(--paper);border:1px solid var(--rule);border-radius:10px;padding:8px 10px}}
@media (max-width:600px){body{font-size:16px}.paper h2{font-size:20px}}
"""

JS = r"""
(function(){
  var K='smote25-sec7-v4-lang', btns=document.querySelectorAll('.tabs button');
  function show(l){document.querySelectorAll('[data-lang]').forEach(function(e){e.hidden=e.getAttribute('data-lang')!==l;});
    btns.forEach(function(b){b.setAttribute('aria-selected',b.dataset.l===l?'true':'false');});
    try{localStorage.setItem(K,l);}catch(e){}}
  btns.forEach(function(b){b.addEventListener('click',function(){show(b.dataset.l);window.scrollTo(0,0);});});
  var s=null;try{s=localStorage.getItem(K);}catch(e){}
  show(s==='th'?'th':'en');
  document.querySelectorAll('.paper table').forEach(function(t){if(t.parentElement.classList.contains('tbl'))return;var w=document.createElement('div');w.className='tbl';t.parentNode.insertBefore(w,t);w.appendChild(t);});
  var d=document.querySelectorAll('nav.rail details');if(window.matchMedia('(max-width:920px)').matches)d.forEach(function(x){x.open=false;});
})();
"""


def page():
    en_b = strip_h1(en); th_b = strip_h1(th)
    th_b = th_b.replace('<div class="lede">', '<div class="lede-th">')
    wrapm = lambda h: re.sub(r'(<math display="block".*?</math>)', r'<span class="mathwrap" style="display:block">\1</span>', h, flags=re.S)
    en_b, th_b = wrapm(en_b), wrapm(th_b)
    body = ('<div class="wrap"><header class="top"><div class="eyebrow">SMOTE25 · Section 7 · Draft v4 · 8 November 2026</div>'
            '<h1>Empirical Comparisons and Benchmarks</h1>'
            '<p class="lede">How SMOTE-family methods are evaluated today, why the practice changed since 2002, and a protocol for a new study. '
            'Analysis of the 71 empirical studies of the SMOTE25 corpus. The English tab is the paper text converted from the LaTeX; the Thai tab is a full translation for the team.</p>'
            '<div class="tabs" role="tablist"><button role="tab" data-l="en">English (paper text)</button><button role="tab" data-l="th">ภาษาไทย</button></div></header>'
            '<div class="layout"><nav class="rail" aria-label="Contents">'
            '<details open data-lang="en"><summary class="rl">Contents</summary>' + rail(en, 'en') + '</details>'
            '<details open data-lang="th" hidden><summary class="rl">สารบัญ</summary>' + rail(th, 'th') + '</details></nav>'
            '<main class="paper"><div data-lang="en" lang="en">' + en_b + '</div><div data-lang="th" lang="th" hidden>' + th_b + '</div>'
            '<div class="foot"><span>Numbers from the coded corpus (76 papers, 71 empirical; second-reading codes with page references). Citations from OpenAlex, 18 Oct 2026. '
            'Illustrative runs: 110 KEEL datasets, 5 samplers, 5 learners, one stratified 5-fold run (31 Aug 2026).</span>'
            '<span>LaTeX package: sections/07-empirical-comparisons.tex, tables/empirical-*.tex, figures/empirical-*.pdf. Regenerate rather than edit numbers.</span></div>'
            '</main></div></div>')
    head = ('<title>SMOTE25 Section 7 v4</title>\n<meta name="claude:viewport-fit-sides" content="cover">\n'
            '<link rel="preconnect" href="https://fonts.googleapis.com">\n<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>\n'
            '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Thai:wght@400;500;600&family=Noto+Serif+Thai:wght@400;600&family=STIX+Two+Text:ital,wght@0,400;0,600;1,400&display=swap">\n'
            '<style>' + CSS + '</style>\n')
    art = head + body + '\n<script>' + JS + '</script>\n'
    assert '—' not in art, 'em-dash'
    open(V4 + 'preview/smote25_section7_v4.html', 'w').write(art)
    i = art.index('</style>\n') + len('</style>\n')
    doc = ('<!doctype html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n'
           + art[:i] + '</head>\n<body>\n' + art[i:] + '\n</body>\n</html>\n')
    open(V4 + 'preview/section07-empirical-comparisons-v4.html', 'w').write(doc)
    print('page', len(art.encode()))


page()
