# Section 7 (empirical comparisons and evaluation practice): files for tohnperfect/SMOTE25, version 4

Version 4 (8 Nov 2026) rewrites Section 7 for a reader who plans a new SMOTE-family study. It keeps the coded
corpus and every verified number of v3, and adds the analyses asked for since then.

Copy these folders into the repository root; paths match the repo layout.

- `sections/07-empirical-comparisons.tex`: Section 7 v4 (replaces the v3 file). About 9,800 words, 13 subsections.
- `tables/empirical-*.tex`: 11 tables (caption above, booktabs). New in v4: `empirical-thennow`, `empirical-learner-causes`,
  `empirical-measure-causes` (longtable), `empirical-direct`, `empirical-reporting`, `empirical-example`, `empirical-drivers`;
  `empirical-measures` rewritten. Kept from v3: `empirical-protocols`, `empirical-reasons`, `empirical-outcomes`.
  No longer used: `empirical-sources`, `empirical-remedies`, `empirical-measuredefs`, `empirical-beyond` (their content moved
  into the text or into the new tables; the data sources are left to the Data section).
- `figures/empirical-*.pdf`: 10 figures. New in v4 (made by `make_figures.py`): toolchain, absorption, smote-vs-none,
  gmean-f1, cd, reporting. Kept from v3: corpus, pipeline, tuning, tests (sources in `figures/src/`).
- `sections/appendix-empirical-map.tex`: Appendix B, unchanged from v3.
- `notes/main-tex-additions.tex`: the two lines to add to `main.tex` (longtable and the appendix), unchanged.
- `notes/empirical-bib-candidates.bib`: v3 candidates plus three new entries (Bradley 1997, Boughorbel et al. 2017,
  Torgo et al. 2013). Verify before merging into references.bib.
- `notes/section07-v4-preview.pdf`: compile check of the section alone (article class, natbib author-year in place of
  biblatex/acmauthoryear).

What the section now answers
1. What SMOTE used in 2002 (3 learners, AUC/TPR/TNR) against the studies of 2021 to 2026 (12 learner families, 21 measures,
   19 different measure sets among 24 studies) and what was added or dropped (7.2, Table 1).
2. Why every learner family and every measure rose, fell, appeared or disappeared, with the evidence level stated
   (Tables 2 and 3; drivers: change of toolkit, absorption into composites, larger benchmarks, change of problem,
   lines of work, realism and critiques).
3. How many measures come from a downstream classifier (27 in 5 families plus cost) and what each family answers (7.3).
4. Why G-mean is the most reported measure, as a mechanism, with the authors' illustrative runs (7.4).
5. How G-mean and F1 differ and when the difference changes the winner (7.5).
6. The six studies that check the resampled data directly, and how (7.6).
7. That every study evaluates through classification (7.7).
8. Protocols, tuning and tests (7.8), reporting with a worked example (7.9), why practice changed (7.10), outcomes (7.11),
   and an 11-step protocol for a new study (7.12).

Revision of 8 Nov 2026, after reading the 15-year review (Fernández, García, Herrera and Chawla, JAIR 61, 2018; `fernandez2018smote`)
- Introduction: Section 7 is positioned as the complement of that review, which catalogues extensions and challenges but does not
  examine how methods are evaluated; recommendations of the review that bear on evaluation are checked against the corpus.
- 7.2: why SMOTE was evaluated with ROC/AUC (the mammography story: 97% accuracy against 97.68% for the majority guess; unequal error costs).
- 7.3: warning that F1 also names Fisher's discriminant ratio in data-complexity work.
- 7.4 and 7.10: preprocessing and cost-sensitive learning found equivalent (López et al. 2012, restated in the review), yet only 5 studies
  include a cost-sensitive competitor, 3 of them after the review.
- 7.6: the review's call to relate synthetic instances to data characteristics; direct checks in 5 of 36 studies since 2019 against 1 of 35 before.
- 7.7 corrected: classification-only is a property of the corpus, not of SMOTE; the review lists 22 SMOTE-based methods for 12 other
  paradigms (streams, regression with SMOTER, multi-label, multi-instance, semi-supervised and others), each with its own measures.
- 7.8: partition-induced dataset shift and DOB-SCV (Moreno-Torres et al. 2012; López et al. 2014), recommended by the review and used by
  none of the 71 studies; the 2008 wrapper of Chawla et al. as a way to choose the amount of resampling on training data.
- 7.12: steps 2, 4 and 6 updated (high-dimensional data, cost-sensitive baseline, DOB-SCV).
- Five bib candidates added from the review's reference list (DOIs still to add, except Blagus and Lusa).

Open items (`\TODO` in the text): checking the second-reading quotes, whether the illustrative runs stay in the paper
(and if so, repeating the CV five times), and the label of the Data section. The illustrative runs use a single 5-fold
run and reimplementations of CISO and QC-SMOTE; the text says so.

The Thai reading version of the same text is in `section07-empirical-comparisons-v4.html` (outside the repo, Thai tab).
No em-dashes anywhere.
