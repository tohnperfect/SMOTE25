"""Re-analysis of experiment/results_mean.csv and results_raw.csv (110 KEEL x 5 methods x 5 classifiers x 5-fold, 31 Aug 2026)."""
import pandas as pd, numpy as np, json
from scipy import stats
U = '/mnt/user-data/uploads/SMOTE/experiment/'
M = pd.read_csv(U + 'results_mean.csv', keep_default_na=False, na_values=['']); RAW = pd.read_csv(U + 'results_raw.csv', keep_default_na=False, na_values=[''])
for _x in (M, RAW): _x['method'] = _x['method'].replace({'QCSMOTE': 'QC-SMOTE'})
METH = ['None', 'SMOTE', 'MWMOTE', 'CISO', 'QC-SMOTE']; CLF = ['CART', 'kNN', 'SVM', 'LR', 'RF']; MEAS = ['AUC', 'PR_AUC', 'F1', 'Gmean']
print(M.classifier.unique(), M.method.unique(), M.dataset.nunique())
CLFMAP = {c: c for c in M.classifier.unique()}
O = {'meth': METH, 'meas': MEAS}
def ranks(sub):  # sub: rows=dataset, cols=method -> ranks (1 best), ties averaged
    return sub[METH].rank(axis=1, ascending=False, method='average')
# pooled check (550 blocks)
pooled = {}
for m in MEAS:
    P = M.pivot_table(index=['dataset', 'classifier'], columns='method', values=m)
    pooled[m] = ranks(P).mean().round(2).to_dict()
print('pooled', pooled)
O['pooled'] = pooled
k = 5; N = M.dataset.nunique(); q05 = 2.728; CD = q05 * np.sqrt(k * (k + 1) / (6 * N)); O['CD'] = CD; O['N'] = N
print('CD', CD)
clfs = list(M.classifier.unique()); O['clf'] = clfs
per = {}
for c in clfs:
    for m in MEAS:
        P = M[M.classifier == c].pivot(index='dataset', columns='method', values=m)[METH]
        Rk = ranks(P); ar = Rk.mean()
        chi = 12 * N / (k * (k + 1)) * (np.sum(ar ** 2) - k * (k + 1) ** 2 / 4)
        FF = (N - 1) * chi / (N * (k - 1) - chi); pF = stats.f.sf(FF, k - 1, (k - 1) * (N - 1))
        # Holm-corrected Wilcoxon vs SMOTE
        ps = {}
        for meth in METH:
            if meth == 'SMOTE': continue
            d = P[meth] - P['SMOTE']
            ps[meth] = float(stats.wilcoxon(d, zero_method='zsplit').pvalue) if (d != 0).any() else 1.0
        order = sorted(ps, key=ps.get); adj = {}; mx = 0
        for i, meth in enumerate(order):
            mx = max(mx, min(1, ps[meth] * (len(order) - i))); adj[meth] = mx
        wtl = {meth: [int((P[meth] > P['SMOTE'] + 1e-12).sum()), int((abs(P[meth] - P['SMOTE']) <= 1e-12).sum()), int((P[meth] < P['SMOTE'] - 1e-12).sum())] for meth in METH if meth != 'SMOTE'}
        per[c + '|' + m] = dict(ar=ar.round(3).to_dict(), chi=round(chi, 2), FF=round(FF, 2), pF=pF, holm=adj, raw=ps, wtl=wtl, mean=P.mean().round(4).to_dict())
O['per'] = per
# classifier-averaged scores per dataset -> one block per dataset (N=110)
avg = {}
for m in MEAS:
    P = M.groupby(['dataset', 'method'])[m].mean().unstack()[METH]
    avg[m] = ranks(P).mean().round(3).to_dict()
O['avg_rank_clfmean'] = avg
# SMOTE vs None per measure across 550 blocks
sv = {}
for m in MEAS:
    P = M.pivot_table(index=['dataset', 'classifier'], columns='method', values=m)
    d = P['SMOTE'] - P['None']
    sv[m] = dict(win=int((d > 1e-12).sum()), tie=int((abs(d) <= 1e-12).sum()), loss=int((d < -1e-12).sum()), med=float(d.median()), mean=float(d.mean()))
O['smote_vs_none'] = sv; print('smote vs none', sv)
# G-mean vs F1 agreement on best method per block
P1 = M.pivot_table(index=['dataset', 'classifier'], columns='method', values='F1')[METH]
P2 = M.pivot_table(index=['dataset', 'classifier'], columns='method', values='Gmean')[METH]
b1 = P1.idxmax(axis=1); b2 = P2.idxmax(axis=1)
O['best_agree'] = dict(same=int((b1 == b2).sum()), n=len(b1))
taus = [stats.kendalltau(P1.loc[i], P2.loc[i]).statistic for i in P1.index]
O['tau_median'] = float(np.nanmedian(taus))
O['best_counts'] = dict(F1=b1.value_counts().to_dict(), Gmean=b2.value_counts().to_dict())
cross = pd.crosstab(b2, b1); O['cross'] = {r: {c: int(cross.loc[r, c]) if c in cross.columns else 0 for c in METH} for r in METH if r in cross.index}
print('agree', O['best_agree'], 'tau', O['tau_median']); print(cross)
# correlation of measure values across all rows
O['corr'] = M[MEAS].corr(method='spearman').round(3).to_dict()
# IR vs gain of SMOTE over None (classifier-averaged)
G = M.groupby(['dataset', 'method']).agg(IR=('IR', 'first'), Gmean=('Gmean', 'mean'), F1=('F1', 'mean'), AUC=('AUC', 'mean'), PR_AUC=('PR_AUC', 'mean')).reset_index()
W = G.pivot(index='dataset', columns='method')
ir = W['IR']['None']
gain = {m: (W[m]['SMOTE'] - W[m]['None']) for m in MEAS}
O['ir_gain'] = [dict(ds=ds, IR=float(ir[ds]), **{m: round(float(gain[m][ds]), 4) for m in MEAS}) for ds in W.index]
O['ir_gain_rho'] = {m: float(stats.spearmanr(ir, gain[m]).statistic) for m in MEAS}
print('rho IR vs gain', O['ir_gain_rho'])
# zero G-mean (trivial majority) counts for None
O['gm_zero_none'] = int((M[(M.method == 'None')].Gmean == 0).sum()); O['f1_zero_none'] = int((M[(M.method == 'None')].F1 == 0).sum())
# per-dataset values for the browser (rounded)
vals = {}
for (ds, c), g in M.groupby(['dataset', 'classifier']):
    g = g.set_index('method')
    vals.setdefault(ds, {'IR': float(g['IR'].iloc[0])})[c] = [[round(float(g.loc[me, m]), 4) for me in METH] for m in MEAS]
O['vals'] = vals
# fold SD example
sd = RAW.groupby(['dataset', 'method', 'classifier'])[MEAS].std().reset_index()
O['fold_sd_median'] = {m: float(sd[m].median()) for m in MEAS}
json.dump(O, open('exp.json', 'w'), default=float)
for key in ['SVM|Gmean', 'SVM|F1', 'RF|Gmean', 'RF|PR_AUC', 'LR|AUC']:
    if key in per: print(key, per[key]['ar'], per[key]['pF'], {k_: round(v, 4) for k_, v in per[key]['holm'].items()})
print('avg', avg); print('fold sd', O['fold_sd_median'], 'zeros', O['gm_zero_none'], O['f1_zero_none'])
# ---- extras: classifier-averaged blocks (N=110) with Friedman + Holm vs SMOTE; example table (SVM, G-mean)
def friedman_holm(P):
    Rk = ranks(P); ar = Rk.mean(); n = len(P)
    chi = 12 * n / (k * (k + 1)) * (np.sum(ar ** 2) - k * (k + 1) ** 2 / 4)
    FF = (n - 1) * chi / (n * (k - 1) - chi); pF = stats.f.sf(FF, k - 1, (k - 1) * (n - 1))
    ps = {me: float(stats.wilcoxon(P[me] - P['SMOTE'], zero_method='zsplit').pvalue) for me in METH if me != 'SMOTE'}
    order = sorted(ps, key=ps.get); adj = {}; mx = 0
    for i, me in enumerate(order):
        mx = max(mx, min(1, ps[me] * (len(order) - i))); adj[me] = mx
    wtl = {me: [int((P[me] > P['SMOTE'] + 1e-12).sum()), int((abs(P[me] - P['SMOTE']) <= 1e-12).sum()), int((P[me] < P['SMOTE'] - 1e-12).sum())] for me in METH if me != 'SMOTE'}
    return dict(ar=ar.round(3).to_dict(), chi=round(chi, 2), FF=round(FF, 2), pF=pF, holm=adj, raw=ps, wtl=wtl, mean=P.mean().round(4).to_dict())
for m in MEAS:
    P = M.groupby(['dataset', 'method'])[m].mean().unstack()[METH]
    O['per']['avg|' + m] = friedman_holm(P)
# example table: SVM G-mean, 8 datasets spread over IR, mean and fold SD
S = RAW[RAW.classifier == 'SVM'].groupby(['dataset', 'method'])['Gmean'].agg(['mean', 'std']).reset_index()
irs = M.groupby('dataset')['IR'].first().sort_values()
pick = [irs.index[int(round(q * (len(irs) - 1)))] for q in [0.02, 0.15, 0.3, 0.45, 0.6, 0.75, 0.88, 0.98]]
ex = []
for ds in pick:
    row = S[S.dataset == ds].set_index('method')
    ex.append(dict(ds=ds, IR=float(irs[ds]), v={me: [float(row.loc[me, 'mean']), float(row.loc[me, 'std'])] for me in METH}))
O['example'] = ex
O['n_runs_note'] = '5 folds, 1 repetition'
# measure-set diversity in our corpus is computed in the page build
json.dump(O, open('exp.json', 'w'), default=float)
print('avg G', O['per']['avg|Gmean']['ar'], O['per']['avg|Gmean']['pF'], O['per']['avg|Gmean']['holm'])
print([ (e['ds'], round(e['IR'],1)) for e in ex])
