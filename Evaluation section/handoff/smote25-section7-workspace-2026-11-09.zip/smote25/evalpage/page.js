(function(){
'use strict';
const DATA = JSON.parse(document.getElementById('evdata').textContent);
const METH = DATA.meth, MCOL = {'None':'m-none','SMOTE':'m1','MWMOTE':'m2','CISO':'m3','QC-SMOTE':'m4'};
const MT = {AUC:'AUC',PR_AUC:'PR-AUC',F1:'F1',Gmean:'G-mean'};
const CT = {CART:'CART',kNN:'k-NN',SVM:'SVM-RBF',LR:'LogReg',RF:'RandomForest',avg:'เฉลี่ย 5 classifier'};
const NS = 'http://www.w3.org/2000/svg';
const fmtP = p => p < 0.001 ? '&lt; 0.001' : p.toFixed(3);
function el(tag, attrs, parent, text){ const e = document.createElementNS(NS, tag); for (const k in attrs) e.setAttribute(k, attrs[k]); if (text !== undefined) e.textContent = text; if (parent) parent.appendChild(e); return e; }

/* ---------- shared tooltip: any element with data-tip, hover or keyboard focus ---------- */
const tip = document.createElement('div'); tip.id = 'tip'; tip.setAttribute('role','tooltip'); document.body.appendChild(tip);
function showTip(t, x, y){ tip.textContent = t; tip.classList.add('on'); const w = tip.offsetWidth, h = tip.offsetHeight;
  let lx = x + 14, ly = y - h - 10; if (lx + w > innerWidth - 8) lx = x - w - 14; if (lx < 8) lx = 8; if (ly < 8) ly = y + 16; tip.style.left = lx + 'px'; tip.style.top = ly + 'px'; }
document.addEventListener('pointermove', e => { const t = e.target.closest && e.target.closest('[data-tip]'); if (t) showTip(t.getAttribute('data-tip'), e.clientX, e.clientY); else tip.classList.remove('on'); });
document.addEventListener('focusin', e => { const t = e.target.closest && e.target.closest('[data-tip]'); if (t){ const r = t.getBoundingClientRect(); showTip(t.getAttribute('data-tip'), r.left + r.width/2, r.top); } });
document.addEventListener('focusout', () => tip.classList.remove('on'));
document.querySelectorAll('[data-tip]').forEach(n => { if (!n.hasAttribute('tabindex') && !/^(A|BUTTON|INPUT|SELECT)$/.test(n.tagName)) n.setAttribute('tabindex','0'); });

/* ---------- CD diagram ---------- */
function drawCD(){
  const m = document.getElementById('cd-m').value, c = document.getElementById('cd-c').value;
  const host = document.getElementById('cd'), r = DATA.per[c + '|' + m], ar = r.ar, CD = DATA.CD;
  const W = Math.max(500, Math.min(820, host.clientWidth || 640)), L = 130, R = 120, axY = 46, xs = v => L + (v - 1) / 4 * (W - L - R);
  const ord = METH.slice().sort((a, b) => ar[a] - ar[b]);
  // maximal groups of methods within CD (Nemenyi)
  let groups = [];
  for (let i = 0; i < ord.length; i++){ let j = i; while (j + 1 < ord.length && ar[ord[j + 1]] - ar[ord[i]] < CD) j++; if (j > i) groups.push([i, j]); }
  groups = groups.filter((g, k) => !groups.some((h, q) => q !== k && h[0] <= g[0] && h[1] >= g[1] && (h[0] !== g[0] || h[1] !== g[1])));
  const gY0 = axY + 14, labY0 = gY0 + groups.length * 9 + 14, H = labY0 + 3 * 22 + 6;
  host.innerHTML = '';
  const s = el('svg', {class:'ch', viewBox:'0 0 ' + W + ' ' + H, role:'img', 'aria-label':'CD diagram ' + MT[m] + ' ' + CT[c], style:'min-width:500px'}, host);
  el('line', {x1:xs(1), x2:xs(5), y1:axY, y2:axY, class:'ax', 'stroke-width':1.5}, s);
  for (let v = 1; v <= 5; v += 0.5){ el('line', {x1:xs(v), x2:xs(v), y1:axY - (v % 1 ? 4 : 7), y2:axY, class:'ax'}, s); if (v % 1 === 0) el('text', {x:xs(v), y:axY - 11, 'text-anchor':'middle'}, s, v); }
  el('line', {x1:xs(1), x2:xs(1 + CD), y1:12, y2:12, style:'stroke:var(--ink)', 'stroke-width':2}, s);
  el('line', {x1:xs(1), x2:xs(1), y1:8, y2:16, style:'stroke:var(--ink)', 'stroke-width':1.5}, s); el('line', {x1:xs(1 + CD), x2:xs(1 + CD), y1:8, y2:16, style:'stroke:var(--ink)', 'stroke-width':1.5}, s);
  el('text', {x:xs(1 + CD) + 6, y:16}, s, 'CD = ' + CD.toFixed(2));
  groups.forEach((g, k) => { const y = gY0 + k * 9; el('line', {x1:xs(ar[ord[g[0]]]) - 3, x2:xs(ar[ord[g[1]]]) + 3, y1:y, y2:y, style:'stroke:var(--ink)', 'stroke-width':4, 'stroke-linecap':'round'}, s); });
  ord.forEach((me, i) => {
    const left = i < 3, row = left ? i : ord.length - 1 - i, y = labY0 + row * 22, x = xs(ar[me]);
    el('polyline', {points: x + ',' + axY + ' ' + x + ',' + y + ' ' + (left ? L - 8 : W - R + 8) + ',' + y, fill:'none', style:'stroke:var(--' + MCOL[me] + ')', 'stroke-width':2}, s);
    el('circle', {cx:x, cy:axY, r:4.5, style:'fill:var(--' + MCOL[me] + ');stroke:var(--paper)', 'stroke-width':2, 'data-tip': me + ': average rank ' + ar[me].toFixed(2)}, s);
    const t = el('text', {x: left ? L - 12 : W - R + 12, y: y + 4, 'text-anchor': left ? 'end' : 'start', class:'lbl'}, s, me + '  ' + ar[me].toFixed(2));
    t.setAttribute('font-weight', i === 0 ? '700' : '400');
  });
  const others = METH.filter(x => x !== 'SMOTE').sort((a, b) => r.holm[a] - r.holm[b]);
  document.getElementById('cd-cap').innerHTML = 'Friedman (Iman-Davenport) F = ' + r.FF.toFixed(2) + ', p ' + (r.pF < 1e-4 ? '= ' + r.pF.toExponential(1) : '= ' + r.pF.toFixed(3)) +
    ' · N = 110 ชุดข้อมูล · Holm p (Wilcoxon เทียบ SMOTE): ' + others.map(x => x + ' ' + fmtP(r.holm[x])).join(', ') + '. เส้นหนาเชื่อมวิธีที่ average rank ต่างกันไม่ถึง CD';
}

/* ---------- paired scatter against SMOTE ---------- */
function drawSC(){
  const a = document.getElementById('sc-a').value, m = document.getElementById('sc-m').value, c = document.getElementById('sc-c').value;
  const mi = DATA.meas.indexOf(m), ia = METH.indexOf(a), ib = METH.indexOf('SMOTE'), host = document.getElementById('sc');
  const pts = Object.keys(DATA.vals).map(ds => { const v = DATA.vals[ds][c][mi]; return {ds, ir: DATA.vals[ds].IR, x: v[ib], y: v[ia]}; });
  let lo = Math.min(...pts.map(p => Math.min(p.x, p.y))); lo = Math.max(0, Math.floor(lo * 10) / 10);
  const W = Math.max(300, Math.min(460, host.clientWidth || 420)), L = 46, B = 40, T = 12, R = 14, sz = W - L - R, H = sz + T + B;
  const xs = v => L + (v - lo) / (1 - lo) * sz, ys = v => T + (1 - (v - lo) / (1 - lo)) * sz;
  host.innerHTML = '';
  const s = el('svg', {class:'ch', viewBox:'0 0 ' + W + ' ' + H, role:'img', 'aria-label':a + ' เทียบ SMOTE รายชุดข้อมูล'}, host);
  for (let v = lo; v <= 1.0001; v += (1 - lo) / 5){ el('line', {x1:L, x2:L + sz, y1:ys(v), y2:ys(v), class:'gr'}, s); el('line', {x1:xs(v), x2:xs(v), y1:T, y2:T + sz, class:'gr'}, s);
    el('text', {x:L - 6, y:ys(v) + 4, 'text-anchor':'end'}, s, v.toFixed(1)); el('text', {x:xs(v), y:T + sz + 15, 'text-anchor':'middle'}, s, v.toFixed(1)); }
  el('line', {x1:xs(lo), y1:ys(lo), x2:xs(1), y2:ys(1), style:'stroke:var(--muted)', 'stroke-dasharray':'4 4', 'stroke-width':1.5}, s);
  el('text', {x:L + sz / 2, y:H - 4, 'text-anchor':'middle', class:'mut'}, s, 'SMOTE (' + MT[m] + ')');
  const yl = el('text', {x:12, y:T + sz / 2, 'text-anchor':'middle', class:'mut', transform:'rotate(-90 12 ' + (T + sz / 2) + ')'}, s, a + ' (' + MT[m] + ')');
  el('text', {x:xs(lo) + 8, y:T + 14, class:'mut'}, s, '↖ ' + a + ' ดีกว่า'); el('text', {x:L + sz - 6, y:T + sz - 8, 'text-anchor':'end', class:'mut'}, s, 'SMOTE ดีกว่า ↘');
  let w = 0, t = 0, l = 0;
  pts.forEach(p => { const d = p.y - p.x; if (d > 1e-12) w++; else if (d < -1e-12) l++; else t++;
    el('circle', {cx:xs(p.x), cy:ys(p.y), r:4.5, style:'fill:var(--' + MCOL[a] + ');stroke:var(--paper)', 'fill-opacity':.8, 'stroke-width':1.2,
      'data-tip': p.ds + ' (IR ' + p.ir.toFixed(1) + ') · SMOTE ' + p.x.toFixed(3) + ' · ' + a + ' ' + p.y.toFixed(3)}, s); });
  const r = DATA.per[c + '|' + m];
  document.getElementById('sc-cap').innerHTML = '<b>' + a + '</b> ดีกว่า / เท่ากัน / แย่กว่า SMOTE: <b>' + w + ' / ' + t + ' / ' + l + '</b> จาก 110 ชุดข้อมูล · ค่าเฉลี่ย ' + a + ' ' + r.mean[a].toFixed(3) + ' กับ SMOTE ' + r.mean.SMOTE.toFixed(3) +
    ' · Holm p (Wilcoxon) = ' + fmtP(r.holm[a]) + '. จุดเหนือเส้นประ = ' + a + ' ดีกว่าในชุดข้อมูลนั้น';
  s.querySelectorAll('[data-tip]').forEach(n => n.setAttribute('tabindex','0'));
}

/* ---------- threshold explorer (two equal-variance Gaussians) ---------- */
function erf(x){ const s = Math.sign(x); x = Math.abs(x); const t = 1 / (1 + 0.3275911 * x);
  const y = 1 - (((((1.061405429 * t - 1.453152027) * t) + 1.421413741) * t - 0.284496736) * t + 0.254829592) * t * Math.exp(-x * x); return s * y; }
const Phi = z => 0.5 * (1 + erf(z / Math.SQRT2));
function drawTH(){
  const host = document.getElementById('th'), ir = Math.pow(10, +document.getElementById('th-ir').value), d = +document.getElementById('th-d').value, pi = 1 / (1 + ir);
  document.getElementById('th-iro').textContent = ir < 10 ? ir.toFixed(1) : Math.round(ir); document.getElementById('th-do').textContent = d.toFixed(1);
  const at = t => { const tpr = 1 - Phi(t - d), tnr = Phi(t), fpr = 1 - tnr, prec = tpr * pi / (tpr * pi + fpr * (1 - pi) || 1e-12);
    return {t, tpr, tnr, prec, g: Math.sqrt(tpr * tnr), f1: (prec + tpr) > 0 ? 2 * prec * tpr / (prec + tpr) : 0}; };
  const t0 = -2.5, t1 = d + 4, n = 240, P = []; for (let i = 0; i <= n; i++) P.push(at(t0 + (t1 - t0) * i / n));
  const fb = P.reduce((a, b) => b.f1 > a.f1 ? b : a), gb = P.reduce((a, b) => b.g > a.g ? b : a);
  const tb = at(d / 2), tr = at(d / 2 + Math.log(ir) / d);
  const W = Math.max(330, Math.min(820, host.clientWidth || 640)), H = W < 520 ? 230 : 270, L = 40, R = 16, T = 14, B = 34, xs = t => L + (t - t0) / (t1 - t0) * (W - L - R), ys = v => T + (1 - v) * (H - T - B);
  host.innerHTML = '';
  const s = el('svg', {class:'ch', viewBox:'0 0 ' + W + ' ' + H, role:'img', 'aria-label':'G-mean และ F1 เทียบ threshold'}, host);
  [0, .25, .5, .75, 1].forEach(v => { el('line', {x1:L, x2:W - R, y1:ys(v), y2:ys(v), class: v ? 'gr' : 'ax'}, s); el('text', {x:L - 6, y:ys(v) + 4, 'text-anchor':'end'}, s, v); });
  for (let t = Math.ceil(t0); t <= t1; t += (W < 520 && t1 - t0 > 7 ? 2 : 1)) el('text', {x:xs(t), y:H - B + 16, 'text-anchor':'middle'}, s, t);
  el('text', {x:(W + L) / 2, y:H - 3, 'text-anchor':'middle', class:'mut'}, s, 'threshold ของ score');
  const vline = (t, col, lab, dy, side) => { if (t < t0 || t > t1) return; el('line', {x1:xs(t), x2:xs(t), y1:T, y2:H - B, style:'stroke:var(--' + col + ')', 'stroke-dasharray':'5 4', 'stroke-width':1.5}, s);
    el('text', {x:xs(t) + (side < 0 ? -4 : 4), y:T + 10 + dy, class:'mut', 'text-anchor': side < 0 ? 'end' : 'start'}, s, lab); };
  vline(tb.t, 'm1', 'resample 1:1', 0, -1); vline(tr.t, 'm-none', 'ไม่ resample', 0, 1);
  const path = k => P.map((p, i) => (i ? 'L' : 'M') + xs(p.t).toFixed(1) + ',' + ys(p[k]).toFixed(1)).join(' ');
  el('path', {d:path('g'), fill:'none', style:'stroke:var(--m1)', 'stroke-width':2}, s);
  el('path', {d:path('f1'), fill:'none', style:'stroke:var(--m2)', 'stroke-width':2}, s);
  [[gb, 'g', 'm1', 'G-mean สูงสุด'], [fb, 'f1', 'm2', 'F1 สูงสุด']].forEach(([p, k, col, lab]) => el('circle', {cx:xs(p.t), cy:ys(p[k]), r:5, style:'fill:var(--' + col + ');stroke:var(--paper)', 'stroke-width':2, tabindex:0,
    'data-tip': lab + ' ที่ threshold ' + p.t.toFixed(2) + ': ' + p[k].toFixed(3)}, s));
  // hover crosshair
  const cross = el('line', {y1:T, y2:H - B, style:'stroke:var(--ink-2);opacity:0', 'stroke-width':1}, s);
  const hit = el('rect', {x:L, y:T, width:W - L - R, height:H - T - B, class:'hit'}, s);
  hit.addEventListener('pointermove', e => { const bx = s.getBoundingClientRect(), x = (e.clientX - bx.left) / bx.width * W, t = t0 + (x - L) / (W - L - R) * (t1 - t0), p = at(t);
    cross.setAttribute('x1', x); cross.setAttribute('x2', x); cross.style.opacity = .5;
    showTip('threshold ' + t.toFixed(2) + ' · G-mean ' + p.g.toFixed(3) + ' · F1 ' + p.f1.toFixed(3) + ' · TPR ' + p.tpr.toFixed(2) + ' · TNR ' + p.tnr.toFixed(2) + ' · precision ' + p.prec.toFixed(2), e.clientX, e.clientY); e.stopPropagation(); });
  hit.addEventListener('pointerleave', () => { cross.style.opacity = 0; tip.classList.remove('on'); });
  const box = (title, p) => '<div class="box"><b>' + title + '</b><div class="kv"><span>threshold</span><b>' + p.t.toFixed(2) + '</b><span>TPR / TNR</span><b>' + p.tpr.toFixed(2) + ' / ' + p.tnr.toFixed(2) +
    '</b><span>precision</span><b>' + p.prec.toFixed(2) + '</b><span>G-mean</span><b>' + p.g.toFixed(3) + '</b><span>F1</span><b>' + p.f1.toFixed(3) + '</b></div></div>';
  document.getElementById('th-out').innerHTML = box('ไม่ resample (threshold ที่ accuracy สูงสุด)', tr) + box('resample 1:1 (threshold = d′/2)', tb) + box('F1 สูงสุด', fb);
}

function init(){
  ['cd-m','cd-c'].forEach(i => document.getElementById(i).addEventListener('change', drawCD)); drawCD();
  ['sc-a','sc-m','sc-c'].forEach(i => document.getElementById(i).addEventListener('change', drawSC)); drawSC();
  ['th-ir','th-d'].forEach(i => document.getElementById(i).addEventListener('input', drawTH)); drawTH();
  let rw = innerWidth; addEventListener('resize', () => { if (Math.abs(innerWidth - rw) < 40) return; rw = innerWidth; drawCD(); drawSC(); drawTH(); });
}
init();
})();
