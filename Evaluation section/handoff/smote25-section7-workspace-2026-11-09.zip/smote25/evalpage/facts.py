"""Facts for the SMOTE25 'my part' evaluation page. Corpus numbers from data.json / v2/analysis.json,
Method-section family membership (37) and class categories hard-coded from SMOTE25_Method_Map_1.html (commit ea1eaa8)."""
import json, collections, statistics as st
R = '/home/claude/smote25/'
D = json.load(open(R + 'data.json')); BY = {p['key']: p for p in D}
E = [p for p in D if p['empirical']]
AN = json.load(open(R + 'v2/analysis.json'))
ERA = ['≤2009', '2010-2015', '2016-2020', '2021-2026']
C = collections.Counter
FAMILY37 = {  # our key -> (Method uid, class category B/M/BM, smote_rel)
 'SMOTE-2002':('P06','B','Core'),'SMOTEBoost-2003':('P07','BM','Core'),'SMOTE-ENN-Tomek-2004':('P08','B','Core'),
 'Borderline-SMOTE-2005':('P09','B','Core'),'Cluster-SMOTE-2006':('P10','B','Core'),'ADASYN-2008':('P12','B','Core'),
 'LS-2008':('P13','B','Core'),'Safe-Level-SMOTE-2009':('P15','B','Core'),'RAMOBoost-2010':('P18','B','Core'),
 'DSRBF-2011':('P21','BM','Core'),'INOS-2013':('P22','B','Partial'),'MWMOTE-2014':('P24','B','Core'),
 'RBBoost-2015':('P26','B','Core'),'SCUT-2015':('P27','M','Core'),'SMOTE-IPF-2015':('P28','B','Core'),
 'A-SUWO-2016':('P30','B','Core'),'CGMOS-2016':('P31','B','Core'),'SMOM-2017':('P33','M','Core'),
 'KMeansSMOTE-2018':('P35','B','Core'),'G-SMOTE-2019':('P39','B','Core'),'GAMO-2019':('P40','BM','Core'),
 'AB-SMOTE-2020':('P43','B','Core'),'EMDO-2021':('P50','M','Partial'),'HDE-2021':('P51','B','Core'),
 'RSMOTE-2021':('P52','BM','Core'),'FW-SMOTE-2022':('P55','B','Core'),'KNNOR-2022':('P57','B','Core'),
 'SVDDWSMOTE-2022':('P61','B','Core'),'GLOS-2023':('P62','M','Partial'),'NROMM-2023':('P63','BM','Core'),
 'OREM-2023':('P64','BM','Core'),'MC-MBRC-2024':('P66','BM','Core'),'MKC-SMOTE-2024':('P67','M','Core'),
 'GDHS-2025':('P68','BM','Core'),'CISO-2025':('P72','B','Core'),'Loyalty-SMOTE-2026':('P74','B','Core'),
 'QC-SMOTE-2026':('P75','B','Core')}
assert len(FAMILY37) == 37 and all(BY[k]['empirical'] for k in FAMILY37)
assert C(v[1] for v in FAMILY37.values()) == C({'B': 24, 'M': 5, 'BM': 8})
NONMEAS = {'Runtime', 'Fidelity/likelihood', 'Other', 'Confusion matrix', 'ROC curve'}
FAM = {'Accuracy/Error':'overall','Precision':'single','Recall/TPR':'single','Specificity/TNR':'single','FPR':'single',
 'F1':'comp','F-measure':'comp','G-mean':'comp','G-score (P,R)':'comp','Balanced accuracy':'comp','MCC':'comp','Kappa':'comp',
 'AUC':'rank','AUPRC':'rank','MAUC':'rank','AUCm':'rank',
 'Macro-F1':'multi','Weighted-F1':'multi','AvAcc':'multi','Macro-precision':'multi','Macro-recall':'multi','Min-sensitivity':'multi',
 'Pmin':'multi','Per-class recall':'multi','CBA':'multi','CEN':'multi','Cost':'cost'}
F = {}

def era_tab(group, field, norm=lambda x: x):
    cnt = {e: C() for e in ERA}; n = C(p['era'] for p in group)
    for p in group:
        for v in {norm(x) for x in (p.get(field) or [])}: cnt[p['era']][v] += 1
    labs = sorted({v for e in ERA for v in cnt[e]}, key=lambda v: -sum(cnt[e][v] for e in ERA))
    return {'n': {e: n[e] for e in ERA}, 'rows': [{'label': v, 'tot': sum(cnt[e][v] for e in ERA), 'c': [cnt[e][v] for e in ERA]} for v in labs]}

for name, grp in [('all', E), ('fam37', [BY[k] for k in FAMILY37])]:
    F['clf_' + name] = era_tab(grp, 'clf_families')
    F['met_' + name] = era_tab(grp, 'metrics_n')
    per = {}
    for e in ERA:
        g = [p for p in grp if p['era'] == e]
        nm = [len([m for m in p['metrics_n'] if m not in NONMEAS]) for p in g]
        nc = [len(p['clf_families']) for p in g]
        nci = [p.get('n_clf') or len(p['classifiers'] or []) for p in g]
        per[e] = dict(n=len(g), med_meas=st.median(nm), med_fam=st.median(nc), med_clf=st.median(nci),
                      distinct_meas=len({m for p in g for m in p['metrics_n'] if m not in NONMEAS}),
                      distinct_fam=len({c for p in g for c in p['clf_families']}),
                      distinct_clf_names=len({c for p in g for c in (p['classifiers'] or [])}))
    F['per_' + name] = per
s = BY['SMOTE-2002']
F['smote2002'] = dict(classifiers=s['classifiers'], fams=s['clf_families'], metrics=s['metrics'], metrics_n=s['metrics_n'], reporting=s['reporting'], protocol=s['protocol'], n_datasets=s['n_datasets'])
# measures in the 5 families
allm = C(m for p in E for m in set(p['metrics_n']))
F['measures'] = {m: dict(n=allm[m], fam=FAM.get(m)) for m in allm}
F['n_measures'] = len([m for m in allm if m not in NONMEAS])
F['fam_counts'] = {f: dict(labels=[m for m in allm if FAM.get(m) == f and m not in NONMEAS], studies=sum(1 for p in E if any(FAM.get(m) == f for m in p['metrics_n'])))
                   for f in ['overall', 'single', 'comp', 'rank', 'multi', 'cost']}
F['n_meas_per_study'] = dict(C(len([m for m in p['metrics_n'] if m not in NONMEAS]) for p in E))
F['median_meas_per_study'] = st.median(len([m for m in p['metrics_n'] if m not in NONMEAS]) for p in E)
# by class category (37) and by our setting (71)
def topmet(grp, k=8):
    c = C(m for p in grp for m in set(p['metrics_n']) if m not in NONMEAS)
    return [(m, c[m]) for m, _ in c.most_common(k)]
F['cat37'] = {cat: dict(n=sum(1 for v in FAMILY37.values() if v[1] == cat), top=topmet([BY[k] for k, v in FAMILY37.items() if v[1] == cat]),
                         fams=C(FAM.get(m) for k, v in FAMILY37.items() if v[1] == cat for m in set(BY[k]['metrics_n']) if m not in NONMEAS)) for cat in ['B', 'M', 'BM']}
F['setting71'] = {s_: dict(n=sum(1 for p in E if p['setting'] == s_), top=topmet([p for p in E if p['setting'] == s_])) for s_ in ['binary', 'multiclass', 'both']}
# G-mean users: reasons
gm = [p for p in E if 'G-mean' in p['metrics_n']]; ng = [p for p in E if 'G-mean' not in p['metrics_n']]
def reasons(g):
    c = C(r for p in g for r in set(p['r2'].get('measure_reasons') or []))
    return {r: c[r] for r in c}
F['gm'] = dict(n=len(gm), n_non=len(ng), reasons=reasons(gm), reasons_non=reasons(ng),
               stated=sum(1 for p in gm if p['r2'].get('measure_stated')), stated_non=sum(1 for p in ng if p['r2'].get('measure_stated')),
               setting=dict(C(p['setting'] for p in gm)), first=sorted((p['year'], p['key']) for p in gm)[:6],
               with_f1=sum(1 for p in gm if {'F1', 'F-measure'} & set(p['metrics_n'])), with_auc=sum(1 for p in gm if 'AUC' in p['metrics_n']),
               only_gm_composite=sum(1 for p in gm if not ({'F1', 'F-measure', 'MCC', 'Balanced accuracy'} & set(p['metrics_n']))),
               primary=sum(1 for p in E if (p.get('primary_metric') or '').lower().find('g-mean') >= 0 or (p.get('primary_metric') or '').lower().find('gmean') >= 0),
               ms_crit_gm=sum(1 for p in E if any('g-mean' in (c or '').lower() for c in (p['r2'].get('ms_criterion') or []))))
F['gm_keys'] = [p['key'] for p in gm]
mc = C(c for p in E for c in set(p['r2'].get('measure_cites') or []))
F['measure_cites_top'] = mc.most_common(30)
F['kubat_cite'] = [p['key'] for p in E if any('Kubat' in c for c in (p['r2'].get('measure_cites') or []))]
F['gm_quotes'] = [(p['key'], p['short'], p['year'], p['r2'].get('measure_quote'), p['r2'].get('measure_where'), p['r2'].get('measure_reasons')) for p in gm if p['r2'].get('measure_quote')]
F['primary'] = C((p.get('primary_metric') or 'none') for p in E).most_common(15)
# reporting and beyond
F['reporting'] = C(r for p in E for r in set(p['reporting'] or [])).most_common()
F['reporting_era'] = era_tab(E, 'reporting')
F['beyond'] = {k: sum(1 for p in E if p.get('beyond_' + k)) for k in ['direct', 'visual', 'analytic', 'model', 'none']}
F['beyond_kinds'] = C(k for p in E for k in set(p['r2'].get('beyond_kinds') or [])).most_common()
F['direct'] = [(p['key'], p['short'], p['year'], p.get('cites'), p['r2'].get('beyond_kinds'), p['r2'].get('beyond_details'), p['r2'].get('beyond_where')) for p in E if p.get('beyond_direct')]
F['model'] = [(p['key'], p['short'], p['year'], p['r2'].get('beyond_details')) for p in E if p.get('beyond_model')]
F['data_type'] = dict(C(p['data_type'] for p in E)); F['setting'] = dict(C(p['setting'] for p in E)); F['approach'] = dict(C(p['approach'] for p in E))
F['roadmap'] = {r['label']: r for r in AN['roadmap']}
F['era_n'] = AN['era_n']
json.dump(F, open('facts.json', 'w'), ensure_ascii=False, indent=1, default=str)
if __name__ == '__main__':
    for k in ['per_all', 'per_fam37', 'smote2002', 'n_measures', 'fam_counts', 'median_meas_per_study', 'cat37', 'setting71', 'gm', 'kubat_cite', 'primary', 'beyond', 'measure_cites_top']:
        print(k, json.dumps(F[k], ensure_ascii=False, default=str)[:1500])
    for name in ['clf_fam37', 'met_fam37']:
        print(name, F[name]['n']); [print('  ', r['label'], r['tot'], r['c']) for r in F[name]['rows']]
