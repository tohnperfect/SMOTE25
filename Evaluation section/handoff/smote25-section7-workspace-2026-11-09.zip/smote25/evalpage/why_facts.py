"""Evidence for the cause-and-effect notes on every row of the Q1 era tables."""
import json, re, collections, statistics as st
R = '/home/claude/smote25/'
D = json.load(open(R + 'data.json')); E = [p for p in D if p['empirical']]
C = collections.Counter
ERA = ['≤2009', '2010-2015', '2016-2020', '2021-2026']
RX = {'py': r'scikit|sklearn|python|imbalanced-learn|imblearn|smote_variants|smote-variants|pytorch|tensorflow|keras',
      'weka': r'\bweka\b|\bJ48\b|\bJ4\.8\b|\bIBk\b|\bSMO\b|\bJRip\b',
      'keel': r'KEEL (software|tool|platform)|KEEL default|implemented in KEEL|KEEL implementation|run in KEEL',
      'matlab': r'matlab'}
WEAK_PY = {'MLOS-2025', 'GOIO-2025', 'DGOT-2026', 'KMeansSMOTE-2018'}  # only datasets/generators from the Python ecosystem
TOOL = {}
for p in E:
    t = json.dumps({k: v for k, v in p.items() if k not in ('title', 'authors', 'venue')}, ensure_ascii=False)
    TOOL[p['key']] = {k: bool(re.search(rx, t, re.I)) for k, rx in RX.items()}
LINE = {'MC-CCR-2020', 'MC-RBO-2020', 'NROMM-2023', 'MC-MBRC-2024', 'MC-NCLWO-2025', 'GLOS-2023'}  # share AvAcc/CBA/CEN with MC-CCR
def ev(users):
    n = len(users)
    return dict(n=n, era=[sum(1 for p in users if p['era'] == e) for e in ERA], code=sum(1 for p in users if p['has_code']),
                py=sum(1 for p in users if TOOL[p['key']]['py']), weka=sum(1 for p in users if TOOL[p['key']]['weka']),
                keel_sw=sum(1 for p in users if TOOL[p['key']]['keel']), matlab=sum(1 for p in users if TOOL[p['key']]['matlab']),
                keel_data=sum(1 for p in users if p['uses_keel']), multi=sum(1 for p in users if p['setting'] in ('multiclass', 'both')),
                line=sum(1 for p in users if p['key'] in LINE), single=sum(1 for p in users if len(p['clf_families']) == 1),
                med_ds=st.median([p['n_datasets'] for p in users if p.get('n_datasets')] or [0]),
                keys=[(p['year'], p['key']) for p in sorted(users, key=lambda x: x['year'])],
                lr=C(r for p in users for r in (p['r2'].get('learner_reasons') or [])).most_common(4),
                mr=C(r for p in users for r in (p['r2'].get('measure_reasons') or [])).most_common(4))
W = {'all': ev(E), 'clf': {}, 'met': {}}
for f in {c for p in E for c in p['clf_families']}:
    W['clf'][f] = ev([p for p in E if f in p['clf_families']])
for m in {c for p in E for c in p['metrics_n']}:
    W['met'][m] = ev([p for p in E if m in p['metrics_n']])
# toolchain by era
W['tool_era'] = {k: [sum(1 for p in E if p['era'] == e and TOOL[p['key']][k]) for e in ERA] for k in RX}
W['code_era'] = [sum(1 for p in E if p['era'] == e and p['has_code']) for e in ERA]
W['multi_era'] = [sum(1 for p in E if p['era'] == e and p['setting'] in ('multiclass', 'both')) for e in ERA]
W['img_era'] = [sum(1 for p in E if p['era'] == e and p['data_type'] == 'image') for e in ERA]
W['tool_keys'] = {k: [p['key'] for p in E if TOOL[p['key']][k]] for k in RX}
# composites absorbing single-class measures: share of single-measure users who also report a composite
def rate_among(comp, m):
    """Among studies that report a composite in `comp`, how many also report the single rate `m` separately (per era)."""
    u = [p for p in E if set(comp) & set(p['metrics_n'])]
    return [sum(1 for p in u if p['era'] == e and m in p['metrics_n']) for e in ERA], [sum(1 for p in u if p['era'] == e) for e in ERA]
W['recall_with_comp'] = rate_among(['G-mean', 'F1', 'F-measure'], 'Recall/TPR')
W['prec_with_comp'] = rate_among(['F1', 'F-measure'], 'Precision')
W['tnr_with_gm'] = rate_among(['G-mean'], 'Specificity/TNR')
W['roc_med_ds'] = st.median([p['n_datasets'] for p in E if 'ROC curve' in p['metrics_n'] and p.get('n_datasets')])
W['auc_med_ds'] = st.median([p['n_datasets'] for p in E if 'AUC' in p['metrics_n'] and 'ROC curve' not in p['metrics_n'] and p.get('n_datasets')])
W['ds_med_era'] = [st.median([p['n_datasets'] for p in E if p['era'] == e and p.get('n_datasets')]) for e in ERA]
json.dump(W, open(R + 'evalpage/why.json', 'w'), ensure_ascii=False, default=str)
if __name__ == '__main__':
    print('tool_era', W['tool_era'], 'code_era', W['code_era'], 'multi', W['multi_era'], 'img', W['img_era'])
    print('py keys', W['tool_keys']['py']); print('weka keys', W['tool_keys']['weka'])
    print('recall_with_comp', W['recall_with_comp'], 'prec', W['prec_with_comp'], 'roc ds', W['roc_med_ds'], 'auc ds', W['auc_med_ds'], 'ds era', W['ds_med_era'])
    for g in ['clf', 'met']:
        for k, v in sorted(W[g].items(), key=lambda x: -x[1]['n']):
            print(g, k, {kk: v[kk] for kk in ('n', 'era', 'code', 'py', 'weka', 'keel_sw', 'matlab', 'keel_data', 'multi', 'line', 'single', 'med_ds')}, v['lr'] if g == 'clf' else v['mr'])
            if v['n'] <= 8 or k in ('Accuracy/Error', 'Runtime'):
                print('     ', v['keys'])
