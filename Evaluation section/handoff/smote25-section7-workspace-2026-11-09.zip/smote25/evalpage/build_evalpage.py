"""SMOTE25 Section 7, Tan's part: eight questions about how SMOTE-family studies evaluate, answered from the
coded corpus (data.json, v2/analysis.json), the Method section's 37-paper SMOTE family (facts.py) and our own
experiment (exp.py). Output: a Thai page with English terms, static SVG plus a small script for the live figures."""
import json, html, math, re, collections, statistics as st
import why_cards as WC
R = '/home/claude/smote25/'
P = R + 'evalpage/'
D = json.load(open(R + 'data.json')); BY = {p['key']: p for p in D}
E = [p for p in D if p['empirical']]
AN = json.load(open(R + 'v2/analysis.json'))
F = json.load(open(P + 'facts.json'))
X = json.load(open(P + 'exp.json'))
import facts as FX
FAMILY37 = FX.FAMILY37
RM = {r['label']: r for r in AN['roadmap']}
REF = {r['key']: r for r in AN['refs']}
ERA = ['≤2009', '2010-2015', '2016-2020', '2021-2026']
ERA_TH = ['ถึง 2009', '2010–15', '2016–20', '2021–26']
EN = F['era_n']
esc = html.escape
C = collections.Counter
assert len(E) == 71
SECS, TOC = [], []
NONMEAS = FX.NONMEAS
METH = X['meth']; MEAS = X['meas']
MCOL = {'None': 'm-none', 'SMOTE': 'm1', 'MWMOTE': 'm2', 'CISO': 'm3', 'QC-SMOTE': 'm4'}
MEAS_TH = {'AUC': 'AUC', 'PR_AUC': 'PR-AUC', 'F1': 'F1', 'Gmean': 'G-mean'}
CLF_TH = {'CART': 'CART', 'kNN': 'k-NN', 'SVM': 'SVM-RBF', 'LR': 'LogReg', 'RF': 'RandomForest', 'avg': 'เฉลี่ย 5 classifier'}


def pct(a, b):
    return round(100 * a / b) if b else 0


def cites(k):
    c = BY[k].get('cites') if k in BY else REF[k]['cites']
    return f"{c:,}" if c is not None else 'n/a'


def sec(sid, num, th, en, body):
    TOC.append((sid, num, th))
    SECS.append('<section class="s" id="' + sid + '"><h2><span class="n">' + num + '</span><span>' + th + ' <span class="en">' + en + '</span></span></h2>' + body + '</section>')


def tiles(items):
    return '<div class="tiles">' + ''.join('<div class="tile"><div class="v">' + v + '</div><div class="l">' + l + '</div></div>' for v, l in items) + '</div>'


def hbars(items, of, col='c1'):
    h = '<div class="hbars">'
    for it in items:
        lab, n = it[0], it[1]
        c = it[2] if len(it) > 2 else col
        h += ('<div class="hb"><span>' + lab + '</span><span class="ht"><i style="width:' + f"{100 * n / of:.1f}" + '%;background:var(--' + c + ')"></i></span>'
              '<span class="hv">' + str(n) + '<em>/' + str(of) + '</em></span></div>')
    return h + '</div>'


def sentence(txt):
    return '<div class="sent"><div class="sl">ประโยคสำหรับ paper (Section 7)</div><p lang="en">' + txt + '</p></div>'


def status(c, n):
    sh = [pct(c[i], n[ERA[i]]) for i in range(4)]
    return sh


def slug(x):
    return re.sub(r'[^a-z0-9]+', '-', x.lower()).strip('-')


def chip_for(label_first_year, c, sh):
    if c[3] == 0:
        return '<span class="tchip t-gone">หายไป</span>'
    if label_first_year >= 2016:
        return '<span class="tchip t-new">ใหม่</span>'
    if sh[3] - sh[0] >= 15:
        return '<span class="tchip t-up">เพิ่มขึ้น</span>'
    if sh[0] - sh[3] >= 15:
        return '<span class="tchip t-down">ลดลง</span>'
    return '<span class="tchip t-flat">ทรงตัว</span>'


FIRST = {}
for p in sorted(E, key=lambda x: x['year']):
    for m in p['metrics_n']:
        FIRST.setdefault('M:' + m, (p['year'], p['key']))
    for c in p['clf_families']:
        FIRST.setdefault('C:' + c, (p['year'], p['key']))


def era_table(kind, rows, labels_th, smote02, groups=None):
    """rows from facts era_tab; kind 'C' or 'M'"""
    n = EN
    h = ('<div class="scroll"><table class="t era"><thead><tr><th>' + ('กลุ่ม classifier' if kind == 'C' else 'measure') + '</th><th class="r">รวม</th>' +
         ''.join('<th class="c">' + ERA_TH[i] + '<div class="sub">' + str(n[e]) + ' งาน</div></th>' for i, e in enumerate(ERA)) +
         '<th class="r">ปีแรก</th><th>สถานะ</th></tr></thead><tbody>')
    bylab = {r['label']: r for r in rows}

    def one(lab):
        r = bylab[lab]
        sh = status(r['c'], n)
        fy = FIRST[kind + ':' + lab][0]
        return ('<tr><td>' + labels_th.get(lab, esc(lab)) + ('<span class="y02">SMOTE 2002</span>' if lab in smote02 else '') + '</td><td class="r"><b>' + str(r['tot']) + '</b>/71</td>' +
                ''.join('<td class="c"><span class="cell" data-tip="' + ERA_TH[i] + ': ' + str(r['c'][i]) + ' จาก ' + str(n[ERA[i]]) + ' งาน"><i style="width:' + str(sh[i]) + '%"></i><span>' + str(sh[i]) + '%</span></span></td>' for i in range(4)) +
                '<td class="r">' + str(fy) + '</td><td><a class="tlink" href="#why-' + kind + '-' + slug(lab) + '" title="ดูเหตุและผล">' + chip_for(fy, r['c'], sh) + '</a></td></tr>')
    if groups:
        for gname, labs in groups:
            labs = [l for l in labs if l in bylab]
            if not labs:
                continue
            h += '<tr class="grp"><td colspan="8">' + gname + '</td></tr>' + ''.join(one(l) for l in sorted(labs, key=lambda l: -bylab[l]['tot']))
    else:
        h += ''.join(one(r['label']) for r in rows)
    return h + '</tbody></table></div>'


# ---------------------------------------------------------------- section 0: short answers
def s0():
    a = []
    S = F['per_all']['2021-2026']
    a.append(('q1', 'Q1 · SMOTE 2002 กับวันนี้', 'SMOTE 2002 ใช้ <b>3 classifier</b> (C4.5, Ripper, Naive Bayes) และวัด <b>3 ค่า</b> (AUC, TPR, TNR) กับ ROC curve. งานปี 2021–26 จำนวน 24 เรื่อง ใช้ classifier <b>' + str(S['distinct_fam']) + ' กลุ่ม</b> และ measure <b>' + str(S['distinct_meas']) + ' ตัว</b> แต่<b>แต่ละงานยังใช้ราว 3 กับ 3 เท่าเดิม</b>. ที่หายไปคือ rule learner, ROC curve ล้วน, TNR แยก; ที่เพิ่มคือ G-mean, CART/SVM/LR/RF/GB และ measure หลายคลาส. <b>เหตุหลัก</b>: เครื่องมือเปลี่ยนจาก Weka/KEEL เป็น Python/scikit-learn และค่าเดี่ยวถูกรวมเข้า G-mean/F1 (ทุกแถวมีคำอธิบาย)'))
    a.append(('q2', 'Q2 · วัดตรงโดยไม่ผ่าน classifier', '<b>6 จาก 71</b> งานวัดข้อมูลที่ resample แล้วโดยตรง (ระยะห่างของการแจกแจง, จำนวน noise, ชนิดตัวอย่าง, ระดับความยาก, certificate). <b>ไม่มีงานไหน</b>ใช้การวัดตรงแทน classifier. ที่พบบ่อยกว่าคือรูป 2 มิติ (33) และวิเคราะห์ความซับซ้อนหรือทฤษฎี (31)'))
    a.append(('q3', 'Q3 · ตารางและกราฟ', 'ตารางรายชุดข้อมูล <b>58</b> งาน, ตัวหนาตัวที่ดีสุด <b>42</b>, ตาราง rank <b>38</b> แต่ CD diagram แค่ <b>4</b>. ควรมี ตาราง mean ± SD พร้อมแถว rank, W/T/L และ Holm p; CD diagram ราย measure; heatmap ของ rank; scatter รายชุดข้อมูลเทียบ baseline; กราฟผลต่างเทียบ IR. ตัวอย่างจริงจากผลทดลองของเราอยู่ในหัวข้อนี้'))
    a.append(('q4', 'Q4 · downstream classification กี่ตัว กี่หมวด', '<b>' + str(F['n_measures']) + ' measures</b> ใน <b>5 หมวด</b>: overall 1, single-class 4, composite 7, ranking 4, multi-class 10 (และ cost อีก 1). งานหนึ่งใช้ค่ากลาง <b>' + str(int(F['median_meas_per_study'])) + ' ตัว</b>'))
    a.append(('q5', 'Q5 · ตัวไหนใช้มากสุด ทำไม', '<b>G-mean</b> 41/71 งาน (ช่วง 2021–26 ถึง 71%) เพราะ<b>วัดสิ่งที่ resampling เปลี่ยนจริง</b> คือสมดุล TPR กับ TNR, ไม่ขึ้นกับสัดส่วนคลาส, ใช้ได้กับ classifier ที่ให้แค่ label และขยายเป็นหลายคลาสได้. ผลของเรายืนยัน: SMOTE ชนะ None ด้วย G-mean <b>78%</b> ของกรณี แต่ด้วย AUC แค่ 46%'))
    a.append(('q6', 'Q6 · ทำไมวิธีวัดผลเปลี่ยน', 'เปลี่ยนเมื่อมี<b>ของที่ทำให้ทำได้ง่ายและถูกคาดหวัง</b>: Demšar 2006 → Friedman/Wilcoxon, KEEL → ข้อมูลหลายสิบชุดและ 5-fold, โจทย์หลายคลาส → MAUC/MG/CBA, scikit-learn/imbalanced-learn → RF/GB และการแจก code. งานดังอย่างเดียวไม่พอ: Saito 2015 (5,156 cites) แต่ PR-AUC ยังราว 8%'))
    a.append(('q7', 'Q7 · มี task อื่นไหม', '<b>ทั้ง 71 งานวัดผลด้วย classification</b>. ที่ต่างคือชนิดข้อมูล (ตาราง 65, ผสม 3, ภาพ 2, อนุกรมเวลา 1) และจำนวนคลาส. ออกนอก classification มีแค่ CTGAN (regression 1 ชุด และ likelihood) กับ GAMO (FID ของภาพ). ไม่มี clustering, anomaly detection, regression หลัก หรือ multi-label'))
    a.append(('q8', 'Q8 · G-mean ต่างจาก F1', 'ใช้ TPR เหมือนกัน ต่างที่อีกตัว: G-mean ใช้ <b>TNR</b> ส่วน F1 ใช้ <b>precision</b> ซึ่งขึ้นกับสัดส่วนคลาส. classifier เดิม (TPR 0.8, FPR 0.1) ที่ IR 1, 10, 100 ได้ G-mean 0.85 เท่าเดิม แต่ F1 0.84 → 0.57 → 0.14. ในผลของเรา 2 ตัวนี้เลือกวิธีที่ดีที่สุดตรงกัน <b>' + str(X['best_agree']['same']) + '/' + str(X['best_agree']['n']) + '</b> กรณี'))
    body = '<p>คำตอบสั้นของทั้ง 8 คำถาม กดที่การ์ดเพื่อไปยังคำอธิบายพร้อมหลักฐาน</p><div class="ans">' + ''.join(
        '<a href="#' + i + '"><span class="q">' + q + '</span><span class="a">' + t + '</span></a>' for i, q, t in a) + '</div>'
    body += ('<div class="box key"><b>อ่านตัวเลขอย่างไร</b><p>"งาน" คือ paper ที่มีการทดลอง 71 เรื่องจาก 76 เรื่องในรายชื่อเดียวกับส่วน Method และ Data. "ตระกูล SMOTE 37 เรื่อง" คือรายชื่อของส่วน Method (Core 34 + Partial 3) '
             'แบ่งเป็น Binary only 24, Multiclass only 5, Binary + Multiclass 8. ช่วงปีมี 4 ช่วง: ถึง 2009 (14 งาน), 2010–15 (13), 2016–20 (20), 2021–26 (24). ยอดอ้างอิงจาก OpenAlex ณ 18 ต.ค. 2026</p></div>')
    sec('q0', '0', 'คำตอบสั้น', 'Short answers', body)


# ---------------------------------------------------------------- Q1
CLF_TH_LAB = {'C4.5/C5.0': 'C4.5 / C5.0', 'Rule learner': 'Rule learner (RIPPER ฯลฯ)', 'CART/DT': 'CART / decision tree', 'MLP/NN': 'MLP / neural net',
              'Boosting ensemble': 'Boosting ensemble (AdaBoost ฯลฯ)', 'Gradient boosting': 'Gradient boosting (GBM, XGBoost, CatBoost)', 'Other': 'อื่น ๆ'}
MEAS_LAB = {'Accuracy/Error': 'Accuracy / error rate', 'Recall/TPR': 'Recall / TPR / sensitivity', 'Specificity/TNR': 'Specificity / TNR', 'FPR': 'FPR',
            'F1': 'F1', 'F-measure': 'F-measure (F-beta หรือไม่ระบุ beta)', 'G-score (P,R)': 'G-score จาก precision กับ recall', 'Balanced accuracy': 'Balanced accuracy',
            'AUPRC': 'PR-AUC / AUPRC', 'MAUC': 'MAUC (Hand & Till)', 'AUCm': 'AUCm', 'AvAcc': 'AvAcc (average accuracy)', 'CBA': 'CBA (class balance accuracy)',
            'CEN': 'CEN (confusion entropy)', 'Pmin': 'Pmin (precision ของคลาสเล็กสุด)', 'Min-sensitivity': 'Minimum sensitivity', 'Per-class recall': 'Recall รายคลาส',
            'Cost': 'Misclassification cost', 'ROC curve': 'ROC curve (รูป)', 'Confusion matrix': 'Confusion matrix (ตาราง)', 'Runtime': 'Runtime', 'Fidelity/likelihood': 'Fidelity / likelihood ของข้อมูลสังเคราะห์', 'Other': 'อื่น ๆ (เช่น tree size)'}
SHORT = {'Recall/TPR': 'Recall', 'Accuracy/Error': 'Accuracy', 'Per-class recall': 'Recall รายคลาส', 'F-measure': 'F-measure', 'Specificity/TNR': 'TNR', 'Macro-precision': 'Macro-precision'}
GROUPS = [('Overall: วัดรวมทุกคลาส', ['Accuracy/Error']),
          ('Single-class: วัดทีละคลาส', ['Recall/TPR', 'Specificity/TNR', 'Precision', 'FPR']),
          ('Composite: รวมหลายค่าเป็นค่าเดียว ที่ threshold หนึ่ง', ['G-mean', 'F1', 'F-measure', 'MCC', 'Balanced accuracy', 'Kappa', 'G-score (P,R)']),
          ('Ranking: ไม่ขึ้นกับ threshold', ['AUC', 'AUPRC', 'MAUC', 'AUCm']),
          ('Multi-class: รวมผลของหลายคลาส', ['Macro-F1', 'AvAcc', 'CBA', 'CEN', 'Macro-precision', 'Per-class recall', 'Weighted-F1', 'Macro-recall', 'Min-sensitivity', 'Pmin']),
          ('Cost', ['Cost']),
          ('ไม่ใช่ measure ค่าเดียว (ไม่นับใน 27)', ['ROC curve', 'Runtime', 'Confusion matrix', 'Fidelity/likelihood', 'Other'])]


def why_cards(kind, rows, content, labels):
    n = EN
    groups = {k: [] for k, _ in WC.STATUS_ORDER}
    for r in rows:
        lab = r['label']; sh = status(r['c'], n); fy = FIRST[kind + ':' + lab][0]
        groups[WC.status_key(fy, r['c'][3], sh)].append((lab, r, sh, fy))
    h = ''
    for k, title in WC.STATUS_ORDER:
        if not groups[k]:
            continue
        h += '<h4 class="wg">' + title + ' <span class="sub">' + str(len(groups[k])) + ' แถว</span></h4><div class="whys">'
        for lab, r, sh, fy in sorted(groups[k], key=lambda x: -x[1]['tot']):
            ct = content[lab]
            tags = ''.join('<span class="dtag" data-tip="' + WC.DRV[d][1] + '">' + d + ' · ' + WC.DRV[d][0] + '</span>' for d in ct['drv'])
            cf = WC.CONF[ct['conf']]
            h += ('<div class="why" id="why-' + kind + '-' + slug(lab) + '"><div class="wh"><b>' + labels.get(lab, esc(lab)) + '</b>' + chip_for(fy, r['c'], sh) +
                  '<span class="wsh">' + ' → '.join(str(v) + '%' for v in sh) + '</span></div>'
                  '<p><span class="wl">เหตุ → ผล</span> ' + ct['cause'] + '</p><div class="wl">หลักฐาน</div><ul>' + ''.join('<li>' + e + '</li>' for e in ct['ev']) + '</ul>'
                  '<div class="tags">' + tags + '<span class="st2 ' + cf[1] + '">' + cf[0] + '</span></div></div>')
        h += '</div>'
    return h


def why_section():
    W = WC.W; T = W['tool_era']; CO = W['code_era']; MU = W['multi_era']; DSm = W['ds_med_era']; rc = W['recall_with_comp']
    h = ('<h3 id="why">เหตุและผลรายแถว <span class="en">Why each row went up, down or away</span></h3>'
         '<p>ทุกแถวในสองตารางข้างบนมีคำอธิบายด้านล่าง (กดป้ายสถานะในตารางเพื่อกระโดดมาที่แถวนั้น). เหตุส่วนใหญ่มาจากตัวขับ 6 ตัว ซึ่งมีหลักฐานจากข้อมูลดังนี้</p>'
         '<div class="scroll"><table class="t drv"><thead><tr><th>ตัวขับ</th><th>หลักฐานตามช่วงปี (ถึง 2009 → 2010–15 → 2016–20 → 2021–26)</th><th>อธิบายแถวไหน</th></tr></thead><tbody>'
         '<tr><td><span class="dtag">T</span> เครื่องมือเปลี่ยน</td><td>งานที่ระบุว่าใช้ Python/scikit-learn ' + ' → '.join(map(str, T['py'])) + ' งาน; ระบุ Weka ' + ' → '.join(map(str, T['weka'])) + ' งาน; แจก code ' + ' → '.join(map(str, CO)) + ' งาน</td>'
         '<td>C4.5 ลง, CART ขึ้น, rule learner หาย, LR, RF, gradient boosting ขึ้น, MCC</td></tr>'
         '<tr><td><span class="dtag">A</span> ถูกรวมเข้าตัวอื่น</td><td>งานที่ใช้ G-mean หรือ F1 แล้วรายงาน recall แยก ' + ' → '.join(str(rc[0][i]) + '/' + str(rc[1][i]) for i in range(4)) + '; ผู้ใช้ G-mean ที่รายงาน TNR แยก 2/4 → 0/17</td>'
         '<td>recall, precision, TNR ลดหรือหาย; G-mean ขึ้น</td></tr>'
         '<tr><td><span class="dtag">S</span> การทดลองใหญ่ขึ้น</td><td>ค่ากลางจำนวนชุดข้อมูลต่องาน ' + ' → '.join(f"{v:g}" for v in DSm) + ' ชุด</td><td>ROC curve และ confusion matrix หาย, runtime ขึ้น</td></tr>'
         '<tr><td><span class="dtag">P</span> โจทย์หรือข้อมูลเปลี่ยน</td><td>งานหลายคลาส ' + ' → '.join(map(str, MU)) + ' งาน; งานข้อมูลภาพ 0 → 0 → 2 → 0; งาน generative เริ่มปี 2019 (5 งาน)</td><td>MAUC, macro-F1 ขึ้น, CNN หาย, accuracy เหลืออยู่ในงาน generative</td></tr>'
         '<tr><td><span class="dtag">L</span> สายงานทำตามกัน</td><td>11 งานเขียนว่าเลือก learner ตามงานก่อน; สาย MC-CCR 6 งาน (2020–25) ใช้ชุด AvAcc, CBA, CEN ร่วมกัน</td><td>CBA, CEN, AvAcc, MLP, C4.5 ที่ยังเหลือ</td></tr>'
         '<tr><td><span class="dtag">R</span> ความสมจริงหรือข้อวิจารณ์</td><td>RF/GB 7% → 33%; ข้อวิจารณ์ต่อ accuracy และ F1 (Boughorbel 2017 อ้าง 3 งาน)</td><td>RF, gradient boosting, MCC, ความทรงตัวของ F1</td></tr>'
         '</tbody></table></div>'
         '<p class="note">ระดับความมั่นใจ: <span class="st2 s-ok">หลักฐานตรง</span> = paper เขียนเหตุผลไว้เอง หรือวัดความเชื่อมโยงได้ตรงจากข้อมูล; <span class="st2 s-note">หลักฐานแวดล้อม</span> = เวลาและความสัมพันธ์ไปทางเดียวกัน แต่ไม่มีใครเขียนยืนยัน; '
         '<span class="st2 s-warn">ข้อสันนิษฐาน</span> = เหตุผลเชิงกลไกของเรา ยังไม่มีข้อมูลยืนยัน. การระบุเครื่องมือนับจากที่ paper เขียนไว้เท่านั้น (งานที่ไม่ได้เขียนนับเป็น "ไม่ระบุ") ตัวเลขจริงจึงอาจสูงกว่านี้</p>')
    h += '<h3>classifier: เหตุและผล <span class="en">Learner families</span></h3>' + why_cards('C', F['clf_all']['rows'], WC.CLF, CLF_TH_LAB)
    h += '<h3>measure: เหตุและผล <span class="en">Measures</span></h3>' + why_cards('M', F['met_all']['rows'], WC.MET, MEAS_LAB)
    return h


def q1():
    s = F['smote2002']; A = F['per_all']; S4 = A['2021-2026']
    era4 = [p for p in E if p['era'] == '2021-2026']
    sets = C(tuple(sorted(m for m in p['metrics_n'] if m not in NONMEAS)) for p in era4)
    cset = C(tuple(sorted(p['clf_families'])) for p in era4)
    still = {lab: (r['c'][3], EN['2021-2026']) for r in F['met_all']['rows'] + F['clf_all']['rows'] for lab in [r['label']]}
    body = ('<p>คำถาม: ตอน SMOTE ออกมาครั้งแรก (Chawla et al. 2002, ' + cites('SMOTE-2002') + ' cites) ใช้ classifier และ measure กี่ตัว วันนี้เหลือกี่ตัว อะไรเพิ่ม อะไรหาย '
            'เราเทียบ SMOTE 2002 กับงานช่วงล่าสุด 2021–26 (24 งาน) และดูทั้ง 71 งานเป็นช่วงปี</p>')
    body += ('<div class="vs"><div class="vcard then"><h3>SMOTE 2002</h3><dl>'
             '<dt>classifier</dt><dd><b>3 ตัว</b>: C4.5, Ripper (rule learner), Naive Bayes</dd>'
             '<dt>measure</dt><dd><b>3 ค่า</b>: AUC, TPR (%TP หรือ Acc+) และ TNR (Acc- หรือ 1 − %FP)<div class="sub">ไม่มี accuracy (paper แย้งว่าใช้ไม่ได้กับข้อมูลไม่สมดุล), ไม่มี G-mean, ไม่มี F1</div></dd>'
             '<dt>รูปและอื่น ๆ</dt><dd>ROC curve, ROC convex hull, ขนาดต้นไม้ C4.5, รูป decision region 2 มิติ</dd>'
             '<dt>ข้อมูลและวิธี</dt><dd>9 ชุดข้อมูล, 10-fold CV, ไม่มี statistical test</dd></dl></div>'
             '<div class="vcard now"><h3>2021–26 (24 งาน)</h3><dl>'
             '<dt>classifier</dt><dd><b>' + str(S4['distinct_fam']) + ' กลุ่ม</b> (ชื่อต่างกัน ' + str(S4['distinct_clf_names']) + ' ชื่อ) แต่ละงานใช้ค่ากลาง <b>' + f"{S4['med_fam']:g}" + '</b> กลุ่ม</dd>'
             '<dt>measure</dt><dd><b>' + str(S4['distinct_meas']) + ' ตัว</b> แต่ละงานใช้ค่ากลาง <b>' + f"{S4['med_meas']:g}" + '</b> ตัว</dd>'
             '<dt>ชุดที่เลือก</dt><dd>24 งานใช้ชุด measure ต่างกัน <b>' + str(len(sets)) + ' แบบ</b> และชุด classifier ต่างกัน <b>' + str(len(cset)) + ' แบบ</b></dd>'
             '<dt>ข้อมูลและวิธี</dt><dd>KEEL 67%, repeated CV 62%, มี test 83%</dd></dl></div></div>')
    body += tiles([('3 → ' + f"{S4['med_fam']:g}", 'classifier ต่องาน: SMOTE 2002 กับค่ากลางของ 2021–26 <b>ไม่เพิ่ม</b>'),
                   ('3 → ' + f"{S4['med_meas']:g}", 'measure ต่องาน <b>ไม่เพิ่ม</b>'),
                   (str(A['≤2009']['distinct_meas']) + ' → ' + str(S4['distinct_meas']), 'measure ที่ต่างกันทั้งช่วงปี (ถึง 2009 กับ 2021–26) <b>เพิ่มเกือบเท่าตัว</b>'),
                   (str(len(sets)) + '<small> แบบ / 24 งาน</small>', 'ชุด measure ที่ต่างกันในช่วงล่าสุด มีแค่ 3 ชุดที่ซ้ำ ผลจึง<b>เทียบข้ามงานยาก</b>')])
    body += ('<div class="box key"><b>สรุปข้อ 1</b><p>สิ่งที่เปลี่ยนไม่ใช่ "จำนวนต่องาน" แต่เป็น "ความหลากหลายระหว่างงาน". แต่ละงานยังเลือกประมาณ 3 classifier กับ 3 measure เหมือน SMOTE 2002 '
             'แต่ตัวเลือกกระจายไปทั่ว: ปี 2021–26 มี 24 งานใช้ชุด measure ' + str(len(sets)) + ' แบบ. ผลคือตัวเลขจาก paper หนึ่งเอาไปเทียบกับอีก paper ตรง ๆ ไม่ได้ '
             'ซึ่งตรงกับที่ส่วน Data พบว่าต้องตั้งกฎเลือก measure ก่อนนับ win/tie/loss. ส่วนที่ว่าแต่ละแถวขึ้น ลง หรือหายเพราะอะไร ดู<a href="#why">เหตุและผลรายแถว</a> ใต้ตาราง</p></div>')
    # what remains from 2002
    rem = [('AUC', 'AUC', 'M'), ('C4.5/C5.0', 'C4.5', 'C'), ('Naive Bayes', 'Naive Bayes', 'C'), ('Recall/TPR', 'TPR / recall', 'M'), ('Rule learner', 'Ripper (rule learner)', 'C'), ('Specificity/TNR', 'TNR รายงานแยก', 'M'), ('ROC curve', 'ROC curve', 'M')]
    body += '<h3>ของจาก SMOTE 2002 ที่ยังใช้ในปี 2021–26 <span class="en">What survived from 2002</span></h3>'
    body += hbars([(lab, still[k][0]) for k, lab, _ in rem], 24)
    body += '<p class="note">แท่ง = จำนวนงานในช่วง 2021–26 (24 งาน) ที่ยังใช้. Ripper, TNR แยก และ ROC curve ไม่มีงานใดใช้แล้ว (TNR ยังอยู่แต่ถูกรวมเข้าไปใน G-mean)</p>'
    body += '<h3>classifier ทุกกลุ่มตามช่วงปี (71 งาน) <span class="en">Learner families by era</span></h3>'
    body += era_table('C', F['clf_all']['rows'], CLF_TH_LAB, set(s['fams']))
    body += '<h3>measure ทุกตัวตามช่วงปี (71 งาน) <span class="en">Measures by era</span></h3>'
    body += era_table('M', F['met_all']['rows'], MEAS_LAB, {'AUC', 'ROC curve', 'Recall/TPR', 'Specificity/TNR', 'Other'}, GROUPS)
    body += ('<p class="note">ช่องคือร้อยละของงานในช่วงนั้นที่ใช้ (เอาเมาส์ชี้เพื่อดูจำนวนงาน). สถานะ: <b>หายไป</b> = ไม่มีงานใน 2021–26 ใช้; <b>ใหม่</b> = ปรากฏครั้งแรกตั้งแต่ 2016; '
             '<b>เพิ่มขึ้น/ลดลง</b> = ร้อยละช่วงแรกกับช่วงล่าสุดต่างกันตั้งแต่ 15 จุด; นอกนั้นทรงตัว. ป้าย SMOTE 2002 = ใช้ใน SMOTE 2002</p>')
    body += why_section()
    # added / gone lists
    gone_c = [r['label'] for r in F['clf_all']['rows'] if r['c'][3] == 0]
    gone_m = [r['label'] for r in F['met_all']['rows'] if r['c'][3] == 0]
    new_c = [r['label'] for r in F['clf_all']['rows'] if r['c'][0] == 0 and r['c'][3] > 0 and r['label'] != 'Other']
    new_m = [r['label'] for r in F['met_all']['rows'] if r['c'][0] == 0 and r['c'][3] > 0 and r['label'] not in ('Runtime', 'Other')]
    body += ('<div class="two"><div class="box"><b>อะไรเพิ่มมา (ไม่มีในช่วงถึง 2009 แต่มีใน 2021–26)</b><p>classifier: ' + ', '.join(CLF_TH_LAB.get(x, x) for x in new_c) +
             '</p><p>measure: ' + ', '.join(MEAS_LAB.get(x, x) for x in new_m) + '</p><p class="note">นอกจากนี้ที่มีอยู่แล้วแต่โตขึ้นมาก: G-mean 29% → 71%, CART 7% → 50%, SVM 21% → 54%, RF/GB 7% → 33%, MAUC 7% → 25%</p></div>'
             '<div class="box warn"><b>อะไรหายไป (มีมาก่อน แต่ไม่มีใน 2021–26)</b><p>classifier: ' + ', '.join(CLF_TH_LAB.get(x, x) for x in gone_c) +
             '</p><p>measure: ' + ', '.join(MEAS_LAB.get(x, x) for x in gone_m) + '</p><p class="note">ลดลงมาก: C4.5 64% → 21%, recall รายงานเดี่ยว 71% → 21%, accuracy 21% → 12% (ยังมี 3 งานที่ใช้). '
             't-test หายไปหลัง 2015 (ดูข้อ 6)</p></div></div>')
    # 37 family by class category
    cat = F['cat37']
    CATN = {'B': ('Binary only', 'bin'), 'M': ('Multiclass only', 'mul'), 'BM': ('Binary + Multiclass', 'both')}
    body += '<h3>ตระกูล SMOTE 37 เรื่องตามหมวดคลาสของส่วน Method <span class="en">Measures by class category</span></h3><div class="cats">'
    for k in ['B', 'M', 'BM']:
        nm, col = CATN[k]
        body += ('<div class="cat"><div class="hd"><i class="sw" style="background:var(--' + col + ')"></i>' + nm + ' <span class="sub">' + str(cat[k]['n']) + ' งาน</span></div>' +
                 hbars([(SHORT.get(m, m), c, col) for m, c in cat[k]['top'][:6]], cat[k]['n']) + '</div>')
    body += '</div>'
    body += ('<p class="note">Binary only ใช้ AUC มากสุด (18/24) ตามด้วย G-mean (14/24). พอมีหลายคลาส G-mean ในรูป MG (geometric mean ของ recall ทุกคลาส) และ MAUC ขึ้นมาแทน '
             'กลุ่ม Binary + Multiclass ใช้ measure หมวด multi-class รวม 14 ครั้งใน 8 งาน. หมวดคลาสจึงมีผลต่อการเลือก measure อย่างชัดเจน</p>')
    body += sentence('SMOTE (Chawla et al., 2002) was evaluated with three learners (C4.5, Ripper and Naive Bayes) and three quantities (AUC, TPR and TNR). Studies published in 2021 to 2026 still use a median of three learner families and three measures each, but the 24 studies draw on ' + str(S4['distinct_fam']) + ' learner families and ' + str(S4['distinct_meas']) + ' measures, and they report ' + str(len(sets)) + ' different combinations of measures; rule learners and stand-alone ROC curves have disappeared, while G-mean, CART, SVM, ensembles and multi-class aggregates have taken their place. These shifts track the move from Weka and KEEL to Python and scikit-learn, which offers CART but neither C4.5 nor rule learners (studies naming Python rose from none before 2016 to 12 of 24 since 2021), and the absorption of single-class rates into composites (studies with a composite that also report recall separately fell from 8 of 9 to 5 of 21).')
    sec('q1', 'Q1', 'SMOTE 2002 กับวันนี้: classifier และ measure', 'Then and now', body)


# ---------------------------------------------------------------- Q2
def q2():
    b = F['beyond']
    body = ('<p>คำถาม: มีงานไหนวัดผลของ resampling <b>ตรง ๆ ที่ตัวข้อมูล</b> โดยไม่ต้องฝึก classifier แล้วดูผลทำนาย และใช้วิธีอะไร. '
            'ภาพด้านล่างแสดงว่าแต่ละแบบของการวัด "แตะ" ที่จุดไหนของ pipeline</p>')
    body += ('<div class="pipe">'
             '<div class="st"><b>1. ข้อมูลฝึก</b><span class="sub">ก่อน resample</span><span class="tap vis">ลักษณะชุดข้อมูล (IR, overlap) ส่วน Data</span></div>'
             '<div class="st"><b>2. resampling</b><span class="sub">SMOTE และตระกูล</span><span class="tap vis">วิเคราะห์ความซับซ้อน หรือทฤษฎี ' + str(b['analytic']) + ' งาน</span></div>'
             '<div class="st"><b>3. ข้อมูลหลัง resample</b><span class="sub">จุดสังเคราะห์</span><span class="tap direct">วัดตรง ' + str(b['direct']) + ' งาน</span><span class="tap vis">รูป 2 มิติ ' + str(b['visual']) + ' งาน</span></div>'
             '<div class="st"><b>4. classifier</b><span class="sub">ฝึกบนข้อมูลข้อ 3</span><span class="tap mod">ตรวจตัวโมเดล ' + str(b['model']) + ' งาน (ขนาดต้นไม้, จำนวนกฎ)</span></div>'
             '<div class="st"><b>5. ผลทำนายบน test</b><span class="sub">ข้อมูลจริงที่กันไว้</span><span class="tap down">downstream measure 71 งาน</span></div>'
             '<div class="st"><b>6. สรุปเทียบวิธี</b><span class="sub">หลายชุดข้อมูล</span><span class="tap down">statistical test 52 งาน</span></div></div>')
    body += tiles([(str(b['direct']) + '<small>/71</small>', 'วัดข้อมูลหลัง resample โดยตรง (ข้อ 3)'), ('0<small>/71</small>', 'ใช้การวัดตรงแทน classifier ทั้งหมด'),
                   (str(b['visual']) + '<small>/71</small>', 'รูปจุดสังเคราะห์ 2 มิติหรือ projection'), (str(b['none']) + '<small>/71</small>', 'มีแต่ตัวเลข downstream ไม่มีหลักฐานอื่นเลย')])
    rows = [
        ('SMOTE-IPF-2015', 'จำนวน noise ที่เกิดจาก SMOTE', 'นับร้อยละของตัวอย่างที่ตัวกรอง (ENN เทียบ IPF) ลบทิ้งหลัง SMOTE แยกเป็นจุดสังเคราะห์ จุดจริงคลาสน้อย และจุดจริงคลาสใหญ่ บนข้อมูลจำลอง ข้อมูลจริง และข้อมูลจริงที่เติม noise', 'pp. 197–199, Sec. 5.4, Tables 12–13'),
        ('SPE-2020', 'ระดับความยากของตัวอย่าง', 'แบ่งตัวอย่างคลาสใหญ่ตาม hardness แล้วนับจำนวนแต่ละช่วงก่อนและหลัง under-sampling และวาดชุดข้อมูลที่ได้บน checkerboard 2 มิติ', 'p. 845 Fig. 3; p. 847 Fig. 6'),
        ('CTGAN-2019', 'ความเหมือนของการแจกแจง', 'likelihood fitness บนข้อมูลจำลองที่รู้การแจกแจงจริง: L<sub>syn</sub> (แถวสังเคราะห์น่าจะมาจากการแจกแจงจริงแค่ไหน) และ L<sub>test</sub> (ฝึกตัวแบบจากข้อมูลสังเคราะห์แล้วดู likelihood ของ test จริง)', 'p. 7 Sec. 5.2; p. 8 Table 2, Fig. 3'),
        ('GAMO-2019', 'ระยะห่างของการแจกแจง (ภาพ)', 'FID ระหว่างภาพจริงกับภาพที่สร้าง และพิสูจน์ว่า objective เท่ากับผลรวมของ Jensen-Shannon divergence', 'p. 1698 Theorem 1; p. 1702 Table 5'),
        ('GLOS-2023', 'ชนิดของตัวอย่าง', 'นับจุดคลาสน้อยที่เป็น safe, borderline, small disjunct เมื่อเปลี่ยนพารามิเตอร์ α และวาด decision region หลังแต่ละขั้นบนข้อมูล 2 มิติ', 'p. 2073 Fig. 2; p. 2079 Fig. 7'),
        ('CISO-2025', 'ระยะห่างของการแจกแจง และ certificate', 'MMD² และ AUC ของ classifier two-sample test ระหว่างจุดสังเคราะห์กับคลาสน้อยที่กันไว้, สัดส่วนจุดที่ผ่าน certificate ว่าไม่ล้ำเข้าเขตคลาสใหญ่', 'p. 22 Table 4; pp. 24–26 Figs. 3–4')]
    body += ('<h3>6 งานที่วัดตรง และสิ่งที่วัด <span class="en">Direct checks of the resampled data</span></h3><div class="scroll"><table class="t wide"><thead><tr><th>งาน</th><th class="r">cites</th><th>วัดอะไร</th><th>วัดอย่างไร</th><th>ตำแหน่งใน paper</th></tr></thead><tbody>' +
             ''.join('<tr><td><b>' + esc(BY[k]['short']) + '</b> ' + str(BY[k]['year']) + '</td><td class="r">' + cites(k) + '</td><td>' + w + '</td><td>' + h + '</td><td class="sub">' + loc + '</td></tr>' for k, w, h, loc in rows) +
             '<tr><td><b>Hassanat et al.</b> 2022<div class="sub">preprint, ไม่นับใน 71</div></td><td class="r">' + cites('StopOversampling-2022') + '</td><td>ความถูกต้องของ label จุดสังเคราะห์</td><td>ซ่อนตัวอย่างคลาสใหญ่ 10, 25 หรือ 50% แล้ว oversample ส่วนที่เหลือ จากนั้นดูว่าจุดสังเคราะห์แต่ละจุดใกล้ตัวอย่างจริงคลาสไหนมากกว่า (รวมตัวที่ซ่อนไว้) ด้วย Hassanat distance. error = สัดส่วนจุดสังเคราะห์ที่ใกล้คลาสใหญ่ ไม่ต้องใช้ classifier เลย</td><td class="sub">Sec. 3, Eq. 1–3, Fig. 2</td></tr>'
             '</tbody></table></div>')
    body += ('<div class="two"><div class="box"><b>วัดตรงแบ่งได้ 4 แบบ</b><ul class="list">'
             '<li><b>ระยะห่างของการแจกแจง</b> (CTGAN, GAMO, CISO): จุดสังเคราะห์มาจากการแจกแจงเดียวกับคลาสน้อยจริงไหม</li>'
             '<li><b>ชนิดหรือความยากของตัวอย่าง</b> (GLOS, SPE): resampling ไปเพิ่มหรือลดจุดตรงไหนของ decision boundary</li>'
             '<li><b>noise</b> (SMOTE-IPF): จุดสังเคราะห์ตกในเขตคลาสใหญ่กี่จุด</li>'
             '<li><b>certificate หรือ validity</b> (CISO, Hassanat): จุดสังเคราะห์แต่ละจุดผ่านเงื่อนไขว่าอยู่ในเขตคลาสน้อยหรือไม่</li></ul></div>'
             '<div class="box warn"><b>ทำไมยังน้อย</b><p>การวัดตรงตอบคำถามว่า "ข้อมูลสังเคราะห์ดีไหม" แต่ไม่ตอบว่า "classifier ดีขึ้นไหม" ซึ่งเป็นสิ่งที่ reviewer และผู้ใช้ถาม. '
             'ทั้ง 6 งานจึงใช้เป็นหลักฐานเสริม ไม่มีงานไหนใช้แทน. อีกเหตุคือไม่มีมาตรฐานกลาง: 6 งานใช้ 6 วิธีที่ต่างกัน และส่วนใหญ่ต้องรู้การแจกแจงจริงหรือต้องกันข้อมูลคลาสน้อยไว้ ซึ่งข้อมูลคลาสน้อยมีน้อยอยู่แล้ว</p></div></div>')
    kinds = dict(F['beyond_kinds'])
    KTH = [('toy_2d_visualization', 'รูปข้อมูล 2 มิติ (toy)'), ('complexity_analysis', 'วิเคราะห์ความซับซ้อน (big-O)'), ('theoretical_analysis', 'ทฤษฎีหรือบทพิสูจน์'),
           ('projection_visualization', 'รูป projection (PCA, t-SNE)'), ('distribution_distance', 'ระยะห่างของการแจกแจง'), ('diversity_measure', 'ความหลากหลายของ ensemble'),
           ('example_type_analysis', 'ชนิดตัวอย่าง safe/borderline'), ('privacy_or_fidelity', 'privacy หรือ fidelity'), ('noise_count', 'นับ noise')]
    body += '<h3>หลักฐานนอกเหนือจากตัวเลข downstream ทั้งหมด <span class="en">Evidence beyond scores</span></h3>' + hbars([(t, kinds.get(k, 0)) for k, t in KTH], 71)
    body += '<p class="note">หนึ่งงานมีได้หลายแบบ. ตรวจตัวโมเดล 5 งาน: SMOTE 2002 (ขนาดต้นไม้), Batista 2004 (จำนวนกฎ), Random Balance 2015 (kappa-error diagram), SOUP 2019 (จำนวน node), OREM 2023 (นับการคำนวณระยะ)</p>'
    body += sentence('Only ' + str(b['direct']) + ' of the 71 studies measure the resampled data directly (distribution distance, noise counts, example types or per-sample certificates), and none of them replaces the downstream classifier with such a measure; ' + str(b['visual']) + ' studies plot synthetic samples in two dimensions and ' + str(b['none']) + ' report nothing beyond classification scores.')
    sec('q2', 'Q2', 'วิธีที่วัดตรง ไม่ผ่าน classifier', 'Direct measures', body)


# ---------------------------------------------------------------- Q3
REP_TH = [('per-dataset table', 'ตารางผลรายชุดข้อมูล', 't'), ('best-in-bold', 'ตัวหนาค่าที่ดีสุด', 't'), ('average rank table', 'ตาราง average rank', 't'), ('p-value table', 'ตาราง p-value', 't'),
          ('line plot vs IR/parameter', 'กราฟเส้นเทียบ IR หรือพารามิเตอร์', 'f'), ('parameter sensitivity', 'ความไวต่อพารามิเตอร์', 'f'), ('scatter/2D visualization of synthetic samples', 'รูปจุดสังเคราะห์ 2 มิติ', 'f'),
          ('mean +/- std', 'mean ± SD', 't'), ('ablation study', 'ablation', 't'), ('win/tie/loss counts', 'นับ win/tie/loss', 't'), ('supplementary tables', 'ตารางในภาคผนวก', 't'),
          ('bar chart', 'กราฟแท่ง', 'f'), ('runtime table', 'ตาราง runtime', 't'), ('ROC plot', 'ROC curve', 'f'), ('box plot', 'box plot', 'f'), ('CD diagram', 'CD diagram', 'f'), ('heatmap', 'heatmap', 'f')]


def heatmap():
    per = X['per']; clfs = ['CART', 'kNN', 'SVM', 'LR', 'RF', 'avg']
    h = ('<div class="scroll"><table class="t hm"><thead><tr><th rowspan="2">วิธี</th>' + ''.join('<th class="gh" colspan="6">' + MEAS_TH[m] + '</th>' for m in MEAS) + '</tr><tr>' +
         ''.join(''.join('<th class="c">' + ('เฉลี่ย' if c == 'avg' else CLF_TH[c].replace('RandomForest', 'RF').replace('SVM-RBF', 'SVM').replace('LogReg', 'LR').replace('k-NN', 'kNN')) + '</th>' for c in clfs) for m in MEAS) + '</tr></thead><tbody>')
    for me in METH:
        h += '<tr><td class="mt"><i class="sw" style="background:var(--' + MCOL[me] + ')"></i> ' + me + '</td>'
        for m in MEAS:
            for c in clfs:
                r = per[c + '|' + m]['ar']; v = r[me]; best = min(r.values())
                a = max(0, min(1, (5 - v) / 4))  # rank 1 -> 1, rank 5 -> 0
                pctc = round(8 + 72 * a)
                ink = '#fff' if pctc > 52 else 'var(--ink)'
                h += ('<td class="v' + (' hi' if v == best else '') + '" style="background:color-mix(in oklab,var(--c1) ' + str(pctc) + '%,var(--paper));color:' + ink + '" data-tip="' +
                      me + ' · ' + MEAS_TH[m] + ' · ' + CLF_TH[c] + ': average rank ' + f"{v:.2f}" + ' (N = 110)">' + f"{v:.2f}" + '</td>')
        h += '</tr>'
    return h + '</tbody></table></div>'


def gain_svg():
    W, H, L, B, T, Rr = 300, 210, 40, 30, 22, 10
    lo, hi = -0.3, 0.6
    xs = lambda ir: L + (math.log10(ir) - math.log10(1.5)) / (math.log10(150) - math.log10(1.5)) * (W - L - Rr)
    ys = lambda v: T + (hi - max(lo, min(hi, v))) / (hi - lo) * (H - T - B)
    out = '<div class="two">'
    for m in ['Gmean', 'F1', 'AUC', 'PR_AUC']:
        rho = X['ir_gain_rho'][m]
        vals = [r[m] for r in X['ir_gain']]
        up = sum(1 for v in vals if v > 1e-9); dn = sum(1 for v in vals if v < -1e-9)
        s = '<svg class="ch" viewBox="0 0 ' + str(W) + ' ' + str(H) + '" role="img" aria-label="ผลต่าง ' + MEAS_TH[m] + ' ของ SMOTE ลบ None เทียบ IR">'
        for v in [-0.2, 0, 0.2, 0.4, 0.6]:
            s += '<line class="' + ('ax' if v == 0 else 'gr') + '" x1="' + str(L) + '" x2="' + str(W - Rr) + '" y1="' + f"{ys(v):.1f}" + '" y2="' + f"{ys(v):.1f}" + '"/><text x="' + str(L - 6) + '" y="' + f"{ys(v) + 4:.1f}" + '" text-anchor="end">' + (f"{v:+.1f}" if v else '0') + '</text>'
        for ir in [2, 5, 10, 20, 50, 100]:
            s += '<text x="' + f"{xs(ir):.1f}" + '" y="' + str(H - B + 16) + '" text-anchor="middle">' + str(ir) + '</text>'
        s += '<text x="' + str((W + L) / 2) + '" y="' + str(H - 2) + '" text-anchor="middle" class="mut">IR (log scale)</text>'
        for r in sorted(X['ir_gain'], key=lambda r: r['IR']):
            v = r[m]
            s += ('<circle cx="' + f"{xs(r['IR']):.1f}" + '" cy="' + f"{ys(v):.1f}" + '" r="4" fill="var(--m1)" fill-opacity=".75" stroke="var(--paper)" stroke-width="1" data-tip="' + esc(r['ds']) + ' · IR ' + f"{r['IR']:.1f}" +
                  ' · SMOTE − None = ' + f"{v:+.3f}" + '"/>')
        s += '<text x="' + str(L) + '" y="13" class="lbl" font-weight="600">' + MEAS_TH[m] + '</text><text x="' + str(W - Rr) + '" y="13" text-anchor="end">ดีขึ้น ' + str(up) + ' · แย่ลง ' + str(dn) + ' · ρ = ' + f"{rho:.2f}" + '</text></svg>'
        out += '<div>' + s + '</div>'
    return out + '</div>'


def example_table():
    ex = X['example']; per = X['per']['SVM|Gmean']
    h = ('<div class="scroll"><table class="t ex"><thead><tr><th>ชุดข้อมูล</th><th class="r">IR</th>' + ''.join('<th class="r">' + me + '</th>' for me in METH) + '</tr></thead><tbody>')
    for r in ex:
        best = max(r['v'][me][0] for me in METH)
        h += '<tr><td>' + esc(r['ds']) + '</td><td class="r">' + f"{r['IR']:.1f}" + '</td>' + ''.join(
            '<td class="r' + (' b' if abs(r['v'][me][0] - best) < 1e-9 else '') + '">' + f"{r['v'][me][0]:.3f}" + '<div class="sd">± ' + f"{r['v'][me][1]:.3f}" + '</div></td>' for me in METH) + '</tr>'
    h += '<tr><td colspan="7" class="sub" style="text-align:center">… อีก 102 ชุดข้อมูลในภาคผนวก …</td></tr>'
    ar = per['ar']; bestar = min(ar.values())
    h += '<tr class="sum"><td colspan="2">Average rank (110 ชุด)</td>' + ''.join('<td class="r' + (' b' if ar[me] == bestar else '') + '">' + f"{ar[me]:.2f}" + '</td>' for me in METH) + '</tr>'
    h += '<tr class="sum"><td colspan="2">W/T/L เทียบ SMOTE</td>' + ''.join('<td class="r">' + ('control' if me == 'SMOTE' else '/'.join(map(str, per['wtl'][me]))) + '</td>' for me in METH) + '</tr>'
    h += '<tr class="sum"><td colspan="2">Holm p (Wilcoxon เทียบ SMOTE)</td>' + ''.join('<td class="r">' + ('–' if me == 'SMOTE' else ('&lt; 0.001' if per['holm'][me] < 0.001 else f"{per['holm'][me]:.3f}")) + '</td>' for me in METH) + '</tr>'
    return h + '</tbody></table></div><p class="note">ตัวอย่างจากผลทดลองของเรา: SVM-RBF, G-mean, ค่าเฉลี่ยและ SD ของ 5 fold (รันครั้งเดียว). Friedman (Iman-Davenport) p = ' + f"{per['pF']:.1e}" + '. ตัวหนา = ดีที่สุดในแถว</p>'


def q3():
    rep = dict(F['reporting'])
    body = '<p>คำถาม: งานต่าง ๆ แสดงผลด้วยตารางและกราฟแบบไหน และควรหน้าตาเป็นอย่างไร. ส่วนแรกนับจาก 71 งาน ส่วนที่สองเป็นรูปจริงจากผลทดลองของเรา (110 KEEL datasets × 5 วิธี × 5 classifier) ที่ทำตามแบบที่แนะนำ</p>'
    body += '<h3>งานทั้งหมดแสดงผลอย่างไร <span class="en">What the 71 studies show</span></h3>'
    body += '<div class="lg"><span><i style="background:var(--c1)"></i>ตาราง</span><span><i style="background:var(--c2)"></i>กราฟหรือรูป</span></div>'
    body += hbars([(t, rep.get(k, 0), 'c1' if ty == 't' else 'c2') for k, t, ty in REP_TH], 71)
    body += ('<div class="box warn"><b>ช่องว่างที่เห็น</b><ul class="list"><li>38 งานมีตาราง average rank แต่มีแค่ <b>4</b> งานวาด CD diagram ซึ่งบอกได้ทันทีว่าวิธีไหนต่างกันจริง</li>'
             '<li>ตัวหนาค่าที่ดีสุด 42 งาน แต่มี SD แค่ 24 งาน: ผู้อ่านไม่รู้ว่าที่ "ดีสุด" ต่างจากที่สองเกินความแปรปรวนของ fold หรือไม่</li>'
             '<li>กราฟแท่ง (17 งาน) เมื่อใช้แสดงค่าเฉลี่ยข้ามชุดข้อมูล จะเอาค่าที่สเกลต่างกันมาเฉลี่ยรวม ชุดข้อมูลง่ายกลบชุดข้อมูลยาก</li>'
             '<li>ROC curve (6 งาน) ใช้ได้กับชุดข้อมูลไม่กี่ชุด พอมี 30 ถึง 100 ชุดก็อ่านไม่ได้</li></ul></div>')
    body += '<h3>ควรเป็นอย่างไร: ตัวอย่างจากผลของเรา <span class="en">What it should look like</span></h3>'
    body += ('<div class="fig"><div class="ft">รูปที่ 1 · Critical difference diagram</div><div class="ctl"><label>measure <select id="cd-m">' + ''.join('<option value="' + m + '"' + (' selected' if m == 'Gmean' else '') + '>' + MEAS_TH[m] + '</option>' for m in MEAS) +
             '</select></label><label>classifier <select id="cd-c">' + ''.join('<option value="' + c + '"' + (' selected' if c == 'SVM' else '') + '>' + CLF_TH[c] + '</option>' for c in ['CART', 'kNN', 'SVM', 'LR', 'RF', 'avg']) + '</select></label></div>'
             '<div id="cd" class="scroll"></div><div class="fs" id="cd-cap"></div></div>')
    body += ('<p class="note">อ่านอย่างไร: ซ้าย = rank ดี. วิธีที่ถูกเชื่อมด้วยเส้นหนาเดียวกันต่างกันไม่ถึง CD (Nemenyi, α = 0.05, k = 5, N = 110, CD = ' + f"{X['CD']:.2f}" + ') จึงสรุปไม่ได้ว่าต่าง. '
             'ต้องทำราย classifier (N = 110 ชุดข้อมูล) ไม่ใช่รวม 550 block แบบใน RESULTS.md เพราะ block จาก classifier ต่างกันบนชุดข้อมูลเดียวกันไม่เป็นอิสระต่อกัน ทำให้ N ใหญ่เกินจริงและ CD แคบเกินจริง</p>')
    body += '<div class="fig"><div class="ft">รูปที่ 2 · Heatmap ของ average rank (ทุก measure × ทุก classifier)</div><div class="fs">สีเข้ม = rank ดี, ตัวหนา = ดีที่สุดในคอลัมน์. ดูทีเดียวรู้ว่าข้อสรุปเปลี่ยนตาม measure: G-mean ให้ SMOTE ดีสุดทุก classifier, PR-AUC ให้ None ดีสุดทุก classifier</div>' + heatmap() + '</div>'
    body += ('<div class="fig"><div class="ft">รูปที่ 3 · เทียบรายชุดข้อมูลกับ baseline</div><div class="ctl"><label>วิธี <select id="sc-a">' + ''.join('<option' + (' selected' if me == 'QC-SMOTE' else '') + '>' + me + '</option>' for me in METH if me != 'SMOTE') +
             '</select></label><label>measure <select id="sc-m">' + ''.join('<option value="' + m + '"' + (' selected' if m == 'F1' else '') + '>' + MEAS_TH[m] + '</option>' for m in MEAS) +
             '</select></label><label>classifier <select id="sc-c">' + ''.join('<option value="' + c + '"' + (' selected' if c == 'SVM' else '') + '>' + CLF_TH[c] + '</option>' for c in ['CART', 'kNN', 'SVM', 'LR', 'RF']) + '</select></label></div>'
             '<div id="sc"></div><div class="fs" id="sc-cap"></div></div>')
    body += '<div class="fig"><div class="ft">รูปที่ 4 · ผลต่าง SMOTE ลบ None เทียบ IR (เฉลี่ย 5 classifier ต่อชุดข้อมูล)</div><div class="fs">จุดเหนือเส้น 0 = SMOTE ดีกว่าไม่ resample. ρ = Spearman ระหว่าง IR กับผลต่าง. G-mean ดีขึ้นแทบทุกชุดและดีขึ้นมากเมื่อ IR สูง ส่วน PR-AUC แย่ลงเกินครึ่ง</div>' + gain_svg() + '</div>'
    body += '<h3>ตารางผลที่ควรเป็น <span class="en">Results table template</span></h3>' + example_table()
    body += ('<div class="two"><div class="box key"><b>ตารางควรมี</b><ul class="list"><li>mean ± SD จากการทำซ้ำ (repeated CV) ไม่ใช่ค่าเดี่ยว</li><li>คอลัมน์ IR และเรียงชุดข้อมูลตาม IR</li>'
             '<li>แถวท้าย: average rank, W/T/L เทียบ baseline หลัก, p-value ที่ปรับ Holm แล้ว</li><li>ตารางรายชุดข้อมูลเต็มไปภาคผนวก ตัวบทแสดงแค่สรุป</li><li>บอกว่าตัวหนาหมายถึงอะไร และถ้าเสมอกันทำอย่างไร</li></ul></div>'
             '<div class="box key"><b>กราฟควรมี</b><ul class="list"><li>CD diagram ทุก measure ที่รายงาน (ราย classifier หรือแยกรูป)</li><li>heatmap ของ rank เมื่อมีหลาย measure × หลาย classifier</li>'
             '<li>scatter รายชุดข้อมูลเทียบ baseline (เห็นทั้งขนาดผลและจำนวนชุดที่แพ้)</li><li>ผลต่างเทียบ IR หรือขนาดข้อมูล (ตอบว่าช่วยตอนไหน)</li><li>runtime เทียบขนาดข้อมูล แบบ log-log</li></ul></div></div>')
    body += sentence('We report, for every measure, a results table with mean and standard deviation over repeated cross-validation, average Friedman ranks computed separately for each classifier over the N = 110 datasets, win/tie/loss counts against SMOTE and Holm-adjusted Wilcoxon p-values, together with critical-difference diagrams, a rank heatmap across measures and classifiers, and per-dataset scatter plots against the SMOTE baseline.')
    sec('q3', 'Q3', 'ตารางและกราฟ: ที่ใช้กัน และที่ควรเป็น', 'Tables and figures', body)


# ---------------------------------------------------------------- Q4
FAMS = [('overall', 'Overall', 'วัดรวมทุกคลาส', 'นับถูกทั้งหมด คลาสใหญ่ครองค่า จึงใช้ลดลง'),
        ('single', 'Single-class', 'วัดทีละคลาส', 'ดูคลาสน้อยหรือคลาสใหญ่ทีละด้าน ใช้คู่กับตัวอื่นเสมอ'),
        ('comp', 'Composite (threshold)', 'รวมหลายค่าที่ threshold หนึ่ง', 'ค่าเดียวที่รวมสองด้าน ต้องเลือก threshold ก่อน'),
        ('rank', 'Ranking (threshold-free)', 'ไม่ขึ้นกับ threshold', 'ใช้ score ของ classifier วัดว่าจัดอันดับบวกเหนือลบได้ดีแค่ไหน'),
        ('multi', 'Multi-class aggregate', 'รวมผลหลายคลาส', 'ขยาย measure สองคลาสไปหลายคลาส ด้วยการเฉลี่ยหรือดูคลาสแย่สุด')]


def q4():
    fc = F['fam_counts']; ms = F['measures']
    body = ('<p>คำถาม: ถ้าวัดผลผ่าน classification (ฝึก classifier บนข้อมูลที่ resample แล้ว ทดสอบบนข้อมูลจริง) ทั้ง 71 งานใช้ measure ต่างกันกี่ตัว แบ่งได้กี่หมวด</p>')
    body += tiles([(str(F['n_measures']), 'measure ค่าเดียว (scalar) ที่ต่างกัน'), ('5', 'หมวด (และ cost อีก 1 ตัว)'), (str(int(F['median_meas_per_study'])), 'ค่ากลางของจำนวน measure ต่องาน'),
                   ('71<small>/71</small>', 'ทุกงานที่มีการทดลองใช้อย่างน้อย 1 ตัว')])
    body += '<div class="fams">'
    for k, en, th, desc in FAMS:
        labs = sorted(fc[k]['labels'], key=lambda m: -ms[m]['n'])
        body += ('<div class="fam"><div class="hd"><b>' + en + '</b><span>' + str(len(labs)) + ' ตัว · ' + str(fc[k]['studies']) + ' งาน</span></div><p><b>' + th + '</b>: ' + desc + '</p><div class="chips">' +
                 ''.join('<span class="chip">' + esc(MEAS_LAB.get(m, m).split(' (')[0]) + ' <b>' + str(ms[m]['n']) + '</b></span>' for m in labs) + '</div></div>')
    body += '</div>'
    body += ('<p class="note">ตัวเลขบนป้าย = จำนวนงานที่ใช้. "งาน" ในหัวการ์ด = จำนวนงานที่ใช้อย่างน้อยหนึ่งตัวในหมวด. cost (misclassification cost) ใช้ 2 งาน. ไม่นับใน 27: ROC curve เป็นรูป (8 งาน), confusion matrix เป็นตาราง (4), runtime (14), '
             'fidelity ของข้อมูลสังเคราะห์ (3, เป็นการวัดตรงในข้อ 2) และอื่น ๆ เช่นขนาดต้นไม้. ถ้านับ F1 กับ F-measure (ไม่ระบุ beta) เป็นตัวเดียวกันจะเหลือ 26</p>')
    dist = {int(k): v for k, v in F['n_meas_per_study'].items()}
    body += '<h3>จำนวน measure ต่องาน <span class="en">Measures per study</span></h3>' + hbars([(str(k) + ' ตัว', dist.get(k, 0)) for k in range(1, max(dist) + 1)], 71)
    body += ('<div class="box key"><b>หมวดไหนตอบคำถามอะไร</b><p>ถ้าเลือกจากคำถามแทนความเคยชิน: อยากรู้ว่า resampling ทำให้คลาสน้อยถูกจับได้มากขึ้นโดยไม่เสียคลาสใหญ่มากไหม ใช้ <b>composite</b> (G-mean, balanced accuracy, MCC); '
             'อยากรู้ว่าตัว classifier แยกสองคลาสได้ดีขึ้นจริงหรือแค่ขยับ threshold ใช้ <b>ranking</b> (AUC, PR-AUC); มีหลายคลาส ใช้ <b>multi-class</b> (MAUC, MG, macro-F1, CBA). '
             'การรายงานอย่างน้อยหนึ่งตัวจาก composite และหนึ่งตัวจาก ranking ทำให้แยกสองเรื่องนี้ออกจากกันได้ (ดูข้อ 5 และผลทดลองของเราในข้อ 3 ที่ข้อสรุปกลับด้านระหว่างสองหมวด)</p></div>')
    body += sentence('Across the 71 empirical studies we found ' + str(F['n_measures']) + ' distinct scalar measures computed on the predictions of a downstream classifier, which fall into five families: overall (1), single-class (4), threshold-dependent composites (7), threshold-free ranking measures (4) and multi-class aggregates (10), plus misclassification cost; a typical study reports three of them.')
    sec('q4', 'Q4', 'วัดจาก downstream classification: กี่ตัว กี่หมวด', 'How many measures, how many families', body)


# ---------------------------------------------------------------- Q5
def line_svg(series, w=640, h=270):
    L, Rr, T, B = 40, 110, 14, 34
    xs = lambda i: L + i * (w - L - Rr) / 3
    ys = lambda v: T + (100 - v) / 100 * (h - T - B)
    s = '<div class="scroll"><svg class="ch" style="min-width:520px;max-width:700px" viewBox="0 0 ' + str(w) + ' ' + str(h) + '" role="img" aria-label="ร้อยละของงานที่ใช้แต่ละ measure ตามช่วงปี">'
    for v in [0, 25, 50, 75, 100]:
        s += '<line class="' + ('ax' if v == 0 else 'gr') + '" x1="' + str(L) + '" x2="' + str(w - Rr) + '" y1="' + f"{ys(v):.1f}" + '" y2="' + f"{ys(v):.1f}" + '"/><text x="' + str(L - 6) + '" y="' + f"{ys(v) + 4:.1f}" + '" text-anchor="end">' + str(v) + '%</text>'
    for i in range(4):
        s += '<text x="' + f"{xs(i):.1f}" + '" y="' + str(h - B + 18) + '" text-anchor="middle">' + ERA_TH[i] + '</text>'
    ends = []
    for lab, col, vals in series:
        pts = ' '.join(f"{xs(i):.1f},{ys(v):.1f}" for i, v in enumerate(vals))
        s += '<polyline points="' + pts + '" fill="none" stroke="var(--' + col + ')" stroke-width="2" stroke-linejoin="round"/>'
        for i, v in enumerate(vals):
            s += '<circle cx="' + f"{xs(i):.1f}" + '" cy="' + f"{ys(v):.1f}" + '" r="4.5" fill="var(--' + col + ')" stroke="var(--paper)" stroke-width="2" data-tip="' + lab + ' · ' + ERA_TH[i] + ': ' + str(v) + '% ของงาน"/>'
        ends.append([ys(vals[-1]), lab, col, vals[-1]])
    ends.sort()
    for i in range(1, len(ends)):
        if ends[i][0] - ends[i - 1][0] < 14:
            ends[i][0] = ends[i - 1][0] + 14
    for y, lab, col, v in ends:
        s += '<text x="' + str(w - Rr + 10) + '" y="' + f"{y + 4:.1f}" + '" class="lbl">' + lab + ' ' + str(v) + '%</text>'
    return s + '</svg></div>'


def q5():
    g = F['gm']; R_ = RM
    top = [('G-mean', R_['G-mean']['n']), ('F1 / F-measure', R_['F1 / F-measure']['n']), ('AUC', R_['AUC']['n']), ('Recall / TPR', R_['Recall / TPR']['n']),
           ('Precision', F['measures']['Precision']['n']), ('Accuracy', R_['Accuracy or error rate']['n']), ('MAUC', R_['MAUC']['n']), ('PR-AUC', R_['PR-AUC']['n']), ('MCC', R_['MCC']['n'])]
    body = '<p>คำถาม: measure ไหนถูกใช้มากที่สุด และใช้เพราะอะไร โดยอธิบายเป็นเหตุและผล ไม่ใช่เพราะคนอื่นใช้</p>'
    body += hbars([(a, b, 'c1' if a == 'G-mean' else 'c3') for a, b in top], 71)
    body += tiles([('41<small>/71</small>', 'งานที่ใช้ G-mean มากที่สุดในทุก measure'), ('71%', 'ของงานช่วง 2021–26 ใช้ G-mean (ถึง 2009: 29%)'),
                   ('11<small>/19</small>', 'งานหลายคลาสใช้ G-mean ในรูป MG'), ('16 กับ 7', 'แต่ถ้าดู measure หลักที่ paper ประกาศ AUC มากกว่า G-mean')])
    body += '<div class="fig"><div class="ft">ร้อยละของงานที่ใช้ measure หลัก 4 ตัว ตามช่วงปี</div><div class="lg"><span><i class="ln" style="background:var(--m1)"></i>G-mean</span><span><i class="ln" style="background:var(--m2)"></i>AUC</span><span><i class="ln" style="background:var(--m3)"></i>F1 / F-measure</span><span><i class="ln" style="background:var(--m4)"></i>Recall</span></div>'
    body += line_svg([('G-mean', 'm1', list(R_['G-mean']['share'].values())), ('AUC', 'm2', list(R_['AUC']['share'].values())), ('F1', 'm3', list(R_['F1 / F-measure']['share'].values())), ('Recall', 'm4', list(R_['Recall / TPR']['share'].values()))]) + '</div>'
    body += '<p class="note">G-mean ขึ้นต่อเนื่องทุกช่วง ขณะที่ recall เดี่ยว ๆ ลดลง (recall ถูกรวมเข้าไปใน G-mean). AUC ขึ้นลงตามช่วง F1 ทรงตัวราวครึ่งหนึ่ง. ในตระกูล SMOTE แบบ Binary only, AUC ยังนำ (18 กับ 14 จาก 24 งาน)</p>'
    body += '<h3>ทำไม G-mean: เหตุและผล <span class="en">Why G-mean, as a mechanism</span></h3>'
    body += ('<div class="chain">'
             '<div class="lk"><div><b>resampling เปลี่ยนสัดส่วนคลาสในข้อมูลฝึก</b><span>SMOTE เพิ่มจุดคลาสน้อยจนสองคลาสเท่ากัน classifier จึงเห็นคลาสน้อยบ่อยขึ้น</span></div></div>'
             '<div class="lk"><div><b>ผลหลักคือ threshold ขยับ ไม่ใช่การแยกคลาสดีขึ้น</b><span>classifier ทายบวกมากขึ้น: TPR ขึ้น, TNR ลงเล็กน้อย. ส่วนความสามารถจัดอันดับ (AUC) แทบไม่เปลี่ยน ผลของเรา: SMOTE ดีกว่า None ด้วย AUC แค่ 255/550 กรณี</span></div></div>'
             '<div class="lk"><div><b>G-mean = √(TPR × TNR) วัดการแลกนี้ตรงตัว</b><span>มีค่าสูงสุดเมื่อสองคลาสถูกพอ ๆ กัน และเป็น 0 ถ้าคลาสใดถูกทิ้ง. เมื่อสองคลาสเป็นการแจกแจงปกติที่ความแปรปรวนเท่ากัน จุด threshold ที่ให้ G-mean สูงสุดคือจุดเดียวกับที่ข้อมูลฝึกแบบ 1:1 ดันไปพอดี (ดูกราฟในข้อ 8)</span></div></div>'
             '<div class="lk"><div><b>ผลจึงออกมาชัดที่สุดใน G-mean</b><span>ผลของเรา: SMOTE ดีกว่า None ด้วย G-mean <b>' + str(X['smote_vs_none']['Gmean']['win']) + '/550</b> กรณี (78%) เทียบ F1 58%, AUC 46%, PR-AUC 32%</span></div></div>'
             '<div class="lk"><div><b>งานที่เสนอ resampling จึงเลือกและส่งต่อ G-mean</b><span>measure ที่ "เห็น" ผลของวิธีที่เสนอถูกเลือก แล้วงานถัดมาใช้ตามเพื่อเทียบกันได้. ส่วนที่สองนี้คือความนิยม แต่เกิดหลังจากกลไกข้อ 1 ถึง 4</span></div></div></div>')
    sv = X['smote_vs_none']
    body += '<div class="fig"><div class="ft">SMOTE เทียบ None ในผลทดลองของเรา (550 กรณี = 110 ชุดข้อมูล × 5 classifier)</div><div class="lg"><span><i style="background:var(--m1)"></i>SMOTE ดีกว่า</span><span><i style="background:var(--tie)"></i>เท่ากัน</span><span><i style="background:var(--m-none)"></i>None ดีกว่า</span></div><div class="wtl">'
    for m in ['Gmean', 'F1', 'AUC', 'PR_AUC']:
        w, t, l = sv[m]['win'], sv[m]['tie'], sv[m]['loss']
        body += ('<div class="wr"><b>' + MEAS_TH[m] + '</b><span class="wb"><i class="w" style="width:' + f"{100 * w / 550:.1f}" + '%" data-tip="SMOTE ดีกว่า ' + str(w) + ' กรณี"></i><i class="t" style="width:' + f"{100 * t / 550:.1f}" +
                 '%" data-tip="เท่ากัน ' + str(t) + ' กรณี"></i><i class="l" style="width:' + f"{100 * l / 550:.1f}" + '%" data-tip="None ดีกว่า ' + str(l) + ' กรณี"></i></span><span class="n">' + str(w) + ' / ' + str(t) + ' / ' + str(l) +
                 ' · median Δ ' + f"{sv[m]['med']:+.3f}" + '</span></div>')
    body += '</div><div class="fs">ตัวเลข = ชนะ / เสมอ / แพ้. resampling ช่วย measure ที่ขึ้นกับ threshold และไม่ช่วยหรือทำให้ measure จัดอันดับแย่ลง ซึ่งตรงกับกลไกข้อ 2</div></div>'
    body += ('<div class="two"><div class="box"><b>คุณสมบัติที่ทำให้ G-mean ใช้ได้กว้าง</b><ul class="list">'
             '<li><b>ไม่ขึ้นกับสัดส่วนคลาส</b>: ใช้อัตราภายในแต่ละคลาส ค่าจากชุดข้อมูล IR 1.8 กับ IR 130 จึงเอามาจัดอันดับร่วมกันได้ ซึ่งจำเป็นเมื่อใช้ KEEL หลายสิบชุด</li>'
             '<li><b>ต้องการแค่ label</b>: C4.5, rule learner, k-NN ให้ score ที่หยาบ AUC จึงคำนวณได้ไม่ดี. SPIDER2 (2010, p. 162) เลือก G-mean แทน AUC ด้วยเหตุนี้</li>'
             '<li><b>ขยายเป็นหลายคลาสได้ตรงไปตรงมา</b>: MG = geometric mean ของ recall ทุกคลาส ทำให้ใช้ชื่อเดียวกันได้ทั้ง binary และ multiclass</li>'
             '<li><b>มีที่มาในสายนี้ตั้งแต่ต้น</b>: Kubat 1997 (OSS) และ 1998 (SHRINK) ใช้เป็นตัววัดหลัก มี 8 งานใน corpus อ้าง Kubat ตอนอธิบาย measure</li></ul></div>'
             '<div class="box warn"><b>ผลข้างเคียงที่ต้องรู้</b><ul class="list"><li>เพราะ G-mean ให้รางวัลกับการขยับ threshold วิธีใดก็ตามที่ขยับ threshold (class weight, threshold moving) จะได้คะแนนเพิ่มเหมือนกัน '
             'ต้องมี baseline แบบนี้จึงจะบอกได้ว่าวิธีที่เสนอดีกว่าการขยับ threshold เฉย ๆ (มีแค่ CISO ที่เทียบกับ class weight)</li>'
             '<li>G-mean ไม่ดู precision: ทายบวกเกินมาก ๆ บนข้อมูล IR สูง G-mean ยังสูงได้ ทั้งที่สิ่งที่ทายว่าบวกส่วนใหญ่ผิด (ดูข้อ 8)</li>'
             '<li>13 งานใช้ G-mean เลือกพารามิเตอร์บนข้อมูลชุดเดียวกับที่รายงานผล ทำให้ G-mean ของวิธีที่เสนอดูดีเกินจริง</li></ul></div></div>')
    rs = g['reasons']; rn = g['reasons_non']
    RTH = [('standard_in_literature', 'ใช้กันทั่วไปในงานก่อนหน้า'), ('accuracy_misleading', 'accuracy ใช้ไม่ได้กับข้อมูลไม่สมดุล'), ('minority_focus', 'ต้องการดูคลาสน้อย'),
           ('threshold_free', 'ไม่ขึ้นกับ threshold หรือสัดส่วนคลาส'), ('multiclass_suitability', 'เหมาะกับหลายคลาส'), ('cost', 'ต้นทุนผิดพลาดไม่เท่ากัน'), ('other', 'อื่น ๆ')]
    body += ('<h3>paper เองเขียนเหตุผลว่าอะไร <span class="en">Stated reasons</span></h3><div class="scroll"><table class="t"><thead><tr><th>เหตุผลที่เขียนไว้ตอนเลือก measure</th><th class="r">งานที่ใช้ G-mean (41)</th><th class="r">งานที่ไม่ใช้ (30)</th></tr></thead><tbody>' +
             ''.join('<tr><td>' + t + '</td><td class="r"><b>' + str(rs.get(k, 0)) + '</b> (' + str(pct(rs.get(k, 0), 41)) + '%)</td><td class="r">' + str(rn.get(k, 0)) + ' (' + str(pct(rn.get(k, 0), 30)) + '%)</td></tr>' for k, t in RTH) +
             '</tbody></table></div>')
    body += ('<div class="box key"><b>อ่านตารางนี้อย่างไร</b><p>เหตุผลที่เขียนบ่อยสุดของผู้ใช้ G-mean คือ "ใช้กันทั่วไป" (24/41) และ "accuracy ใช้ไม่ได้" (21/41) ซึ่งเป็นเหตุผลที่ใช้กับ measure ใดก็ได้ที่ไม่ใช่ accuracy และสัดส่วนไม่ต่างจากงานที่ไม่ใช้ G-mean. '
             'มีราว 6 งานที่เขียนเหตุผลเฉพาะของ G-mean: SHRINK 1998 (accuracy ใช้ไม่ได้ในโจทย์นี้ จึงใช้ geometric mean), SPIDER2 2010 (เหมาะกับ classifier ที่ให้แค่ label), RACOG 2015 (เพิ่ม sensitivity โดยรักษาทั้งสองคลาส), '
             'DLexiBoost 2020 (สูงเมื่อดีทุกคลาส), FW-SMOTE 2022 (สมดุลระหว่างความถูกสองคลาส) และ MKC-SMOTE 2024 (ไม่มีคลาสใดถูกมองข้าม). '
             'สรุปคือ paper ส่วนใหญ่อ้างความนิยม แต่กลไกที่อธิบายข้างบนคือเหตุที่ความนิยมนี้เกิดและอยู่ต่อ</p></div>')
    body += sentence('G-mean is the most frequently reported measure (41 of 71 studies, and 71% of those published since 2021) because it responds to exactly what resampling changes: the operating point of the classifier, traded between TPR and TNR. In our own runs SMOTE beats no resampling in 78% of dataset-classifier pairs under G-mean but in only 46% under AUC and 32% under PR-AUC, so G-mean alone cannot separate a better sampler from a shifted threshold.')
    sec('q5', 'Q5', 'measure ไหนใช้มากสุด และทำไม', 'The most used measure and why', body)


# ---------------------------------------------------------------- Q6
def mini(label):
    sh = list(RM[label]['share'].values())
    return '<span class="mini" data-tip="' + esc(label) + ': ' + ' · '.join(ERA_TH[i] + ' ' + str(v) + '%' for i, v in enumerate(sh)) + '">' + ''.join(
        '<i' + (' class="z"' if v == 0 else '') + ' style="height:' + str(max(1, round(v / 100 * 26))) + 'px"></i>' for v in sh) + '</span>'


def q6():
    rows = [
        ('Demšar 2006', 'REF-Demsar-2006', 2006, [('Friedman', 'Friedman'), ('Wilcoxon signed-rank', 'Wilcoxon'), ('t-test', 't-test'), ('No significance test', 'ไม่มี test')],
         'Friedman ปีแรก 2008 (LS), Wilcoxon 2010 (RAMOBoost), t-test งานสุดท้าย 2015. อ้าง Demšar 19 งาน (มากสุดในบรรดางานด้านสถิติ)', 'สูตรสำเร็จพร้อมเครื่องมือ: บทความบอกขั้นตอนครบ และ KEEL ใส่ Friedman กับ post-hoc ไว้ให้ (García และ Herrera 2008, ' + cites('REF-GarciaHerrera-2008') + ' cites)'),
        ('KEEL 2009, 2011', ('REF-KEEL-2009', 'REF-KEEL-2011'), 2009, [('KEEL repository', 'ข้อมูล KEEL'), ('Fewer than 10 real datasets', 'น้อยกว่า 10 ชุด')],
         'ข้อมูล KEEL ปีแรก 2013. ผู้ใช้ KEEL ใช้ 5-fold 13 จาก 33 งาน เทียบกับไม่ใช้ KEEL 7 จาก 38 งาน (KEEL แจกข้อมูลแบบแบ่ง 5 fold ไว้แล้ว)', 'ข้อมูลกลางที่พร้อมใช้: ทดลอง 30 ถึง 100 ชุดได้ในต้นทุนเท่าเดิม และชุดเดียวกันทำให้เทียบกับงานก่อนได้'),
        ('Hand และ Till 2001', 'REF-HandTill-2001', 2001, [('MAUC', 'MAUC')],
         'MAUC ปีแรก 2006 (Global-CS). อ้าง Hand และ Till 9 งาน. CBA และ CEN ปีแรก 2020 (MC-RBO) ใช้ต่อใน MC-CCR, GLOS, NROMM, MC-MBRC, MC-NCLWO', 'โจทย์เปลี่ยน: เมื่อตระกูล SMOTE ขยายไปหลายคลาส measure สองคลาสใช้ไม่ได้ ต้องหาตัวใหม่'),
        ('He และ Garcia 2009', 'REF-HeGarcia-2009', 2009, [('G-mean', 'G-mean'), ('Recall / TPR', 'Recall เดี่ยว')],
         'อ้าง He และ Garcia ตอนเลือก measure 11 งาน (มากสุดเท่ากับ Bradley 1997). G-mean ขึ้นจาก 29% เป็น 54% ในช่วงถัดมา', 'survey ที่คนอ่านมากกำหนด "ชุดมาตรฐาน" (G-mean, F-measure, AUC) ให้ทั้งสาขา'),
        ('imbalanced-learn 2017', 'REF-imblearn-2017', 2017, [('Code released', 'แจก code'), ('Random forest or gradient boosting', 'RF / GB')],
         'แจก code ปีแรก 2013 แล้วกระโดดเป็น 65% ในช่วง 2016–20. gradient boosting ปีแรก 2018 (k-means SMOTE)', 'เครื่องมือมาตรฐาน (scikit-learn, imbalanced-learn) ทำให้แจก code และใช้ learner สมัยใหม่ได้ถูก'),
        ('Benavoli et al. 2017', 'REF-Benavoli-2017', 2017, [('Bayesian test', 'Bayesian test')],
         'ปีแรก 2022 (SHSampler) 3 งาน. อ้าง Benavoli 3 งาน', 'คำแนะนำใหม่ที่ช้าและยังน้อย: ต้องเปลี่ยนทั้งวิธีคิดและวิธีรายงาน'),
        ('Saito และ Rehmsmeier 2015', 'REF-SaitoRehmsmeier-2015', 2015, [('PR-AUC', 'PR-AUC')],
         'PR-AUC ปีแรก 2010 (RUSBoost) ก่อน Saito. หลังจากนั้นยังอยู่ที่ 8–10%. อ้าง Saito 2 งาน', '<b>ไม่เปลี่ยน</b>: งานดังแต่ไม่มีแรงผลักจาก benchmark หรือเครื่องมือ และ PR-AUC ต้องการ score ที่ classifier ตระกูล C4.5/rule ให้ไม่ได้'),
        ('Buda et al. 2018 (deep learning)', 'ROS-Buda-2018', 2018, [('Image data', 'ข้อมูลภาพ')],
         'ข้อมูลภาพ 2018–2020 (Buda, CTGAN, GAMO, NBU) แล้วหายไปในช่วง 2021–26', 'งานกลุ่มอื่นเข้ามาชั่วคราว ไม่กลายเป็นแนวปฏิบัติของตระกูล SMOTE ที่ยังอยู่กับข้อมูลตาราง')]
    body = '<p>คำถาม: วิธีวัดผลเริ่มเปลี่ยนเพราะอะไร. เราจับคู่ "ตัวขับ" (งานหรือเครื่องมือที่ทำให้แนวปฏิบัติใหม่เป็นไปได้) กับปีที่แนวปฏิบัตินั้นปรากฏครั้งแรกใน corpus และสัดส่วนในแต่ละช่วงปี แล้วดูหลักฐานว่าเชื่อมกันจริงไหม</p>'
    body += ('<div class="scroll"><table class="t tl wide"><thead><tr><th>ตัวขับ</th><th class="r">cites</th><th style="min-width:170px">แนวปฏิบัติที่เปลี่ยน <span class="sub">(4 แท่ง = 4 ช่วงปี)</span></th><th>หลักฐานที่เชื่อมกัน</th><th>กลไก</th></tr></thead><tbody>')
    for name, key, yr, pr, ev, mech in rows:
        body += ('<tr><td><b>' + name + '</b></td><td class="r">' + (' / '.join(cites(k_) for k_ in key) if isinstance(key, tuple) else cites(key)) + '</td><td>' + ''.join('<div style="display:flex;gap:8px;align-items:center;margin-bottom:3px">' + mini(lab) + '<span>' + th + '</span></div>' for lab, th in pr) +
                 '</td><td>' + ev + '</td><td>' + mech + '</td></tr>')
    body += '</tbody></table></div>'
    body += ('<div class="box key"><b>สรุป: แนวปฏิบัติเปลี่ยนเมื่อมี 4 อย่างนี้</b><ul class="list">'
             '<li><b>สูตรสำเร็จที่ทำตามได้ทันที</b>: Demšar บอกขั้นตอนครบ จากไม่มี test 64% เหลือ 17% และ t-test หายไปทั้งหมด</li>'
             '<li><b>ข้อมูลและเครื่องมือกลาง</b>: KEEL และ scikit-learn/imbalanced-learn ลดต้นทุนของการทดลองหลายชุดข้อมูลและการแจก code</li>'
             '<li><b>โจทย์เปลี่ยน</b>: พอตระกูล SMOTE ขยายไปหลายคลาส ต้องใช้ MAUC, MG, CBA, CEN</li>'
             '<li><b>measure ที่เห็นผลของวิธีที่เสนอ</b>: G-mean (ข้อ 5)</li></ul>'
             '<p>ส่วนที่ไม่เพียงพอคือ "งานดัง" อย่างเดียว: Saito และ Rehmsmeier 2015 มี 5,156 cites แต่ PR-AUC ไม่ขึ้น. Benavoli 2017 แนะนำ Bayesian test แต่ใช้แค่ 3 งาน '
             'แสดงว่าการเปลี่ยนต้องการทั้งเหตุผลและต้นทุนที่ต่ำพอ</p></div>')
    body += ('<p class="note">ข้อจำกัด: นี่คือความสัมพันธ์ตามเวลาร่วมกับการอ้างอิง ไม่ใช่การทดลองเชิงสาเหตุ. หลักฐานที่ใช้เชื่อมคือ (1) ปีแรกที่ใช้อยู่หลังตัวขับ (2) งานที่ใช้อ้างตัวขับโดยตรง (3) งานที่ใช้ตัวขับทำต่างจากงานที่ไม่ใช้ เช่น ผู้ใช้ KEEL ใช้ 5-fold บ่อยกว่า</p>')
    body += sentence('Changes in evaluation practice followed resources that made a new practice cheap and expected rather than citations alone: significance testing spread after Demšar (2006), cited by 19 studies, multi-dataset benchmarks after the KEEL repository, multi-class aggregates when the family moved to multi-class problems, and code release after scikit-learn and imbalanced-learn, whereas PR-AUC stayed at about 8% of studies despite Saito and Rehmsmeier (2015).')
    sec('q6', 'Q6', 'ทำไมวิธีวัดผลจึงเริ่มเปลี่ยน', 'Why practice changed', body)


# ---------------------------------------------------------------- Q7
def q7():
    dt = F['data_type']; stt = F['setting']; ap = F['approach']
    body = '<p>คำถาม: นอกจากวัดด้วย classifier แล้ว มีงานที่เอาข้อมูลที่ resample ไปใช้กับ task อื่นไหม เช่น regression, clustering, anomaly detection</p>'
    body += tiles([('71<small>/71</small>', 'ทุกงานวัดผลด้วย classification'), ('1', 'งานที่มี regression (CTGAN, ชุดข้อมูลเดียว)'), ('0', 'clustering, anomaly detection, multi-label, ranking'),
                   ('2', 'งานที่วัดคุณภาพของสิ่งที่สร้าง (CTGAN likelihood, GAMO FID)')])
    body += '<div class="two">'
    body += '<div><h3>จำนวนคลาส <span class="en">Class setting</span></h3>' + hbars([('binary', stt['binary']), ('multiclass', stt['multiclass']), ('ทั้งสองแบบ', stt['both'])], 71) + '</div>'
    body += '<div><h3>ชนิดข้อมูล <span class="en">Data type</span></h3>' + hbars([('ตาราง (tabular)', dt['tabular']), ('ผสมหลายชนิด', dt['mixed']), ('ภาพ', dt['image']), ('อนุกรมเวลา', dt['time-series'])], 71) + '</div></div>'
    body += ('<h3>งานที่ออกนอก classification ตารางทั่วไป <span class="en">Where studies step outside</span></h3><div class="scroll"><table class="t wide"><thead><tr><th>งาน</th><th class="r">cites</th><th>task หรือข้อมูล</th><th>วัดอย่างไร</th></tr></thead><tbody>' +
             '<tr><td><b>CTGAN</b> 2019</td><td class="r">' + cites('CTGAN-2019') + '</td><td>สร้างข้อมูลตารางสังเคราะห์ (ไม่ใช่ resampling โดยตรง) มีชุด regression 1 ชุด (news)</td><td>train บนข้อมูลสังเคราะห์ test บนข้อมูลจริง: F1, macro-F1, accuracy และ R² สำหรับ regression; likelihood fitness บนข้อมูลจำลอง</td></tr>'
             '<tr><td><b>GAMO</b> 2019</td><td class="r">' + cites('GAMO-2019') + '</td><td>ภาพ: classification และการสร้างภาพคลาสน้อย</td><td>ACSA, G-mean ของ classifier และ FID ของภาพที่สร้าง</td></tr>'
             '<tr><td><b>Buda et al.</b> 2018</td><td class="r">' + cites('ROS-Buda-2018') + '</td><td>ภาพ: CNN (LeNet-5, All-CNN, ResNet-10)</td><td>multi-class ROC AUC, accuracy</td></tr>'
             '<tr><td><b>INOS</b> 2013</td><td class="r">' + cites('INOS-2013') + '</td><td>อนุกรมเวลา</td><td>F-value, G-mean, precision, recall ของ SVM</td></tr>'
             '<tr><td><b>COG-OS</b> 2007</td><td class="r">' + cites('COG-OS-2007') + '</td><td>ข้อความ (document) ร่วมกับตาราง</td><td>F-measure, recall, precision</td></tr>'
             '</tbody></table></div>')
    body += ('<div class="two"><div class="box"><b>ทำไมเป็น classification ทั้งหมด</b><p>SMOTE นิยามจาก "คลาสน้อย" และสร้างจุดใหม่ระหว่างเพื่อนบ้านในคลาสเดียวกัน วิธีจึงผูกกับ label แบบกลุ่ม. '
             'ปัญหาที่ตระกูลนี้ตั้งใจแก้คือ classifier มองข้ามคลาสน้อย การวัดผลจึงย้อนไปที่ classifier เสมอ. งานที่สร้างข้อมูลแบบอื่น (CTGAN, GAMO) จึงเป็นกลุ่มที่เริ่มวัดอย่างอื่นด้วย</p></div>'
             '<div class="box warn"><b>ผลต่อการเขียน survey</b><p>ข้อสรุปเรื่องการวัดผลทั้งหมดใน Section 7 ใช้ได้กับ classification เท่านั้น ควรเขียนเป็นขอบเขตไว้ชัด ๆ. '
             'ตระกูล SMOTE สำหรับ regression ที่ไม่สมดุล (เช่น SMOTER ของ Torgo และคณะ) มีอยู่จริงแต่ไม่อยู่ในรายชื่อ 76 เรื่องของเรา ถ้าทีมจะพูดถึงควรแยกเป็นหัวข้อ "นอกขอบเขต"</p></div></div>')
    body += sentence('All 71 empirical studies judge resampling through a downstream classification task; apart from one regression dataset in CTGAN and the image-quality FID reported by GAMO, none evaluates regression, clustering, anomaly detection or multi-label learning, so the conclusions of this section are restricted to classification.')
    sec('q7', 'Q7', 'มี task อื่นนอกจาก classification ไหม', 'Tasks other than classification', body)


# ---------------------------------------------------------------- Q8
MATH_G = ('<math display="block"><mrow><mtext>G-mean</mtext><mo>=</mo><msqrt><mrow><mtext>TPR</mtext><mo>×</mo><mtext>TNR</mtext></mrow></msqrt><mo>=</mo><msqrt><mrow>'
          '<mfrac><mtext>TP</mtext><mrow><mtext>TP</mtext><mo>+</mo><mtext>FN</mtext></mrow></mfrac><mo>×</mo><mfrac><mtext>TN</mtext><mrow><mtext>TN</mtext><mo>+</mo><mtext>FP</mtext></mrow></mfrac></mrow></msqrt></mrow></math>')
MATH_F = ('<math display="block"><mrow><mtext>F1</mtext><mo>=</mo><mfrac><mrow><mn>2</mn><mo>·</mo><mtext>Precision</mtext><mo>·</mo><mtext>Recall</mtext></mrow><mrow><mtext>Precision</mtext><mo>+</mo><mtext>Recall</mtext></mrow></mfrac>'
          '<mo>=</mo><mfrac><mrow><mn>2</mn><mtext>TP</mtext></mrow><mrow><mn>2</mn><mtext>TP</mtext><mo>+</mo><mtext>FP</mtext><mo>+</mo><mtext>FN</mtext></mrow></mfrac></mrow></math>')
MATH_P = ('<math display="block"><mrow><mtext>Precision</mtext><mo>=</mo><mfrac><mrow><mtext>TPR</mtext><mo>·</mo><mi>π</mi></mrow><mrow><mtext>TPR</mtext><mo>·</mo><mi>π</mi><mo>+</mo><mtext>FPR</mtext><mo>·</mo><mo>(</mo><mn>1</mn><mo>−</mo><mi>π</mi><mo>)</mo></mrow></mfrac>'
          '<mo>,</mo><mspace width="1em"/><mi>π</mi><mo>=</mo><mfrac><mn>1</mn><mrow><mn>1</mn><mo>+</mo><mtext>IR</mtext></mrow></mfrac></mrow></math>')


def cmx(used, title):
    cls = {'TP': 'u', 'FN': 'u', 'FP': 'u', 'TN': 'u'}
    td = lambda k: '<td class="' + (used[k] if k in used else '') + '">' + k + '</td>'
    return ('<table class="cm2"><caption class="sub" style="caption-side:top;text-align:left;padding-bottom:4px">' + title + '</caption><tr><th></th><th>ทายบวก</th><th>ทายลบ</th></tr><tr><th>จริงบวก</th>' + td('TP') + td('FN') +
            '</tr><tr><th>จริงลบ</th>' + td('FP') + td('TN') + '</tr></table>')


def irrow(ir, tpr=0.8, fpr=0.1):
    pi = 1 / (1 + ir); prec = tpr * pi / (tpr * pi + fpr * (1 - pi)); f1 = 2 * prec * tpr / (prec + tpr); g = math.sqrt(tpr * (1 - fpr))
    return prec, f1, g


def q8():
    body = '<p>คำถาม: G-mean กับ F1 ต่างกันอย่างไร ทั้งสองเป็น composite ที่ threshold หนึ่ง และใช้ recall (TPR) เหมือนกัน ความต่างอยู่ที่ "อีกครึ่งหนึ่ง"</p>'
    body += ('<div class="two"><div class="box"><b>G-mean</b><div class="mathd">' + MATH_G + '</div>' + cmx({'TP': 'u', 'FN': 'u', 'TN': 'g', 'FP': 'g'}, 'ใช้ทั้ง 4 ช่อง แยกรายแถว (รายคลาส)') +
             '<p>ถามว่า: <b>แต่ละคลาสถูกกี่เปอร์เซ็นต์</b> แล้วเอามาเฉลี่ยแบบเรขาคณิต. ตัวหารคือจำนวนจริงของแต่ละคลาส จึงไม่สนว่าคลาสไหนใหญ่กว่า</p></div>'
             '<div class="box"><b>F1</b><div class="mathd">' + MATH_F + '</div>' + cmx({'TP': 'u', 'FN': 'u', 'FP': 'o'}, 'ไม่ใช้ TN เลย, FP เทียบกับสิ่งที่ทายว่าบวก') +
             '<p>ถามว่า: <b>คลาสบวกถูกจับได้กี่เปอร์เซ็นต์ และสิ่งที่ทายว่าบวกถูกกี่เปอร์เซ็นต์</b>. ไม่สนคลาสลบที่ทายถูก และ precision ขึ้นกับว่าคลาสลบมีมากแค่ไหน</p></div></div>')
    body += '<div class="box key"><b>จุดที่ทำให้ต่างกันจริง: precision ขึ้นกับสัดส่วนคลาส</b><div class="mathd">' + MATH_P + '</div><p>เมื่อ IR สูง π เล็ก FP จำนวนน้อยในเชิงร้อยละ (FPR) ก็กลายเป็นจำนวนมากเมื่อเทียบกับคลาสบวก precision จึงตก. TNR ไม่มี π อยู่ในสูตร G-mean จึงไม่เปลี่ยน</p></div>'
    rows = [(1,), (10,), (100,)]
    body += ('<h3>classifier ตัวเดิม ต่างแค่ IR <span class="en">Same classifier, different imbalance</span></h3><div class="scroll"><table class="t"><thead><tr><th>IR</th><th class="r">TPR</th><th class="r">FPR</th><th class="r">Precision</th><th class="r">F1</th><th class="r">G-mean</th></tr></thead><tbody>' +
             ''.join('<tr><td>' + str(ir) + '</td><td class="r">0.80</td><td class="r">0.10</td><td class="r">' + f"{irrow(ir)[0]:.3f}" + '</td><td class="r"><b>' + f"{irrow(ir)[1]:.3f}" + '</b></td><td class="r"><b>' + f"{irrow(ir)[2]:.3f}" + '</b></td></tr>' for (ir,) in rows) +
             '</tbody></table></div><p class="note">ความสามารถของ classifier เท่าเดิมทุกแถว. F1 ลดเพราะคลาสลบมากขึ้น ไม่ใช่เพราะ classifier แย่ลง. ข้อนี้ทำให้ค่าเฉลี่ย F1 ข้ามชุดข้อมูลที่ IR ต่างกันมาก (KEEL 1.8 ถึง 130) ปน "ความยากจาก IR" เข้าไปด้วย</p>')
    body += ('<div class="fig"><div class="ft">ลองเอง: G-mean และ F1 เมื่อเลื่อน threshold</div><div class="fs">คลาสลบ ~ N(0, 1), คลาสบวก ~ N(d′, 1). classifier ทายบวกเมื่อ score เกิน threshold. เส้นประสีฟ้า = threshold ที่ข้อมูลฝึกแบบ 1:1 ให้ (resample แล้ว), เส้นประสีเทา = threshold ที่ classifier ไม่ resample ใช้ (ทำ accuracy สูงสุดที่ IR นั้น)</div>'
             '<div class="ctl"><label>IR <input type="range" id="th-ir" min="0" max="2.3" step="0.01" value="1"><output id="th-iro">10</output></label><label>d′ (แยกคลาสได้แค่ไหน) <input type="range" id="th-d" min="0.5" max="3" step="0.1" value="1.5"><output id="th-do">1.5</output></label></div>'
             '<div class="lg"><span><i class="ln" style="background:var(--m1)"></i>G-mean</span><span><i class="ln" style="background:var(--m2)"></i>F1</span></div><div id="th"></div><div class="calc2" id="th-out"></div></div>')
    body += ('<div class="box"><b>อ่านกราฟนี้</b><ul class="list"><li>จุดสูงสุดของ G-mean อยู่ที่ threshold = d′/2 เสมอ ไม่ว่า IR เท่าไร และตรงกับเส้นประสีฟ้าพอดี: resample แบบ 1:1 พา classifier ไปที่จุดที่ G-mean ชอบที่สุด</li>'
             '<li>จุดสูงสุดของ F1 เลื่อนไปทางขวาเมื่อ IR สูงขึ้น (ต้องระวังทายบวกมากขึ้นเพื่อรักษา precision) จึงอยู่ระหว่างสองเส้นประ: resample ช่วย F1 น้อยกว่า และถ้า IR สูงมากอาจทำให้ F1 แย่ลง</li>'
             '<li>นี่คือเหตุที่ในผลของเรา SMOTE ชนะ None ด้วย G-mean 78% แต่ด้วย F1 58%</li></ul></div>')
    cr = X['cross']
    body += ('<h3>ในผลทดลองของเรา: สองตัวนี้เลือกวิธีที่ดีที่สุดตรงกันไหม <span class="en">Agreement in our runs</span></h3><div class="scroll"><table class="t hm"><thead><tr><th>ดีสุดตาม G-mean ↓ / ตาม F1 →</th>' + ''.join('<th class="c">' + me + '</th>' for me in METH) + '<th class="r">รวม</th></tr></thead><tbody>')
    mx = max(cr[r][c] for r in cr for c in METH)
    for r in METH:
        if r not in cr:
            continue
        body += '<tr><td class="mt"><i class="sw" style="background:var(--' + MCOL[r] + ')"></i> ' + r + '</td>'
        for c in METH:
            v = cr[r][c]; pc = round(6 + 74 * v / mx)
            body += '<td class="v' + (' hi' if r == c else '') + '" style="background:color-mix(in oklab,var(--c1) ' + str(pc) + '%,var(--paper));color:' + ('#fff' if pc > 52 else 'var(--ink)') + '" data-tip="G-mean เลือก ' + r + ', F1 เลือก ' + c + ': ' + str(v) + ' กรณี">' + str(v) + '</td>'
        body += '<td class="r">' + str(sum(cr[r].values())) + '</td></tr>'
    body += '</tbody></table></div>'
    pa = X['pooled']
    body += ('<p class="note">550 กรณี (110 ชุดข้อมูล × 5 classifier). ตรงกัน ' + str(X['best_agree']['same']) + ' กรณี (' + str(pct(X['best_agree']['same'], 550)) + '%). ที่ไม่ตรงกันส่วนใหญ่คือ G-mean เลือก SMOTE แต่ F1 เลือกวิธีอื่น (100 กรณี) '
             'และ F1 เลือก None ที่ G-mean ไม่เลือก (56 กรณี). Spearman ระหว่างค่า G-mean กับ F1 ทุกแถว = ' + f"{X['corr']['Gmean']['F1']:.2f}" + ': ค่าเคลื่อนไปด้วยกันแต่<b>อันดับของวิธีต่างกัน</b> '
             'average rank (รวม 550 block แบบ RESULTS.md): G-mean ให้ SMOTE ' + f"{pa['Gmean']['SMOTE']:.2f}" + ' ดีสุด, F1 ให้ QC-SMOTE ' + f"{pa['F1']['QC-SMOTE']:.2f}" + ' และ CISO ' + f"{pa['F1']['CISO']:.2f}" + '</p>')
    body += ('<div class="two"><div class="box key"><b>ใช้ G-mean เมื่อ</b><ul class="list"><li>ความผิดพลาดของทั้งสองคลาสสำคัญ (เช่น วินิจฉัยโรค: พลาดคนป่วยและเตือนคนปกติผิดล้วนมีต้นทุน)</li><li>เทียบหลายชุดข้อมูลที่ IR ต่างกันมาก</li><li>มีหลายคลาส (ใช้ MG)</li><li>classifier ให้แค่ label</li></ul></div>'
             '<div class="box key"><b>ใช้ F1 เมื่อ</b><ul class="list"><li>สนใจคลาสบวกเป็นหลัก และต้นทุนอยู่ที่ "ทายว่าบวกแล้วผิด" (เช่น ส่งเคสให้คนตรวจต่อ, ค้นเอกสาร)</li><li>คลาสลบเป็นพื้นหลังที่ไม่ต้องรายงาน</li><li>ต้องเทียบกับงานด้าน retrieval หรือ detection</li></ul></div></div>'
             '<div class="box warn"><b>ข้อแนะนำสำหรับงานของเรา</b><p>รายงานทั้งคู่และเพิ่ม measure จัดอันดับ (AUC, PR-AUC) เพราะสามตัวนี้ตอบคนละคำถาม และในผลของเราให้ผู้ชนะต่างกัน (G-mean: SMOTE, F1: QC-SMOTE/CISO, PR-AUC: None). ถ้าเลือกได้ตัวเดียวเป็น measure หลัก ต้องประกาศก่อนดูผล และบอกเหตุผลจากโจทย์ ไม่ใช่จากผล</p></div>')
    body += sentence('G-mean and F1 share recall but differ in their second component: G-mean uses the true negative rate, which is independent of the class prior, whereas F1 uses precision, which falls with the imbalance ratio even for an unchanged classifier (at TPR = 0.8 and FPR = 0.1, F1 drops from 0.84 at IR = 1 to 0.14 at IR = 100 while G-mean stays at 0.85). In our experiments the two measures pick the same best method in only ' + str(pct(X['best_agree']['same'], 550)) + '% of dataset-classifier pairs.')
    sec('q8', 'Q8', 'G-mean ต่างจาก F1 อย่างไร', 'G-mean versus F1', body)


# ---------------------------------------------------------------- consistency with the Method and Data sections
def cons():
    rows = [
        ('รายชื่อ paper', '76 เรื่อง (Method Map, commit ea1eaa8)', '76 เรื่อง พร้อมตารางจับคู่กับ key ของเรา (section7_key_map.csv)', '76 เรื่อง มีการทดลอง 71', 'ok', 'ตรงกัน'),
        ('ตระกูล SMOTE', '37 = Core 34 + Partial 3', 'ไม่ได้แยก', 'ใช้รายชื่อ 37 ของ Method ตรง ๆ ทุกเรื่องอยู่ใน 71 งานที่มีการทดลอง', 'ok', 'ตรงกัน'),
        ('หมวดคลาส', 'Binary only 24, Multiclass only 5, Binary + Multiclass 8 (ตรวจกับ PDF แล้ว)', 'ไม่ได้แยก', 'การลงรหัส setting ของเราตรงกับ Method 34/37 ต่างกัน 3: GAMO และ MC-MBRC (เราลง multiclass, Method ลง Binary + Multiclass), Loyalty-SMOTE (เราลง both, Method ลง Binary only)', 'warn', 'ใช้ของ Method'),
        ('ปีของ CISO', '2026', '2025', '2025 (arXiv v1, 2025)', 'warn', 'ต้องตกลง'),
        ('SMOTE 2002', 'C4.5, Ripper, Naive Bayes; AUC, ROC convex hull, Acc+, Acc-', 'ไม่ได้ลงรหัส', 'C4.5, Ripper, Naive Bayes; AUC, ROC curve และ convex hull, TPR, TNR (Acc+ = TPR, Acc- = TNR)', 'ok', 'ตรงกัน'),
        ('ตัวเลขที่ใช้ได้', 'ตรวจกับ PDF แล้ว', 'ทุกตัวยังเป็น ai_draft (README ของ Data)', 'ผ่านการตรวจรอบ 2 (pass-2) มีหน้าอ้างอิง', 'note', 'ไม่อ้างตัวเลขของ Data'),
        ('กฎ W/T/L ของ Data (ทางเลือก A)', 'n/a', 'ล็อก measure เดียวต่อ paper ลำดับ G-mean > AUC > F1 > accuracy', 'จำนวนงานที่รายงาน: G-mean 41, F1/F-measure 35, AUC 33, accuracy 13. measure หลักที่ประกาศ: AUC 16, G-mean 7', 'note', 'ลำดับใช้ได้ ดูหมายเหตุ')]
    body = '<p>ส่วนนี้ตรวจว่าตัวเลขและนิยามของส่วน Evaluation ใช้ฐานเดียวกับส่วน Method (P / S1xzy) และ Data (Toon / Kanvara001) ใน repo ณ commit ea1eaa8 (ตรงกับ origin/main วันที่ 8 พ.ย. 2026)</p>'
    body += ('<div class="scroll"><table class="t cons wide"><thead><tr><th>เรื่อง</th><th>Method section</th><th>Data section</th><th>Evaluation (ส่วนนี้)</th><th>สถานะ</th></tr></thead><tbody>' +
             ''.join('<tr><td><b>' + a + '</b></td><td>' + b + '</td><td>' + c + '</td><td>' + d + '</td><td><span class="st2 s-' + s + '">' + t + '</span></td></tr>' for a, b, c, d, s, t in rows) + '</tbody></table></div>')
    body += ('<div class="two"><div class="box"><b>ที่ส่วนนี้ใช้จากอีกสองส่วน</b><ul class="list"><li>รายชื่อ 37 เรื่องและหมวดคลาสของ Method ใช้ในข้อ 1 (measure ตามหมวดคลาส) และข้อ 5</li><li>สีของหมวดคลาสใช้ชุดเดียวกับหน้า "SMOTE Family at 25"</li>'
             '<li>ข้อค้นพบเรื่องชุดข้อมูล (KEEL, จำนวนชุด, การดัดแปลงชุดข้อมูล) ปล่อยให้ส่วน Data เป็นเจ้าของ ส่วนนี้พูดแค่ผลต่อการวัด (5-fold ของ KEEL)</li></ul></div>'
             '<div class="box warn"><b>ฝากถึงทีม</b><ul class="list"><li><b>Method</b>: ปีของ CISO ควรตรงกันทั้ง 3 ส่วน (Data กับ Evaluation ใช้ 2025)</li>'
             '<li><b>Evaluation (เรา)</b>: จะปรับหมวดคลาสของ GAMO, MC-MBRC, Loyalty-SMOTE ตาม Method ที่ตรวจกับ PDF แล้ว</li>'
             '<li><b>Data</b>: ลำดับ measure ของทางเลือก A ขึ้นกับเป้าหมาย. ถ้าต้องการ N มากที่สุดควรเรียงตามจำนวนงานที่รายงาน (G-mean, F1, AUC, accuracy); ถ้าต้องการตรงกับสิ่งที่ผู้เขียนตั้งใจเป็นหลักควรใช้ measure หลักที่ paper ประกาศก่อน (AUC 16 งาน). '
             'ข้อ 8 แสดงว่า G-mean กับ F1 เลือกผู้ชนะตรงกันแค่ 65% ในผลของเรา การเลือกลำดับจึงเปลี่ยนผล W/T/L ได้จริง</li></ul></div></div>')
    sec('team', '9', 'ความสอดคล้องกับส่วน Method และ Data', 'Consistency with the team', body)


def sources():
    body = ('<ul class="list"><li>ข้อมูลที่ลงรหัสของหัวข้อที่ 7: data.json (76 เรื่อง, 71 มีการทดลอง) และ pass-2 (r2) ที่ตรวจกับ PDF พร้อมเลขหน้า, ใน "Evaluation section/section07-coded-data.json"</li>'
            '<li>สรุปตามช่วงปีและงานอ้างอิง: v2/analysis.json (roadmap 46 แถว, refs 19 งาน) ยอดอ้างอิงจาก OpenAlex ณ 18 ต.ค. 2026</li>'
            '<li>รายชื่อตระกูล SMOTE 37 เรื่องและหมวดคลาส: SMOTE25_Method_Map_1.html และ "Method section/" (commit 339e6cc, ea1eaa8)</li>'
            '<li>Data section: ใช้แค่ section7_key_map.csv และกฎ W/T/L ใน decisions-pending.md ไม่ได้ใช้ตัวเลข ai_draft</li>'
            '<li>ผลทดลองของเรา: experiment/results_mean.csv และ results_raw.csv (31 ส.ค. 2026): 110 KEEL datasets × 5 วิธี × 5 classifier × 5-fold stratified CV รันครั้งเดียว. '
            'CISO และ QC-SMOTE เป็นการเขียนขึ้นใหม่จาก paper. การวิเคราะห์ในหน้านี้ (rank ราย classifier N = 110, Friedman/Iman-Davenport, Wilcoxon + Holm, Nemenyi CD) คำนวณใหม่จากไฟล์ดิบ</li>'
            '<li>สคริปต์: evalpage/facts.py, exp.py, build_evalpage.py ใน section07-empirical-build-source-v3.zip</li></ul>'
            '<p class="note">ข้อจำกัดของผลทดลองที่ใช้เป็นตัวอย่าง: CV 5 fold ครั้งเดียว (ควรทำซ้ำอย่างน้อย 5 ครั้ง), ไม่มี baseline แบบ class weight หรือ ROS, ไม่มี gradient boosting, ไม่ได้วัด runtime. '
            'ตัวเลขจึงใช้แสดงรูปแบบการรายงาน ไม่ใช่ผลสุดท้ายของ paper</p>')
    sec('src', '10', 'แหล่งข้อมูลและข้อจำกัด', 'Sources and limits', body)


# ---------------------------------------------------------------- page
def build():
    for f in (s0, q1, q2, q3, q4, q5, q6, q7, q8, cons, sources):
        f()
    css = open(R + 'guide/primer_style.css').read() + open(P + 'extra.css').read()
    js = open(P + 'page.js').read()
    data = dict(meth=METH, meas=MEAS, CD=X['CD'], per={k: {kk: v[kk] for kk in ('ar', 'pF', 'FF', 'holm', 'mean')} for k, v in X['per'].items()}, vals=X['vals'])
    dj = json.dumps(data, separators=(',', ':')).replace('</', '<\\/')
    page = ('<title>SMOTE25 Evaluation, Tan</title>\n<meta name="claude:viewport-fit-sides" content="cover">\n'
            '<link rel="preconnect" href="https://fonts.googleapis.com">\n<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>\n'
            '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500&family=IBM+Plex+Sans+Thai:wght@400;500;600;700&family=Noto+Serif+Thai:wght@400;600&family=STIX+Two+Text:ital,wght@0,400;0,600;1,400&display=swap">\n'
            '<style>\n' + css + '</style>\n'
            '<div class="wrap"><header class="top"><div class="eyebrow">SMOTE25 · หัวข้อที่ 7 Evaluation · ส่วนของ Tan</div>'
            '<h1>การวัดผลในงานตระกูล SMOTE ตลอด 25 ปี: วัดด้วยอะไร เปลี่ยนไปอย่างไร และเพราะอะไร</h1>'
            '<p class="lede">ตอบ 8 คำถามจากงานที่มีการทดลอง 71 เรื่อง (ในนั้นเป็นตระกูล SMOTE 37 เรื่องตามรายชื่อของส่วน Method) ใช้รายชื่อ paper ชุดเดียวกับส่วน Method และ Data '
            'ตัวเลขมาจากข้อมูลที่ลงรหัสไว้ของหัวข้อที่ 7 และรูปตัวอย่างทำจากผลทดลองของเราเอง (110 KEEL datasets) แต่ละข้อมีประโยคภาษาอังกฤษสำหรับใส่ใน paper</p></header>'
            '<div class="layout"><nav class="toc" aria-label="สารบัญ"><details id="tocd" open><summary>สารบัญ</summary><ol>' +
            ''.join('<li><a href="#' + a + '"><span>' + n + '</span><span>' + t + '</span></a></li>' for a, n, t in TOC) +
            '</ol></details></nav><main class="sheet">' + '\n'.join(SECS) +
            '<div class="foot"><span>ตัวเลขจากข้อมูลที่ลงรหัสของหัวข้อที่ 7 (76 เรื่อง มีการทดลอง 71) · ยอดอ้างอิงจาก OpenAlex ณ 18 ต.ค. 2026 · ตระกูล SMOTE 37 เรื่องจากส่วน Method (commit ea1eaa8) · ผลทดลองของเราจาก experiment/ (31 ส.ค. 2026)</span>'
            '<span>ใช้คู่กับ SMOTE25_Evaluation_Section, Roadmap, Primer และ Guide · ปรับปรุง 8 พ.ย. 2026</span></div>'
            '</main></div></div>\n<script type="application/json" id="evdata">' + dj + '</script>\n'
            '<script>\n(function(){var d=document.getElementById("tocd");if(d&&window.matchMedia("(max-width:900px)").matches)d.open=false;})();\n' + js + '</script>\n')
    assert '—' not in page, 'em-dash'
    open(P + 'smote25_evaluation_tan.html', 'w').write(page)
    i = page.index('</style>\n') + len('</style>\n')
    doc = ('<!doctype html>\n<html lang="th">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n'
           + page[:i] + '</head>\n<body>\n' + page[i:] + '\n</body>\n</html>\n')
    open(P + 'section07-evaluation-tan.html', 'w').write(doc)
    print('page bytes', len(page.encode()), 'data bytes', len(dj), 'sections', len(SECS))


if __name__ == '__main__':
    build()
