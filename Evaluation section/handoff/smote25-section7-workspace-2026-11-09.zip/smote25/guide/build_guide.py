"""SMOTE25 evaluation guide: for each evaluation topic, (1) what the 71 empirical studies did,
(2) what we should use and why, with references and their OpenAlex citation counts, and
(3) what a reader of our paper needs to be told. Numbers come from data.json and v2/analysis.json."""
import json, html, re

R = '/home/claude/smote25/'
D = json.load(open(R + 'data.json'))
AN = json.load(open(R + 'v2/analysis.json'))
BY = {p['key']: p for p in D}
EMP = [p for p in D if p['empirical']]
RM = {r['label']: r for r in AN['roadmap']}
INF = {r['key']: r for r in AN['influence']}
REF = {r['key']: r for r in AN['refs']}
ERA = ['≤2009', '2010-2015', '2016-2020', '2021-2026']
ERA_TH = ['ถึง 2009', '2010–15', '2016–20', '2021–26']
ERA_N = AN['era_n']
esc = html.escape
assert len(EMP) == 71

# ------------------------------------------------------------------ references (OpenAlex counts, 18 Oct 2026)
def cpy(c, y):
    return c / (2026 - y + 1) if c is not None else None

SRC = {}  # key -> dict(label, year, venue, cites, kind)
for k, r in REF.items():
    SRC[k] = dict(label=r['label'], year=r['pub_year'], venue=r.get('venue') or '', cites=r['cites'], title=r.get('title') or '', kind='ref')
SRC['REF-UCI']['venue'] = ''
for k in ['SMOTE-2002', 'KMeansSMOTE-2018', 'G-SMOTE-2019', 'CISO-2025', 'SMOTE-IPF-2015', 'SPIDER2-2010', 'MC-CCR-2020', 'MC-RBO-2020',
          'LS-2008', 'A-SUWO-2016', 'RBBoost-2015', 'RUSBoost-2010', 'CTGAN-2019', 'MLOS-2025', 'GDHS-2025', 'SHSampler-2022', 'RBO-2019',
          'MWMOTE-2014', 'MDO-2016', 'QC-SMOTE-2026', 'SPE-2020', 'GLOS-2023']:
    p = BY[k]
    SRC[k] = dict(label=p['short'] + ' ' + str(p['year']), year=p['year'], venue=p.get('venue') or '', cites=p.get('cites'), title=p.get('title') or '', kind='corpus')
for _k in SRC:
    SRC[_k]['title'] = SRC[_k]['title'].replace('$k$ -Fold', 'k-Fold').replace('$k$', 'k')
    if len(SRC[_k]['venue']) > 70:
        SRC[_k]['venue'] = SRC[_k]['venue'][:68].rstrip() + '…'
USED = {}  # key -> set of topic numbers that cite it


def cite(k, topic):
    USED.setdefault(k, set()).add(topic)
    s = SRC[k]
    return '<span class="cite" title="' + esc(s['title']) + '">' + esc(s['label']) + ' · <b>' + (f"{s['cites']:,}" if s['cites'] is not None else 'n/a') + '</b> cites</span>'


def evidence(rows, topic):
    """rows: (key, what it supports)"""
    h = '<div class="scroll"><table class="t ev"><thead><tr><th>งาน</th><th class="r">ปี</th><th class="r">ยอดอ้างอิง</th><th>ใช้สนับสนุนเรื่อง</th></tr></thead><tbody>'
    for k, what in rows:
        USED.setdefault(k, set()).add(topic)
        s = SRC[k]
        h += '<tr><td><b>' + esc(s['label']) + '</b><div class="sub">' + esc(s['title'][:110]) + (' · ' + esc(s['venue']) if s['venue'] else '') + '</div></td><td class="r">' + str(s['year']) + '</td><td class="r">' + (f"{s['cites']:,}" if s['cites'] is not None else 'n/a') + '</td><td>' + what + '</td></tr>'
    return h + '</tbody></table></div>'


# ------------------------------------------------------------------ small components
def trend(rows):
    """rows: (roadmap label, Thai label)"""
    TR = {'rising': ('เพิ่มขึ้น', 'up'), 'declining': ('ลดลง', 'down'), 'stable': ('ทรงตัว', 'flat'), 'new': ('เพิ่งเริ่ม', 'new'), 'abandoned': ('เลิกใช้', 'gone')}
    h = '<div class="scroll"><table class="t trend"><thead><tr><th>แนวปฏิบัติ</th><th class="r">รวม</th>' + ''.join(
        '<th class="c">' + ERA_TH[i] + '<div class="sub">' + str(ERA_N[e]) + ' งาน</div></th>' for i, e in enumerate(ERA)) + '<th>แนวโน้ม</th></tr></thead><tbody>'
    for lab, th in rows:
        r = RM[lab]
        t = TR.get(r.get('trend'), ('', 'flat'))
        h += '<tr><td>' + th + '</td><td class="r"><b>' + str(r['n']) + '</b>/71</td>' + ''.join(
            '<td class="c"><span class="cell"><i style="width:' + str(r['share'][e]) + '%"></i><span>' + str(r['share'][e]) + '%</span></span></td>' for e in ERA) + \
            '<td><span class="tchip t-' + t[1] + '">' + t[0] + '</span></td></tr>'
    return h + '</tbody></table></div><p class="note">ตัวเลขในช่องคือร้อยละของงานในช่วงปีนั้นที่ทำแนวปฏิบัตินี้</p>'


def mult(rows):
    """citation multipliers: (influence key, Thai label)"""
    h = '<div class="mults">'
    for k, th in rows:
        r = INF[k]
        v = 'low' if r['hi'] < 1 else 'high' if r['lo'] > 1 else 'near' if (r['lo'] >= 0.95 or r['hi'] <= 1.05) else 'none'
        vt = {'low': 'ถูกอ้างอิงน้อยกว่าจริง', 'high': 'ถูกอ้างอิงมากกว่าจริง', 'near': 'เกือบถึงเกณฑ์', 'none': 'ไม่ต่าง'}[v]
        h += '<span class="mult m-' + v + '">' + th + ' <b>×' + f"{r['ratio']:.2f}" + '</b> <small>(' + f"{r['lo']:.2f}–{r['hi']:.2f}" + ') ' + vt + '</small></span>'
    return h + '</div>'


def bars(items, of=71):
    """items: (label, n, color)"""
    h = '<div class="hbars">'
    for lab, n, *c in items:
        col = c[0] if c else 'c1'
        h += '<div class="hb"><span class="hl">' + lab + '</span><span class="ht"><i style="width:' + f"{100 * n / of:.1f}" + '%;background:var(--' + col + ')"></i></span><span class="hv">' + str(n) + '<em>/' + str(of) + '</em></span></div>'
    return h + '</div>'


ST = {'ok': ('มีแล้ว', 'ok'), 'add': ('ควรเพิ่ม', 'add'), 'fix': ('ควรแก้', 'fix'), 'note': ('ต้องเขียนบอก', 'note')}


def ours(items):
    return '<div class="ours"><div class="oh">การทดลองของเราตอนนี้ <span class="sub">experiment/RESULTS.md, 31 ส.ค. 2026</span></div><ul>' + ''.join(
        '<li><span class="st s-' + ST[s][1] + '">' + ST[s][0] + '</span><span>' + t + '</span></li>' for s, t in items) + '</ul></div>'


CHECK = []  # (topic, id, text)


def write(topic, items, sentence):
    h = '<ul class="chk">'
    for i, t in enumerate(items):
        cid = f'c{topic}-{i}'
        CHECK.append((topic, cid, t))
        h += '<li><label><input type="checkbox" data-c="' + cid + '"><span>' + t + '</span></label></li>'
    h += '</ul>'
    if sentence:
        h += '<div class="sent"><div class="sl">ตัวอย่างประโยคใน paper</div><p lang="en">' + sentence + '</p></div>'
    return h


TOPICS = []


def topic(n, tid, th, en, did, choose, tell, summary):
    TOPICS.append((n, tid, th, en, summary))
    return ('<section class="s topic" id="' + tid + '"><h2><span class="n">' + str(n) + '</span><span>' + th + ' <span class="en">' + en + '</span></span></h2>' +
            '<div class="part p1"><div class="ph"><span class="pn">1</span>งานทั้ง 71 เรื่องทำอะไร</div>' + did + '</div>' +
            '<div class="part p2"><div class="ph"><span class="pn">2</span>ถ้าเป็นเรา ควรเลือกอะไร และเพราะอะไร</div>' + choose + '</div>' +
            '<div class="part p3"><div class="ph"><span class="pn">3</span>ถ้าเขียนลง paper ผู้อ่านต้องรู้อะไร</div>' + tell + '</div></section>')


def ex(keys):
    return ', '.join(esc(BY[k]['short'] + ' ' + str(BY[k]['year'])) + ' (' + f"{BY[k]['cites']:,}" + ')' for k in keys)


SECS = []

# =================================================================== 1 data
SECS.append(topic(1, 't-data', 'ข้อมูลที่ใช้ทดสอบ', 'Benchmark data',
    '<p>เกือบทุกงานใช้ข้อมูลตารางสาธารณะ จำนวนชุดข้อมูลจริงต่องานมีค่ากลาง <b>18 ชุด</b> (ครึ่งกลางอยู่ระหว่าง 9 ถึง 30 ชุด น้อยสุด 1 มากสุด 86) และเพิ่มขึ้นตามเวลา งานที่ใช้ไม่ถึง 10 ชุดลดจาก 64% เหลือ 4%</p>' +
    trend([('UCI repository', 'ใช้ข้อมูลจาก UCI'), ('KEEL repository', 'ใช้ข้อมูลจาก KEEL'), ('Synthetic data', 'มีข้อมูลสังเคราะห์'), ('Private or application data', 'มีข้อมูลที่ไม่เปิดเผย'),
           ('Fewer than 10 real datasets', 'ใช้ข้อมูลจริงไม่ถึง 10 ชุด'), ('Reason for data stated', 'บอกเหตุผลที่เลือกข้อมูล')]) +
    '<h4>เหตุผลที่เขียนไว้ และการดัดแปลงข้อมูล</h4>' +
    bars([('ให้ครอบคลุม IR ขนาด หรือมิติที่ต่างกัน', 30), ('ได้ระดับ IR ที่ต้องการ', 19), ('ใช้ตามการทดลองของงานก่อนหน้า', 18), ('มีปัจจัยความยาก (ซ้อนทับ noise ฯลฯ)', 17),
          ('เพื่อเทียบกับผลที่ตีพิมพ์แล้ว', 14), ('เพราะโหลดได้สาธารณะ', 12, 'c3'), ('ดัดแปลงข้อมูลก่อนใช้', 52, 'c2'), ('ปล่อยชุดที่ดัดแปลงแล้ว', 10, 'c2')]) +
    '<p>ชุดข้อมูลถูกส่งต่อเป็นสาย เช่น ชุดหลายคลาสจาก KEEL ที่ Sáez et al. (2016) คัดไว้ ถูก MC-RBO และ MC-CCR (2020) ใช้ แล้วต่อไปที่ NROMM (2023) คลังข้อมูลได้เครดิตเอง: UCI ' + cite('REF-UCI', 1) + ' และ KEEL ' + cite('REF-KEEL-2011', 1) + ' แต่ตัวคูณการอ้างอิงของงานที่ใช้ข้อมูลแบบต่าง ๆ ใกล้ 1 ทั้งหมด</p>' +
    mult([('keel', 'ใช้ KEEL'), ('uci', 'ใช้ UCI'), ('many_ds', 'ใช้ 18 ชุดขึ้นไป'), ('private', 'มีข้อมูลที่ไม่เปิดเผย'), ('data_reason', 'บอกเหตุผล')]),
    '<ol class="rec">'
    '<li><b>ใช้ชุดข้อมูลไม่สมดุลของ KEEL เป็นแกนหลัก อย่างน้อย 30 ชุด</b> ครอบคลุม IR ตั้งแต่ราว 1.5 ถึงมากกว่า 100 และขนาดกับจำนวนมิติที่ต่างกัน</li>'
    '<li><b>เพิ่มชุดข้อมูลสังเคราะห์ที่ควบคุมได้</b> 4 ถึง 8 ชุด ที่ปรับการซ้อนทับ IR และกลุ่มย่อยเล็กทีละปัจจัย</li>'
    '<li><b>วัดความยากของแต่ละชุด</b> เช่น สัดส่วนตัวอย่าง safe, borderline, rare, outlier หรือ complexity measures แล้วใช้อธิบายว่าวิธีชนะที่ไหน</li>'
    '<li><b>ถ้าจะอ้างว่าใช้กับหลายคลาส ต้องคงหลายคลาสไว้</b> ไม่ยุบเหลือสองคลาส</li>'
    '<li><b>ปล่อยไฟล์ข้อมูลที่ใช้จริงและการแบ่ง fold</b></li></ol>'
    '<div class="why"><b>เพราะ</b><ul>'
    '<li>KEEL มีชุดไม่สมดุลที่ตั้งชื่อตามการแบ่งคลาส ทำให้คนอื่นหาชุดเดียวกันได้ และกลายเป็นมาตรฐานของงานรุ่นหลัง (0% ก่อนปี 2010 เป็น 67% ในงานตั้งแต่ 2021)</li>'
    '<li>การทดสอบทางสถิติใช้ชุดข้อมูลเป็นหน่วย ยิ่งมีชุดมาก ผลยิ่งเชื่อถือได้ ' + cite('REF-Demsar-2006', 1) + '</li>'
    '<li>IR อย่างเดียวไม่บอกความยาก การซ้อนทับ กลุ่มย่อยเล็ก และ noise กระทบผลมากกว่า ' + cite('REF-Lopez-2013', 1) + ' ' + cite('REF-NapieralaStefanowski-2016', 1) + '</li>'
    '<li>52 จาก 71 เรื่องดัดแปลงข้อมูล แต่ปล่อยเพียง 10 เรื่อง ผลส่วนใหญ่จึงทำซ้ำไม่ได้ทั้งที่ข้อมูลต้นฉบับเปิดเผย</li>'
    '<li>การใช้ KEEL หรือ UCI ไม่ได้เพิ่มยอดอ้างอิง (×1.12 และ ×0.97) เลือกเพราะทำซ้ำได้ ไม่ใช่เพราะจะได้อ้างอิงมาก</li></ul></div>' +
    evidence([('REF-KEEL-2011', 'ชุดข้อมูลไม่สมดุลของ KEEL'), ('REF-KEEL-2009', 'ซอฟต์แวร์และคลัง KEEL'), ('REF-UCI', 'แหล่งต้นฉบับของชุดคลาสสิก'),
              ('REF-Demsar-2006', 'ใช้ชุดข้อมูลหลายชุดเป็นหน่วยของการทดสอบ'), ('REF-Lopez-2013', 'ลักษณะเฉพาะของข้อมูลที่ทำให้ยาก'),
              ('REF-NapieralaStefanowski-2016', 'ประเภทตัวอย่าง safe, borderline, rare, outlier'), ('REF-HoBasu-2002', 'complexity measures ของชุดข้อมูล'),
              ('SPIDER2-2010', 'ข้อมูลสังเคราะห์ที่ควบคุมปัจจัยความยาก'), ('KMeansSMOTE-2018', '80 ชุดจริง + 10 ชุดสังเคราะห์ และปล่อยโค้ด'),
              ('RBBoost-2015', '87 ชุดข้อมูล')], 1) +
    ours([('ok', '110 ชุดจาก KEEL'), ('ok', 'คำนวณ IR ของทุกชุด'), ('add', 'ชุดข้อมูลสังเคราะห์ที่ควบคุมปัจจัย'), ('add', 'ค่าความยากของแต่ละชุด (safe/borderline/rare/outlier หรือ overlap)'),
          ('add', 'ปล่อยไฟล์ที่ใช้จริงและดัชนีของแต่ละ fold')]),
    write(1, ['แหล่งข้อมูลและชื่อชุดตาม KEEL หรือ UCI พร้อมวันที่ดาวน์โหลด',
              'ตารางลักษณะของทุกชุด: จำนวนตัวอย่าง จำนวนฟีเจอร์ จำนวนคลาส และ IR พร้อมนิยามของ IR ที่ใช้',
              'การเตรียมข้อมูล: แปลงเป็นสองคลาสอย่างไร เข้ารหัสตัวแปรกลุ่มอย่างไร จัดการค่าที่หายอย่างไร',
              'เหตุผลที่เลือกชุดเหล่านี้ เช่น ช่วงของ IR และความยาก ไม่ใช่แค่ "ใช้กันแพร่หลาย"',
              'ที่อยู่ของไฟล์ที่ใช้จริงและการแบ่ง fold'],
          'We use the [N] imbalanced binary datasets of the KEEL repository (Alcalá-Fdez et al., 2011), whose imbalance ratios range from [min] to [max]. Table [X] lists the size, dimension, imbalance ratio and the share of borderline and rare minority examples of each dataset; the processed files and fold assignments are available at [URL].'),
    'KEEL ≥30 ชุด + ข้อมูลสังเคราะห์ + วัดความยาก + ปล่อยไฟล์'))

# =================================================================== 2 learners
SECS.append(topic(2, 't-learners', 'ตัวจำแนกพื้นฐาน', 'Base learners',
    '<p>ค่ากลางคือ 3 ตัวจำแนกต่องาน แต่ <b>25 จาก 71 เรื่องใช้ตัวเดียว</b> และสัดส่วนนี้ไม่ลดลง C4.5 เคยเป็นตัวหลักแต่ลดลงตั้งแต่ปี 2016 ขณะที่ random forest และ gradient boosting เพิ่มขึ้น</p>' +
    trend([('C4.5/C5.0', 'C4.5 / C5.0'), ('k-NN', 'k-NN'), ('SVM', 'SVM'), ('Random forest or gradient boosting', 'Random forest หรือ gradient boosting'),
           ('Single base learner', 'ใช้ตัวจำแนกตัวเดียว'), ('Reason for learners stated', 'บอกเหตุผลที่เลือก')]) +
    '<h4>เหตุผลที่ใช้เลือกตัวจำแนก (49 เรื่องที่บอก)</h4>' +
    bars([('นิยมใช้หรือเป็นที่รู้จัก', 22), ('ครอบคลุม classifier หลายแบบ', 15), ('ตามงานก่อนหน้า', 11), ('เรียบง่ายหรือเร็ว', 10), ('ตัวเดียวกันทุกวิธีเพื่อความยุติธรรม', 8),
          ('ไวต่อความไม่สมดุล', 4, 'c2')]) +
    mult([('multi_clf', 'ใช้มากกว่าหนึ่งตัว'), ('ens_clf', 'ใช้ RF หรือ boosting'), ('learner_reason', 'บอกเหตุผล')]),
    '<ol class="rec">'
    '<li><b>ใช้อย่างน้อย 4 ตัวจากคนละตระกูล</b>: ต้นไม้ตัดสินใจ (CART หรือ C4.5), k-NN, โมเดลเส้นตรงหรือ margin (logistic regression, SVM) และ ensemble ที่แข็งแรง (random forest และ gradient boosting)</li>'
    '<li><b>ตั้งค่าตัวจำแนกให้เหมือนกันทุกวิธีปรับสมดุล</b> และบอกค่าทั้งหมด</li>'
    '<li><b>รายงานผลแยกตามตัวจำแนก</b> ไม่ใช่แค่ค่าเฉลี่ยรวม</li></ol>'
    '<div class="why"><b>เพราะ</b><ul>'
    '<li>ผลของการปรับสมดุลขึ้นกับตัวจำแนก ในการทดลองของเราเอง G-mean ของ LR, SVM และ k-NN เพิ่มจากราว 0.56–0.63 เป็น 0.77–0.83 แต่ RF และ CART ได้ประโยชน์น้อยกว่า</li>'
    '<li>ตัวจำแนกที่แข็งแรงลดประโยชน์ของการปรับสมดุล งานที่ลงทะเบียนแผนล่วงหน้าพบว่าวิธีใหม่ไม่ดีกว่า class weighting หรือไม่ปรับเลย เมื่อทดสอบกับ RF และ gradient boosting ' + cite('CISO-2025', 2) + '</li>'
    '<li>ใช้ตัวเดียว แยกไม่ได้ว่าผลมาจากวิธี หรือจากการที่วิธีเข้ากับตัวจำแนกนั้นพอดี</li>'
    '<li>k-NN ใช้หลักเพื่อนบ้านแบบเดียวกับ SMOTE จึงไวต่อตำแหน่งของจุดสังเคราะห์ ส่วนต้นไม้ไวต่อการตัดกิ่งที่ลบกฎของคลาสส่วนน้อย</li></ul></div>' +
    evidence([('KMeansSMOTE-2018', 'ใช้ LR, k-NN และ gradient boosting'), ('CISO-2025', '4 ตัวจำแนกรวม RF และ gradient boosting และลงทะเบียนแผน'),
              ('MC-CCR-2020', '4 ตัวจำแนกในงานหลายคลาส'), ('RUSBoost-2010', '3 ตัวจำแนก'), ('REF-Lopez-2013', 'ผลของการปรับสมดุลต่างกันตามตัวจำแนก'),
              ('REF-Fernandez-2018', 'บทความ 15 ปีของ SMOTE ใน JAIR')], 2) +
    ours([('ok', 'CART, k-NN, SVM-RBF, LR และ RF (5 ตัว)'), ('ok', 'รายงานผลแยกตามตัวจำแนก'), ('add', 'gradient boosting เช่น LightGBM หรือ XGBoost'),
          ('note', 'ค่าตั้งของแต่ละตัว (เช่น k = 5, RF 100 ต้น) และที่มาของคะแนน (predict_proba หรือ decision_function)')]),
    write(2, ['ชื่อตัวจำแนก ไลบรารีและเวอร์ชัน (เช่น scikit-learn 1.x)', 'ค่าไฮเปอร์พารามิเตอร์ทุกตัวและบอกว่าปรับหรือไม่',
              'คะแนนที่ใช้คำนวณ AUC มาจากไหน (ความน่าจะเป็นหรือ decision function)', 'เหตุผลที่เลือกแต่ละตัว'],
          'Each sampler is paired with five learners from distinct families, CART, k-NN (k = 5), an RBF-kernel SVM, logistic regression and a random forest (100 trees), all with fixed scikit-learn [version] settings that are identical across samplers; AUC and PR-AUC are computed from predicted probabilities or, for the SVM, from the decision function.'),
    '≥4 ตระกูล รวม RF และ gradient boosting รายงานแยกตัว'))

# =================================================================== 3 competitors
SECS.append(topic(3, 't-baselines', 'วิธีคู่เทียบและเส้นฐาน', 'Competitors and baselines',
    '<p>ค่ากลางคือ 7 วิธีคู่เทียบต่องาน SMOTE เป็นคู่เทียบใน <b>50 จาก 71</b> เรื่อง เส้นฐานที่ไม่ปรับสมดุลมีใน <b>52</b> เรื่อง แต่ลดลงในงานรุ่นใหม่ ROS เป็นคู่เทียบใน 24 เรื่อง คู่เทียบแบบ cost-sensitive พบราว 10 เรื่อง แต่ class weighting แบบง่ายบนตัวจำแนกเดียวกันพบชัดเจนเฉพาะใน CISO 2025 มี 6 เรื่องที่คัดลอกผลคู่เทียบจากบทความเก่าแทนการรันใหม่</p>' +
    trend([('No-resampling baseline', 'มีเส้นฐานที่ไม่ปรับสมดุล')]) +
    '<p>ชัยชนะไม่สะสมเป็นอันดับ: MDO เป็นคู่เทียบใน 13 งานถัดมา และ MC-CCR ใน 7 งาน ทุกงานรายงานว่าวิธีของตนดีกว่า เพราะแต่ละงานใช้การแบ่งข้อมูลและการตั้งค่าของตัวเอง</p>' +
    mult([('smote_base', 'มี SMOTE เป็นคู่เทียบ'), ('nores', 'มีเส้นฐานไม่ปรับสมดุล')]),
    '<ol class="rec">'
    '<li><b>ต้องมีเส้นฐานอย่างง่ายครบ 4 แบบ</b>: ไม่ปรับสมดุล, class weighting, ROS และ SMOTE</li>'
    '<li><b>เพิ่มวิธีล่าสุดที่แข็งที่สุด 2 ถึง 4 วิธี</b> โดยเลือกวิธีที่มีโค้ดสาธารณะก่อน</li>'
    '<li><b>รันทุกวิธีใหม่บน fold เดียวกัน</b> ห้ามคัดลอกตัวเลขจากบทความอื่น</li>'
    '<li><b>ใช้ implementation ที่มีคนดูแล</b> เช่น imbalanced-learn และระบุเวอร์ชัน ถ้าต้องเขียนเองให้ตรวจกับผลในบทความต้นฉบับอย่างน้อยหนึ่งชุด</li></ol>'
    '<div class="why"><b>เพราะ</b><ul>'
    '<li>ไม่มีเส้นฐาน ผู้อ่านไม่รู้ว่าการปรับสมดุลช่วยจริงไหม ในการทดลองของเรา การไม่ปรับสมดุลได้อันดับดีที่สุดใน PR-AUC และ SMOTE ธรรมดาชนะใน AUC และ G-mean</li>'
    '<li>งานที่ลงทะเบียนแผนล่วงหน้าพบว่าวิธีใหม่ไม่ชนะ class weighting, ROS หรือการไม่ปรับ ' + cite('CISO-2025', 3) + '</li>'
    '<li>มี SMOTE เป็นคู่เทียบสัมพันธ์กับยอดอ้างอิงเกือบ 2 เท่า (×1.89 ช่วงเริ่มที่ 0.96 ยังไม่ผ่านเกณฑ์) และ SMOTE ยังเป็นเส้นฐานมาตรฐาน ' + cite('REF-Fernandez-2018', 3) + '</li>'
    '<li>ผลที่คัดลอกมาใช้ fold การตั้งค่า และบางครั้งนิยามตัวชี้วัดคนละแบบ เทียบกันตรง ๆ ไม่ได้</li></ul></div>' +
    evidence([('CISO-2025', 'เทียบกับ class weighting, ROS และไม่ปรับสมดุล'), ('KMeansSMOTE-2018', 'คู่เทียบ 5 วิธีรวมไม่ปรับ ROS และ SMOTE'),
              ('REF-imblearn-2017', 'ไลบรารี imbalanced-learn'), ('REF-Fernandez-2018', 'SMOTE เป็นเส้นฐานมาตรฐาน'), ('MDO-2016', 'ตัวอย่างวิธีที่ถูกวางใต้วิธีใหม่ในทุกงานถัดมา')], 3) +
    ours([('ok', 'ไม่ปรับสมดุล และ SMOTE'), ('ok', 'MWMOTE จาก smote_variants'), ('note', 'CISO และ QC-SMOTE เขียนใหม่จากสมการในบทความ ไม่มีโค้ดต้นฉบับ'),
          ('add', 'class weighting และ ROS'), ('add', 'ตรวจ CISO และ QC-SMOTE ที่เขียนเองกับตัวเลขในบทความต้นฉบับอย่างน้อยหนึ่งชุด')]),
    write(3, ['รายชื่อคู่เทียบทุกวิธี พร้อมแหล่งของโค้ด (ไลบรารีและเวอร์ชัน หรือเขียนเอง)', 'ค่าพารามิเตอร์ของทุกวิธี',
              'ยืนยันว่าทุกวิธีรันใหม่บน fold เดียวกัน', 'ถ้าเขียนวิธีใดเอง: เขียนจากส่วนไหนของบทความ ค่าที่บทความไม่ระบุตั้งไว้อย่างไร และตรวจความถูกต้องอย่างไร'],
          'All competitors are re-run on identical folds: no resampling, class weighting, random oversampling and SMOTE from imbalanced-learn [version] (Lemaître et al., 2017), MWMOTE from smote_variants [version], and our re-implementations of CISO and QC-SMOTE, which follow [equations] of the original papers; parameters the papers leave unspecified are set to [values].'),
    'ไม่ปรับ + class weighting + ROS + SMOTE รันใหม่บน fold เดียวกัน'))

# =================================================================== 4 measures
SECS.append(topic(4, 't-measures', 'ตัวชี้วัด', 'Performance measures',
    '<p>ค่ากลางคือ 4 ตัวชี้วัดต่องาน G-mean ใช้มากที่สุดและเพิ่มขึ้นต่อเนื่อง ตัวที่ไม่ขึ้นกับค่าเกณฑ์ (ROC-AUC, MAUC หรือ PR-AUC) มีใน 46 เรื่อง อีก 25 เรื่องวัดแค่ที่ค่าเกณฑ์ปกติ accuracy มีใน 13 เรื่องแต่ไม่เคยใช้ตัวเดียว</p>' +
    trend([('G-mean', 'G-mean'), ('F1 / F-measure', 'F1 / F-measure'), ('AUC', 'ROC-AUC'), ('Recall / TPR', 'Recall / TPR'), ('Accuracy or error rate', 'Accuracy'),
           ('MAUC', 'MAUC'), ('PR-AUC', 'PR-AUC'), ('MCC', 'MCC')]) +
    '<p><b>14 เรื่องนิยามตัวชี้วัดผิด</b> เช่น เรียก (TPR + TNR)/2 ว่า AUC หรือนิยาม G-mean ด้วย precision และเป็นแนวปฏิบัติเดียวที่สัมพันธ์กับยอดอ้างอิงชัดเจน (น้อยกว่า) เหตุผลที่เขียนไว้ส่วนใหญ่คือ "เป็นมาตรฐาน" (40) และ "accuracy หลอกได้" (39) มีเพียง 7 เรื่องที่ผูกตัวชี้วัดกับต้นทุนของงาน</p>' +
    mult([('metric_issue', 'นิยามตัวชี้วัดผิด'), ('thrfree', 'มีตัวที่ไม่ขึ้นกับค่าเกณฑ์'), ('acc', 'รายงาน accuracy')]),
    '<ol class="rec">'
    '<li><b>สองคลาส: ROC-AUC และ PR-AUC จากคะแนน</b> คู่กับ <b>G-mean (หรือ BA) และ F1 หรือ MCC</b> ที่ค่าเกณฑ์ปกติ</li>'
    '<li><b>หลายคลาส: MAUC แบบ Hand and Till</b> คู่กับ <b>macro-F1 หรือ AvAcc</b> และ MG</li>'
    '<li><b>เลือกตัวชี้วัดหลักหนึ่งตัวก่อนรัน</b> และบอกเหตุผลจากต้นทุนของการพลาดกับการเตือนผิด</li>'
    '<li><b>เขียนสูตรของทุกตัว</b> และวิธีเฉลี่ยข้ามคลาส ไม่ใช้ accuracy ตัวเดียว และไม่ใช้ weighted F1 เป็นตัวหลัก</li></ol>'
    '<div class="why"><b>เพราะ</b><ul>'
    '<li>ตัวชี้วัดต่างตัวเลือกผู้ชนะต่างกัน ในการทดลองของเรา G-mean เลือก SMOTE, F1 เลือก QC-SMOTE และ PR-AUC เลือกการไม่ปรับสมดุล การรายงานทั้งสองแบบทำให้เห็นว่าผลดีขึ้นจากการเลื่อนค่าเกณฑ์ หรือจากการจัดอันดับที่ดีขึ้นจริง</li>'
    '<li>เมื่อคลาสบวกหายาก PR-AUC ให้ข้อมูลมากกว่า ROC ' + cite('REF-SaitoRehmsmeier-2015', 4) + '</li>'
    '<li>MAUC มีนิยามมาตรฐานที่ต้องใช้คะแนน ไม่ใช่ป้ายทาย ' + cite('REF-HandTill-2001', 4) + '</li>'
    '<li>นิยามผิดเป็นสิ่งเดียวที่สัมพันธ์กับยอดอ้างอิงที่ต่ำกว่า (×0.33) และทำให้ตัวเลขเทียบข้ามงานไม่ได้</li>'
    '<li>G-mean และ BA ให้รางวัลกับการทายบวกมากเกินไป F1 และ MCC ลงโทษการเตือนผิด จึงควรมีอย่างละตัว (ดูตัวอย่าง A, B, C ใน Primer หัวข้อ 5)</li></ul></div>' +
    evidence([('REF-SaitoRehmsmeier-2015', 'PR-AUC เมื่อคลาสบวกหายาก'), ('REF-HandTill-2001', 'นิยาม MAUC'), ('REF-HeGarcia-2009', 'ทบทวนตัวชี้วัดของข้อมูลไม่สมดุล'),
              ('REF-Lopez-2013', 'ตัวชี้วัดที่ใช้ในการทดลองข้อมูลไม่สมดุล'), ('KMeansSMOTE-2018', 'ใช้ G-mean, F1 และ PR-AUC พร้อมเหตุผลที่ไม่ใช้ accuracy')], 4) +
    ours([('ok', 'ROC-AUC และ PR-AUC จากคะแนน'), ('ok', 'F1 และ G-mean (imbalanced-learn) ที่ค่าเกณฑ์ปกติ'), ('add', 'MCC หรือ BA'),
          ('add', 'ประกาศตัวชี้วัดหลักและเหตุผล'), ('note', 'คลาสบวกคือคลาสส่วนน้อย และค่าเกณฑ์คือกฎตัดสินปกติของแต่ละตัวจำแนก')]),
    write(4, ['สูตรของทุกตัวชี้วัด และคลาสไหนเป็นคลาสบวก', 'ค่าเกณฑ์ที่ใช้กับตัวชี้วัดแบบขึ้นกับค่าเกณฑ์', 'คะแนนที่ใช้คำนวณ AUC และ PR-AUC',
              'วิธีเฉลี่ยข้ามคลาส (ถ้ามีหลายคลาส)', 'ตัวชี้วัดหลักคือตัวไหน และเหตุผล', 'ฟังก์ชันหรือไลบรารีที่ใช้คำนวณ'],
          'We report two threshold-free measures computed from scores, ROC-AUC and PR-AUC (average precision), and two measures at the default decision rule of each learner, G-mean = √(TPR·TNR) and F1 of the minority class, which is the positive class. [Primary measure] is the primary measure because [cost argument].'),
    'ROC-AUC + PR-AUC + G-mean + F1/MCC พร้อมสูตร'))

# =================================================================== 5 protocol
SECS.append(topic(5, 't-protocol', 'การแบ่งข้อมูลฝึกและทดสอบ', 'Validation protocol',
    '<p>Stratified k-fold CV เป็นมาตรฐาน: ทำซ้ำหลายรอบ (รวม 5 × 2 CV) 37 เรื่อง, ทำรอบเดียว 16 เรื่อง, แบ่งครั้งเดียว 8 เรื่อง, แบ่งสุ่มซ้ำ 6 เรื่อง, ใช้การแบ่งที่มากับชุดข้อมูล 3 เรื่อง k = 10 พบใน 23 เรื่อง และ k = 5 ใน 20 เรื่อง</p>' +
    trend([('Repeated k-fold CV / 5x2 CV', 'CV ทำซ้ำหลายรอบหรือ 5 × 2 CV'), ('Single k-fold CV', 'k-fold รอบเดียว'), ('Single hold-out', 'แบ่งครั้งเดียว'),
           ('Train-only resampling stated', 'บอกว่าปรับสมดุลเฉพาะข้อมูลฝึก')]) +
    '<p>มีแค่ <b>34 จาก 71</b> ที่บอกชัดว่าปรับสมดุลเฉพาะข้อมูลฝึก อีก 36 เรื่องไม่บอก มีงานหนึ่งที่ตัวเลขบ่งว่าปรับทั้งชุดก่อนแบ่ง fold (AB-SMOTE) และอีกงานดูเหมือนปรับสเกลก่อนแบ่ง (MC-NCLWO)</p>' +
    mult([('repeated', 'ทำซ้ำหลายรอบ'), ('inside', 'บอกว่าปรับเฉพาะข้อมูลฝึก')]),
    '<ol class="rec">'
    '<li><b>Stratified 5-fold CV ทำซ้ำ 5 รอบ</b> (หรือ 10 รอบ) ด้วย seed ที่กำหนดไว้</li>'
    '<li><b>ใช้การแบ่งชุดเดียวกันกับทุกวิธีและทุกตัวจำแนก</b></li>'
    '<li><b>ทุกขั้นที่เรียนจากข้อมูลทำในข้อมูลฝึกของแต่ละ fold เท่านั้น</b>: ปรับสมดุล ปรับสเกล เข้ารหัส เติมค่าที่หาย เลือกฟีเจอร์ (ใช้ pipeline)</li>'
    '<li>ถ้าจะทดสอบรายชุดข้อมูล ใช้ <b>5 × 2 CV</b></li></ol>'
    '<div class="why"><b>เพราะ</b><ul>'
    '<li>CV รอบเดียวให้ค่าเดียวต่อชุดและแกว่งตามการแบ่ง การทำซ้ำทำให้ประมาณความแปรปรวนได้ งานรุ่นใหม่ทำซ้ำมากขึ้น (36% เป็น 62%)</li>'
    '<li>5 fold แทน 10 fold ทำให้ fold ทดสอบมีคลาสส่วนน้อยมากพอ เช่น ชุดที่มีคลาสส่วนน้อย 20 ตัว ถ้าใช้ 10 fold จะเหลือ 2 ตัวต่อ fold</li>'
    '<li>ปรับสมดุลก่อนแบ่ง fold ทำให้จุดสังเคราะห์ที่สร้างจากข้อสอบอยู่ในข้อมูลฝึก คะแนนจะสูงเกินจริง</li>'
    '<li>5 × 2 CV ออกแบบมาให้การทดสอบแบบจับคู่บนชุดเดียวมีความผิดพลาดชนิดที่หนึ่งต่ำ ' + cite('REF-Dietterich-1998', 5) + '</li>'
    '<li>การแบ่ง fold เองอาจทำให้การแจกแจงของ fold ฝึกกับ fold ทดสอบต่างกัน (dataset shift) ' + cite('REF-MorenoTorres-2012', 5) + '</li></ul></div>' +
    evidence([('REF-Dietterich-1998', '5 × 2 CV และการทดสอบบนชุดเดียว'), ('REF-MorenoTorres-2012', 'dataset shift จากการแบ่ง fold'),
              ('RBO-2019', 'ใช้ 5 × 2 CV'), ('MC-RBO-2020', 'CV ทำซ้ำ และปรับค่าแบบ nested'), ('KMeansSMOTE-2018', '5-fold CV ทำซ้ำ 5 รอบ')], 5) +
    ours([('ok', 'Stratified 5-fold CV'), ('ok', 'ปรับสมดุลและปรับสเกลเฉพาะข้อมูลฝึก'), ('ok', 'fold เดียวกันกับทุกวิธี และ seed คงที่'),
          ('add', 'ทำซ้ำ 5 รอบขึ้นไป (ตอนนี้รอบเดียว)')]),
    write(5, ['k, จำนวนรอบที่ทำซ้ำ, การรักษาสัดส่วนคลาส และ seed', 'ขั้นตอนใดบ้างที่ fit บนข้อมูลฝึกของแต่ละ fold',
              'ยืนยันว่าทุกวิธีใช้การแบ่งชุดเดียวกัน', 'จำนวนคลาสส่วนน้อยน้อยที่สุดใน fold ทดสอบ'],
          'Performance is estimated with stratified 5-fold cross-validation repeated [5] times with fixed seeds; the same partitions are used for every sampler and learner, and the sampler, feature scaling and encoding are fitted on the training folds only.'),
    'Stratified 5-fold × 5 รอบ, ทุกขั้นทำในข้อมูลฝึก'))

# =================================================================== 6 tuning
SECS.append(topic(6, 't-tuning', 'การเลือกค่าพารามิเตอร์', 'Hyperparameter selection',
    '<p>นี่คือขั้นที่อ่อนที่สุด <b>35 จาก 71 เรื่องเลือกค่าบนข้อมูลที่ใช้รายงานผล</b> (25 เรื่องเขียนไว้ตรง ๆ อีก 10 เรื่องบอกเป็นนัย) ใช้ค่าคงที่กับทุกวิธี 20 เรื่อง ใช้ nested CV หรือชุดปรับจูนแยก 9 เรื่อง และไม่บอก 7 เรื่อง</p>' +
    trend([('Settings chosen on evaluation data', 'เลือกค่าบนข้อมูลที่รายงานผล'), ('Nested or held-out tuning', 'Nested CV หรือชุดปรับจูนแยก')]) +
    '<p>ใน 54 เรื่องที่มีการเลือกค่า มี 33 เรื่องที่บอกตัวชี้วัดที่ใช้เลือก (G-mean 15, AUC 12, F1 8) และ 25 เรื่องเลือกบน fold เดียวกับที่รายงาน งบการค้นหามักไม่เท่ากัน เช่น G-SMOTE เลือกจาก 294 ค่ากำหนด เทียบกับ 2 ค่าของ SMOTE และ k-means SMOTE 144 ค่าเทียบกับ 3 ค่าของ SMOTE</p>' +
    mult([('evalsel', 'เลือกค่าบนข้อมูลที่รายงานผล')]),
    '<ol class="rec">'
    '<li><b>ทางเลือก ก (แนะนำสำหรับงานเปรียบเทียบ): ใช้ค่าคงที่ตามที่ผู้เขียนแต่ละวิธีแนะนำ</b> กับทุกวิธี และเขียนค่าทั้งหมดไว้</li>'
    '<li><b>ทางเลือก ข (ถ้าจะปรับ): nested CV</b> วงในแบ่งข้อมูลฝึกอีกชั้นเพื่อเลือกค่า ใช้งบการค้นหาเท่ากันทุกวิธีรวม SMOTE และประกาศตัวชี้วัดที่ใช้เลือกก่อนรัน</li>'
    '<li><b>ห้ามรายงานจุดดีที่สุดของกริดที่วัดบน fold ทดสอบ</b></li>'
    '<li>ถ้าอยากแสดงผลของพารามิเตอร์ ให้แยกเป็นการวิเคราะห์ความไว ไม่ใช่ผลหลัก</li></ol>'
    '<div class="why"><b>เพราะ</b><ul>'
    '<li>การเลือกโมเดลบนข้อมูลเดียวกับที่ใช้ประเมินทำให้ค่าประมาณสูงเกินจริง ' + cite('REF-Cawley-2010', 6) + '</li>'
    '<li>ยิ่งลองหลายค่า ยิ่งเกินจริงมาก ถ้าทุกค่าที่ลองดีเท่ากันจริงและคะแนนแกว่ง ±0.02 เลือกตัวดีสุดจาก 294 ค่าได้เกินจริงราว 0.057 แต่จาก 2 ค่าเกินแค่ 0.011 วิธีที่ได้ลองมากกว่าจึงดูชนะทั้งที่ไม่ได้ดีกว่า</li>'
    '<li>คนอ้างอิงไม่ได้ลงโทษเรื่องนี้ (×1.15) จึงไม่มีแรงจูงใจให้แก้ ผู้ตรวจที่รู้เรื่องจะมองหาจุดนี้</li></ul></div>' +
    evidence([('REF-Cawley-2010', 'อคติจากการเลือกโมเดลบนข้อมูลประเมิน'), ('MC-CCR-2020', 'nested tuning'), ('MC-RBO-2020', 'nested tuning'),
              ('LS-2008', 'ปรับค่าใน 5 × 2 CV แบบซ้อน'), ('A-SUWO-2016', 'ปรับค่าในข้อมูลฝึก'), ('G-SMOTE-2019', 'ตัวอย่างงบไม่เท่ากัน 294 กับ 2')], 6) +
    ours([('ok', 'ใช้ค่าคงที่กับทุกวิธี ไม่มีการเลือกบน fold ทดสอบ'), ('note', 'ค่าของ CISO และ QC-SMOTE ที่บทความไม่ระบุ ซึ่งตั้งเอง (เช่น η = 0.5, น้ำหนัก 1/3)'),
          ('note', 'ถ้าจะปรับค่าภายหลัง ใช้ nested CV และงบเท่ากันทุกวิธี')]),
    write(6, ['ค่าพารามิเตอร์ของทุกวิธี หรือกริดที่ค้นหา', 'งบการค้นหาของแต่ละวิธี (จำนวนค่ากำหนดที่ลอง)', 'ตัวชี้วัดและข้อมูลที่ใช้เลือก',
              'ยืนยันว่าไม่มีการเลือกค่าบน fold ทดสอบ'],
          'No setting is selected on the test folds: every sampler runs with the default parameters recommended by its authors, listed in Table [Y]; where a paper leaves a parameter unspecified, we use [value] for all datasets.'),
    'ค่าคงที่ตามผู้เขียน หรือ nested CV งบเท่ากัน'))

# =================================================================== 7 stats
SECS.append(topic(7, 't-stats', 'การทดสอบทางสถิติ', 'Statistical testing',
    '<p>52 จาก 71 เรื่องมีการทดสอบ งานที่ไม่ทดสอบลดจาก 64% (ถึงปี 2009) เหลือ 17% (2021–26) Wilcoxon (26) และ Friedman (25) เป็นหลัก ตามด้วย post-hoc แบบ Holm (10), Bonferroni–Dunn (6), Shaffer (4), Nemenyi (4) การทดสอบแบบเบย์เพิ่งเริ่ม (3 เรื่องตั้งแต่ 2022) t-test เลิกใช้หลังปี 2015</p>' +
    trend([('No significance test', 'ไม่ทดสอบ'), ('Wilcoxon signed-rank', 'Wilcoxon signed-rank'), ('Friedman', 'Friedman'), ('Corrected multiple comparison', 'ปรับแก้การเทียบหลายครั้ง'),
           ('Bayesian test', 'การทดสอบแบบเบย์'), ('t-test', 't-test'), ('Cites Demšar (2006)', 'อ้าง Demšar (2006)')]) +
    '<p>19 เรื่องใช้การทดสอบรายคู่โดยไม่ปรับแก้ ทั้งที่เทียบกับคู่เทียบหลายวิธี ยังพบการวาด Nemenyi หลัง Friedman ที่ไม่มีนัยสำคัญ (SOUP), Nemenyi โดยไม่มีการทดสอบรวม (MC-MBRC) และการอ้างแหล่งที่ไม่ได้อธิบายการทดสอบที่ใช้ (G-SMOTE, CBHSID)</p>' +
    mult([('anytest', 'มีการทดสอบ'), ('corr', 'ปรับแก้หรือแบบเบย์'), ('method_ref', 'อ้างแหล่งระเบียบวิธี')]),
    '<ol class="rec">'
    '<li><b>หน่วยของการทดสอบคือชุดข้อมูล</b> ทดสอบแยกตามตัวจำแนกและตัวชี้วัด</li>'
    '<li><b>หลายวิธี: Friedman (ปรับด้วย Iman–Davenport) แล้ว Holm</b> เทียบกับวิธีควบคุม หรือ <b>Shaffer</b> ถ้าเทียบทุกคู่</li>'
    '<li><b>สองวิธี: Wilcoxon signed-rank</b></li>'
    '<li><b>รายงานขนาดของผล</b> (ผลต่างค่ากลาง, ชนะ/เสมอ/แพ้) คู่กับ p-value</li>'
    '<li>ถ้าจะสรุปว่าสองวิธี "เท่ากันในทางปฏิบัติ" ใช้ <b>Bayesian signed-rank พร้อม ROPE</b> เช่น ±0.01</li></ol>'
    '<div class="why"><b>เพราะ</b><ul>'
    '<li>การเทียบตัวจำแนกข้ามหลายชุดข้อมูลควรใช้การทดสอบแบบไม่อิงพารามิเตอร์ที่ใช้ชุดข้อมูลเป็นหน่วย ' + cite('REF-Demsar-2006', 7) + '</li>'
    '<li>Holm และ Shaffer มีอำนาจมากกว่า Nemenyi และ Bonferroni–Dunn ' + cite('REF-GarciaHerrera-2008', 7) + ' ' + cite('REF-Garcia-2010', 7) + '</li>'
    '<li>เทียบ 10 คู่ที่ระดับ 0.05 โดยไม่ปรับแก้ มีโอกาสได้ผลบวกลวงอย่างน้อยหนึ่งครั้งราว 40%</li>'
    '<li>p-value ไม่บอกว่าเท่ากัน การทดสอบแบบเบย์ให้ความน่าจะเป็นที่ A ดีกว่า เท่ากัน หรือ B ดีกว่า ' + cite('REF-Benavoli-2017', 7) + '</li>'
    '<li>ถ้านับชุดข้อมูล × ตัวจำแนก (110 × 5 = 550) เป็นหน่วยอิสระ จะนับข้อมูลชุดเดียวกันซ้ำ 5 ครั้ง ทำให้ p-value เล็กเกินจริง</li></ul></div>' +
    evidence([('REF-Demsar-2006', 'Friedman, Wilcoxon และ CD diagram'), ('REF-GarciaHerrera-2008', 'Holm และ Shaffer สำหรับเทียบทุกคู่'), ('REF-Garcia-2010', 'การทดสอบ post-hoc ขั้นสูง'),
              ('REF-Derrac-2011', 'คู่มือการทดสอบแบบไม่อิงพารามิเตอร์'), ('REF-Benavoli-2017', 'การทดสอบแบบเบย์และ ROPE'), ('MLOS-2025', 'ใช้การทดสอบแบบเบย์'),
              ('KMeansSMOTE-2018', 'Friedman + Holm')], 7) +
    ours([('ok', 'Friedman และอันดับเฉลี่ย'), ('fix', 'ตอนนี้นับ 550 คู่ชุดข้อมูล × ตัวจำแนกเป็นหน่วยเดียวกัน ควรทดสอบแยกตัวจำแนก (N = 110)'),
          ('add', 'Holm หรือ Shaffer หลัง Friedman'), ('add', 'ขนาดของผล และ Bayesian signed-rank สำหรับคู่ CISO กับ QC-SMOTE')]),
    write(7, ['ชื่อการทดสอบ หน่วย (ชุดข้อมูล) และ N', 'ระดับนัยสำคัญ และวิธีปรับแก้การเทียบหลายครั้ง', 'ทดสอบกับตัวชี้วัดและตัวจำแนกใด',
              'ซอฟต์แวร์ที่ใช้', 'ตาราง p-value และ CD diagram', 'ขนาดของผล'],
          'For each learner and measure we apply the Friedman test with the Iman–Davenport correction over the [N] datasets, followed by Holm’s procedure with [method] as the control (Demšar, 2006; García & Herrera, 2008); we also report the median difference and win/tie/loss counts against each baseline.'),
    'Friedman + Holm/Shaffer ต่อตัวจำแนก + ขนาดของผล'))

# =================================================================== 8 reporting
SECS.append(topic(8, 't-reporting', 'การรายงานผล', 'Reporting',
    '<p>ตารางรายชุดข้อมูลมีใน 58 เรื่อง อันดับเฉลี่ยเพิ่มจาก 7% เป็น 75% แต่ <b>ส่วนเบี่ยงเบนมาตรฐานมีแค่ 24 เรื่อง</b> เวลาประมวลผล 14 เรื่อง และ CD diagram 4 เรื่อง การปล่อยโค้ดเพิ่มจาก 0% (ถึงปี 2009) เป็น 65% (2016–20) พบตารางที่ขัดกับเนื้อความในบทความเดียวกัน 3 เรื่อง</p>' +
    trend([('Mean ± standard deviation', 'ค่าเฉลี่ย ± SD'), ('Average-rank table', 'ตารางอันดับเฉลี่ย'), ('Win/tie/loss counts', 'ชนะ/เสมอ/แพ้'), ('Running time', 'เวลาประมวลผล'),
           ('Code released', 'ปล่อยโค้ด')]) +
    mult([('code', 'ปล่อยโค้ด'), ('std', 'รายงาน SD'), ('runtime', 'รายงานเวลา')]),
    '<ol class="rec">'
    '<li><b>ตารางค่าเฉลี่ย ± SD รายชุดข้อมูล</b> (ในภาคผนวกหรือไฟล์ CSV)</li>'
    '<li><b>อันดับเฉลี่ยและ CD diagram</b> แยกตามตัวจำแนกและตัวชี้วัด</li>'
    '<li><b>ชนะ/เสมอ/แพ้</b> เทียบกับแต่ละเส้นฐาน</li>'
    '<li><b>เวลาประมวลผล</b> ของแต่ละวิธี</li>'
    '<li><b>ปล่อยโค้ด seed ดัชนี fold และผลราย fold</b> พร้อมเวอร์ชันของไลบรารี</li></ol>'
    '<div class="why"><b>เพราะ</b><ul>'
    '<li>การปล่อยโค้ดเป็นแนวปฏิบัติที่สัมพันธ์กับยอดอ้างอิงมากที่สุด (ประมาณ 2 เท่า ×2.01 ช่วงเริ่มที่ 0.98) และทำให้คนอื่นนำวิธีไปเป็นคู่เทียบได้ง่าย</li>'
    '<li>ไม่มี SD ผู้อ่านแยกความต่างจริงกับความแกว่งระหว่าง fold ไม่ได้</li>'
    '<li>หลายวิธีเพิ่มการจัดกลุ่มหรือการหาค่าเหมาะสมบน SMOTE เวลาที่เพิ่มขึ้นเป็นต้นทุนที่ผู้ใช้ต้องรู้</li>'
    '<li>ผลราย fold ทำให้คนอื่นวิเคราะห์ซ้ำด้วยการทดสอบหรือตัวชี้วัดอื่นได้</li></ul></div>' +
    evidence([('KMeansSMOTE-2018', 'ปล่อยโค้ด อันดับเฉลี่ย และตาราง p-value'), ('SMOTE-IPF-2015', 'ปล่อยโค้ด'), ('CTGAN-2019', 'ปล่อยโค้ด'), ('G-SMOTE-2019', 'ปล่อยโค้ด'),
              ('REF-imblearn-2017', 'ไลบรารีที่ทำให้วิธีถูกนำไปใช้ซ้ำ')], 8) +
    ours([('ok', 'ผลราย fold (results_raw.csv) และค่าเฉลี่ยรายชุด'), ('ok', 'อันดับเฉลี่ยและจำนวนครั้งที่ชนะ'), ('add', 'SD และเวลาประมวลผล'),
          ('add', 'CD diagram'), ('add', 'เผยแพร่โค้ด (ตอนนี้อยู่ในเครื่อง)')]),
    write(8, ['ตารางที่อยู่ในเนื้อหาหลักกับที่อยู่ในภาคผนวก', 'ที่อยู่ของโค้ด ผลราย fold และไฟล์ข้อมูล', 'เวอร์ชันของไลบรารีและฮาร์ดแวร์ที่ใช้วัดเวลา'],
          'Per-dataset means and standard deviations for every learner, sampler and measure are given in the supplementary material; code, seeds, fold indices and per-fold results are available at [URL].'),
    'ค่าเฉลี่ย ± SD, อันดับ + CD, เวลา, ปล่อยโค้ด'))

# =================================================================== 9 beyond
SECS.append(topic(9, 't-beyond', 'หลักฐานนอกจากคะแนนของตัวจำแนก', 'Direct checks of the resampled data',
    '<p><b>ไม่มีงานใดประเมินโดยไม่ใช้ตัวจำแนก</b> มีเพียง 6 เรื่องที่วัดข้อมูลหลังปรับสมดุลโดยตรง เช่น สัดส่วนจุดสังเคราะห์ที่ถูกลบเป็น noise (SMOTE-IPF), FID (GAMO), likelihood (CTGAN), MMD (CISO) หลักฐานอื่นส่วนใหญ่เป็นกราฟสองมิติ (33 เรื่อง) และทฤษฎีหรือ big-O (31 เรื่อง) อีก 23 เรื่องมีแค่คะแนน</p>' +
    trend([('Direct measure of resampled data', 'วัดข้อมูลหลังปรับสมดุลโดยตรง'), ('2-D or projected plots of samples', 'กราฟสองมิติหรือภาพฉาย')]) +
    mult([('beyond_direct', 'วัดข้อมูลโดยตรง')]),
    '<ol class="rec">'
    '<li><b>เพิ่มการตรวจข้อมูลหลังปรับสมดุลโดยตรงอย่างน้อยหนึ่งแบบ</b> คำนวณกับข้อมูลที่กันไว้:'
    '<ul><li>สัดส่วนจุดสังเคราะห์ที่เพื่อนบ้านส่วนใหญ่เป็นคลาสส่วนมาก หรือที่ตัวกรอง noise ลบทิ้ง</li>'
    '<li>สัดส่วน safe, borderline, rare, outlier ก่อนและหลังปรับสมดุล</li>'
    '<li>MMD หรือ classifier two-sample test ระหว่างจุดสังเคราะห์กับคลาสส่วนน้อยที่กันไว้</li></ul></li>'
    '<li><b>เชื่อมกับลักษณะของข้อมูล</b> (IR, การซ้อนทับ) เพื่ออธิบายว่าวิธีชนะที่ไหนและเพราะอะไร</li>'
    '<li>ใช้กราฟสองมิติเป็นภาพประกอบเท่านั้น ไม่ใช่หลักฐานหลัก</li></ol>'
    '<div class="why"><b>เพราะ</b><ul>'
    '<li>คะแนนบอกว่าผลดีขึ้น แต่ไม่บอกว่าทำไม การวัดข้อมูลตรง ๆ บอกได้ว่าจุดสังเคราะห์ไปตกในที่ผิดบ่อยแค่ไหน</li>'
    '<li>ในการทดลองของเรา CISO และ QC-SMOTE เด่นบนชุด ecoli และ yeast ที่ IR สูง การวัดข้อมูลตรง ๆ จะช่วยอธิบายว่าเป็นเพราะอะไร</li>'
    '<li>งานที่วัดตรงยังมีน้อยจนตัวคูณการอ้างอิงสรุปไม่ได้ (×2.30 ช่วงกว้าง 0.73–7.26) แต่เป็นช่องว่างที่ทำให้งานของเราต่างจากงานอื่น</li></ul></div>' +
    evidence([('SMOTE-IPF-2015', 'สัดส่วนจุดสังเคราะห์ที่ถูกลบเป็น noise'), ('REF-NapieralaStefanowski-2016', 'ประเภทตัวอย่าง safe, borderline, rare, outlier'),
              ('CISO-2025', 'MMD และ two-sample test กับคลาสส่วนน้อยที่กันไว้'), ('CTGAN-2019', 'likelihood ของข้อมูลสังเคราะห์'), ('REF-HoBasu-2002', 'วัดการซ้อนทับและความซับซ้อนของข้อมูล'),
              ('SPE-2020', 'สัดส่วนตัวอย่างง่ายและยากหลังสุ่มตัด')], 9) +
    ours([('add', 'ยังไม่มีการวัดข้อมูลโดยตรง'), ('add', 'ค่าความยากของชุดข้อมูล เพื่ออธิบายผลบน ecoli และ yeast')]),
    write(9, ['นิยามของการวัดแต่ละแบบ และคำนวณบนข้อมูลชุดไหน', 'ผลการวัดสัมพันธ์กับคะแนนของตัวจำแนกอย่างไร', 'กราฟสองมิติใช้เป็นภาพประกอบเท่านั้น'],
          'Beyond classifier scores, we measure the synthetic data directly on held-out minority examples: the share of synthetic points whose five nearest neighbours are mostly majority examples, and the maximum mean discrepancy to the held-out minority class.'),
    'วัดจุดสังเคราะห์ตรง ๆ อย่างน้อย 1 แบบ'))

# =================================================================== 10 claims
SECS.append(topic(10, 't-claims', 'การสรุปผลและข้อจำกัด', 'Claims and threats to validity',
    '<p><b>68 จาก 69 งานที่เสนอวิธีใหม่สรุปว่าวิธีของตนดีที่สุด</b> (27 เรื่องไม่มีข้อยกเว้น 41 เรื่องระบุข้อยกเว้นเอง) มีเพียง CISO ที่รายงานว่าไม่ดีกว่าเส้นฐานอย่างง่าย และเป็นงานเดียวที่ลงทะเบียนแผนล่วงหน้า ชัยชนะเหล่านี้รวมเป็นอันดับไม่ได้ เพราะแต่ละงานใช้การแบ่ง การตั้งค่า และนิยามตัวชี้วัดของตัวเอง</p>' +
    mult([('outB', 'ระบุกรณีที่ไม่ดีกว่า')]) +
    '<p class="note">งานที่ระบุว่าวิธีของตนไม่ดีกว่าในบางกรณี ไม่ได้ถูกอ้างอิงน้อยลงอย่างมีนัยสำคัญ</p>',
    '<ol class="rec">'
    '<li><b>สรุปแยกตามตัวชี้วัดและตัวจำแนก</b> และบอกกรณีที่วิธีแพ้ ไม่ใช้คำว่า "ดีที่สุดโดยรวม"</li>'
    '<li><b>บอกขนาดของผลและความเท่ากันในทางปฏิบัติ</b> ไม่ใช่แค่มีนัยสำคัญ</li>'
    '<li><b>ลงทะเบียนแผนการทดลองล่วงหน้าถ้าทำได้</b> (เช่น บน OSF) แบบ CISO</li>'
    '<li><b>มีย่อหน้าข้อจำกัด</b>: ความถูกต้องของวิธีที่เขียนเอง ค่าพารามิเตอร์ที่ตั้งเอง ข้อมูลมาจาก KEEL แหล่งเดียว และสิ่งที่ยังไม่ได้ทดสอบ</li></ol>'
    '<div class="why"><b>เพราะ</b><ul>'
    '<li>เมื่อแทบทุกงานบอกว่าตัวเองดีที่สุด คำนี้ไม่มีน้ำหนักแล้ว ผลที่บอกว่า "ดีกว่าเมื่อไร" มีประโยชน์กว่า</li>'
    '<li>การทดลองของเราเองได้ผลต่างกันตามตัวชี้วัด จึงสรุปแบบมีเงื่อนไขได้ตรงกับข้อมูล</li>'
    '<li>การลงทะเบียนแผนตัดข้อสงสัยเรื่องการเลือกตัวชี้วัดหรือชุดข้อมูลภายหลัง ' + cite('CISO-2025', 10) + '</li></ul></div>' +
    evidence([('CISO-2025', 'ลงทะเบียนแผน และรายงานว่าไม่ดีกว่าเส้นฐาน'), ('MDO-2016', 'ตัวอย่างวิธีที่แพ้ในทุกงานถัดมา'), ('REF-Fernandez-2018', 'ทิศทางงานวิจัยของ SMOTE')], 10) +
    ours([('ok', 'RESULTS สรุปตามตัวชี้วัด ("ขึ้นกับ metric ที่วัด")'), ('ok', 'มีหัวข้อความเที่ยงตรงของการเขียนวิธีใหม่'),
          ('add', 'ขนาดของผลและความเท่ากันในทางปฏิบัติ'), ('add', 'ย่อหน้าข้อจำกัดใน paper')]),
    write(10, ['ข้อสรุปแยกตามตัวชี้วัดและตัวจำแนก พร้อมกรณีที่แพ้', 'ขนาดของผล ไม่ใช่แค่ p-value', 'ข้อจำกัด: วิธีที่เขียนเอง ค่าที่ตั้งเอง แหล่งข้อมูล สิ่งที่ยังไม่ได้ทดสอบ',
               'ถ้าลงทะเบียนแผน ให้ลิงก์ไปยังแผน'],
          'No sampler dominates: SMOTE ranks best on ROC-AUC and G-mean, QC-SMOTE and CISO on F1, and no resampling on PR-AUC. Differences among the three newer samplers are within [ROPE] for [x] of [y] learners.'),
    'สรุปแบบมีเงื่อนไข + ขนาดของผล + ข้อจำกัด'))

# ------------------------------------------------------------------ page parts
def overview():
    DID = {1: 'UCI 53, KEEL 33 (เพิ่มขึ้น); ค่ากลาง 18 ชุด; ดัดแปลง 52 ปล่อย 10', 2: 'ค่ากลาง 3 ตัว; ตัวเดียว 25 เรื่อง; C4.5 ลดลง RF/GB เพิ่มขึ้น',
           3: 'SMOTE 50, ไม่ปรับ 52 (ลดลง); class weighting แทบไม่มี; คัดลอกผล 6', 4: 'G-mean 41, F1 35, AUC 33; PR-AUC 5, MCC 4; นิยามผิด 14',
           5: 'CV ทำซ้ำ 37; บอกว่าปรับเฉพาะข้อมูลฝึก 34', 6: 'เลือกบนข้อมูลรายงานผล 35; nested 9; งบไม่เท่ากัน',
           7: 'ทดสอบ 52; Wilcoxon/Friedman; ไม่ปรับแก้ 19', 8: 'ตารางรายชุด 58; SD 24; เวลา 14; โค้ด 27', 9: 'วัดตรง 6; กราฟสองมิติ 33; คะแนนอย่างเดียว 23',
           10: 'ดีที่สุด 68 จาก 69; ไม่ดีกว่าเส้นฐาน 1'}
    TELL = {1: 'แหล่ง ตารางลักษณะ การเตรียมข้อมูล ไฟล์', 2: 'ไลบรารี ค่าตั้ง ที่มาของคะแนน เหตุผล', 3: 'แหล่งโค้ด ค่าตั้ง รันใหม่บน fold เดียวกัน',
            4: 'สูตร คลาสบวก ค่าเกณฑ์ ตัวหลัก', 5: 'k รอบ seed ขั้นที่ทำในข้อมูลฝึก', 6: 'ค่าทุกวิธี งบ ตัวชี้วัดที่ใช้เลือก',
            7: 'การทดสอบ หน่วย N การปรับแก้ ขนาดของผล', 8: 'SD เวลา ที่อยู่ของโค้ดและผล', 9: 'นิยามและข้อมูลที่ใช้วัด', 10: 'ข้อสรุปมีเงื่อนไข ข้อจำกัด'}
    h = '<section class="s" id="overview"><h2><span class="n">0</span><span>ภาพรวมในหน้าเดียว <span class="en">Summary</span></span></h2>'
    h += '<p>หน้านี้สรุปจากงานที่มีการทดลอง 71 เรื่องในคลังบทความ SMOTE25 (76 เรื่อง) แต่ละหัวข้อด้านล่างตอบ 3 คำถาม: <b>1</b> งานทั้งหมดทำอะไร <b>2</b> ถ้าเป็นเรา ควรเลือกอะไรและเพราะอะไร <b>3</b> ถ้าเขียนลง paper ผู้อ่านต้องรู้อะไร ตารางนี้ย่อคำตอบทั้งหมดไว้ กดชื่อหัวข้อเพื่อดูรายละเอียด</p>'
    h += '<div class="scroll"><table class="t sum"><thead><tr><th>หัวข้อ</th><th>1 งานทั้งหมดทำ</th><th>2 เราควรใช้</th><th>3 ต้องบอกใน paper</th></tr></thead><tbody>'
    for n, tid, th, en, summ in TOPICS:
        h += '<tr><td><a href="#' + tid + '"><b>' + str(n) + ' ' + th + '</b></a><div class="sub">' + en + '</div></td><td>' + DID[n] + '</td><td class="g">' + summ + '</td><td>' + TELL[n] + '</td></tr>'
    h += '</tbody></table></div>'
    h += ('<div class="box key"><b>อ่านตัวเลขในหน้านี้อย่างไร</b><ul class="list">'
          '<li><b>x/71</b> คือจำนวนงานจาก 71 เรื่องที่มีการทดลอง แถบตามช่วงปีคือร้อยละของงานในช่วงนั้น (ถึง 2009: 14 งาน, 2010–15: 13, 2016–20: 20, 2021–26: 24)</li>'
          '<li><b>ยอดอ้างอิง</b> (cites) มาจาก OpenAlex ดึงวันที่ 18 ต.ค. 2026 ต่ำกว่า Google Scholar งาน arXiv ใหม่มีค่า 0 ปีที่ตีพิมพ์อยู่คู่กันเสมอ จึงตัดสินเองได้ว่าเก่าหรือใหม่</li>'
          '<li><b>ตัวคูณการอ้างอิง ×</b> บอกว่างานที่ทำแนวปฏิบัตินั้นถูกอ้างอิงกี่เท่าของงานอายุเท่ากันที่ไม่ได้ทำ ตัวเลขในวงเล็บคือช่วงความเชื่อมั่น 95% ถ้าคร่อม 1 ถือว่าไม่ต่าง (ใช้ 62 เรื่องที่ตีพิมพ์ถึงปี 2024)</li>'
          '<li><b>การทดลองของเรา</b> หมายถึง experiment/RESULTS.md (MWMOTE, CISO, QC-SMOTE บน KEEL 110 ชุด, 31 ส.ค. 2026)</li></ul></div>')
    return h + '</section>'


def scorecard():
    h = '<section class="s" id="ours"><h2><span class="n">11</span><span>การทดลองของเราเทียบกับข้อแนะนำ <span class="en">Our experiment</span></span></h2>'
    h += '<p>การทดลองใน experiment/RESULTS.md (110 ชุดจาก KEEL × 5 วิธี × 5 ตัวจำแนก × stratified 5-fold CV = 13,750 รอบ) ทำส่วนสำคัญไว้ถูกแล้ว รายการนี้รวบรวมจากทุกหัวข้อว่ามีอะไรแล้วและควรเพิ่มอะไร</p>'
    ok = ['110 ชุดจาก KEEL และคำนวณ IR', 'เส้นฐานไม่ปรับสมดุลและ SMOTE', '5 ตัวจำแนกจากคนละตระกูล และรายงานแยกตัว', 'ROC-AUC และ PR-AUC จากคะแนน คู่กับ F1 และ G-mean',
          'Stratified 5-fold CV, fold เดียวกันทุกวิธี, seed คงที่', 'ปรับสมดุลและปรับสเกลเฉพาะข้อมูลฝึก', 'ค่าคงที่กับทุกวิธี ไม่เลือกค่าบน fold ทดสอบ',
          'เก็บผลราย fold', 'อันดับเฉลี่ย Friedman และจำนวนครั้งที่ชนะ', 'สรุปผลแยกตามตัวชี้วัด และบันทึกความเที่ยงตรงของวิธีที่เขียนเอง']
    add = ['ทำ CV ซ้ำ 5 รอบขึ้นไป', 'เส้นฐาน class weighting และ ROS', 'ตัวจำแนก gradient boosting', 'MCC หรือ BA และประกาศตัวชี้วัดหลัก',
           'ทดสอบ Friedman + Holm แยกตามตัวจำแนก (N = 110) แทนการรวม 550 คู่', 'ขนาดของผล และ Bayesian signed-rank', 'SD เวลาประมวลผล และ CD diagram',
           'วัดจุดสังเคราะห์ตรง ๆ และค่าความยากของชุดข้อมูล', 'ข้อมูลสังเคราะห์ที่ควบคุมปัจจัย', 'ตรวจ CISO และ QC-SMOTE ที่เขียนเองกับตัวเลขในบทความ', 'เผยแพร่โค้ด ดัชนี fold และผล']
    h += '<div class="two"><div class="ours"><div class="oh">มีแล้ว (' + str(len(ok)) + ')</div><ul>' + ''.join('<li><span class="st s-ok">มีแล้ว</span><span>' + x + '</span></li>' for x in ok) + '</ul></div>'
    h += '<div class="ours"><div class="oh">ควรเพิ่มหรือแก้ (' + str(len(add)) + ')</div><ul>' + ''.join('<li><span class="st s-add">ควรเพิ่ม</span><span>' + x + '</span></li>' for x in add) + '</ul></div></div>'
    return h + '</section>'


def checklist():
    h = '<section class="s" id="checklist"><h2><span class="n">12</span><span>รายการตรวจก่อนส่ง paper <span class="en">Reporting checklist</span></span></h2>'
    h += '<p>รวมทุกข้อในส่วนที่ 3 ของแต่ละหัวข้อ ติ๊กได้ เบราว์เซอร์จะจำไว้ในเครื่องนี้ <span id="ckcount" class="chip"></span> <button type="button" id="ckreset" class="btn">ล้างเครื่องหมาย</button></p>'
    cur = None
    names = {n: th for n, tid, th, en, s in TOPICS}
    for t, cid, txt in CHECK:
        if t != cur:
            if cur is not None:
                h += '</ul>'
            h += '<h3>' + str(t) + ' ' + names[t] + '</h3><ul class="chk">'
            cur = t
        h += '<li><label><input type="checkbox" data-c="' + cid + '"><span>' + txt + '</span></label></li>'
    return h + '</ul></section>'


def references():
    rows = sorted(USED.items(), key=lambda kv: -(SRC[kv[0]]['cites'] or 0))
    h = '<section class="s" id="refs"><h2><span class="n">13</span><span>งานที่อ้างถึงทั้งหมด <span class="en">References with citation counts</span></span></h2>'
    h += '<p>ยอดอ้างอิงจาก OpenAlex (18 ต.ค. 2026) "ต่อปี" คือยอดหารด้วยจำนวนปีตั้งแต่ตีพิมพ์ถึงปี 2026 รวมปีแรก กดหัวคอลัมน์เพื่อเรียง</p>'
    h += '<div class="scroll"><table class="t wide" id="reftable"><thead><tr><th data-k="label">งาน</th><th data-k="kind">ประเภท</th><th class="r" data-k="year">ปี</th><th class="r" data-k="cites">ยอดอ้างอิง</th><th class="r" data-k="cpy">ต่อปี</th><th data-k="topics">ใช้ในหัวข้อ</th></tr></thead><tbody>'
    for k, ts in rows:
        s = SRC[k]
        c = s['cites'] or 0
        y = s['year']
        h += ('<tr data-label="' + esc(s['label']) + '" data-kind="' + s['kind'] + '" data-year="' + str(y) + '" data-cites="' + str(c) + '" data-cpy="' + f"{cpy(c, y):.1f}" + '" data-topics="' + str(min(ts)) + '">'
              '<td><b>' + esc(s['label']) + '</b><div class="sub">' + esc(s['title']) + (' · ' + esc(s['venue']) if s['venue'] else '') + '</div></td>'
              '<td>' + ('ระเบียบวิธี / แหล่งข้อมูล' if s['kind'] == 'ref' else 'งานในคลังบทความ') + '</td><td class="r">' + str(y) + '</td><td class="r"><b>' + f"{c:,}" + '</b></td><td class="r">' + f"{cpy(c, y):.1f}" + '</td>'
              '<td>' + ', '.join('<a href="#' + [tid for n, tid, *_ in TOPICS if n == t][0] + '">' + str(t) + '</a>' for t in sorted(ts)) + '</td></tr>')
    return h + '</tbody></table></div></section>'


TOC = [('overview', '0', 'ภาพรวมในหน้าเดียว')] + [(tid, str(n), th) for n, tid, th, en, s in TOPICS] + [('ours', '11', 'การทดลองของเรา'), ('checklist', '12', 'รายการตรวจก่อนส่ง'), ('refs', '13', 'งานที่อ้างถึง')]

CSS_EXTRA = r"""
.part{border:1px solid var(--rule);border-radius:12px;padding:14px 16px;display:grid;gap:12px;min-width:0}
.ph{display:flex;align-items:center;gap:10px;font-weight:600;font-size:15px}
.pn{display:inline-grid;place-items:center;width:24px;height:24px;border-radius:50%;font-size:13px;color:var(--paper);flex:none}
.p1 .pn{background:var(--accent)} .p2 .pn{background:var(--good)} .p3 .pn{background:var(--warn)}
.p2{background:var(--good-soft);border-color:transparent} .p3{background:var(--warn-soft);border-color:transparent}
.p2 .t th,.p3 .t th{border-bottom-color:var(--rule)}
h4{margin:4px 0 0;font-size:14px}
.note{font-size:12.5px;color:var(--muted);margin:0}
.sub{font-size:11.5px;color:var(--muted);font-weight:400;line-height:1.4}
table.trend{min-width:640px} .trend td,.trend th{padding:6px 8px}
.cell{position:relative;display:block;width:100%;min-width:56px;height:22px;border-radius:4px;background:var(--rule-2);overflow:hidden}
.cell i{position:absolute;left:0;top:0;bottom:0;background:var(--c1);opacity:.75}
.cell span{position:relative;display:block;text-align:center;font-size:12px;line-height:22px;color:var(--ink);font-variant-numeric:tabular-nums}
.tchip{font-size:11.5px;font-weight:600;border-radius:999px;padding:1px 9px;white-space:nowrap;border:1px solid var(--rule)}
.t-up{color:var(--accent)} .t-down{color:var(--warn)} .t-new{color:var(--good)} .t-gone{color:var(--muted);text-decoration:line-through} .t-flat{color:var(--ink-2)}
.hbars{display:grid;gap:5px;font-variant-numeric:tabular-nums}
.hb{display:grid;grid-template-columns:minmax(0,300px) minmax(0,1fr) 58px;gap:10px;align-items:center;font-size:13px}
.ht{height:10px;background:var(--rule-2);border-radius:3px;overflow:hidden} .ht i{display:block;height:100%}
.hv{text-align:right;font-weight:600} .hv em{font-style:normal;font-weight:400;color:var(--muted);font-size:11.5px}
.mults{display:flex;flex-wrap:wrap;gap:6px}
.mult{font-size:12.5px;border:1px solid var(--rule);border-radius:8px;padding:3px 9px;background:var(--paper)}
.mult small{color:var(--muted)} .mult.m-low{border-color:var(--warn);color:var(--warn)} .mult.m-near b{color:var(--accent)}
ol.rec{margin:0;padding-left:22px;display:grid;gap:6px;max-width:80ch}
ol.rec ul{margin:4px 0 0;padding-left:18px;display:grid;gap:2px}
.why{display:grid;gap:4px} .why > b{font-size:13px;color:var(--good)} .why ul{margin:0;padding-left:20px;display:grid;gap:5px;max-width:80ch}
.cite{display:inline-block;font-size:12px;border-radius:999px;padding:0 9px;background:var(--paper);border:1px solid var(--rule);white-space:nowrap;line-height:1.7}
.cite b{font-variant-numeric:tabular-nums}
table.ev{background:var(--paper);border-radius:8px}
.ours{background:var(--paper);border:1px solid var(--rule);border-radius:10px;padding:10px 12px;display:grid;gap:6px}
.oh{font-weight:600;font-size:13.5px} .ours ul{list-style:none;margin:0;padding:0;display:grid;gap:5px}
.ours li{display:grid;grid-template-columns:86px minmax(0,1fr);gap:8px;font-size:13.5px;align-items:start}
.st{font-size:11.5px;font-weight:600;border-radius:999px;padding:1px 8px;text-align:center;white-space:nowrap}
.s-ok{background:var(--good-soft);color:var(--good)} .s-add{background:var(--warn-soft);color:var(--warn)} .s-fix{background:var(--warn);color:var(--paper)} .s-note{background:var(--accent-soft);color:var(--accent)}
ul.chk{list-style:none;margin:0;padding:0;display:grid;gap:4px}
ul.chk label{display:grid;grid-template-columns:22px minmax(0,1fr);gap:6px;align-items:start;cursor:pointer;font-size:14px}
ul.chk input{margin-top:5px;width:15px;height:15px;accent-color:var(--good)}
ul.chk input:checked + span{color:var(--muted);text-decoration:line-through}
.sent{background:var(--paper);border-radius:8px;padding:10px 12px;border:1px solid var(--rule)}
.sl{font-size:12px;font-weight:600;color:var(--warn);margin-bottom:4px}
.sent p{font-family:var(--f-serif);font-size:15px;line-height:1.6;max-width:none}
table.sum td.g{color:var(--good);font-weight:600}
table.sum{min-width:820px}
.two{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:14px}
.btn{font:inherit;font-size:12.5px;border:1px solid var(--rule);background:var(--paper);color:var(--ink-2);border-radius:999px;padding:2px 10px;cursor:pointer}
#reftable th[data-k]{cursor:pointer;user-select:none} #reftable th[data-k]:hover{color:var(--ink)}
#reftable th.sorted::after{content:" ▾"}
@media (max-width:640px){.hb{grid-template-columns:minmax(0,1fr) 54px}.hb .ht{grid-column:1/-1;grid-row:2}.ours li{grid-template-columns:minmax(0,1fr);gap:2px}.st{justify-self:start}.part{padding:12px}.ev .sub{display:none}table.ev td,table.ev th{padding:6px}}
"""

SCRIPT = r"""
<script>
(function () {
  var $ = function (id) { return document.getElementById(id); };
  var toc = $('tocd'), mq = window.matchMedia('(max-width:900px)');
  function syncToc() { toc.open = !mq.matches; }
  syncToc(); if (mq.addEventListener) mq.addEventListener('change', syncToc);
  toc.querySelector('summary').addEventListener('click', function (e) { if (!mq.matches) e.preventDefault(); });
  toc.addEventListener('click', function (e) { if (e.target.closest('a') && mq.matches) toc.open = false; });
  // checklist: one state shared by the topic lists and the combined list, remembered in this browser
  var KEY = 'smote25-eval-guide-check', state = {};
  try { state = JSON.parse(localStorage.getItem(KEY) || '{}') || {}; } catch (e) { state = {}; }
  var boxes = Array.prototype.slice.call(document.querySelectorAll('input[data-c]'));
  var ids = {}; boxes.forEach(function (b) { ids[b.getAttribute('data-c')] = 1; });
  function paint() {
    boxes.forEach(function (b) { b.checked = !!state[b.getAttribute('data-c')]; });
    var total = Object.keys(ids).length, done = Object.keys(ids).filter(function (k) { return state[k]; }).length;
    $('ckcount').textContent = 'ทำแล้ว ' + done + ' จาก ' + total + ' ข้อ';
  }
  function save() { try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (e) {} }
  boxes.forEach(function (b) { b.addEventListener('change', function () { state[b.getAttribute('data-c')] = b.checked; save(); paint(); }); });
  $('ckreset').addEventListener('click', function () { state = {}; save(); paint(); });
  paint();
  // sortable reference table
  var tb = $('reftable'), dir = {};
  tb.querySelectorAll('th[data-k]').forEach(function (th) {
    th.addEventListener('click', function () {
      var k = th.getAttribute('data-k'), num = ['year', 'cites', 'cpy', 'topics'].indexOf(k) >= 0;
      dir[k] = dir[k] === undefined ? (num && k !== 'topics' ? -1 : 1) : -dir[k];
      var rows = Array.prototype.slice.call(tb.tBodies[0].rows);
      rows.sort(function (a, b) {
        var x = a.getAttribute('data-' + k), y = b.getAttribute('data-' + k);
        return (num ? (parseFloat(x) - parseFloat(y)) : x.localeCompare(y)) * dir[k];
      });
      rows.forEach(function (r) { tb.tBodies[0].appendChild(r); });
      tb.querySelectorAll('th').forEach(function (h) { h.classList.remove('sorted'); }); th.classList.add('sorted');
    });
  });
})();
</script>
"""


def build():
    css = open(R + 'guide/primer_style.css').read()
    body = '\n'.join(SECS)
    page = ('<title>SMOTE25 Evaluation Guide</title>\n<meta name="claude:viewport-fit-sides" content="cover">\n'
            '<link rel="preconnect" href="https://fonts.googleapis.com">\n<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>\n'
            '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500&family=IBM+Plex+Sans+Thai:wght@400;500;600&family=Noto+Serif+Thai:wght@400;600&family=STIX+Two+Text:ital,wght@0,400;0,600;1,400&display=swap">\n'
            '<style>\n' + css + CSS_EXTRA + '</style>\n'
            '<div class="wrap"><header class="top"><div class="eyebrow">SMOTE25 · หัวข้อที่ 7 · คู่มือการวัดผล</div>'
            '<h1>งานตระกูล SMOTE วัดผลกันอย่างไร และเราควรวัดอย่างไร</h1>'
            '<p class="lede">วิเคราะห์จากงานที่มีการทดลอง 71 เรื่อง แบ่งเป็น 10 หัวข้อของการวัดผล แต่ละหัวข้อบอกว่างานทั้งหมดทำอะไร เราควรเลือกอะไรพร้อมเหตุผลและงานอ้างอิงที่มียอดอ้างอิงกำกับ และถ้าเขียนลง paper ผู้อ่านต้องรู้อะไร '
            'ถ้ายังไม่คุ้นกับตัวชี้วัดหรือการทดสอบ อ่าน SMOTE25_Evaluation_Primer ก่อน</p></header>'
            '<div class="layout"><nav class="toc" aria-label="สารบัญ"><details id="tocd" open><summary>สารบัญ</summary><ol>' +
            ''.join('<li><a href="#' + a + '"><span>' + n + '</span><span>' + t + '</span></a></li>' for a, n, t in TOC) +
            '</ol></details></nav><main class="sheet">' + overview() + body + scorecard() + checklist() + references() +
            '<div class="foot"><span>ตัวเลขจากข้อมูลที่ลงรหัสไว้สำหรับหัวข้อที่ 7 (76 เรื่อง มีการทดลอง 71 เรื่อง) ยอดอ้างอิงจาก OpenAlex ณ 18 ต.ค. 2026 การทดลองของเราจาก experiment/RESULTS.md (31 ส.ค. 2026)</span>'
            '<span>ใช้คู่กับ SMOTE25_Evaluation_Section, SMOTE25_Evaluation_Roadmap และ SMOTE25_Evaluation_Primer · ปรับปรุง 8 พ.ย. 2026</span></div>'
            '</main></div></div>' + SCRIPT)
    assert '—' not in page, 'em-dash'
    open(R + 'guide/evaluation_guide.html', 'w').write(page)
    i = page.index('</style>\n') + len('</style>\n')
    doc = ('<!doctype html>\n<html lang="th">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n'
           + page[:i] + '</head>\n<body>\n' + page[i:] + '\n</body>\n</html>\n')
    open(R + 'section07-evaluation-guide.html', 'w').write(doc)
    print('page', len(page.encode()), 'refs used', len(USED), 'checklist', len(CHECK))


build()
