"""SMOTE25 Section 7 paper picker: the data book split into items that can be marked for the paper (use / maybe / not),
assigned to a paper subsection and a form, annotated, edited in place and exported as Markdown or JSON.
Choices are kept in the artifact's db (collection `picks`, one document per item; `meta/outline` holds the subsection list),
or in the browser when no db is available (a downloaded copy)."""
import json, re, hashlib, html
from bs4 import BeautifulSoup, NavigableString
import build_databook as BD

OUT = BD.OUT
esc = html.escape

TARGETS = ['7.1 Corpus, coding and how to read the numbers', '7.2 From SMOTE (2002) to today', '7.3 Data and tasks', '7.4 Base learners',
           '7.5 Competitors and baselines', '7.6 Performance measures', '7.7 Evidence beyond classifier scores', '7.8 Protocol and settings',
           '7.9 Statistical testing', '7.10 Reporting results', '7.11 Why evaluation practice changed', '7.12 What the comparisons conclude',
           '7.13 A protocol for a new study', '7.14 Limitations', 'Appendix / supplement']
SUG = {'d0': 0, 'd1': 1, 'd2': 2, 'd3': 3, 'd4': 4, 'd5': 5, 'd6': 6, 'd7': 7, 'd8': 8, 'd9': 9, 'd10': 10, 'd11': 11, 'd12': 12, 'd13': 14, 'd14': 14, 'd15': 0, 'd16': 13}

TYPE_TH = {'table': 'ตาราง', 'fig': 'รูป / กราฟ', 'interactive': 'เครื่องมือโต้ตอบ', 'box': 'กล่องสรุป', 'tiles': 'ตัวเลขสรุป', 'bars': 'แท่งเทียบ',
           'sent': 'ประโยคสำหรับ paper', 'why': 'เหตุและผล', 'text': 'ข้อความ', 'list': 'รายการ', 'guide': 'ข้อแนะนำ'}


def txt(el, n=None):
    t = re.sub(r'\s+', ' ', el.get_text(' ', strip=True)).strip()
    return t if n is None or len(t) <= n else t[:n].rstrip() + '…'


def classes(el):
    return set(el.get('class') or [])


def kind(el):
    c = classes(el)
    if 'why' in c:
        return 'why'
    if 'part' in c:
        return 'guide'
    if el.find(['select', 'input']) is not None and el.name != 'ul':
        return 'interactive'
    if 'sent' in c or el.find(class_='sent') is not None:
        return 'sent'
    if 'part' in c:
        return 'guide'
    if el.name == 'table' or el.find('table') is not None:
        return 'table'
    if el.name == 'svg' or el.find('svg') is not None or 'fig' in c:
        return 'fig'
    if 'tiles' in c or 'vs' in c:
        return 'tiles'
    if 'hbars' in c or 'cats' in c:
        return 'bars'
    if 'box' in c or 'two' in c or 'pipe' in c or 'chain' in c:
        return 'box'
    if el.name in ('ul', 'ol', 'dl'):
        return 'list'
    return 'text'


def default_title(el, k):
    c = classes(el)
    if k == 'why':
        wh = el.find(class_='wh')
        return txt(wh or el, 90)
    if k == 'guide':
        ph = el.find(class_='ph')
        return txt(ph or el, 90)
    if 'fig' in c and el.find(class_='ft') is not None:
        return txt(el.find(class_='ft'), 90)
    if k == 'sent':
        return 'ประโยคภาษาอังกฤษสำหรับ paper'
    if 'box' in c and el.find('b') is not None:
        return txt(el.find('b'), 90)
    if 'two' in c:
        hs = [txt(h, 50) for h in el.find_all(['h3', 'h4', 'b'], limit=2)]
        if hs:
            return ' / '.join(hs)
    if k == 'tiles':
        return 'ตัวเลขสรุป: ' + txt(el, 70)
    if 'mapctl' in c:
        return 'แผนที่งานทั้ง 71 เรื่อง: ตารางที่ค้นหา กรอง และเรียงได้'
    if 'pipe' in c:
        return 'ภาพ pipeline: การวัดแต่ละแบบแตะที่จุดไหน'
    if k == 'table':
        t = el.find('table')
        if t is not None:
            cap = t.find('caption')
            if cap is not None:
                return txt(cap, 90)
            head = [txt(x) for x in (t.find('thead') or t).find_all('th')]
            rows = [txt(r.find(['td', 'th'])) for r in (t.find('tbody') or t).find_all('tr')[:4] if r.find(['td', 'th']) is not None]
            rows = [r for r in rows if r]
            era = any('2009' in h for h in head)
            lab = ', '.join(rows[:3]) + (' …' if len(rows) > 3 else '')
            if era:
                return 'ตามช่วงปี: ' + (lab or ' '.join(head[:3]))
            return 'ตาราง ' + ' / '.join(h for h in head[:4] if h) + (': ' + lab if lab else '')
    return txt(el, 90)


class Splitter:
    def __init__(self):
        self.items, self.seen = [], set()

    def add(self, sec, crumbs, title, el_html, k, anchors):
        base = sec + '|' + '|'.join(crumbs) + '|' + title + '|' + re.sub(r'\s+', ' ', BeautifulSoup(el_html, 'html.parser').get_text(' '))[:400]
        h = hashlib.md5(base.encode()).hexdigest()[:10]
        iid = sec + '-' + h
        n = 2
        while iid in self.seen:
            iid = sec + '-' + h + '-' + str(n); n += 1
        self.seen.add(iid)
        self.items.append(dict(id=iid, sec=sec, crumbs=list(crumbs), title=title, html=el_html, kind=k, anchors=anchors))

    def walk(self, sec, container, crumbs):
        pending, sub, anchors = None, None, []
        last = None
        for el in container.children:
            if isinstance(el, NavigableString):
                continue
            c = classes(el)
            if el.get('id') and el.name in ('h3', 'h4'):
                anchors.append(el['id'])
            if el.name in ('h2',) or 'asks' in c:
                continue
            if el.name == 'h3':
                pending, sub = txt(el), None
                continue
            if el.name == 'h4':
                sub = txt(el)
                continue
            if el.name == 'p' and 'note' in c and last is not None:
                last['html'] += str(el)
                continue
            if 'qblock' in c or 'gtopic' in c:
                h = el.find(['h3'], class_='qh')
                head = txt(h) if h else ''
                if h is not None:
                    h.extract()
                if el.get('id'):
                    anchors.append(el['id'])
                self.pending_anchors = anchors
                self.walk(sec, el, crumbs + [head])
                anchors, pending, sub, last = [], None, None, None
                continue
            if 'whys' in c:
                group = [x for x in (pending, sub) if x]
                for w in el.find_all('div', class_='why', recursive=False):
                    self.add(sec, crumbs + group, default_title(w, 'why'), str(w), 'why', anchors)
                    anchors = []
                last = None
                continue
            k = kind(el)
            if 'mapctl' in c:
                self.merge_next = True
            elif getattr(self, 'merge_next', False) and last is not None:
                self.merge_next = False
                last['html'] += str(el)
                continue
            title = pending or default_title(el, k)
            if k == 'guide' and crumbs and crumbs[-1]:
                title = re.sub(r'^คู่มือ:\s*', '', crumbs[-1]) + ' · ' + title
            if pending and k in ('why', 'guide'):
                title = pending + ' · ' + default_title(el, k)
            pre = getattr(self, 'pending_anchors', [])
            self.pending_anchors = []
            self.add(sec, crumbs + ([sub] if sub and not pending else []), title, str(el), k, pre + anchors)
            last = self.items[-1]
            anchors, pending = [], None


def collect():
    for f in (BD.d0, BD.d1, BD.d2, BD.d3, BD.d4, BD.d5, BD.d6, BD.d7, BD.d8, BD.d9, BD.d10, BD.d11, BD.d12, BD.d13, BD.d14, BD.d15, BD.d16):
        f()
    qh, nq = BD.qindex()
    S = Splitter()
    secs = []
    for s in BD.SECS:
        soup = BeautifulSoup(s, 'html.parser')
        sec = soup.find('section')
        sid = sec['id']
        h2 = sec.find('h2')
        asks = sec.find('div', class_='asks', recursive=False)
        n0 = len(S.items)
        S.walk(sid, sec, [])
        secs.append(dict(id=sid, h2=str(h2), asks=str(asks) if asks else '', items=S.items[n0:]))
    return secs, qh, nq, len(S.items)


def article(it):
    editable = '0' if it['kind'] in ('interactive', 'fig') or '<svg' in it['html'] or 'id="m' in it['html'] else '1'
    crumbs = ' › '.join(esc(c) for c in it['crumbs'] if c)
    anch = ''.join('<span class="anc" id="' + esc(a) + '"></span>' for a in it['anchors'])
    return (anch + '<article class="it" id="i-' + it['id'] + '" data-id="' + it['id'] + '" data-sec="' + it['sec'] + '" data-kind="' + it['kind'] + '" data-edit="' + editable +
            '" data-sug="' + str(SUG.get(it['sec'], '')) + '"><header class="ih"><div class="it-meta"><span class="isec">' + it['sec'].upper() + '</span><span class="ity">' + TYPE_TH[it['kind']] +
            '</span>' + ('<span class="icr">' + crumbs + '</span>' if crumbs else '') + '</div><h4 class="it-t"><button type="button" class="tt" aria-expanded="true">' + esc(it['title']) +
            '</button></h4></header><div class="ic">' + it['html'] + '</div></article>')


CSS_PK = r"""
:root{--use:#1d6f3c;--use-soft:#e4f2e8;--maybe:#9a6a00;--maybe-soft:#fbf1d9;--no:#6c7986;--no-soft:#eef1f4}
@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){--use:#6cc58c;--use-soft:#173022;--maybe:#e7b955;--maybe-soft:#352a12;--no:#8b97a3;--no-soft:#1f252b}}
:root[data-theme="dark"]{--use:#6cc58c;--use-soft:#173022;--maybe:#e7b955;--maybe-soft:#352a12;--no:#8b97a3;--no-soft:#1f252b}
.pk-layout{display:grid;grid-template-columns:minmax(0,1fr) 330px;gap:22px;align-items:start}
.pk-bar{position:sticky;top:0;z-index:20;background:var(--bg);padding:10px 0;display:flex;flex-wrap:wrap;gap:8px;align-items:center;border-bottom:1px solid var(--rule)}
.pk-bar input[type=search],.pk-bar select{font:inherit;font-size:13.5px;padding:7px 9px;border:1px solid var(--rule);border-radius:8px;background:var(--paper);color:var(--ink);min-width:0}
.pk-bar input[type=search]{flex:1 1 220px}
.pk-bar .cnt{font-size:12.5px;color:var(--muted)}
.btn2{font:inherit;font-size:13px;padding:6px 11px;border:1px solid var(--rule);border-radius:8px;background:var(--paper);color:var(--ink);cursor:pointer;line-height:1.3}
.btn2:hover{border-color:var(--accent)}
.btn2.pri{background:var(--accent);border-color:var(--accent);color:#fff}
.btn2[aria-pressed="true"]{background:var(--accent-soft);border-color:var(--accent);color:var(--accent)}
.pk-main{min-width:0}
section.ps{margin:18px 0 26px;min-width:0}
section.ps > h2{font-size:21px;margin:0 0 8px;display:flex;gap:10px;align-items:baseline;flex-wrap:wrap}
section.ps > h2 .n{font-size:12px;font-weight:600;color:var(--accent);border:1.5px solid var(--accent);border-radius:6px;padding:1px 7px}
section.ps > h2 .en{font-size:13px;color:var(--muted);font-weight:400}
.ps-tools{display:flex;gap:6px;flex-wrap:wrap;margin:0 0 10px}
article.it{background:var(--paper);border:1px solid var(--rule);border-left:4px solid var(--rule);border-radius:10px;margin:0 0 12px;min-width:0;scroll-margin-top:70px}
article.it[data-st="use"]{border-left-color:var(--use)}
article.it[data-st="maybe"]{border-left-color:var(--maybe)}
article.it[data-st="no"]{border-left-color:var(--no);opacity:.72}
article.it.flash{box-shadow:0 0 0 3px var(--accent)}
.ih{display:grid;gap:4px;padding:10px 14px 8px;border-bottom:1px solid var(--rule-2)}
.it-meta{display:flex;flex-wrap:wrap;gap:6px;align-items:center;font-size:11.5px;color:var(--muted)}
.isec{font-weight:600;color:var(--accent)}
.ity{border:1px solid var(--rule);border-radius:999px;padding:0 7px}
.icr{min-width:0;overflow-wrap:anywhere}
h4.it-t{margin:0;font-size:15px;line-height:1.45}
h4.it-t .tt{all:unset;cursor:pointer;display:block;overflow-wrap:anywhere}
h4.it-t .tt:focus-visible{outline:2px solid var(--accent);outline-offset:2px;border-radius:4px}
.ictl{display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin-top:4px}
.seg{display:inline-flex;border:1px solid var(--rule);border-radius:8px;overflow:hidden}
.seg button{font:inherit;font-size:12.5px;padding:5px 10px;border:0;border-right:1px solid var(--rule);background:var(--paper);color:var(--ink-2);cursor:pointer}
.seg button:last-child{border-right:0}
.seg button[data-s="use"][aria-pressed="true"]{background:var(--use-soft);color:var(--use);font-weight:600}
.seg button[data-s="maybe"][aria-pressed="true"]{background:var(--maybe-soft);color:var(--maybe);font-weight:600}
.seg button[data-s="no"][aria-pressed="true"]{background:var(--no-soft);color:var(--no);font-weight:600}
.ictl select{font:inherit;font-size:12.5px;padding:5px 6px;border:1px solid var(--rule);border-radius:8px;background:var(--paper);color:var(--ink);max-width:260px;min-width:0}
.ictl .btn2{font-size:12.5px;padding:5px 9px}
.badges{display:inline-flex;gap:4px}
.bdg{font-size:11px;border-radius:999px;padding:1px 7px;background:var(--accent-soft);color:var(--accent)}
.ic{padding:12px 14px;min-width:0;display:grid;gap:12px}
.ic > *{min-width:0}
.ic[contenteditable="true"]{outline:2px dashed var(--accent);outline-offset:-4px;background:var(--tint)}
body.compact article.it:not(.open) .ic,body.compact article.it:not(.open) .edbar{display:none}
article.it.shut .ic,article.it.shut .edbar{display:none}
.edbar{display:flex;flex-wrap:wrap;gap:6px;align-items:center;padding:8px 14px;border-top:1px solid var(--rule-2);background:var(--tint);font-size:12.5px}
.inote{padding:8px 14px 12px;border-top:1px solid var(--rule-2)}
.inote label{display:block;font-size:12px;color:var(--muted);margin-bottom:4px}
.inote textarea{width:100%;min-height:84px;font:inherit;font-size:14px;line-height:1.6;padding:8px 10px;border:1px solid var(--rule);border-radius:8px;background:var(--paper);color:var(--ink);resize:vertical}
aside.pk-panel{position:sticky;top:64px;max-height:calc(100vh - 76px);overflow:auto;background:var(--paper);border:1px solid var(--rule);border-radius:12px;padding:12px 14px;font-size:13.5px;display:grid;gap:10px}
.pp-h{display:flex;justify-content:space-between;align-items:center;gap:8px}
.pp-h b{font-size:15px}
.pp-x{display:none}
.pp-c{display:grid;grid-template-columns:repeat(3,1fr);gap:6px}
.pp-c div{border:1px solid var(--rule);border-radius:8px;padding:6px 8px;line-height:1.3}
.pp-c div b{display:block;font-size:19px;font-variant-numeric:tabular-nums}
.pp-c .u b{color:var(--use)} .pp-c .m b{color:var(--maybe)} .pp-c .x b{color:var(--no)}
.pp-st{font-size:12px;color:var(--muted)}
.pp-st.warn{color:var(--warn)}
.pp-g{display:grid;gap:4px}
.pp-g h5{margin:6px 0 0;font-size:12.5px;color:var(--ink-2);display:flex;justify-content:space-between;gap:6px}
.pp-g button{all:unset;cursor:pointer;display:grid;grid-template-columns:10px minmax(0,1fr);gap:7px;align-items:baseline;font-size:12.5px;line-height:1.4;padding:2px 4px;border-radius:5px}
.pp-g button:hover,.pp-g button:focus-visible{background:var(--tint)}
.pp-g i{width:8px;height:8px;border-radius:50%;display:inline-block}
.pp-g i.use{background:var(--use)} .pp-g i.maybe{background:var(--maybe)}
.pp-g .empty{font-size:12px;color:var(--muted)}
.pp-a{display:flex;flex-wrap:wrap;gap:6px}
.fab{display:none}
.modal{position:fixed;inset:0;z-index:50;background:rgba(10,15,20,.45);display:grid;place-items:center;padding:16px}
.modal > div{background:var(--paper);color:var(--ink);border-radius:12px;border:1px solid var(--rule);width:min(860px,100%);max-height:calc(100vh - 32px);display:grid;grid-template-rows:auto minmax(0,1fr) auto;gap:10px;padding:14px 16px}
.modal h3{margin:0;font-size:17px}
.modal textarea{width:100%;min-height:300px;height:100%;font-family:var(--f-mono);font-size:12.5px;line-height:1.5;padding:10px;border:1px solid var(--rule);border-radius:8px;background:var(--tint);color:var(--ink);resize:vertical}
.modal .row{display:flex;flex-wrap:wrap;gap:8px;align-items:center;justify-content:flex-end}
.modal .row label{margin-right:auto;font-size:13px}
.toast{position:fixed;left:50%;bottom:22px;transform:translateX(-50%);background:var(--ink);color:var(--paper);padding:8px 14px;border-radius:8px;font-size:13px;z-index:60}
details.qiwrap{background:var(--paper);border:1px solid var(--rule);border-radius:12px;padding:8px 14px;margin:12px 0}
details.qiwrap summary{cursor:pointer;font-weight:600}
details.qiwrap section.s{border-top:0;margin-top:0;padding-top:6px}
details.qiwrap section.s > h2{display:none}
.help{font-size:13.5px;color:var(--ink-2);background:var(--paper);border:1px solid var(--rule);border-radius:12px;padding:10px 14px;margin:0}
.help ol{margin:4px 0 0;padding-left:1.3em}
.anc{display:block;height:0;scroll-margin-top:70px}
@media (max-width:1000px){
  .pk-layout{grid-template-columns:minmax(0,1fr)}
  aside.pk-panel{position:fixed;inset:auto 0 0 0;top:auto;max-height:78vh;border-radius:14px 14px 0 0;z-index:40;box-shadow:0 -6px 24px rgba(0,0,0,.18);display:none;padding-bottom:max(12px,env(safe-area-inset-bottom,0px))}
  body.panel-open aside.pk-panel{display:grid}
  .pp-x{display:inline-block}
  .fab{display:inline-flex;position:fixed;right:max(16px,env(safe-area-inset-right,0px));bottom:max(16px,env(safe-area-inset-bottom,0px));z-index:30;box-shadow:0 4px 14px rgba(0,0,0,.2)}
}
@media (max-width:640px){.ictl select{max-width:100%;flex:1 1 140px}.pk-bar{position:static}article.it{scroll-margin-top:12px}}
"""

PICKJS = r"""
(function(){
'use strict';
const OUT_DEF = JSON.parse(document.getElementById('pk-outline').textContent);
const FORMS = [['', 'รูปแบบใน paper'], ['table', 'ตาราง'], ['figure', 'รูป'], ['text', 'ข้อความในเนื้อหา'], ['number', 'ตัวเลขในประโยค'], ['appendix', 'ภาคผนวก / supplement'], ['cite', 'อ้างอิงเท่านั้น']];
const FORM_TH = Object.fromEntries(FORMS);
const ST_TH = {use: 'ใช้', maybe: 'อาจใช้', no: 'ไม่ใช้'};
const S = {picks: {}, targets: OUT_DEF.slice(), mode: 'init', ro: false, db: null, dl: null};
const ITEMS = [...document.querySelectorAll('article.it')];
const BYID = new Map(ITEMS.map(a => [a.dataset.id, a]));
const ORIG = new Map(ITEMS.map(a => [a.dataset.id, a.querySelector('.ic').innerHTML]));
const LOW = new Map(ITEMS.map(a => [a.dataset.id, a.textContent.toLowerCase()]));
const LSK = 'smote25-sec7-picker-v1';
const dirty = new Set(), timers = {}, chain = {};
const $ = s => document.querySelector(s);
function esc(s){ return String(s == null ? '' : s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c])); }
function toast(t){ const d = document.createElement('div'); d.className = 'toast'; d.setAttribute('role','status'); d.textContent = t; document.body.appendChild(d); setTimeout(() => d.remove(), 2200); }
function status(t, warn){ const e = $('#pp-st'); e.textContent = t; e.classList.toggle('warn', !!warn); }

/* ---------- sanitizer for edited content (only formatting tags and a few attributes survive) ---------- */
const OK_TAGS = new Set('TABLE THEAD TBODY TFOOT TR TH TD CAPTION B STRONG I EM U SUB SUP SMALL SPAN DIV P UL OL LI BR H3 H4 H5 CODE MARK S DEL INS DL DT DD'.split(' '));
const OK_ATTR = new Set(['class', 'colspan', 'rowspan', 'style']);
function sanitize(htmlStr){
  const t = document.createElement('template'); t.innerHTML = String(htmlStr || '');
  (function walk(n){
    [...n.childNodes].forEach(c => {
      if (c.nodeType === 8) { c.remove(); return; }
      if (c.nodeType !== 1) return;
      if (!OK_TAGS.has(c.tagName)) {
        if (/^(SCRIPT|STYLE|IFRAME|OBJECT|EMBED|LINK|META|SVG|MATH|FORM|INPUT|SELECT|TEXTAREA|BUTTON|IMG|VIDEO|AUDIO)$/i.test(c.tagName)) { c.remove(); return; }
        const frag = document.createDocumentFragment(); while (c.firstChild) frag.appendChild(c.firstChild); walk(frag); c.replaceWith(frag); return;
      }
      [...c.attributes].forEach(a => { const v = a.value; if (!OK_ATTR.has(a.name) || (a.name === 'style' && /url\(|expression|javascript:|@import/i.test(v))) c.removeAttribute(a.name); });
      walk(c);
    });
  })(t.content);
  return t.innerHTML;
}

/* ---------- controls ---------- */
function targetOptions(sel, cur){
  const list = S.targets.slice(); if (cur && !list.includes(cur)) list.push(cur);
  sel.innerHTML = '<option value="">หัวข้อใน paper</option>' + list.map(t => '<option' + (t === cur ? ' selected' : '') + '>' + esc(t) + '</option>').join('');
}
function buildControls(a){
  const id = a.dataset.id, h = a.querySelector('.ih');
  const c = document.createElement('div'); c.className = 'ictl';
  c.innerHTML = '<div class="seg" role="group" aria-label="สถานะ">' + ['use', 'maybe', 'no'].map(s => '<button type="button" data-s="' + s + '" aria-pressed="false">' + ST_TH[s] + '</button>').join('') + '</div>' +
    '<select class="tgt" aria-label="หัวข้อใน paper"></select><select class="frm" aria-label="รูปแบบใน paper">' + FORMS.map(f => '<option value="' + f[0] + '">' + f[1] + '</option>').join('') + '</select>' +
    '<button type="button" class="btn2 nt" aria-expanded="false">โน้ต / ประโยค</button>' + (a.dataset.edit === '1' ? '<button type="button" class="btn2 ed">แก้ไขเนื้อหา</button>' : '') + '<span class="badges"></span>';
  h.appendChild(c);
  targetOptions(c.querySelector('.tgt'), '');
  const n = document.createElement('div'); n.className = 'inote'; n.hidden = true;
  n.innerHTML = '<label for="nt-' + id + '">โน้ตหรือประโยคที่จะเขียนใน paper (บันทึกอัตโนมัติ)</label><textarea id="nt-' + id + '" placeholder="เช่น ประโยคที่จะใช้, ตัวเลขที่ต้องการ, ควรย่อตารางเหลือแถวไหน"></textarea>';
  a.appendChild(n);
  if (a.dataset.edit === '1') {
    const e = document.createElement('div'); e.className = 'edbar'; e.hidden = true;
    e.innerHTML = '<span>กำลังแก้ไข: พิมพ์ทับในกรอบได้ตรง ๆ</span><button type="button" class="btn2 pri sv">บันทึกการแก้ไข</button><button type="button" class="btn2 cx">ยกเลิก</button><button type="button" class="btn2 rs">คืนค่าเดิม</button>';
    a.querySelector('.ic').after(e);
  }
}
function isEmpty(p){ return !p || (!p.status && !p.target && !p.form && !p.note && !p.html); }
function applyPick(a){
  if (!a) return;
  const id = a.dataset.id, p = S.picks[id] || {};
  a.dataset.st = p.status || '';
  a.querySelectorAll('.seg button').forEach(b => b.setAttribute('aria-pressed', b.dataset.s === p.status ? 'true' : 'false'));
  const tg = a.querySelector('.tgt'); if (tg.value !== (p.target || '') || ![...tg.options].some(o => o.value === (p.target || ''))) targetOptions(tg, p.target || '');
  a.querySelector('.frm').value = p.form || '';
  const ta = a.querySelector('.inote textarea');
  if (document.activeElement !== ta && ta.value !== (p.note || '')) ta.value = p.note || '';
  const ic = a.querySelector('.ic');
  if (ic.getAttribute('contenteditable') !== 'true') {
    const want = p.html ? sanitize(p.html) : ORIG.get(id);
    if (a.dataset.shown !== (p.html ? 'edit:' + p.html.length + ':' + (p.t || '') : 'orig')) { ic.innerHTML = want; a.dataset.shown = p.html ? 'edit:' + p.html.length + ':' + (p.t || '') : 'orig'; }
  }
  a.querySelector('.badges').innerHTML = (p.note ? '<span class="bdg">มีโน้ต</span>' : '') + (p.html ? '<span class="bdg">แก้ไขแล้ว</span>' : '');
}
function setPick(id, patch, delay){
  const cur = Object.assign({}, S.picks[id] || {}, patch, {t: Date.now()});
  S.picks[id] = cur; dirty.add(id);
  applyPick(BYID.get(id)); renderPanel(); applyFilters(true);
  clearTimeout(timers[id]); timers[id] = setTimeout(() => queueWrite(id), delay == null ? 350 : delay);
}
function queueWrite(id){
  chain[id] = (chain[id] || Promise.resolve()).then(() => doWrite(id)).catch(() => {});
}
let inflight = 0;
async function doWrite(id){
  const p = S.picks[id];
  if (S.mode !== 'db') { saveLocal(); dirty.delete(id); return; }
  inflight++; status('กำลังบันทึก…');
  const body = {}; ['status', 'target', 'form', 'note', 'html', 't'].forEach(k => { if (p && p[k]) body[k] = p[k]; });
  const ref = S.db.doc('picks/' + id);
  const attempt = () => isEmpty(p) ? ref.delete() : ref.set(body);
  try { await attempt(); }
  catch (e) {
    if (e && e.code === 'unavailable') { await new Promise(r => setTimeout(r, 800 + Math.random() * 800)); try { await attempt(); } catch (e2) { fail(e2); } }
    else fail(e);
  } finally { inflight--; if (timers[id] == null || !dirty.has(id)) {} dirty.delete(id); if (!inflight && S.mode === 'db') status('บันทึกในข้อมูลกลางของหน้านี้แล้ว · Claude อ่านได้'); }
}
function fail(e){
  const code = e && e.code;
  if (code === 'invalid_argument' || code === 'not_granted' || code === 'revoked') { S.mode = 'local'; S.ro = true; status('บัญชีนี้บันทึกข้อมูลกลางไม่ได้ จึงบันทึกไว้ในเบราว์เซอร์นี้เท่านั้น', true); saveLocal(); }
  else if (code === 'quota_exceeded') status('พื้นที่ข้อมูลเต็ม: ลบโน้ตหรือการแก้ไขที่ไม่ใช้ก่อน', true);
  else status('บันทึกไม่สำเร็จ (' + (code || 'error') + ') ลองอีกครั้ง', true);
}
function saveLocal(){ try { localStorage.setItem(LSK, JSON.stringify({picks: S.picks, targets: S.targets})); } catch (e) {} }
function loadLocal(){ try { const v = JSON.parse(localStorage.getItem(LSK) || 'null'); if (v) { S.picks = v.picks || {}; if (Array.isArray(v.targets) && v.targets.length) S.targets = v.targets; } } catch (e) {} }

/* ---------- filters ---------- */
function applyFilters(soft){
  const q = $('#f-q').value.trim().toLowerCase(), sec = $('#f-sec').value, st = $('#f-st').value, kd = $('#f-kind').value;
  let shown = 0;
  ITEMS.forEach(a => {
    const p = S.picks[a.dataset.id] || {};
    let ok = (!sec || a.dataset.sec === sec) && (!kd || a.dataset.kind === kd);
    if (ok && st) ok = st === 'none' ? !p.status : st === 'edited' ? !!p.html : st === 'noted' ? !!p.note : st === 'picked' ? (p.status === 'use' || p.status === 'maybe') : p.status === st;
    if (ok && q) ok = LOW.get(a.dataset.id).includes(q) || (p.note || '').toLowerCase().includes(q) || (p.target || '').toLowerCase().includes(q);
    if (soft && !ok && a.contains(document.activeElement)) ok = true;
    a.hidden = !ok; if (ok) shown++;
  });
  document.querySelectorAll('section.ps').forEach(s => { s.hidden = !s.querySelector('article.it:not([hidden])'); });
  $('#f-cnt').textContent = 'แสดง ' + shown + ' จาก ' + ITEMS.length + ' รายการ';
}

/* ---------- panel ---------- */
function renderPanel(){
  const all = Object.entries(S.picks).filter(([id]) => BYID.has(id));
  const n = s => all.filter(([, p]) => p.status === s).length;
  $('#pp-u').textContent = n('use'); $('#pp-m').textContent = n('maybe'); $('#pp-x').textContent = n('no');
  $('#fab-n').textContent = n('use') + n('maybe');
  const order = id => ITEMS.indexOf(BYID.get(id));
  const groups = new Map(S.targets.map(t => [t, []]));
  all.filter(([, p]) => p.status === 'use' || p.status === 'maybe').sort((a, b) => order(a[0]) - order(b[0])).forEach(([id, p]) => {
    const k = p.target || '__none'; if (!groups.has(k)) groups.set(k, []); groups.get(k).push([id, p]);
  });
  let h = '';
  groups.forEach((list, k) => {
    if (!list.length && k === '__none') return;
    h += '<h5><span>' + esc(k === '__none' ? 'ยังไม่ระบุหัวข้อ' : k) + '</span><span>' + list.length + '</span></h5>';
    h += list.length ? list.map(([id, p]) => '<button type="button" data-go="' + id + '"><i class="' + p.status + '"></i><span>' + esc(BYID.get(id).querySelector('.tt').textContent) + (p.form ? ' · ' + esc(FORM_TH[p.form]) : '') + '</span></button>').join('') : '<div class="empty">ยังไม่มี</div>';
  });
  $('#pp-g').innerHTML = h;
}
function go(id){
  const a = BYID.get(id); if (!a) return;
  if (a.hidden) { $('#f-q').value = ''; $('#f-sec').value = ''; $('#f-st').value = ''; $('#f-kind').value = ''; applyFilters(); }
  a.classList.add('open'); a.classList.remove('shut');
  document.body.classList.remove('panel-open');
  a.scrollIntoView({block: 'start'}); a.classList.add('flash'); setTimeout(() => a.classList.remove('flash'), 1400);
}

/* ---------- export ---------- */
function mdOf(root){
  const out = []; let buf = '';
  const flush = () => { const s = buf.replace(/\s+/g, ' ').trim(); if (s) out.push(s); buf = ''; };
  const cell = c => c.textContent.replace(/\s+/g, ' ').trim().replace(/\|/g, '\\|');
  (function walk(n){
    n.childNodes.forEach(c => {
      if (c.nodeType === 3) { buf += c.textContent; return; }
      if (c.nodeType !== 1) return;
      const t = c.tagName.toUpperCase();
      if (/^(SCRIPT|STYLE|SELECT|INPUT|BUTTON|TEXTAREA)$/.test(t)) return;
      if (t === 'TABLE') { flush(); const rows = [...c.rows].map(r => [...r.cells].map(cell)); if (rows.length) { const w = Math.max(...rows.map(r => r.length)); rows.forEach(r => { while (r.length < w) r.push(''); }); out.push('| ' + rows[0].join(' | ') + ' |', '|' + rows[0].map(() => ' --- ').join('|') + '|'); rows.slice(1).forEach(r => out.push('| ' + r.join(' | ') + ' |')); out.push(''); } return; }
      if (t === 'SVG') { flush(); out.push('[รูป: ดูในหน้า picker]'); return; }
      const block = /^(P|DIV|LI|H[1-6]|UL|OL|DL|DT|DD|SECTION|ARTICLE|FIGURE|FIGCAPTION|TR|BLOCKQUOTE|HEADER)$/.test(t);
      if (block) flush();
      if (t === 'LI') buf += '- ';
      walk(c);
      if (block) flush(); else if (t === 'BR') flush();
    });
  })(root);
  flush();
  return out.join('\n').replace(/\n{3,}/g, '\n\n');
}
function buildMd(withMaybe, withContent){
  const pick = Object.entries(S.picks).filter(([id, p]) => BYID.has(id) && (p.status === 'use' || (withMaybe && p.status === 'maybe')));
  const order = id => ITEMS.indexOf(BYID.get(id));
  const groups = new Map(S.targets.map(t => [t, []]));
  pick.sort((a, b) => order(a[0]) - order(b[0])).forEach(([id, p]) => { const k = p.target || 'ยังไม่ระบุหัวข้อ'; if (!groups.has(k)) groups.set(k, []); groups.get(k).push([id, p]); });
  const d = new Date();
  let md = '# SMOTE25 Section 7: ข้อมูลที่เลือกสำหรับ paper\n\nส่งออก ' + d.toISOString().slice(0, 16).replace('T', ' ') + ' · ใช้ ' + pick.filter(x => x[1].status === 'use').length + ' รายการ' + (withMaybe ? ' · อาจใช้ ' + pick.filter(x => x[1].status === 'maybe').length + ' รายการ' : '') + '\n';
  groups.forEach((list, k) => {
    if (!list.length) return;
    md += '\n## ' + k + '\n';
    list.forEach(([id, p]) => {
      const a = BYID.get(id);
      md += '\n### ' + (p.status === 'maybe' ? '[อาจใช้] ' : '') + a.querySelector('.tt').textContent.trim() + '\n';
      md += '_ที่มา: ' + a.dataset.sec.toUpperCase() + ' · ' + a.querySelector('.ity').textContent + (p.form ? ' · นำเสนอเป็น: ' + FORM_TH[p.form] : '') + (p.html ? ' · แก้ไขแล้ว' : '') + ' · id ' + id + '_\n';
      if (p.note) md += '\n> ' + p.note.trim().replace(/\n/g, '\n> ') + '\n';
      if (withContent) { const box = document.createElement('div'); box.innerHTML = p.html ? sanitize(p.html) : ORIG.get(id); md += '\n' + mdOf(box) + '\n'; }
    });
  });
  return md;
}
function buildJson(){
  const items = Object.entries(S.picks).filter(([id, p]) => BYID.has(id) && !isEmpty(p)).sort((a, b) => ITEMS.indexOf(BYID.get(a[0])) - ITEMS.indexOf(BYID.get(b[0]))).map(([id, p]) => {
    const a = BYID.get(id);
    return {id, section: a.dataset.sec.toUpperCase(), kind: a.dataset.kind, title: a.querySelector('.tt').textContent.trim(), status: p.status || '', target: p.target || '', form: p.form || '', note: p.note || '', edited: !!p.html, edited_html: p.html || ''};
  });
  return JSON.stringify({exported: new Date().toISOString(), outline: S.targets, items}, null, 2);
}
async function offer(filename, text){
  if (S.dl) { try { await S.dl.save({filename, data: text}); toast('ส่งไฟล์ให้บันทึกแล้ว'); return; } catch (e) { if (e && (e.code === 'declined')) return; } }
  try { const u = URL.createObjectURL(new Blob([text], {type: 'text/plain;charset=utf-8'})); const l = document.createElement('a'); l.href = u; l.download = filename; document.body.appendChild(l); l.click(); l.remove(); setTimeout(() => URL.revokeObjectURL(u), 3000); }
  catch (e) { toast('ดาวน์โหลดไม่ได้ในหน้านี้: ใช้ปุ่มคัดลอกแทน'); }
}
async function copy(text){
  try { await navigator.clipboard.writeText(text); toast('คัดลอกแล้ว'); return; } catch (e) {}
  const ta = $('#ex-ta'); ta.focus(); ta.select(); try { document.execCommand('copy'); toast('คัดลอกแล้ว'); } catch (e) { toast('กด Ctrl+C เพื่อคัดลอก'); }
}
function openExport(){
  const m = $('#ex'); m.hidden = false;
  const upd = () => { $('#ex-ta').value = buildMd($('#ex-maybe').checked, $('#ex-content').checked); };
  upd(); $('#ex-maybe').onchange = upd; $('#ex-content').onchange = upd; $('#ex-ta').focus();
}
function openOutline(){
  const m = $('#ol'); m.hidden = false; $('#ol-ta').value = S.targets.join('\n'); $('#ol-ta').focus();
}
async function saveOutline(){
  const lines = $('#ol-ta').value.split('\n').map(s => s.trim()).filter(Boolean).slice(0, 60);
  if (!lines.length) return;
  S.targets = lines; $('#ol').hidden = true;
  ITEMS.forEach(a => targetOptions(a.querySelector('.tgt'), (S.picks[a.dataset.id] || {}).target || ''));
  renderPanel();
  if (S.mode === 'db') { try { await S.db.doc('meta/outline').set({targets: lines, t: Date.now()}); toast('บันทึกหัวข้อแล้ว'); } catch (e) { fail(e); } }
  else saveLocal();
}

/* ---------- events ---------- */
document.addEventListener('click', e => {
  const b = e.target.closest('button'); if (!b) return;
  const a = b.closest('article.it'), id = a && a.dataset.id;
  if (b.dataset.s && a) { const cur = (S.picks[id] || {}).status; const ns = cur === b.dataset.s ? '' : b.dataset.s; const patch = {status: ns};
    if (ns && ns !== 'no' && !(S.picks[id] || {}).target && a.dataset.sug !== '') patch.target = S.targets[+a.dataset.sug] || ''; setPick(id, patch); return; }
  if (b.classList.contains('tt') && a) { const shut = document.body.classList.contains('compact') ? !a.classList.toggle('open') : a.classList.toggle('shut'); b.setAttribute('aria-expanded', shut ? 'false' : 'true'); return; }
  if (b.classList.contains('nt') && a) { const n = a.querySelector('.inote'); n.hidden = !n.hidden; b.setAttribute('aria-expanded', n.hidden ? 'false' : 'true'); if (!n.hidden) n.querySelector('textarea').focus(); return; }
  if (b.classList.contains('ed') && a) { if (S.ro) { toast('บันทึกได้เฉพาะในเบราว์เซอร์นี้'); } const ic = a.querySelector('.ic'); ic.setAttribute('contenteditable', 'true'); a.querySelector('.edbar').hidden = false; a.classList.remove('shut'); a.classList.add('open'); ic.focus(); return; }
  if (b.classList.contains('sv') && a) { const ic = a.querySelector('.ic'); ic.removeAttribute('contenteditable'); a.querySelector('.edbar').hidden = true; const h = sanitize(ic.innerHTML); a.dataset.shown = ''; setPick(id, {html: h === sanitize(ORIG.get(id)) ? '' : h}); return; }
  if (b.classList.contains('cx') && a) { const ic = a.querySelector('.ic'); ic.removeAttribute('contenteditable'); a.querySelector('.edbar').hidden = true; a.dataset.shown = ''; applyPick(a); return; }
  if (b.classList.contains('rs') && a) { const ic = a.querySelector('.ic'); ic.removeAttribute('contenteditable'); a.querySelector('.edbar').hidden = true; a.dataset.shown = ''; setPick(id, {html: ''}); return; }
  if (b.dataset.go) { go(b.dataset.go); return; }
  switch (b.id) {
    case 'b-compact': { const on = document.body.classList.toggle('compact'); b.setAttribute('aria-pressed', on ? 'true' : 'false'); ITEMS.forEach(x => x.classList.remove('open', 'shut')); break; }
    case 'b-export': case 'b-export2': openExport(); break;
    case 'b-outline': openOutline(); break;
    case 'fab': document.body.classList.add('panel-open'); break;
    case 'pp-close': document.body.classList.remove('panel-open'); break;
    case 'ex-close': $('#ex').hidden = true; break;
    case 'ex-copy': copy($('#ex-ta').value); break;
    case 'ex-md': offer('smote25-section7-picks.md', $('#ex-ta').value); break;
    case 'ex-json': offer('smote25-section7-picks.json', buildJson()); break;
    case 'ol-close': $('#ol').hidden = true; break;
    case 'ol-save': saveOutline(); break;
  }
});
document.addEventListener('change', e => {
  const a = e.target.closest('article.it'); if (!a) { if (e.target.closest('.pk-bar')) applyFilters(); return; }
  if (e.target.classList.contains('tgt')) setPick(a.dataset.id, {target: e.target.value});
  if (e.target.classList.contains('frm')) setPick(a.dataset.id, {form: e.target.value});
});
document.addEventListener('input', e => {
  if (e.target.id === 'f-q') { clearTimeout(timers.__q); timers.__q = setTimeout(applyFilters, 180); return; }
  const a = e.target.closest('article.it');
  if (a && e.target.matches('.inote textarea')) setPick(a.dataset.id, {note: e.target.value}, 900);
});
document.addEventListener('keydown', e => { if (e.key === 'Escape') { ['#ex', '#ol'].forEach(s => $(s).hidden = true); document.body.classList.remove('panel-open'); } });

/* ---------- start ---------- */
ITEMS.forEach(buildControls);
ITEMS.forEach(a => a.dataset.shown = 'orig');
loadLocal(); ITEMS.forEach(applyPick); renderPanel(); applyFilters();
status('บันทึกในเบราว์เซอร์นี้ (ยังไม่ได้เชื่อมข้อมูลกลาง)');
(async () => {
  const C = window.claude;
  if (!C || typeof C.use !== 'function') { S.mode = 'local'; status('ไฟล์นี้เปิดนอก claude.ai: บันทึกไว้ในเบราว์เซอร์นี้เท่านั้น ส่งออก JSON เพื่อเก็บ'); return; }
  C.use('downloads').then(d => { S.dl = d; }).catch(() => {});
  let db = null; try { db = await C.use('db'); } catch (e) { db = null; }
  if (!db) { S.mode = 'local'; status('ข้อมูลกลางใช้ไม่ได้ในมุมมองนี้: บันทึกไว้ในเบราว์เซอร์นี้เท่านั้น', true); return; }
  S.db = db; S.mode = 'db'; status('กำลังโหลดการเลือกที่บันทึกไว้…');
  const local = Object.assign({}, S.picks);
  let first = true;
  const timer = setTimeout(() => status('ยังเชื่อมข้อมูลกลางไม่ได้: การเลือกใหม่จะบันทึกเมื่อเชื่อมได้', true), 10000);
  db.collection('picks').onSnapshot(snap => {
    if (!snap.metadata.fromCache) clearTimeout(timer);
    const seen = new Set();
    snap.docs.forEach(d => { seen.add(d.id); if (!dirty.has(d.id)) S.picks[d.id] = Object.assign({}, d.data()); });
    if (first) {
      first = false;
      if (snap.empty && Object.keys(local).some(k => !isEmpty(local[k]))) { Object.keys(local).forEach(k => { if (!isEmpty(local[k])) { S.picks[k] = local[k]; dirty.add(k); queueWrite(k); } }); }
      else Object.keys(S.picks).forEach(k => { if (!seen.has(k) && !dirty.has(k)) delete S.picks[k]; });
    } else snap.docChanges().forEach(ch => { if (ch.type === 'removed' && !dirty.has(ch.doc.id)) delete S.picks[ch.doc.id]; });
    ITEMS.forEach(applyPick); renderPanel(); applyFilters(true);
    if (!inflight) status('บันทึกในข้อมูลกลางของหน้านี้ · Claude อ่านได้' + (snap.metadata.fromCache ? ' (กำลังซิงก์)' : ''));
  }, err => { clearTimeout(timer); S.mode = 'local'; status('เชื่อมข้อมูลกลางไม่ได้ (' + (err && err.code) + '): บันทึกไว้ในเบราว์เซอร์นี้แทน', true); });
  db.doc('meta/outline').onSnapshot(s => {
    if (s.exists) { const v = s.data(); if (Array.isArray(v.targets) && v.targets.length) { S.targets = v.targets.map(String); ITEMS.forEach(a => targetOptions(a.querySelector('.tgt'), (S.picks[a.dataset.id] || {}).target || '')); renderPanel(); } }
  }, () => {});
})();
})();
"""


def build():
    secs, qh, nq, ni = collect()
    BD.TOC.clear()
    css = open(BD.R + 'guide/primer_style.css').read() + open(BD.R + 'evalpage/extra.css').read() + BD.GUIDE_CSS + BD.CSS_DB + CSS_PK
    js = open(BD.R + 'evalpage/page.js').read()
    X = BD.X; BE = BD.BE
    data = dict(meth=BE.METH, meas=BE.MEAS, CD=X['CD'], per={k: {kk: v[kk] for kk in ('ar', 'pF', 'FF', 'holm', 'mean')} for k, v in X['per'].items()}, vals=X['vals'])
    dj = json.dumps(data, separators=(',', ':')).replace('</', '<\\/')
    mj = json.dumps(BD.map_rows(), ensure_ascii=False, separators=(',', ':')).replace('</', '<\\/')
    fj = json.dumps(BD.MAPFIELDS, ensure_ascii=False, separators=(',', ':'))
    oj = json.dumps(TARGETS, ensure_ascii=False)
    kinds = sorted(set(it['kind'] for s in secs for it in s['items']), key=lambda k: list(TYPE_TH).index(k))
    body = ''
    for s in secs:
        h2 = s['h2'].replace('<h2>', '<h2>', 1)
        body += ('<section class="ps" id="' + s['id'] + '">' + h2 + s['asks'] + ''.join(article(it) for it in s['items']) + '</section>')
    page = ('<title>SMOTE25 Paper Picker</title>\n<meta name="claude:viewport-fit-sides" content="cover">\n'
            '<link rel="preconnect" href="https://fonts.googleapis.com">\n<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>\n'
            '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500&family=IBM+Plex+Sans+Thai:wght@400;500;600;700&family=Noto+Serif+Thai:wght@400;600&family=STIX+Two+Text:ital,wght@0,400;0,600;1,400&display=swap">\n'
            '<style>\n' + css + '</style>\n'
            '<div class="wrap" style="max-width:1320px"><header class="top"><div class="eyebrow">SMOTE25 · หัวข้อที่ 7 Evaluation · เลือกข้อมูลลง paper</div>'
            '<h1>เลือกและแก้ข้อมูลจาก data book เพื่อเขียน Section 7</h1>'
            '<p class="lede">ทุกตาราง กราฟ กล่องสรุป และเหตุผลรายแถวจาก data book ถูกแยกเป็น ' + str(ni) + ' รายการ เลือกได้ว่าจะใช้ไหม ใส่หัวข้อไหนของ paper ในรูปแบบอะไร เขียนโน้ตหรือประโยค และแก้ข้อความในรายการได้ตรง ๆ แล้วส่งออกเป็น Markdown หรือ JSON</p></header>'
            '<div class="help"><b>วิธีใช้</b><ol><li>กด <b>ใช้</b> / <b>อาจใช้</b> / <b>ไม่ใช้</b> ที่แต่ละรายการ (กดซ้ำเพื่อยกเลิก) หัวข้อใน paper จะเติมให้ตามหัวข้อของ data book แล้วเปลี่ยนได้</li>'
            '<li>เลือกรูปแบบ (ตาราง รูป ข้อความ ภาคผนวก) และกด <b>โน้ต / ประโยค</b> เพื่อเขียนสิ่งที่จะใส่ใน paper</li>'
            '<li><b>แก้ไขเนื้อหา</b> ทำให้พิมพ์ทับตารางหรือข้อความได้ กดบันทึกแล้วจะใช้ฉบับที่แก้ (คืนค่าเดิมได้เสมอ) รายการที่เป็นกราฟหรือเครื่องมือโต้ตอบแก้ไม่ได้ ให้ใช้โน้ตแทน</li>'
            '<li>สรุปอยู่ที่แผงด้านขวา ปุ่ม <b>ส่งออก</b> ให้ Markdown หรือ JSON การเลือกบันทึกอัตโนมัติในหน้านี้ บอก Claude ได้เลยว่า "เขียนตามที่เลือก"</li></ol></div>'
            '<details class="qiwrap"><summary>ดัชนีคำถาม ' + str(nq) + ' ข้อ (อ้างอิง กดเพื่อเปิด)</summary>' + qh + '</details>'
            '<div class="pk-bar" role="search"><input id="f-q" type="search" placeholder="ค้นหาในรายการ โน้ต หรือหัวข้อ" aria-label="ค้นหา">'
            '<select id="f-sec" aria-label="หัวข้อ data book"><option value="">ทุกหัวข้อ D0–D16</option>' + ''.join('<option value="' + s['id'] + '">' + s['id'].upper() + ' ' + esc(BeautifulSoup(s['h2'], 'html.parser').find_all('span')[1].contents[0].strip()) + '</option>' for s in secs) + '</select>'
            '<select id="f-st" aria-label="สถานะ"><option value="">ทุกสถานะ</option><option value="picked">ใช้ + อาจใช้</option><option value="use">ใช้</option><option value="maybe">อาจใช้</option><option value="no">ไม่ใช้</option><option value="none">ยังไม่เลือก</option><option value="noted">มีโน้ต</option><option value="edited">แก้ไขแล้ว</option></select>'
            '<select id="f-kind" aria-label="ชนิด"><option value="">ทุกชนิด</option>' + ''.join('<option value="' + k + '">' + TYPE_TH[k] + '</option>' for k in kinds) + '</select>'
            '<button type="button" class="btn2" id="b-compact" aria-pressed="false">ย่อเหลือหัวเรื่อง</button><span class="cnt" id="f-cnt"></span></div>'
            '<div class="pk-layout"><main class="pk-main">' + body + '</main>'
            '<aside class="pk-panel" aria-label="สรุปการเลือก"><div class="pp-h"><b>สรุปการเลือก</b><button type="button" class="btn2 pp-x" id="pp-close">ปิด</button></div>'
            '<div class="pp-c"><div class="u"><b id="pp-u">0</b>ใช้</div><div class="m"><b id="pp-m">0</b>อาจใช้</div><div class="x"><b id="pp-x">0</b>ไม่ใช้</div></div>'
            '<div class="pp-st" id="pp-st" role="status"></div><div class="pp-a"><button type="button" class="btn2 pri" id="b-export">ส่งออก Markdown / JSON</button><button type="button" class="btn2" id="b-outline">แก้รายชื่อหัวข้อ paper</button></div>'
            '<div class="pp-g" id="pp-g"></div></aside></div>'
            '<div class="foot"><span>รายการมาจาก databook/build_databook.py (ข้อมูลเดียวกับ data book) · แยกและสร้างหน้าโดย databook/build_picker.py · id ของรายการคงที่ถ้าเนื้อหาไม่เปลี่ยน</span></div></div>'
            '<button type="button" class="btn2 pri fab" id="fab">ที่เลือก <b id="fab-n" style="margin-left:4px">0</b></button>'
            '<div class="modal" id="ex" hidden role="dialog" aria-modal="true" aria-labelledby="ex-h"><div><h3 id="ex-h">ส่งออกสิ่งที่เลือก</h3><textarea id="ex-ta" readonly aria-label="Markdown"></textarea>'
            '<div class="row"><label><input type="checkbox" id="ex-maybe" checked> รวม "อาจใช้"</label><label style="margin-right:0"><input type="checkbox" id="ex-content" checked> รวมเนื้อหา</label>'
            '<button type="button" class="btn2" id="ex-copy">คัดลอก</button><button type="button" class="btn2" id="ex-md">ดาวน์โหลด .md</button><button type="button" class="btn2" id="ex-json">ดาวน์โหลด .json</button><button type="button" class="btn2 pri" id="ex-close">ปิด</button></div></div></div>'
            '<div class="modal" id="ol" hidden role="dialog" aria-modal="true" aria-labelledby="ol-h"><div><h3 id="ol-h">หัวข้อของ Section 7 ใน paper (บรรทัดละหัวข้อ)</h3><textarea id="ol-ta" aria-label="หัวข้อ"></textarea>'
            '<div class="row"><label>เปลี่ยนชื่อหัวข้อแล้ว รายการเดิมจะยังอยู่ใต้ชื่อเก่าจนกว่าจะเลือกใหม่</label><button type="button" class="btn2" id="ol-close">ยกเลิก</button><button type="button" class="btn2 pri" id="ol-save">บันทึก</button></div></div></div>'
            '<script type="application/json" id="evdata">' + dj + '</script>\n'
            '<script type="application/json" id="mapdata">' + mj + '</script>\n<script type="application/json" id="mapfields">' + fj + '</script>\n'
            '<script type="application/json" id="pk-outline">' + oj + '</script>\n'
            '<script>\n' + js + '\n' + BD.MAPJS + '\n' + PICKJS + '</script>\n')
    assert '—' not in page, 'em-dash'
    open(OUT + 'smote25_paper_picker.html', 'w').write(page)
    i = page.index('</style>\n') + len('</style>\n')
    doc = ('<!doctype html>\n<html lang="th">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n'
           + page[:i] + '</head>\n<body>\n' + page[i:] + '\n</body>\n</html>\n')
    open(OUT + 'section07-paper-picker.html', 'w').write(doc)
    print('bytes', len(page.encode()), 'items', ni, 'sections', len(secs))
    return secs


if __name__ == '__main__':
    secs = build()
    from collections import Counter
    print(Counter(it['kind'] for s in secs for it in s['items']))
    for s in secs:
        print(s['id'], len(s['items']), ' | '.join(it['title'][:40] for it in s['items'][:6]))
