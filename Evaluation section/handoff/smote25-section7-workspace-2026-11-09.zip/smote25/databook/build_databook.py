"""SMOTE25 Section 7 data book: every analysis of evaluation practice done so far, on one Thai page with English terms.
Reuses the sections of the evaluation page (evalpage/build_evalpage.py), the topic sections of the guide (guide/evaluation_guide.html)
and adds the remaining data: data sources, baselines, protocol, tuning, tests, reporting, outcomes, the 7-criteria standard,
the 46-row roadmap, citation ratios, every number of the illustrative runs and a filterable map of the 71 studies."""
import json, re, sys, html, collections, statistics as st
sys.path.insert(0, '/home/claude/smote25/evalpage')
import build_evalpage as BE
import why_cards as WC

R = '/home/claude/smote25/'
OUT = R + 'databook/'
D, E, BY, F, X, AN = BE.D, BE.E, BE.BY, BE.F, BE.X, BE.AN
W = WC.W
ERA, ERA_TH, EN = BE.ERA, BE.ERA_TH, BE.EN
esc = html.escape
C = collections.Counter
pct = BE.pct
tiles, hbars = BE.tiles, BE.hbars
SECS, TOC = [], []
RM = {r['label']: r for r in AN['roadmap']}
INF = {r['key']: r for r in AN['influence']}


def sec(sid, num, th, en, body):
    TOC.append((sid, num, th))
    SECS.append('<section class="s" id="' + sid + '"><h2><span class="n">' + num + '</span><span>' + th + ' <span class="en">' + en + '</span></span></h2>' + body + '</section>')


def take(fn, label):
    """Run a section builder of the evaluation page and return its body with a sub-heading instead of its own h2."""
    fn()
    h = BE.SECS.pop()
    m = re.match(r'<section class="s" id="([^"]+)"><h2><span class="n">([^<]*)</span><span>(.*?)</span></h2>(.*)</section>$', h, re.S)
    sid, num, title, body = m.groups()
    return '<div class="qblock" id="' + sid + '"><h3 class="qh"><span class="qtag">' + num + '</span> ' + title + '</h3>' + body + '</div>'


def table(head, rows, cls='', right=()):
    h = '<div class="scroll"><table class="t ' + cls + '"><thead><tr>' + ''.join('<th' + (' class="r"' if i in right else '') + '>' + x + '</th>' for i, x in enumerate(head)) + '</tr></thead><tbody>'
    for r in rows:
        h += '<tr>' + ''.join('<td' + (' class="r"' if i in right else '') + '>' + str(x) + '</td>' for i, x in enumerate(r)) + '</tr>'
    return h + '</tbody></table></div>'


def era_counts(pred):
    return [sum(1 for p in E if p['era'] == e and pred(p)) for e in ERA]


def era_row(label, pred, extra=''):
    c = era_counts(pred); n = sum(c)
    return [label, '<b>' + str(n) + '</b>/71'] + [str(c[i]) + ' <span class="sub">(' + str(pct(c[i], EN[e])) + '%)</span>' for i, e in enumerate(ERA)] + ([extra] if extra != '' else [])


ERA_HEAD = ['', 'รวม'] + [ERA_TH[i] + ' <span class="sub">' + str(EN[e]) + ' งาน</span>' for i, e in enumerate(ERA)]


def short(k):
    p = BY[k]; return esc(p['short']) + ' ' + str(p['year'])


def keys_list(keys):
    return ', '.join(short(k) for k in sorted(keys, key=lambda k: (BY[k]['year'], k)))


def note(t):
    return '<p class="note">' + t + '</p>'


def ask(*qs):
    return '<div class="asks"><b>คำถามที่หัวข้อนี้ตอบ</b><ul>' + ''.join('<li>' + q + '</li>' for q in qs) + '</ul></div>'


# ------------------------------------------------------------------ guide topics (what to choose, with references)
GH = open(R + 'guide/evaluation_guide.html').read()
GUIDE_CSS = re.search(r'CSS_EXTRA = r"""(.*?)"""', open(R + 'guide/build_guide.py').read(), re.S).group(1)


def scope_css(css, pre):
    """Prefix every selector of a flat stylesheet (with @media blocks) so the guide's rules apply only inside the guide topics."""
    out, i = [], 0
    css = re.sub(r'/\*.*?\*/', '', css, flags=re.S)
    while i < len(css):
        j = css.find('{', i)
        if j < 0:
            break
        sel = css[i:j].strip()
        if sel.startswith('@media'):
            depth, k = 1, j + 1
            while depth:
                depth += {'{': 1, '}': -1}.get(css[k], 0); k += 1
            out.append(sel + '{' + scope_css(css[j + 1:k - 1], pre) + '}'); i = k
        else:
            k = css.index('}', j)
            out.append(','.join(pre + ' ' + x.strip() for x in sel.split(',')) + '{' + css[j + 1:k] + '}'); i = k + 1
    return '\n'.join(out)


GUIDE_CSS = scope_css(GUIDE_CSS, '.gtopic')


def guide_topic(tid):
    m = re.search(r'(<section[^>]*id="' + tid + r'".*?</section>)', GH, re.S)
    s = m.group(1)
    s = re.sub(r'^<section[^>]*>', '<div class="gtopic">', s).replace('</section>', '</div>')
    s = re.sub(r'<h2>(.*?)</h2>', r'<h3 class="qh">คู่มือ: \1</h3>', s, count=1, flags=re.S)
    return s


# ------------------------------------------------------------------ seven-criteria standard
COMP = {'G-mean', 'F1', 'F-measure', 'MCC', 'Balanced accuracy', 'Kappa', 'G-score (P,R)'}; RANK = {'AUC', 'AUPRC', 'MAUC', 'AUCm'}
CRIT = [('แบ่งข้อมูลซ้ำหลายรอบ', lambda p: p['protocol_class'] in ('Repeated k-fold CV', '5x2 CV', 'Repeated hold-out')),
        ('ระบุว่า resample เฉพาะข้อมูลฝึก', lambda p: p['resampling_inside_cv'] is True),
        ('ไม่เลือกค่าบนข้อมูลที่ใช้วัดผล (nested หรือค่าตายตัว)', lambda p: p['tuning_class'] in ('Nested / held-out tuning', 'Fixed / default settings')),
        ('test ที่ปรับแก้แล้วหรือ Bayesian', lambda p: p['test_class'] in ('Corrected multiple comparison', 'Bayesian')),
        ('มี baseline ไม่ resample', lambda p: bool(p['no_resampling_baseline'])),
        ('measure ทั้งแบบประกอบและแบบจัดอันดับ', lambda p: bool(COMP & set(p['metrics_n'])) and bool(RANK & set(p['metrics_n']))),
        ('แจก code', lambda p: bool(p['has_code']))]
SCORE = {p['key']: sum(1 for _, f in CRIT if f(p)) for p in E}

# ------------------------------------------------------------------ study map rows (for the filterable table)
COPIED = {'SMOTE-2002', 'COG-OS-2007', 'SplitBal-2015', 'HDE-2021', 'NROMM-2023', 'QC-SMOTE-2026'}
TOOLK = {k: [t for t, v in W.get('tool_keys', {}).items() if k in v] for k in BY}
FAM37 = BE.FAMILY37
OUTC = {'A': 'ดีสุด ไม่มีข้อยกเว้น', 'B': 'ดีสุด มีข้อยกเว้นที่ระบุเอง', 'C': 'ไม่ได้เปรียบ baseline', 'D': 'ไม่ได้เสนอวิธี'}


def map_rows():
    rows = []
    for p in sorted(E, key=lambda p: (p['year'], p['key'])):
        r2 = p['r2']
        rows.append(dict(
            k=p['key'], s=p['short'], y=p['year'], era=ERA_TH[ERA.index(p['era'])], set=p['setting'], ap=p['approach'], dt=p['data_type'],
            fam=(FAM37[p['key']][1] if p['key'] in FAM37 else ''), nds=p.get('n_datasets'), keel=int(bool(p['uses_keel'])), uci=int(bool(p['uses_uci'])),
            clf=', '.join(p['clf_families']), nclf=len(p['clf_families']), nb=p.get('n_baselines'), smb=int(bool(p['smote_baseline'])), nor=int(bool(p['no_resampling_baseline'])),
            cop=int(p['key'] in COPIED), met=', '.join(m for m in p['metrics_n']), pm=p.get('primary_metric') or '', prot=p['protocol_class'], cvk=str(p.get('cv_k') or ''),
            ins={True: 'ใช่', None: 'ไม่ระบุ', False: 'ไม่'}[p['resampling_inside_cv']], tun=p['tuning_class'], crit=', '.join(r2.get('ms_criterion') or []),
            test=p['test_class'], tests=', '.join(p['tests_n']), rep=', '.join(sorted(set(p['reporting'] or []))), code=int(bool(p['has_code'])),
            rt=int(bool(p['runtime_reported'])), tool=', '.join(TOOLK.get(p['key'], [])), dir=int(bool(p.get('beyond_direct'))), vis=int(bool(p.get('beyond_visual'))),
            ana=int(bool(p.get('beyond_analytic'))), mi=(str(p['metric_issue']) if p['metric_issue'] else ''), out=OUTC.get(p['outcome'], ''), cites=p.get('cites'),
            sc=SCORE[p['key']], venue=p.get('venue') or ''))
    return rows


# ================================================================== sections
def d0():
    body = ask('คลังบทความมีกี่เรื่อง กี่เรื่องมีการทดลอง กี่เรื่องเป็นตระกูล SMOTE', 'แบ่งช่วงปีอย่างไร และอ่านร้อยละอย่างไร', 'ลงรหัสอย่างไร เชื่อถือได้แค่ไหน', 'หลักฐานสามระดับคืออะไร', 'วิเคราะห์ citation อย่างไร')
    body += tiles([('76', 'เรื่องในคลัง (รวมฉบับซ้ำแล้ว)'), ('71', 'มีการทดลองกับข้อมูลไม่สมดุล'), ('37', 'ตระกูล SMOTE ตามส่วน Method (Core 34 + Partial 3)'), ('5', 'ไม่มีการทดลอง: review หรือบทวิจารณ์ 2 (Pradipta 2021, Hassanat 2022), งานรากฐาน 3 (Tomek links, ENN, AdaBoost)')])
    body += table(['ช่วงปี', 'งาน', 'binary', 'multi-class', 'ทั้งสอง', 'ตระกูล SMOTE (37)'],
                  [[ERA_TH[i], EN[e], sum(1 for p in E if p['era'] == e and p['setting'] == 'binary'), sum(1 for p in E if p['era'] == e and p['setting'] == 'multiclass'),
                    sum(1 for p in E if p['era'] == e and p['setting'] == 'both'), sum(1 for k in FAM37 if BY[k]['era'] == e)] for i, e in enumerate(ERA)], right=(1, 2, 3, 4, 5))
    body += ('<div class="box"><b>วิธีลงรหัส</b><ul class="list"><li>รอบที่ 1: ลงรหัสจากเนื้อความเต็มและไฟล์เสริม ได้แก่ ข้อมูล, learner, คู่เทียบ, measure พร้อมนิยามจริง, protocol, การเลือก hyperparameter, test, รูปแบบการรายงาน; '
             'ช่องที่ paper ไม่ระบุลงว่า "ไม่ได้รายงาน" ไม่อนุมาน; รหัสที่ต้องใช้ดุลยพินิจ 4 ตัว (protocol class, tuning class, ปัญหานิยาม measure, outcome class)</li>'
             '<li>รอบที่ 2: เหตุผลของการเลือกข้อมูล learner measure, measure และข้อมูลที่ใช้เลือกค่า, แหล่งวิธีวิทยาที่อ้าง, หลักฐานนอกเหนือคะแนน; ทุกรหัสมีเลขหน้าและข้อความสั้นจาก paper (ไฟล์ section07-pass2-verification.xlsx) · สุ่มตรวจรหัสที่ต้องตีความ 20 รายการกับ PDF: ยืนยัน 14 ยืนยันบางส่วน 6 · ยังไม่ได้ให้ผู้อ่านคนที่สองตรวจทั้งหมด</li>'
             '<li>ซอฟต์แวร์: นับเฉพาะที่ paper ระบุชื่อ (Weka, KEEL software, MATLAB, scikit-learn, imbalanced-learn, smote-variants, Keras ฯลฯ) จึงเป็นขอบล่าง</li></ul></div>')
    body += ('<div class="box key"><b>หลักฐานสามระดับที่ใช้อธิบายสาเหตุ</b><ul class="list"><li><b>หลักฐานตรง</b>: paper เขียนเหตุผลเอง หรือวัดความเชื่อมโยงได้ตรง</li><li><b>หลักฐานแวดล้อม</b>: เวลาและความสัมพันธ์ไปทางเดียวกัน แต่ไม่มีใครเขียนยืนยัน</li>'
             '<li><b>ข้อสันนิษฐาน</b>: กลไกที่เราเสนอ ข้อมูลยังยืนยันไม่ได้</li></ul><p>ไม่มีระดับไหนเป็นการประมาณผลเชิงสาเหตุทางสถิติ</p></div>')
    body += ('<div class="box"><b>การวิเคราะห์ citation</b><p>OpenAlex ณ 18 ต.ค. 2026 มีข้อมูล 75 จาก 76 เรื่อง อายุเพิ่มหนึ่งปีคูณจำนวนอ้างอิงที่คาดไว้ ' + f"{AN['year_ratio']:.2f}" +
             ' เท่า จึงใช้ regression ของ log(1 + citations) บนปีที่ตีพิมพ์กับตัวแปรของแนวปฏิบัติ ใช้ ' + str(AN['eligible_n']) + ' งานที่ตีพิมพ์ถึงปี 2024 รายงานเป็น citation ratio (exp ของสัมประสิทธิ์) พร้อม 95% CI ค่า 2 = ถูกอ้างอิงสองเท่าของงานอายุเท่ากัน ผลทั้งหมดอยู่ใน D10</p></div>')
    sec('d0', 'D0', 'คลังบทความ การลงรหัส และวิธีอ่านตัวเลข', 'Corpus, coding and how to read', body)


def d1():
    body = ask('SMOTE 2002 ใช้ classifier และ measure กี่ตัว ตอนนี้เหลือกี่ตัว อะไรเพิ่ม อะไรหาย', 'learner และ measure แต่ละตัวเพิ่ม ลด หรือหายไปเพราะอะไร (ทุกแถว)', 'ตระกูล SMOTE 37 เรื่องใช้ measure ต่างกันตามหมวดคลาสอย่างไร')
    body += take(BE.q1, 'Q1')
    sec('d1', 'D1', 'SMOTE 2002 กับวันนี้ และเหตุผลรายแถว', 'Then and now, with causes', body)


def d2():
    dr = C(r for p in E for r in (p['r2'].get('data_reasons') or []))
    DRT = [('varied_characteristics', 'ต้องการช่วงของ IR ขนาด หรือมิติที่หลากหลาย'), ('imbalance_level', 'ต้องการระดับความไม่สมดุลเป้าหมาย'), ('follows_prior_work', 'ใช้ชุดเดียวกับงานก่อนที่ระบุชื่อ'),
           ('difficulty_factors', 'overlap, noise หรือ small disjunct'), ('comparability', 'เทียบกับผลที่ตีพิมพ์แล้วได้'), ('public_benchmark', 'เป็นข้อมูลสาธารณะ'), ('application_domain', 'โดเมนงานประยุกต์'),
           ('multiclass_availability', 'มีข้อมูลหลายคลาส'), ('other', 'อื่น ๆ')]
    repos = C(r for p in E for r in (p['r2'].get('repos') or []))
    nds = [p['n_datasets'] for p in E if p.get('n_datasets')]
    q = st.quantiles(nds, n=4)
    body = ask('งานใช้ข้อมูลจากไหน กี่ชุด และให้เหตุผลการเลือกข้อมูลไหม', 'ข้อมูลที่ดัดแปลงถูกเปิดเผยไหม', 'KEEL ส่งผลต่อการวัดผลอย่างไร', 'วัดผลกับ task อื่นนอกจาก classification ไหม')
    body += tiles([(str(sum(1 for p in E if p['uses_uci'])), 'งานใช้ UCI'), (str(sum(1 for p in E if p['uses_keel'])), 'งานใช้ KEEL (ปีแรก 2013)'), (f"{st.median(nds):g}", f'ค่ากลางชุดข้อมูลต่องาน (IQR {q[0]:g}–{q[2]:g}, ช่วง {min(nds)}–{max(nds)})'),
                   (str(sum(1 for p in E if p['r2'].get('data_stated'))) + '<small>/71</small>', 'ให้เหตุผลการเลือกข้อมูล')])
    body += '<h3>แหล่งข้อมูลและขนาด benchmark ตามช่วงปี</h3>' + table(ERA_HEAD, [
        era_row('ใช้ UCI', lambda p: p['uses_uci']), era_row('ใช้ KEEL', lambda p: p['uses_keel']),
        era_row('ข้อมูลสังเคราะห์', lambda p: p['key'] in RM['Synthetic data']['keys']), era_row('ข้อมูลส่วนตัวหรืองานประยุกต์', lambda p: p['key'] in RM['Private or application data']['keys']),
        era_row('ข้อมูลภาพ', lambda p: p['key'] in RM['Image data']['keys']), era_row('ชุดข้อมูลจริงน้อยกว่า 10', lambda p: p['key'] in RM['Fewer than 10 real datasets']['keys']),
        era_row('ให้เหตุผลการเลือกข้อมูล', lambda p: p['r2'].get('data_stated'))], right=(1, 2, 3, 4, 5))
    nr = [p['datasets']['n_real'] for p in E]; qr = st.quantiles(nr, n=4)
    body += table(['จำนวนชุดข้อมูลต่องาน', 'ค่ากลาง', 'IQR', 'ช่วง'] + [ERA_TH[i] for i in range(4)],
                  [['ทั้งหมด (รวมข้อมูลสังเคราะห์)', f"{st.median(nds):g}", f"{q[0]:g}–{q[2]:g}", f"{min(nds)}–{max(nds)}"] + [f"{v:g}" for v in W['ds_med_era']],
                   ['เฉพาะข้อมูลจริง', f"{st.median(nr):g}", f"{qr[0]:g}–{qr[2]:g}", f"{min(nr)}–{max(nr)}"] + [f"{st.median([p['datasets']['n_real'] for p in E if p['era'] == e]):g}" for e in ERA]], right=(1, 2, 3, 4, 5, 6, 7))
    body += note('คู่มือและ citation ratio ใช้ค่ากลางของข้อมูลจริง (18 ชุด) · ข้อมูลจริงอย่างน้อย 18 ชุด: citation ratio ' + infl('many_ds') + ' · ใช้ KEEL ' + infl('keel') + ' · ใช้ UCI ' + infl('uci') +
                 ' · มีข้อมูลไม่สาธารณะ ' + infl('private') + ' · ให้เหตุผลการเลือกข้อมูล ' + infl('data_reason'))
    fam = AN['families']
    body += '<h3>ตระกูลชุดข้อมูลที่ใช้บ่อย (นับงานที่ใช้ชุดใดชุดหนึ่งในตระกูล)</h3>' + table(['ตระกูล', 'งาน', 'มาจาก KEEL', 'ปีแรก', 'ปีล่าสุด'] + [ERA_TH[i] for i in range(4)],
        [[esc(f['family']), f['n'], f['keel'], f['first'], f['last']] + [f['by_era'][e] for e in ERA] for f in fam], right=(1, 2, 3, 4, 5, 6, 7, 8))
    body += note('ชุดข้อมูลคลาสสิกที่ใช้ต่อเนื่อง: ' + esc(', '.join(AN['classic'])) + ' · รายละเอียดรายชุดข้อมูลเป็นของส่วน Data (Toon)')
    body += '<div class="two"><div><h3>เหตุผลที่ให้ในการเลือกข้อมูล (' + str(sum(1 for p in E if p['r2'].get('data_stated'))) + ' งาน)</h3>' + hbars([(t, dr.get(k, 0)) for k, t in DRT], 71) + '</div><div><h3>คลังข้อมูลที่ระบุ</h3>' + hbars([(esc(k), v) for k, v in repos.most_common(10)], 71) + '</div></div>'
    mod = C(str(p['r2'].get('mod_released')) for p in E); pub = C(str(p['r2'].get('all_public')) for p in E)
    body += table(['การเข้าถึงข้อมูล', 'จำนวนงาน'], [['ข้อมูลทั้งหมดเป็นสาธารณะ', pub['True']], ['มีข้อมูลที่ไม่สาธารณะ', pub['False']], ['ไม่ระบุ', pub['None']],
                                                     ['ดัดแปลงข้อมูล (เช่น ยุบเป็นสองคลาส) และเปิดเผยฉบับที่ดัดแปลง', mod['True']], ['ดัดแปลงแต่ไม่เปิดเผย', mod['False']], ['ไม่ได้ดัดแปลงหรือไม่ระบุ', mod['None']]], right=(1,))
    body += note('ดัดแปลงรวม ' + str(mod['True'] + mod['False']) + ' งาน เปิดเผยเพียง ' + str(mod['True']) + ' งาน · KEEL 2009 มี ' + BE.cites('REF-KEEL-2009') + ' cites, KEEL 2011 ' + BE.cites('REF-KEEL-2011') + ', UCI ' + BE.cites('REF-UCI') +
                 ' · ผู้ใช้ KEEL ใช้ 5-fold 13/33 งาน เทียบกับไม่ใช้ KEEL 7/38 (KEEL แจกข้อมูลที่แบ่ง 5 fold ไว้แล้ว) · รายละเอียดชุดข้อมูลรายชื่อเป็นของส่วน Data')
    body += take(BE.q7, 'Q7')
    sec('d2', 'D2', 'โจทย์ ข้อมูล และ task', 'Problems, data and tasks', body)


def d3():
    lr = C(r for p in E for r in (p['r2'].get('learner_reasons') or []))
    LRT = [('popular', 'ใช้กันแพร่หลายหรือรู้จักดี'), ('diverse_paradigms', 'ครอบคลุมแนวคิดการเรียนรู้หลายแบบ'), ('follows_prior_work', 'ทำตามงานก่อนที่ระบุชื่อ'), ('simplicity', 'ง่าย เร็ว หรือตีความได้'),
           ('fair_comparison', 'ใช้ learner เดียวกันกับทุกวิธี'), ('sensitive_to_imbalance', 'ไวต่อความไม่สมดุล'), ('matches_mechanism', 'เข้ากับกลไกของวิธี'), ('other', 'อื่น ๆ')]
    nf = C(len(p['clf_families']) for p in E)
    singles = collections.defaultdict(list)
    for p in E:
        if len(p['clf_families']) == 1:
            singles[p['clf_families'][0]].append(p['key'])
    T = W['tool_era']
    body = ask('learner กลุ่มไหนถูกใช้มากสุด และเปลี่ยนไปอย่างไร', 'ทำไม C4.5 ลด CART เพิ่ม rule learner หาย', 'กี่งานใช้ learner ตัวเดียว ใช้ตัวไหน', 'งานให้เหตุผลการเลือก learner อย่างไร', 'เครื่องมือ (Weka, Python) เปลี่ยนไปอย่างไร')
    body += note('ตาราง learner ทุกกลุ่มตามช่วงปีและการ์ดเหตุผลรายแถวอยู่ใน D1')
    body += '<div class="two"><div><h3>จำนวนกลุ่ม learner ต่องาน</h3>' + hbars([(str(k) + ' กลุ่ม', nf[k]) for k in sorted(nf)], 71) + '</div><div><h3>เหตุผลที่ให้ในการเลือก learner (' + str(sum(1 for p in E if p['r2'].get('learner_stated'))) + ' งาน)</h3>' + hbars([(t, lr.get(k, 0)) for k, t in LRT], 71) + '</div></div>'
    body += '<h3>งานที่ใช้ learner ตัวเดียว (' + str(sum(len(v) for v in singles.values())) + ' งาน; ช่วง 2021–26: 9 จาก 24)</h3>' + table(['กลุ่ม', 'งาน', 'รายชื่อ'], [[esc(k), len(v), keys_list(v)] for k, v in sorted(singles.items(), key=lambda x: -len(x[1]))], right=(1,))
    body += '<h3>เครื่องมือที่ระบุและการแจก code ตามช่วงปี</h3>' + table(ERA_HEAD, [
        ['ระบุ Python / scikit-learn / imbalanced-learn', '<b>' + str(sum(T['py'])) + '</b>'] + [str(v) for v in T['py']], ['ระบุ Weka', '<b>' + str(sum(T['weka'])) + '</b>'] + [str(v) for v in T['weka']],
        ['ระบุ KEEL software', '<b>' + str(sum(T['keel'])) + '</b>'] + [str(v) for v in T['keel']], ['ระบุ MATLAB', '<b>' + str(sum(T['matlab'])) + '</b>'] + [str(v) for v in T['matlab']],
        ['แจก code', '<b>' + str(sum(W['code_era'])) + '</b>'] + [str(v) for v in W['code_era']]], right=(1, 2, 3, 4, 5))
    rows = []
    for f in ['C4.5/C5.0', 'CART/DT', 'Rule learner', 'k-NN', 'SVM', 'Logistic Regression', 'Random Forest', 'Gradient boosting', 'Naive Bayes', 'MLP/NN']:
        c = W['clf'][f]; rows.append([esc(f), c['n'], c['py'], c['weka'], c['code'], c['keel_data'], c['multi'], c['single'], f"{c['med_ds']:g}"])
    body += '<h3>ผู้ใช้แต่ละกลุ่ม: เครื่องมือ code ข้อมูล</h3>' + table(['กลุ่ม', 'งาน', 'ระบุ Python', 'ระบุ Weka', 'แจก code', 'ใช้ KEEL', 'หลายคลาส', 'ใช้ตัวเดียว', 'ค่ากลางชุดข้อมูล'], rows, right=tuple(range(1, 9)))
    follows = [(p['key'], p['r2']['learner_follows']) for p in E if p['r2'].get('learner_follows')]
    body += '<h3>งานที่ระบุว่าเลือก learner ตามงานใด</h3>' + table(['งาน', 'ทำตาม'], [[short(k), esc(v)] for k, v in follows])
    body += note('citation ratio: ใช้ learner มากกว่าหนึ่งตัว ' + infl('multi_clf') + ' · ใช้ RF หรือ boosting ' + infl('ens_clf') + ' · ให้เหตุผลการเลือก learner ' + infl('learner_reason'))
    sec('d3', 'D3', 'Base learner', 'Base learners', body)


def infl(k):
    r = INF[k]; return f"{r['ratio']:.2f} (95% CI {r['lo']:.2f}–{r['hi']:.2f})"


def d4():
    import re as _re
    NAMES = [('Borderline-SMOTE', r'borderline'), ('ADASYN', r'adasyn'), ('Safe-Level-SMOTE', r'safe[- ]?level'), ('MWMOTE', r'mwmote'),
             ('Random oversampling', r'\bROS\b|random[- ]?over'), ('Random undersampling', r'\bRUS\b|random[- ]?under'), ('SMOTE+ENN / SMOTE+Tomek', r'smote[- +]*(enn|tomek)'), ('k-means SMOTE', r'k-?means'),
             ('MDO', r'\bMDO\b'), ('MC-CCR / CCR', r'\bCCR\b|MC-CCR'), ('RBO / MC-RBO', r'\bRBO\b'), ('SMOTEBoost', r'smoteboost'), ('RUSBoost', r'rusboost'), ('EasyEnsemble', r'easy ?ensemble')]
    def has(p, rx):
        return any(_re.search(rx, b or '', _re.I) for b in (p['baselines'] or []))
    nb = [p['n_baselines'] for p in E if p['n_baselines'] is not None]
    body = ask('งานเทียบกับวิธีอะไร กี่วิธี', 'มี baseline ที่ไม่ resample / random oversampling / class weighting ไหม', 'มีงานที่คัดลอกผลคู่เทียบมาไหม', 'วิธีที่ชนะในงานหนึ่งถูกจัดอันดับอย่างไรในงานต่อมา')
    body += tiles([(f"{st.median(nb):g}", 'ค่ากลางจำนวนคู่เทียบต่องาน'), (str(sum(1 for p in E if p['smote_baseline'])), 'งานที่มี SMOTE เป็นคู่เทียบ'), (str(sum(1 for p in E if p['no_resampling_baseline'])), 'งานที่มี baseline ไม่ resample'),
                   ('6', 'งานที่คัดลอกผลคู่เทียบบางส่วนหรือทั้งหมด')])
    body += '<h3>คู่เทียบที่พบบ่อย</h3>' + table(['คู่เทียบ', 'งาน', 'รายชื่องาน'], [['SMOTE (รหัส smote_baseline)', sum(1 for p in E if p['smote_baseline']), '<span class="sub">50 งาน</span>']] + [[n, sum(1 for p in E if has(p, rx)), keys_list([p['key'] for p in E if has(p, rx)])] for n, rx in NAMES], right=(1,))
    body += table(ERA_HEAD, [era_row('มี SMOTE เป็นคู่เทียบ', lambda p: p['smote_baseline']), era_row('มี baseline ไม่ resample', lambda p: p['no_resampling_baseline'])], right=(1, 2, 3, 4, 5))
    body += note('รายชื่อคู่เทียบนับจากชื่อในรายการ baseline ที่ลงรหัส (regex) จึงเป็นค่าประมาณ ยกเว้น SMOTE (50) และ baseline ไม่ resample (52) ซึ่งมาจากรหัสโดยตรง')
    body += ('<div class="box warn"><b>baseline ที่ไม่ใช่ resampling: cost-sensitive, class weighting, threshold moving</b><ul class="list">'
             '<li><b>cost-sensitive learning หรือ instance weighting ของ learner เดียวกัน</b> (นิยามที่ใช้ใน v4): 5 งาน ' + keys_list(['OVO-SMOTE-2013', 'AMDO-2018', 'EMDO-2021', 'GDO-2022', 'CISO-2025']) + ' สามงานหลัง review 15 ปี · '
             'Global-CS 2006 และ 2010 เป็นวิธี cost-sensitive เองและเทียบกับ rescaling แบบเดิม</li>'
             '<li><b>cost-sensitive ensemble</b>: AdaCost ใน SMOTEBoost 2003 และ RAMOBoost 2010; MetaCost ใน SplitBal 2015; cost-proportional oversampling ใน DSRBF 2011</li>'
             '<li><b>class weighting ของ learner ตรง ๆ</b>: 1 งาน (CISO 2025) และงานนี้พบว่าวิธีใหม่ไม่ดีกว่า class weighting, ROS หรือการไม่ resample</li>'
             '<li><b>threshold moving</b>: 3 งาน ' + keys_list(['Global-CS-2010', 'DSRBF-2011', 'ROS-Buda-2018']) + ' (Global-CS 2010: threshold-moving NN และ PETs; DSRBF 2011: TMNN; Buda 2018: thresholding ด้วย prior) และ SMOTE 2002 เลื่อน threshold ที่ใบของ C4.5 เพื่อสร้างจุดบน ROC '
             '<b>หมายเหตุ</b>: v4 เขียนว่ามี threshold moving งานเดียว (Buda) ควรแก้เป็น 3 งาน</li>'
             '<li>López et al. 2012 พบว่า preprocessing กับ cost-sensitive learning ดีพอ ๆ กัน (review 15 ปีย้ำในปี 2018)</li></ul></div>')
    body += table(['งาน', 'baseline ที่ไม่ใช่ resampling (ตามที่ลงรหัส)'], [[short(p['key']), esc('; '.join(b for b in p['baselines'] if _re.search('weight|cost|threshold|AdaCost|MetaCost', b or '', _re.I)))]
                                                                       for p in sorted(E, key=lambda p: p['year']) if any(_re.search('weight|cost|threshold|AdaCost|MetaCost', b or '', _re.I) for b in (p['baselines'] or []))], cls='wide')
    body += ('<div class="box"><b>คัดลอกผลคู่เทียบ (6 งาน)</b><ul class="list">' + ''.join('<li>' + short(k) + ': ' + esc('; '.join(BY[k]['integrity'])) + '</li>' for k in sorted(COPIED, key=lambda k: BY[k]['year'])) + '</ul></div>')
    body += note('ชัยชนะไม่รวมเป็นอันดับ: MDO เป็นคู่เทียบใน 13 งานต่อมา MC-CCR ใน 7 งาน และทุกงานรายงานว่าวิธีของตัวเองนำบน measure หลัก · citation ratio: มี SMOTE เป็นคู่เทียบ ' + infl('smote_base') + ' · มี baseline ไม่ resample ' + infl('nores'))
    nbc = C(nb)
    body += '<h3>จำนวนคู่เทียบต่องาน</h3>' + hbars([(str(k) + ' วิธี', nbc[k]) for k in sorted(nbc)], 71)
    sec('d4', 'D4', 'คู่เทียบและ baseline', 'Competitors and baselines', body)


# ------------------------------------------------------------------ D5 measures
MDEF = [
    ('Accuracy/Error', 'overall', 'สัดส่วนที่ทำนายถูกทั้งหมด (หรือ 1 − ค่านี้)', '(TP + TN) / n'),
    ('Recall/TPR', 'single', 'recall, sensitivity: สัดส่วนคลาสน้อยที่จับได้', 'TP / (TP + FN)'),
    ('Specificity/TNR', 'single', 'specificity: สัดส่วนคลาสใหญ่ที่ทายถูก', 'TN / (TN + FP)'),
    ('Precision', 'single', 'ในที่ทายว่าเป็นคลาสน้อย ถูกกี่ส่วน (ขึ้นกับสัดส่วนคลาส)', 'TP / (TP + FP)'),
    ('FPR', 'single', 'false positive rate', 'FP / (FP + TN) = 1 − TNR'),
    ('G-mean', 'comp', 'ค่าเฉลี่ยเรขาคณิตของ TPR กับ TNR', '√(TPR · TNR)'),
    ('F1', 'comp', 'ค่าเฉลี่ยฮาร์มอนิกของ precision กับ recall', '2PR / (P + R)'),
    ('F-measure', 'comp', 'F<sub>β</sub> ทั่วไป ให้น้ำหนัก recall β เท่า', '(1 + β²)PR / (β²P + R)'),
    ('Kappa', 'comp', 'Cohen κ: ความถูกต้องที่หักส่วนที่ถูกโดยบังเอิญ', '(p<sub>o</sub> − p<sub>e</sub>) / (1 − p<sub>e</sub>)'),
    ('Balanced accuracy', 'comp', 'ค่าเฉลี่ยเลขคณิตของ TPR กับ TNR', '(TPR + TNR) / 2'),
    ('MCC', 'comp', 'Matthews correlation: สหสัมพันธ์ระหว่างค่าจริงกับค่าทำนาย ใช้ทั้ง 4 ช่อง', '(TP·TN − FP·FN) / √((TP+FP)(TP+FN)(TN+FP)(TN+FN))'),
    ('G-score (P,R)', 'comp', 'ค่าเฉลี่ยเรขาคณิตของ precision กับ recall (Fowlkes–Mallows) ซึ่งไม่ใช่ G-mean', '√(P · R)'),
    ('AUC', 'rank', 'ROC-AUC: ความน่าจะเป็นที่ตัวอย่างบวกได้คะแนนสูงกว่าตัวอย่างลบ ไม่ขึ้นกับ threshold', '∫ TPR d(FPR)'),
    ('AUPRC', 'rank', 'PR-AUC หรือ average precision: พื้นที่ใต้เส้น precision–recall ไวต่อ IR', '∫ P d(R)'),
    ('MAUC', 'rank', 'Hand และ Till 2001: ค่าเฉลี่ย AUC ของทุกคู่คลาส', '2 / (K(K−1)) · Σ<sub>i&lt;j</sub> Â(i, j)'),
    ('AUCm', 'rank', 'AUC แบบหลายคลาสอื่น (เช่น one-vs-rest เฉลี่ย)', 'เฉลี่ย AUC ต่อคลาส'),
    ('Per-class recall', 'multi', 'recall ของแต่ละคลาสแยกกัน', 'r<sub>k</sub>'),
    ('Macro-F1', 'multi', 'F1 เฉลี่ยทุกคลาสเท่ากัน', '(1/K) Σ F1<sub>k</sub>'),
    ('AvAcc', 'multi', 'average accuracy: ค่าเฉลี่ย recall ต่อคลาส (บางงานนิยามเป็น one-vs-rest accuracy ซึ่งพองด้วย TN)', '(1/K) Σ r<sub>k</sub>'),
    ('Weighted-F1', 'multi', 'F1 เฉลี่ยถ่วงด้วยขนาดคลาส (คลาสใหญ่ครอง)', 'Σ w<sub>k</sub> F1<sub>k</sub>'),
    ('Macro-precision', 'multi', 'precision เฉลี่ยทุกคลาส', '(1/K) Σ P<sub>k</sub>'),
    ('Pmin', 'multi', 'precision ต่ำสุดในบรรดาคลาส', 'min<sub>k</sub> P<sub>k</sub>'),
    ('CBA', 'multi', 'class balance accuracy: ช่องทแยงหารด้วยผลรวมแถวหรือคอลัมน์ที่มากกว่า แล้วเฉลี่ย', '(1/K) Σ c<sub>kk</sub> / max(c<sub>k·</sub>, c<sub>·k</sub>)'),
    ('CEN', 'multi', 'confusion entropy: ความกระจายของการทายผิด (ยิ่งต่ำยิ่งดี)', 'entropy ของ confusion matrix'),
    ('Macro-recall', 'multi', 'recall เฉลี่ยทุกคลาส (เท่ากับ AvAcc แบบถูกนิยาม)', '(1/K) Σ r<sub>k</sub>'),
    ('Min-sensitivity', 'multi', 'recall ต่ำสุดในบรรดาคลาส', 'min<sub>k</sub> r<sub>k</sub>'),
    ('Cost', 'cost', 'ต้นทุนรวมของการทายผิดตาม cost matrix', 'Σ C(i, j) · n<sub>ij</sub>'),
    ('ROC curve', None, 'เส้นโค้ง ROC (ไม่ใช่ค่าเดียว ไม่นับเป็น measure)', ''),
    ('Confusion matrix', None, 'ตาราง confusion matrix (ไม่นับเป็น measure)', ''),
    ('Runtime', None, 'เวลาประมวลผล (ไม่นับเป็น measure ของคุณภาพ)', ''),
    ('Fidelity/likelihood', None, 'likelihood หรือ fidelity ของข้อมูลสังเคราะห์ (CTGAN)', ''),
    ('Other', None, 'อื่น ๆ', '')]
FAMTH = {'overall': 'Overall', 'single': 'Single-class', 'comp': 'Composite', 'rank': 'Ranking', 'multi': 'Multi-class', 'cost': 'Cost', None: 'ไม่นับเป็น measure'}


def users(pred):
    return [p['key'] for p in E if pred(p)]


def d5():
    MF = F['measures']
    body = ask('มี measure กี่ตัว กี่หมวด งานหนึ่งใช้กี่ตัว', 'measure ไหนใช้มากสุดและทำไม', 'G-mean ต่างจาก F1 อย่างไร เมื่อไรให้ข้อสรุปต่างกัน', 'แต่ละ measure นิยามอย่างไร',
               'มีงานไหนนิยาม measure ผิด', 'งานให้เหตุผลการเลือก measure อย่างไร อ้างใคร', 'measure หลัก (primary) ของแต่ละงานคืออะไร')
    body += take(BE.q4, 'Q4') + take(BE.q5, 'Q5') + take(BE.q8, 'Q8')
    rows = []
    for lab, fam, th, fx in MDEF:
        n = MF.get(lab, {}).get('n', 0)
        ks = users(lambda p, l=lab: l in p['metrics_n'])
        rows.append(['<b>' + esc(lab) + '</b>', FAMTH[fam], th, fx, n, '<span class="sub">' + keys_list(ks) + '</span>' if n <= 12 else '<span class="sub">' + str(n) + ' งาน</span>'])
    body += '<h3>นิยามของทุก measure ที่พบ พร้อมจำนวนงาน</h3>' + table(['measure', 'หมวด', 'ความหมาย', 'สูตร', 'งาน', 'งานที่ใช้ (ถ้าไม่เกิน 12)'], rows, cls='wide', right=(4,))
    nm = F['n_meas_per_study']
    body += '<div class="two"><div><h3>จำนวน measure ต่องาน</h3>' + hbars([(k + ' ตัว', nm[k]) for k in sorted(nm, key=int)], 71) + note('ใช้ 1–2 ตัว ' + str(nm.get('1', 0) + nm.get('2', 0)) + ' งาน · ค่ากลาง ' + f"{F['median_meas_per_study']:g}" + ' ตัว') + '</div>'
    mr = C(r for p in E for r in (p['r2'].get('measure_reasons') or []))
    MRT = [('standard_in_literature', 'เป็นมาตรฐานในวงการ'), ('accuracy_misleading', 'accuracy ใช้ไม่ได้กับข้อมูลไม่สมดุล'), ('minority_focus', 'เน้นคลาสน้อย'), ('threshold_free', 'ไม่ขึ้นกับ threshold'),
           ('multiclass_suitability', 'เหมาะกับหลายคลาส'), ('cost', 'สะท้อนต้นทุน'), ('other', 'อื่น ๆ')]
    body += '<div><h3>เหตุผลที่ให้ในการเลือก measure (' + str(sum(1 for p in E if p['r2'].get('measure_stated'))) + ' งาน)</h3>' + hbars([(t, mr.get(k, 0)) for k, t in MRT], 71) + '</div></div>'
    mc = F['measure_cites_top']
    body += '<h3>แหล่งที่อ้างตอนเลือกหรือนิยาม measure</h3>' + table(['แหล่ง', 'งานที่อ้าง'], [[esc(a), b] for a, b in mc[:30]], right=(1,))
    pm = C(p['primary_metric'] or 'ไม่ระบุ measure หลัก' for p in E)
    body += '<h3>measure หลักที่แต่ละงานประกาศ</h3>' + table(['measure หลัก', 'งาน', 'รายชื่อ'], [[esc(k), v, keys_list(users(lambda p, k=k: (p['primary_metric'] or 'ไม่ระบุ measure หลัก') == k))] for k, v in pm.most_common()], right=(1,))
    mi = [p for p in E if p['metric_issue']]
    body += ('<h3>ปัญหานิยามของ measure (' + str(len(mi)) + ' งาน)</h3>' + table(['งาน', 'ปัญหา (ตามที่ลงรหัส)'], [[short(p['key']), esc(str(p['metric_issue']))] for p in sorted(mi, key=lambda p: p['year'])]) +
             '<div class="box warn"><b>ที่ควรระวังที่สุด</b><ul class="list"><li>"AUC" ที่คำนวณจาก label เดียว (1 + TPR − FPR)/2 คือ balanced accuracy ไม่ใช่ ROC-AUC: DLExiBoost 2020, GDO 2022</li>'
             '<li>G-mean นิยามเป็น √(Recall · Precision): SPE 2020</li><li>MAUC จาก hard label แทน score: SHSampler 2022, GDHS 2025</li><li>AvAcc แบบ one-vs-rest accuracy ซึ่งพองด้วย TN: MC-MBRC 2024, MC-NCLWO 2025</li>'
             '<li>ไม่บอกวิธีเฉลี่ยหลายคลาส: SCUT 2015, CBHSID 2022 (CBHSID นิยาม F1 เป็น harmonic mean ของ TPR กับ TNR)</li></ul>'
             '<p>citation ratio ของงานที่มีปัญหานิยาม: ' + infl('metric_issue') + ' เป็นแนวปฏิบัติเดียวที่ช่วง CI ไม่คร่อม 1</p></div>')
    body += note('รายงาน accuracy หรือ error: citation ratio ' + infl('acc') + ' · รายงาน measure ที่ไม่ขึ้นกับ threshold ' + infl('thrfree') +
                 ' · ผู้ใช้ G-mean ที่รายงาน TNR ด้วย ตามช่วงปี: ' + ' → '.join(str(a) + '/' + str(b) for a, b in zip(*W['tnr_with_gm'])) +
                 ' · ผู้ใช้ composite ที่รายงาน recall ด้วย: ' + ' → '.join(str(a) + '/' + str(b) for a, b in zip(*W['recall_with_comp'])) +
                 ' · ผู้ใช้ F ที่รายงาน precision ด้วย: ' + ' → '.join(str(a) + '/' + str(b) for a, b in zip(*W['prec_with_comp'])))
    sec('d5', 'D5', 'Performance measure', 'Performance measures', body)


# ------------------------------------------------------------------ D6 beyond scores
def d6():
    KTH = [('toy_2d_visualization', 'รูปข้อมูล 2 มิติ (toy)'), ('complexity_analysis', 'วิเคราะห์ความซับซ้อน (big-O)'), ('theoretical_analysis', 'ทฤษฎีหรือบทพิสูจน์'), ('other', 'อื่น ๆ'),
           ('projection_visualization', 'รูป projection (PCA, t-SNE)'), ('distribution_distance', 'ระยะห่างของการแจกแจง'), ('diversity_measure', 'ความหลากหลายของ ensemble'),
           ('example_type_analysis', 'ชนิดตัวอย่าง safe/borderline'), ('privacy_or_fidelity', 'privacy หรือ fidelity'), ('noise_count', 'นับ noise')]
    body = ask('มีงานไหนวัดข้อมูลหลัง resample โดยตรงโดยไม่ผ่าน classifier', 'หลักฐานนอกเหนือคะแนนมีแบบไหนบ้าง แต่ละแบบมีงานไหน', 'การวัดตรงเพิ่มขึ้นหลัง review 15 ปีไหม')
    body += take(BE.q2, 'Q2')
    body += '<h3>หลักฐานนอกเหนือคะแนน ตามช่วงปี</h3>' + table(ERA_HEAD, [
        era_row('วัดข้อมูลหลัง resample โดยตรง', lambda p: p.get('beyond_direct')), era_row('รูป 2 มิติหรือ projection', lambda p: p.get('beyond_visual')),
        era_row('วิเคราะห์ความซับซ้อนหรือทฤษฎี', lambda p: p.get('beyond_analytic')), era_row('ตรวจตัวโมเดล', lambda p: p.get('beyond_model')),
        era_row('ไม่มีหลักฐานนอกเหนือคะแนน', lambda p: p.get('beyond_none'))], right=(1, 2, 3, 4, 5))
    pre = sum(1 for p in E if p['year'] < 2019 and p.get('beyond_direct')); npre = sum(1 for p in E if p['year'] < 2019)
    post = sum(1 for p in E if p['year'] >= 2019 and p.get('beyond_direct')); npost = sum(1 for p in E if p['year'] >= 2019)
    body += note('วัดตรงตั้งแต่ 2019 (หลัง review 15 ปี): ' + str(post) + '/' + str(npost) + ' งาน เทียบกับก่อนหน้า ' + str(pre) + '/' + str(npre) + ' · นับชนิดตัวอย่าง safe/borderline/rare ที่ review ชี้: 2 งาน (SPE 2020, GLOS 2023) · citation ratio ' + infl('beyond_direct'))
    rows = []
    for k, t in KTH:
        ks = [p['key'] for p in E if k in (p['r2'].get('beyond_kinds') or [])]
        rows.append([t, len(ks), keys_list(ks)])
    body += '<h3>รายชื่องานตามแบบของหลักฐาน</h3>' + table(['แบบ', 'งาน', 'รายชื่อ'], rows, right=(1,))
    det = [(p['key'], p['r2'].get('beyond_details'), p['r2'].get('beyond_where')) for p in E if p.get('beyond_direct') or p.get('beyond_model')]
    body += '<h3>รายละเอียดของงานที่วัดตรงหรือตรวจตัวโมเดล</h3>' + table(['งาน', 'สิ่งที่ทำ (ตามที่ลงรหัส)', 'หน้า'], [[short(k), esc(str(d or '')), esc(str(w or ''))] for k, d, w in sorted(det, key=lambda x: BY[x[0]]['year'])])
    sec('d6', 'D6', 'หลักฐานนอกเหนือคะแนนของ classifier', 'Evidence beyond scores', body)


# ------------------------------------------------------------------ D7 protocol and settings
def d7():
    S = AN['summary']
    body = ask('งานแบ่งข้อมูลอย่างไร k เท่าไร ทำซ้ำไหม', 'resample เฉพาะข้อมูลฝึกไหม มีงานไหนรั่ว', 'ใช้ DOB-SCV ไหม', 'เลือก hyperparameter อย่างไร บนข้อมูลไหน ด้วย measure อะไร', 'งบการค้นหาของวิธีที่เสนอกับคู่เทียบเท่ากันไหม')
    PC = ['Repeated k-fold CV', 'Single k-fold CV', '5x2 CV', 'Single hold-out', 'Repeated hold-out', 'Fixed benchmark split', 'Not stated']
    body += tiles([('43<small>/71</small>', 'เฉลี่ยจากการแบ่งข้อมูลซ้ำหลายรอบ'), (str(sum(1 for p in E if p['resampling_inside_cv'] is True)) + '<small>/71</small>', 'ระบุว่า resample เฉพาะข้อมูลฝึก'),
                   ('0', 'ใช้ DOB-SCV'), (str(sum(1 for p in E if p['tuning_class'] == 'Selected on evaluation data')) + '<small>/71</small>', 'เลือกค่าบนข้อมูลที่ใช้วัดผล')])
    body += '<h3>protocol ตามช่วงปี</h3>' + table(ERA_HEAD + ['รายชื่อ (ถ้าไม่เกิน 10)'], [era_row(c, lambda p, c=c: p['protocol_class'] == c,
                  extra=(keys_list(users(lambda p, c=c: p['protocol_class'] == c)) if sum(1 for p in E if p['protocol_class'] == c) <= 10 else '')) for c in PC], right=(1, 2, 3, 4, 5))
    kc = C(str(p.get('cv_k') or 'ไม่ใช้ k-fold / ไม่ระบุ') for p in E)
    body += '<div class="two"><div><h3>ค่า k</h3>' + hbars([(k if not k.isdigit() else 'k = ' + k, v) for k, v in kc.most_common()], 71) + '</div><div><h3>resample เฉพาะข้อมูลฝึก</h3>' + hbars(
        [('ระบุหรือบรรยายชัด', sum(1 for p in E if p['resampling_inside_cv'] is True)), ('ไม่ระบุ', sum(1 for p in E if p['resampling_inside_cv'] is None)), ('resample ก่อนแบ่ง (รั่ว)', sum(1 for p in E if p['resampling_inside_cv'] is False))], 71) + '</div></div>'
    body += table(ERA_HEAD, [era_row('ระบุว่า resample เฉพาะข้อมูลฝึก', lambda p: p['resampling_inside_cv'] is True), era_row('แบ่งข้อมูลซ้ำหลายรอบ (รวม 5x2)', lambda p: p['protocol_class'] in ('Repeated k-fold CV', '5x2 CV', 'Repeated hold-out')),
                             era_row('ใช้ 5-fold', lambda p: p.get('cv_k') == 5), era_row('ใช้ 10-fold', lambda p: p.get('cv_k') == 10)], right=(1, 2, 3, 4, 5))
    body += ('<div class="box warn"><b>การรั่วของข้อมูล (leakage)</b><ul class="list"><li>' + short('AB-SMOTE-2020') + ': ' + esc(BY['AB-SMOTE-2020']['integrity'][0]) + '</li><li>' + short('MC-NCLWO-2025') + ': normalization ดูเหมือนทำก่อนแบ่งข้อมูล และบอกจำนวน fold ขัดกัน (10 กับ 5)</li></ul>'
             '<p>KEEL แจกข้อมูลที่แบ่ง 5 fold ไว้แล้ว: ผู้ใช้ KEEL ใช้ 5-fold 13/33 งาน เทียบกับ 7/38 งานที่ไม่ใช้ · stratification ยังทำให้เกิด dataset shift ในคลาสน้อยได้ DOB-SCV (López et al. 2014) แก้ได้และ review 15 ปีแนะนำ แต่ไม่มีงานใดใช้</p></div>')
    body += note('citation ratio: แบ่งข้อมูลซ้ำหลายรอบ ' + infl('repeated') + ' · ระบุว่า resample เฉพาะข้อมูลฝึก ' + infl('inside') + ' · เลือกค่าบนข้อมูลที่ใช้วัดผล ' + infl('evalsel'))
    TC = ['Selected on evaluation data', 'Fixed / default settings', 'Nested / held-out tuning', 'Unclear']
    TTH = {'Selected on evaluation data': 'เลือกบนข้อมูลที่ใช้วัดผล', 'Fixed / default settings': 'ค่าตายตัวหรือค่า default ทุกวิธี', 'Nested / held-out tuning': 'nested CV หรือชุด tuning แยก', 'Unclear': 'ไม่ชัด'}
    body += '<h3>การเลือก hyperparameter ตามช่วงปี</h3>' + table(ERA_HEAD + ['รายชื่อ (ถ้าไม่เกิน 10)'], [era_row(TTH[c], lambda p, c=c: p['tuning_class'] == c,
                  extra=(keys_list(users(lambda p, c=c: p['tuning_class'] == c)) if sum(1 for p in E if p['tuning_class'] == c) <= 10 else '')) for c in TC], right=(1, 2, 3, 4, 5))
    body += note('เลือกบนข้อมูลที่ใช้วัดผล 35 งาน: เขียนชัด ' + str(S['tuning_explicit']) + ' งาน และบอกเป็นนัย (ทดลองเบื้องต้นโดยไม่มีข้อมูล validation แยก) ' + str(S['tuning_implied']) + ' งาน · สัดส่วนเพิ่มจาก 36% (ถึง 2009) เป็น 54% (2021–26)')
    sel = C(s for p in E for s in (p['r2'].get('ms_selected') or [])); dat = C(str(p['r2'].get('ms_data')) for p in E); cri = C(s for p in E for s in (p['r2'].get('ms_criterion') or []))
    SELT = {'method parameters': 'พารามิเตอร์ของวิธี', 'none (fixed settings)': 'ไม่เลือก (ค่าตายตัว)', 'classifier hyperparameters': 'hyperparameter ของ classifier', 'best variant': 'เลือก variant ที่ดีสุด', 'sampling rate': 'อัตรา resample', 'not stated': 'ไม่ระบุ'}
    DATT = {'evaluation data': 'ข้อมูลที่ใช้วัดผล', 'not stated': 'ไม่ระบุ', 'not applicable': 'ไม่เกี่ยว (ค่าตายตัว)', 'inner validation (training data only)': 'validation ภายในข้อมูลฝึก', 'other: five disjoint KEEL tuning datasets excluded from all evaluation': 'ชุด tuning 5 ชุดที่ไม่ใช้วัดผล (CISO)'}
    body += ('<div class="two"><div><h3>สิ่งที่ถูกเลือก</h3>' + hbars([(SELT.get(k, esc(k)), v) for k, v in sel.most_common()], 71) + '</div><div><h3>เลือกบนข้อมูลไหน</h3>' + hbars([(DATT.get(k, esc(k)), v) for k, v in dat.most_common()], 71) + '</div></div>')
    body += '<h3>measure ที่ใช้เป็นเกณฑ์เลือก (' + str(sum(1 for p in E if p['r2'].get('ms_criterion'))) + ' งานที่ระบุ)</h3>' + hbars([(esc(k), v) for k, v in cri.most_common(14)], 71)
    body += ('<div class="box"><b>ข้อสังเกต</b><ul class="list"><li>เลือกด้วย sensitivity อย่างเดียว ซึ่งให้รางวัลการทาย minority ทั้งหมด: ' + keys_list([p['key'] for p in E if p['r2'].get('ms_sens_only')]) + '</li>'
             '<li>งบไม่เท่ากัน: G-SMOTE 2019 เลือกจาก 294 configuration เทียบกับ SMOTE 2 configuration บน test fold เดียวกัน</li><li>ทางเลือกที่มีตั้งแต่ 2008: wrapper ของ Chawla et al. เลือกปริมาณ undersampling และ SMOTE จากข้อมูลฝึกเท่านั้น</li>'
             '<li>Cawley และ Talbot 2010: เลือกโมเดลบนข้อมูลที่ใช้ประมาณผลทำให้ผลสูงเกินจริง และเอื้อวิธีที่ค้นหามากที่สุด</li></ul></div>')
    body += table(['งาน', 'สิ่งที่เลือก', 'บนข้อมูล', 'เกณฑ์', 'tuning class'], [[short(p['key']), esc(', '.join(p['r2'].get('ms_selected') or [])), esc(str(p['r2'].get('ms_data'))), esc(', '.join(p['r2'].get('ms_criterion') or [])), TTH[p['tuning_class']]]
                                                                      for p in sorted(E, key=lambda p: (p['year'], p['key']))], cls='wide compact')
    sec('d7', 'D7', 'protocol และการเลือกค่าพารามิเตอร์', 'Protocol and settings', body)


# ------------------------------------------------------------------ D8 statistical tests
def d8():
    S = AN['summary']
    TC = ['Corrected multiple comparison', 'Pairwise only (uncorrected)', 'Omnibus, no corrected post-hoc', 'Bayesian', 'None']
    TTH = {'Corrected multiple comparison': 'ปรับแก้การเปรียบเทียบหลายคู่', 'Pairwise only (uncorrected)': 'รายคู่ ไม่ปรับแก้', 'Omnibus, no corrected post-hoc': 'omnibus อย่างเดียว', 'Bayesian': 'Bayesian', 'None': 'ไม่มี test'}
    body = ask('กี่งานใช้ statistical test ใช้ test อะไร', 'ปรับแก้การเปรียบเทียบหลายคู่ไหม', 'อ้างแหล่งวิธีวิทยาอะไร', 'มีงานไหนใช้ test ผิด', 'test ช่วยให้ถูกอ้างอิงมากขึ้นไหม')
    body += tiles([(str(sum(1 for p in E if p['test_class'] != 'None')) + '<small>/71</small>', 'มี test อย่างน้อยหนึ่งแบบ'), ('27', 'ปรับแก้หลายคู่ (23 เป็น Friedman + post-hoc)'),
                   ('19', 'รายคู่โดยไม่ปรับแก้'), (str(S['stats_method_ref']) if isinstance(S['stats_method_ref'], int) else '25', 'อ้างแหล่งวิธีวิทยาของ test')])
    body += '<h3>ชั้นของ test ตามช่วงปี</h3>' + table(ERA_HEAD + ['รายชื่อ (ถ้าไม่เกิน 10)'], [era_row(TTH[c], lambda p, c=c: p['test_class'] == c,
                  extra=(keys_list(users(lambda p, c=c: p['test_class'] == c)) if sum(1 for p in E if p['test_class'] == c) <= 10 else '')) for c in TC], right=(1, 2, 3, 4, 5))
    tn = C(t for p in E for t in p['tests_n'])
    body += '<div class="two"><div><h3>test ที่ใช้</h3>' + hbars([(esc(k), v) for k, v in tn.most_common()], 71) + '</div>'
    sc = C(s for p in E for s in (p['r2'].get('stats_cited') or []))
    body += '<div><h3>แหล่งวิธีวิทยาที่อ้าง</h3>' + hbars([(esc(k.replace('Demsar', 'Demšar').replace('Garcia', 'García')), v) for k, v in sc.most_common(16)], 71) + '</div></div>'
    body += table(ERA_HEAD, [era_row(t, lambda p, t=t: t in p['tests_n']) for t in ['Wilcoxon signed-rank', 'Friedman', 't-test', 'Holm', 'Bonferroni-Dunn', 'Nemenyi', 'Shaffer', 'Bayesian test']] +
                  [era_row('อ้าง Demšar 2006', lambda p: 'Demsar 2006' in (p['r2'].get('stats_cited') or [])), era_row('อ้างแหล่งวิธีวิทยา', lambda p: p['r2'].get('stats_method_ref'))], right=(1, 2, 3, 4, 5))
    unc = [p for p in E if p['test_class'] == 'Pairwise only (uncorrected)']
    body += note('งานที่ใช้รายคู่โดยไม่ปรับแก้เทียบกับคู่เทียบค่ากลาง ' + f"{st.median([p['n_baselines'] for p in unc if p['n_baselines'] is not None]):g}" + ' วิธี จึงมีโอกาสได้ผลมีนัยสำคัญโดยบังเอิญ · รายชื่อ: ' + keys_list([p['key'] for p in unc]))
    ERR = [('SOUP-2019', 'วาด Nemenyi CD diagram หลัง Friedman ที่ไม่มีนัยสำคัญ (p = 0.36)'), ('MC-MBRC-2024', 'ใช้ Nemenyi โดยไม่มี omnibus Friedman'),
           ('MC-NCLWO-2025', 'บอกชื่อ post-hoc ขัดกัน (Holm กับ Shaffer) และไม่รายงาน omnibus'), ('G-SMOTE-2019', 'ไม่บอกว่าใช้ paired test ใด ก่อนปรับ Holm'),
           ('CBHSID-2022', 'อ้าง Wilcoxon ไปยังคู่มือการทดสอบ normality; Wilcoxon รายคู่ไม่ปรับแก้; ระดับ α ขัดกัน (0.1 กับ 0.01/0.05)')]
    body += '<h3>ข้อผิดพลาดที่พบในการใช้ test</h3>' + table(['งาน', 'ข้อผิดพลาด', 'รายละเอียด test (ตามที่ลงรหัส)'], [[short(k), t, '<span class="sub">' + esc(BY[k]['stat_test_details'] or '') + '</span>'] for k, t in ERR], cls='wide')
    body += ('<div class="box warn"><b>test ไม่ได้แก้ selection bias</b><p>test ทำบน fold เดียวกับที่ใช้เลือกค่า (D7) จึงไม่ลดอคติจากการเลือกค่า · การรวม dataset × classifier เป็น block เดียวทำให้ block ไม่อิสระกัน ควรคำนวณ rank ต่อ classifier '
             '(ดูผลของเราใน D13: CD = ' + f"{X['CD']:.2f}" + ' สำหรับ 5 วิธี 110 ชุด)</p></div>')
    body += note('citation ratio: มี test ' + infl('anytest') + ' · ปรับแก้หรือ Bayesian ' + infl('corr') + ' · อ้างแหล่งวิธีวิทยา ' + infl('method_ref'))
    sec('d8', 'D8', 'การทดสอบทางสถิติ', 'Statistical testing', body)


# ------------------------------------------------------------------ D9 reporting
def d9():
    body = ask('งานรายงานผลด้วยตารางและกราฟแบบไหน', 'ควรรายงานอะไร (ตัวอย่างจากผลทดลองของเรา)', 'กี่งานแจก code รายงาน runtime รายงาน SD')
    rk = C(r for p in E for r in sorted(set(p['reporting'] or [])))
    body += '<h3>ทุกรูปแบบการรายงานที่พบ</h3>' + hbars([(esc(k), v) for k, v in rk.most_common()], 71)
    MAIN = [('per-dataset table', 'ตารางผลรายชุดข้อมูล'), ('best-in-bold', 'ตัวหนาค่าที่ดีสุด'), ('average rank table', 'ตาราง average rank'), ('p-value table', 'ตาราง p-value'), ('mean +/- std', 'mean ± SD'),
            ('win/tie/loss counts', 'W/T/L'), ('ablation study', 'ablation'), ('parameter sensitivity', 'parameter sensitivity'), ('CD diagram', 'CD diagram'), ('box plot', 'box plot'), ('runtime table', 'ตาราง runtime'), ('supplementary tables', 'ตารางในไฟล์เสริม')]
    body += '<h3>รูปแบบหลักตามช่วงปี</h3>' + table(ERA_HEAD, [era_row(t, lambda p, k=k: k in (p['reporting'] or [])) for k, t in MAIN] +
                                                   [era_row('รายงาน runtime (measure หรือตาราง)', lambda p: p['runtime_reported']), era_row('แจก code', lambda p: p['has_code'])], right=(1, 2, 3, 4, 5))
    body += note('citation ratio: รายงาน SD ' + infl('std') + ' · รายงาน runtime ' + infl('runtime') + ' · แจก code ' + infl('code'))
    body += take(BE.q3, 'Q3')
    sec('d9', 'D9', 'การรายงานผล', 'Reporting', body)


# ------------------------------------------------------------------ D10 why practice changed
TOPTH = {'data': 'ข้อมูล', 'learners': 'learner และ baseline', 'measures': 'measure', 'protocol': 'protocol', 'stats': 'สถิติ', 'reporting': 'การรายงาน'}
TRTH = {'rising': 'เพิ่ม', 'declining': 'ลด', 'stable': 'คงที่', 'new': 'ใหม่', 'abandoned': 'หายไป'}


def d10():
    body = ask('ทำไมวิธีวัดผลเปลี่ยน ตัวขับคืออะไร', 'แนวปฏิบัติแต่ละอย่างเริ่มเมื่อไร งานแรกและงานล่าสุดคืออะไร', 'แนวปฏิบัติแบบไหนสัมพันธ์กับการถูกอ้างอิง', 'งานที่ถูกอ้างมากที่สุดวัดผลอย่างไร')
    body += take(BE.q6, 'Q6')
    body += ('<div class="box key"><b>ตัวขับ 7 แบบที่ใช้อธิบายการเปลี่ยน (การ์ดรายแถวอยู่ใน D1)</b><ul class="list"><li><b>T toolchain</b>: Python ระบุ ' + '/'.join(map(str, W['tool_era']['py'])) + ' ตามช่วงปี, Weka ' + '/'.join(map(str, W['tool_era']['weka'])) + ', แจก code ' + '/'.join(map(str, W['code_era'])) + '</li>'
             '<li><b>A absorption</b>: ค่าเดี่ยวถูกรวมเข้า composite: ผู้ใช้ composite ที่รายงาน recall ' + ', '.join(str(a) + '/' + str(b) for a, b in zip(*W['recall_with_comp'])) + '; ผู้ใช้ F ที่รายงาน precision ' + ', '.join(str(a) + '/' + str(b) for a, b in zip(*W['prec_with_comp'])) + '; ผู้ใช้ G-mean ที่รายงาน TNR ' + ', '.join(str(a) + '/' + str(b) for a, b in zip(*W['tnr_with_gm'])) + '</li>'
             '<li><b>S scale</b>: ค่ากลางชุดข้อมูล ' + ', '.join(f"{v:g}" for v in W['ds_med_era']) + '; ผู้ใช้ ROC curve ค่ากลาง ' + f"{W['roc_med_ds']:g}" + ' ชุด เทียบผู้ใช้ AUC อย่างเดียว ' + f"{W['auc_med_ds']:g}" + ' ชุด</li>'
             '<li><b>P problem</b>: งานหลายคลาส ' + ', '.join(map(str, W['multi_era'])) + '; ข้อมูลภาพ ' + ', '.join(map(str, W['img_era'])) + '; generative ตั้งแต่ 2019 (5 งาน)</li>'
             '<li><b>L lineage</b>: สาย MC-CCR 6 งาน; 11 งานบอกว่าทำตามงานก่อน</li><li><b>R realism และคำวิจารณ์</b>: RF/GB จาก 7% เป็น 33%; Boughorbel (MCC) ถูกอ้าง 3 งาน</li><li><b>N</b>: ใช้ไม่เกิน 2 งาน ไม่มีแนวโน้ม</li></ul>'
             '<p>สถานะ: หายไป ถ้าช่วง 2021–26 เป็น 0; ใหม่ ถ้าปีแรก ≥ 2016; เพิ่มหรือลด ถ้าสัดส่วนเปลี่ยน ≥ 15 จุด; นอกนั้นคงที่ · หลักฐาน: ตรง, แวดล้อม, ข้อสันนิษฐาน</p></div>')
    rows = []
    for r in AN['roadmap']:
        rows.append([TOPTH.get(r['topic'], r['topic']), esc(r['label']), r['n']] + [str(r['by_era'][e]) + ' <span class="sub">(' + str(r['share'][e]) + '%)</span>' for e in ERA] +
                    [TRTH.get(r['trend'], r['trend']), (short(r['first_key']) if r.get('first_key') in BY else str(r.get('first', ''))), (short(r['last_key']) if r.get('last_key') in BY else str(r.get('last', '')))])
    body += '<h3>roadmap ทั้ง ' + str(len(rows)) + ' แนวปฏิบัติ</h3>' + table(['หัวข้อ', 'แนวปฏิบัติ', 'รวม'] + [ERA_TH[i] for i in range(4)] + ['แนวโน้ม', 'งานแรก', 'งานล่าสุด'], rows, cls='wide compact', right=(2, 3, 4, 5, 6))
    rows = []
    for r in AN['influence']:
        sig = r['lo'] > 1 or r['hi'] < 1
        rows.append([TOPTH.get(r['topic'], r['topic']), esc(r['th']), r['n_users'], r['n_other'], f"{r['med_cpy_users']:g}", f"{r['med_cpy_other']:g}",
                     ('<b>' if sig else '') + f"{r['ratio']:.2f}" + ('</b>' if sig else ''), f"{r['lo']:.2f}–{r['hi']:.2f}", f"{r['p']:.3f}"])
    body += ('<h3>citation ratio ของแต่ละแนวปฏิบัติ (' + str(AN['eligible_n']) + ' งานที่ตีพิมพ์ถึง 2024)</h3>' + table(['หัวข้อ', 'แนวปฏิบัติ', 'งานที่ทำ', 'งานที่ไม่ทำ', 'cites/ปี (ทำ)', 'cites/ปี (ไม่ทำ)', 'ratio', '95% CI', 'p'], rows, cls='wide compact', right=(2, 3, 4, 5, 6, 7, 8)) +
             note('ratio = exp ของสัมประสิทธิ์ใน regression ของ log(1 + cites) บนปีและแนวปฏิบัตินั้น; ตัวหนา = CI ไม่คร่อม 1 (มีแค่ปัญหานิยาม measure) · อายุเพิ่ม 1 ปีคูณ cites ' + f"{AN['year_ratio']:.2f}" + ' เท่า · ใช้บอกความสัมพันธ์ ไม่ใช่ผลเชิงสาเหตุ'))
    top = sorted([p for p in E if p.get('cites') is not None], key=lambda p: -p['cites'])[:10]
    body += '<h3>10 งานที่ถูกอ้างมากที่สุด วัดผลอย่างไร</h3>' + table(['งาน', 'cites', 'ชุดข้อมูลจริง', 'learner', 'measure', 'protocol', 'test', 'tuning', 'code'],
        [[short(p['key']), p['cites'], p['datasets']['n_real'], p['n_clf'], esc(', '.join(p['metrics_n'])), esc(p['protocol_class']), esc(p['test_class']), esc(p['tuning_class']), 'ใช่' if p['has_code'] else ''] for p in top], cls='wide compact', right=(1, 2, 3))
    body += note('ค่ากลางชุดข้อมูลจริง ' + f"{st.median([p['datasets']['n_real'] for p in top]):g}" + ' ชุด · มี test ' + str(sum(1 for p in top if p['test_class'] != 'None')) + ' จาก 10 · ตีพิมพ์ก่อน 2010 ' + str(sum(1 for p in top if p['year'] < 2010)) + ' จาก 10 · งานดังส่วนใหญ่เป็นงานเก่าที่วัดผลแบบเรียบง่าย จึงไม่ใช่ต้นแบบของการวัดผลวันนี้')
    sec('d10', 'D10', 'ทำไมการวัดผลเปลี่ยน และอะไรสัมพันธ์กับการถูกอ้างอิง', 'Why practice changed, and citations', body)


# ------------------------------------------------------------------ D11 outcomes and the 7-criteria standard
def d11():
    import re as _re
    body = ask('มีงานที่วิธีใหม่ไม่ชนะไหม', 'วิธีที่ชนะในงานหนึ่งยังชนะในงานต่อมาไหม', 'กี่งานผ่านมาตรฐาน 7 ข้อ ข้อไหนขาดบ่อย')
    oc = C(p['outcome'] for p in E)
    body += tiles([(str(oc['A'] + oc['B']) + '<small>/' + str(oc['A'] + oc['B'] + oc['C']) + '</small>', 'งานที่เสนอวิธีและสรุปว่าวิธีตัวเองดีสุด'), (str(oc['A']), 'ดีสุดโดยไม่มีข้อยกเว้น'), (str(oc['B']), 'ดีสุด แต่ระบุข้อยกเว้นเอง'), (str(oc['C']), 'ไม่ได้เปรียบ baseline')])
    body += table(['outcome', 'งาน', 'รายชื่อ'], [[OUTC[c], oc[c], keys_list(users(lambda p, c=c: p['outcome'] == c))] for c in 'ABCD'], cls='wide', right=(1,))
    def later(rx, y0):
        return [p['key'] for p in E if p['year'] > y0 and any(_re.search(rx, b or '') for b in (p['baselines'] or []))]
    body += ('<div class="box"><b>ชัยชนะไม่สะสม</b><ul class="list"><li>MDO 2016 เป็นคู่เทียบใน ' + str(len(later(r'\bMDO\b', 2016))) + ' งานต่อมา: ' + keys_list(later(r'\bMDO\b', 2016)) + '</li>'
             '<li>MC-CCR 2020 เป็นคู่เทียบใน ' + str(len(later(r'MC-CCR', 2020))) + ' งานต่อมา: ' + keys_list(later(r'MC-CCR', 2020)) + '</li><li>ทุกงานต่อมารายงานว่าวิธีของตัวเองนำบน measure หลัก จึงสรุปไม่ได้ว่าวิธีไหนดีกว่ากันจริง</li>'
             '<li>CISO 2025 เป็นงานเดียว (outcome C) ที่รายงานตรง ๆ ว่าวิธีใหม่ไม่ดีกว่า class weighting, ROS หรือการไม่ resample</li></ul></div>')
    body += note('citation ratio ของงานที่ระบุข้อยกเว้นเอง (outcome B): ' + infl('outB'))
    cnt = [sum(1 for p in E if f(p)) for _, f in CRIT]
    body += '<h3>มาตรฐาน 7 ข้อ</h3>' + table(['เกณฑ์', 'ผ่าน'] + [ERA_TH[i] for i in range(4)], [[t, '<b>' + str(cnt[i]) + '</b>/71'] + [str(sum(1 for p in E if p['era'] == e and f(p))) + ' <span class="sub">(' + str(pct(sum(1 for p in E if p['era'] == e and f(p)), EN[e])) + '%)</span>' for e in ERA] for i, (t, f) in enumerate(CRIT)], right=(1, 2, 3, 4, 5))
    sd = C(SCORE.values())
    body += '<div class="two"><div><h3>จำนวนเกณฑ์ที่ผ่านต่องาน</h3>' + hbars([(str(k) + ' ข้อ', sd[k]) for k in sorted(sd)], 71) + '</div><div><h3>ค่ากลางคะแนนตามช่วงปี</h3>' + table(['ช่วงปี', 'ค่ากลาง', 'สูงสุด'], [[ERA_TH[i], f"{st.median([SCORE[p['key']] for p in E if p['era'] == e]):g}", max(SCORE[p['key']] for p in E if p['era'] == e)] for i, e in enumerate(ERA)], right=(1, 2)) + '</div></div>'
    best = sorted([p for p in E if SCORE[p['key']] >= 5], key=lambda p: (-SCORE[p['key']], p['year']))
    body += '<h3>งานที่ผ่านตั้งแต่ 5 ข้อ</h3>' + table(['งาน', 'คะแนน', 'ข้อที่ขาด'], [[short(p['key']), SCORE[p['key']], ', '.join(t for t, f in CRIT if not f(p)) or 'ครบ'] for p in best], cls='wide', right=(1,))
    body += note('ผ่านครบ 7 ข้อ: ' + keys_list([k for k, v in SCORE.items() if v == 7]) + ' · คะแนนนี้ใช้สรุปภาพรวม ไม่ใช่เกณฑ์ตัดสินคุณภาพของงานรายเรื่อง')
    sec('d11', 'D11', 'ผลลัพธ์ที่อ้าง และมาตรฐาน 7 ข้อ', 'Claims and a seven-point standard', body)


# ------------------------------------------------------------------ D12 recommendations
def d12():
    body = ask('งานใหม่ควรวัดผลอย่างไร ทีละหัวข้อ', 'มีรายการตรวจก่อนส่ง paper ไหม', 'การทดลองของเราทำตามข้อแนะนำแค่ไหน')
    body += note('ข้อความทั้งหมดในหัวข้อนี้มาจาก guide (section07-evaluation-guide.html) แต่ละหัวข้อตอบ 3 คำถาม: งานทั้ง 71 เรื่องทำอะไร, ควรเลือกอย่างไรและทำไม, ต้องรายงานอะไร')
    for t in ['t-data', 't-learners', 't-baselines', 't-measures', 't-protocol', 't-tuning', 't-stats', 't-reporting', 't-beyond', 't-claims', 'ours', 'checklist']:
        body += guide_topic(t)
    sec('d12', 'D12', 'ข้อแนะนำสำหรับงานใหม่', 'Recommendations for a new study', body)


# ------------------------------------------------------------------ D13 illustrative runs, every number
MTH = BE.MEAS_TH; CTH = BE.CLF_TH; METH = BE.METH; MEAS = BE.MEAS


def fp(p):
    return '&lt;0.0001' if p < 1e-4 else f"{p:.4f}"


def d13():
    body = ask('ผลทดลองของเรา (110 ชุด KEEL) วิธีไหนชนะ แยกกันได้ไหม', 'measure ต่างกันให้ผู้ชนะต่างกันไหม', 'SMOTE ดีกว่าไม่ resample จริงไหม', 'ผลแปรตาม IR ไหม', 'rank แบบรวม block กับแบบต่อ classifier ต่างกันอย่างไร')
    body += ('<div class="box key"><b>การออกแบบ</b><p>110 ชุดข้อมูลจาก KEEL · วิธี None (ไม่ resample), SMOTE, MWMOTE, CISO, QC-SMOTE · classifier CART, k-NN, SVM-RBF, Logistic Regression, Random Forest · stratified 5-fold CV รอบเดียว (' + esc(X['n_runs_note']) +
             ') · measure AUC, PR-AUC, F1, G-mean · rank 1 = ดีสุด (ค่าเท่ากันเฉลี่ย rank) · Friedman แบบ Iman-Davenport และ Wilcoxon เทียบ SMOTE ปรับ Holm · CD (Nemenyi, α = 0.05, k = 5, N = ' + str(X['N']) + ', q = 2.728) = <b>' + f"{X['CD']:.2f}" + '</b></p>'
             '<p>ข้อจำกัด: รอบเดียว ไม่มีการเลือกค่าพารามิเตอร์ ถ้าจะใส่ใน paper ควรรันซ้ำอย่างน้อย 5 รอบ ใช้เป็นตัวอย่างประกอบ ไม่ใช่ benchmark</p></div>')
    clfs = ['CART', 'kNN', 'SVM', 'LR', 'RF', 'avg']
    rows = []
    for c in clfs:
        for m in MEAS:
            r = X['per'][c + '|' + m]; best = max(r['mean'].values())
            rows.append([CTH[c], MTH[m]] + [('<b>' if r['mean'][me] == best else '') + f"{r['mean'][me]:.4f}" + ('</b>' if r['mean'][me] == best else '') for me in METH])
    body += '<h3>ค่าเฉลี่ยของ measure (110 ชุด)</h3>' + table(['classifier', 'measure'] + METH, rows, cls='compact', right=(2, 3, 4, 5, 6))
    rows = []
    for c in clfs:
        for m in MEAS:
            r = X['per'][c + '|' + m]; lo = min(r['ar'].values())
            rows.append([CTH[c], MTH[m]] + [('<b>' if r['ar'][me] == lo else '') + f"{r['ar'][me]:.2f}" + ('</b>' if r['ar'][me] == lo else '') for me in METH] + [f"{r['FF']:.2f}", fp(r['pF'])])
    body += '<h3>average rank และ Friedman ต่อ classifier ต่อ measure</h3>' + table(['classifier', 'measure'] + METH + ['F<sub>F</sub>', 'p'], rows, cls='compact', right=(2, 3, 4, 5, 6, 7, 8))
    rows = []
    for c in clfs:
        for m in MEAS:
            r = X['per'][c + '|' + m]
            rows.append([CTH[c], MTH[m]] + [fp(r['holm'][me]) + ' <span class="sub">' + '/'.join(map(str, r['wtl'][me])) + '</span>' for me in METH if me != 'SMOTE'])
    body += ('<h3>เทียบกับ SMOTE: Holm p และ ดีกว่า/เท่ากัน/แย่กว่า SMOTE</h3>' + table(['classifier', 'measure'] + [me for me in METH if me != 'SMOTE'], rows, cls='compact', right=(2, 3, 4, 5)) +
             note('ตัวเลขเล็กคือจำนวนชุดข้อมูลที่วิธีนั้นดีกว่า / เท่ากับ / แย่กว่า SMOTE · "เฉลี่ย 5 classifier" = ค่าเฉลี่ยของ 5 classifier ต่อชุดข้อมูล แล้วจัด rank บน 110 block'))
    rows = [[MTH[m]] + [f"{X['pooled'][m][me]:.2f}" for me in METH] + [f"{X['avg_rank_clfmean'][m][me]:.2f}" for me in METH] for m in MEAS]
    body += ('<h3>rank แบบรวม 550 block (ชุดข้อมูล × classifier) เทียบกับแบบเฉลี่ย classifier ก่อน (110 block)</h3>' + table(['measure'] + ['รวม: ' + me for me in METH] + ['เฉลี่ยก่อน: ' + me for me in METH], rows, cls='compact', right=tuple(range(1, 11))) +
             note('แบบรวม 550 block ทำให้ block ไม่อิสระกัน (ชุดข้อมูลเดียวกันซ้ำ 5 ครั้ง) จึงไม่ควรใช้กับ Friedman; ผู้ชนะตาม G-mean คือ SMOTE ทั้งสองแบบ แต่ F1 แบบรวมให้ QC-SMOTE และ CISO เกือบเท่ากัน และ PR-AUC ให้ None ดีสุด'))
    sv = X['smote_vs_none']
    body += '<h3>SMOTE เทียบกับ None (550 กรณี)</h3>' + table(['measure', 'SMOTE ดีกว่า', 'เท่ากัน', 'None ดีกว่า', 'ผลต่างค่ากลาง', 'ผลต่างเฉลี่ย', 'ρ(IR, gain)'],
        [[MTH[m], sv[m]['win'], sv[m]['tie'], sv[m]['loss'], f"{sv[m]['med']:+.4f}", f"{sv[m]['mean']:+.4f}", f"{X['ir_gain_rho'][m]:.2f}"] for m in MEAS], right=(1, 2, 3, 4, 5, 6))
    body += note('ρ(IR, gain) = Spearman ระหว่าง IR กับผลต่าง SMOTE − None (เฉลี่ย 5 classifier) บน 110 ชุด · None ได้ G-mean = 0 ใน ' + str(X['gm_zero_none']) + ' กรณี และ F1 = 0 ใน ' + str(X['f1_zero_none']) + ' กรณี (ทายคลาสใหญ่ทั้งหมด) · SD ข้าม fold ค่ากลาง: ' + ', '.join(MTH[m] + ' ' + f"{X['fold_sd_median'][m]:.3f}" for m in MEAS) + ' ซึ่งมากกว่าผลต่างของค่าเฉลี่ยระหว่าง 4 วิธี resample ในทุก classifier และ measure (ค่ากลาง 0.016 มากสุด 0.052 ที่ k-NN G-mean)')
    bc = X['best_counts']; cr = X['cross']
    body += '<div class="two"><div><h3>จำนวนครั้งที่เป็นวิธีดีสุด (550 กรณี)</h3>' + table(['วิธี', 'ตาม G-mean', 'ตาม F1'], [[me, bc['Gmean'].get(me, 0), bc['F1'].get(me, 0)] for me in METH], right=(1, 2)) + '</div>'
    body += '<div><h3>วิธีดีสุดตาม G-mean (แถว) เทียบตาม F1 (คอลัมน์)</h3>' + table(['G-mean \\ F1'] + METH, [[r] + [('<b>' if r == c else '') + str(cr[r][c]) + ('</b>' if r == c else '') for c in METH] for r in METH], right=(1, 2, 3, 4, 5)) + '</div></div>'
    off_s = sum(v for c, v in cr['SMOTE'].items() if c != 'SMOTE'); off_n = sum(cr[r]['None'] for r in METH if r != 'None')
    body += note('เลือกวิธีดีสุดตรงกัน ' + str(X['best_agree']['same']) + '/' + str(X['best_agree']['n']) + ' กรณี · ค่ากลาง Kendall τ ของอันดับ 5 วิธีระหว่าง G-mean กับ F1 ต่อกรณี = ' + f"{X['tau_median']:.2f}" +
                 ' · ไม่ตรงกันแบบเป็นระบบ: G-mean เลือก SMOTE แต่ F1 เลือกวิธีอื่น ' + str(off_s) + ' กรณี; F1 เลือก None แต่ G-mean เลือกวิธีอื่น ' + str(off_n) + ' กรณี')
    co = X['corr']
    body += '<h3>Spearman ระหว่างค่าของ measure (ทุกแถวของผล)</h3>' + table([''] + [MTH[m] for m in MEAS], [[MTH[a]] + [f"{co[a][b]:.3f}" for b in MEAS] for a in MEAS], right=(1, 2, 3, 4))
    body += ('<div class="box"><b>ตัวอย่าง threshold (ใช้ใน Q8)</b><p>คะแนนคลาสใหญ่ N(0, 1) คลาสน้อย N(1.5, 1) ที่ IR = 10: G-mean สูงสุดที่ t = 0.75 (0.773, TPR = TNR = 0.773); F1 สูงสุดที่ t = 1.48 (0.461, TPR 0.507, TNR 0.931); '
             'accuracy สูงสุดที่ t = 2.29 (TPR 0.216) · classifier เดียวกัน TPR 0.8 FPR 0.1: G-mean 0.849 ทุก IR แต่ F1 = 0.842, 0.571, 0.136 ที่ IR 1, 10, 100</p></div>')
    ex = X['example']
    body += '<h3>ตัวอย่างตารางที่ควรรายงาน (SVM, G-mean, mean ± SD ข้าม fold)</h3>' + table(['ชุดข้อมูล', 'IR'] + METH, [[esc(e['ds']), f"{e['IR']:.2f}"] + [f"{e['v'][me][0]:.3f} ± {e['v'][me][1]:.3f}" for me in METH] for e in ex], cls='compact', right=(1, 2, 3, 4, 5, 6))
    sec('d13', 'D13', 'ผลทดลองของเรา: ทุกตัวเลข', 'Illustrative runs, every number', body)


# ------------------------------------------------------------------ D14 study map
def d14():
    body = ask('งานเรื่อง X วัดผลอย่างไร', 'งานไหนใช้ measure / test / protocol แบบที่ต้องการ', 'งานตระกูล SMOTE 37 เรื่องต่างจากงานอื่นอย่างไร')
    body += ('<div class="mapctl"><input id="mq" type="search" placeholder="ค้นหา: ชื่องาน measure test learner ..." aria-label="ค้นหา">'
             '<select id="mera" aria-label="ช่วงปี"><option value="">ทุกช่วงปี</option>' + ''.join('<option>' + t + '</option>' for t in ERA_TH) + '</select>'
             '<select id="mset" aria-label="setting"><option value="">ทุก setting</option><option>binary</option><option>multiclass</option><option>both</option></select>'
             '<select id="mfam" aria-label="ตระกูล SMOTE"><option value="">ทุกงาน</option><option value="1">ตระกูล SMOTE 37</option><option value="0">ไม่ใช่ตระกูล SMOTE</option></select>'
             '<select id="mtest" aria-label="test"><option value="">ทุกแบบ test</option>' + ''.join('<option>' + t + '</option>' for t in sorted(set(p['test_class'] for p in E))) + '</select>'
             '<select id="mtun" aria-label="tuning"><option value="">ทุกแบบ tuning</option>' + ''.join('<option>' + t + '</option>' for t in sorted(set(p['tuning_class'] for p in E))) + '</select>'
             '<span id="mcount" class="sub"></span></div>'
             '<div class="scroll"><table class="t map2" id="mtab"><thead><tr>'
             + ''.join('<th data-k="' + k + '"' + (' class="r"' if r else '') + '>' + t + '</th>' for k, t, r in MAPCOLS) +
             '</tr></thead><tbody></tbody></table></div>' + note('กดหัวคอลัมน์เพื่อเรียง กดแถวเพื่อดูรหัสทั้งหมดของงานนั้น · คะแนน = จำนวนเกณฑ์ที่ผ่านจากมาตรฐาน 7 ข้อ (D11)'))
    sec('d14', 'D14', 'แผนที่งานทั้ง 71 เรื่อง (กรองและเรียงได้)', 'Study map', body)


MAPCOLS = [('s', 'งาน', 0), ('y', 'ปี', 1), ('set', 'setting', 0), ('fam', 'SMOTE 37', 0), ('nds', 'ชุดข้อมูล', 1), ('clf', 'learner', 0), ('met', 'measure', 0), ('prot', 'protocol', 0),
           ('ins', 'resample ในข้อมูลฝึก', 0), ('tun', 'tuning', 0), ('test', 'test', 0), ('code', 'code', 1), ('out', 'outcome', 0), ('sc', 'คะแนน 7 ข้อ', 1), ('cites', 'cites', 1)]
MAPFIELDS = [('k', 'key'), ('venue', 'venue'), ('era', 'ช่วงปี'), ('ap', 'approach'), ('dt', 'ชนิดข้อมูล'), ('fam', 'ตระกูล SMOTE (Method)'), ('nds', 'ชุดข้อมูล'), ('keel', 'ใช้ KEEL'), ('uci', 'ใช้ UCI'),
             ('clf', 'learner'), ('nclf', 'จำนวนกลุ่ม learner'), ('nb', 'จำนวนคู่เทียบ'), ('smb', 'SMOTE เป็นคู่เทียบ'), ('nor', 'baseline ไม่ resample'), ('cop', 'คัดลอกผลคู่เทียบ'),
             ('met', 'measure'), ('pm', 'measure หลัก'), ('mi', 'ปัญหานิยาม measure'), ('prot', 'protocol'), ('cvk', 'k'), ('ins', 'resample เฉพาะข้อมูลฝึก'), ('tun', 'tuning'), ('crit', 'เกณฑ์เลือกค่า'),
             ('test', 'ชั้นของ test'), ('tests', 'test'), ('rep', 'การรายงาน'), ('code', 'แจก code'), ('rt', 'runtime'), ('tool', 'เครื่องมือที่ระบุ'), ('dir', 'วัดตรง'), ('vis', 'รูป 2 มิติ'),
             ('ana', 'วิเคราะห์ความซับซ้อน/ทฤษฎี'), ('out', 'outcome'), ('sc', 'คะแนน 7 ข้อ'), ('cites', 'cites (OpenAlex)')]

MAPJS = r"""
(function(){
  var R=JSON.parse(document.getElementById('mapdata').textContent), F=JSON.parse(document.getElementById('mapfields').textContent);
  var tb=document.querySelector('#mtab tbody'), cols=[].map.call(document.querySelectorAll('#mtab th'),function(t){return t.dataset.k;});
  var sk='y', sd=1;
  function esc(s){return String(s==null?'':s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}
  function cell(r,k){var v=r[k]; if(k==='fam')return v?esc(v):''; if(k==='code')return v?'ใช่':''; return esc(v);}
  function draw(){
    var q=document.getElementById('mq').value.trim().toLowerCase(), e=document.getElementById('mera').value, s=document.getElementById('mset').value,
        f=document.getElementById('mfam').value, t=document.getElementById('mtest').value, u=document.getElementById('mtun').value;
    var L=R.filter(function(r){
      if(e&&r.era!==e)return false; if(s&&r.set!==s)return false; if(f==='1'&&!r.fam)return false; if(f==='0'&&r.fam)return false;
      if(t&&r.test!==t)return false; if(u&&r.tun!==u)return false;
      if(q){var h=Object.keys(r).map(function(k){return r[k];}).join(' ').toLowerCase(); if(h.indexOf(q)<0)return false;}
      return true;});
    L.sort(function(a,b){var x=a[sk],y=b[sk]; if(x==null)x=''; if(y==null)y=''; return (x>y?1:x<y?-1:0)*sd;});
    var h='';
    L.forEach(function(r){
      h+='<tr class="mr" tabindex="0" data-k="'+esc(r.k)+'">'+cols.map(function(k){return '<td'+(['y','nds','code','sc','cites'].indexOf(k)>=0?' class="r"':'')+'>'+cell(r,k)+'</td>';}).join('')+'</tr>';
      h+='<tr class="md" hidden><td colspan="'+cols.length+'"><dl class="mdl">'+F.map(function(f){var v=r[f[0]]; if(v===1)v='ใช่'; if(v===0)v='ไม่'; return '<dt>'+esc(f[1])+'</dt><dd>'+esc(v)+'</dd>';}).join('')+'</dl></td></tr>';});
    tb.innerHTML=h; document.getElementById('mcount').textContent=L.length+' จาก '+R.length+' งาน';
    document.querySelectorAll('#mtab th').forEach(function(t){t.classList.toggle('sorted',t.dataset.k===sk); t.setAttribute('aria-sort',t.dataset.k===sk?(sd>0?'ascending':'descending'):'none');});
  }
  tb.addEventListener('click',function(ev){var tr=ev.target.closest('tr.mr'); if(!tr)return; var d=tr.nextElementSibling; d.hidden=!d.hidden;});
  tb.addEventListener('keydown',function(ev){if(ev.key!=='Enter'&&ev.key!==' ')return; var tr=ev.target.closest('tr.mr'); if(!tr)return; ev.preventDefault(); var d=tr.nextElementSibling; d.hidden=!d.hidden;});
  document.querySelectorAll('#mtab th').forEach(function(t){t.tabIndex=0; function go(){if(sk===t.dataset.k)sd=-sd; else{sk=t.dataset.k; sd=1;} draw();}
    t.addEventListener('click',go); t.addEventListener('keydown',function(ev){if(ev.key==='Enter'){ev.preventDefault();go();}});});
  ['mq','mera','mset','mfam','mtest','mtun'].forEach(function(i){document.getElementById(i).addEventListener('input',draw);});
  draw();
})();
"""


# ------------------------------------------------------------------ D15 the fifteen-year review
def d15():
    body = ask('review 15 ปีของ SMOTE (Fernández et al. 2018) รายงานอะไรเกี่ยวกับการวัดผล', 'ข้อเสนอของ review ถูกทำตามไหมในงานหลังจากนั้น', 'มีอะไรขัดกับข้อมูลของเรา')
    body += ('<div class="box key"><b>Fernández, García, Herrera และ Chawla (2018), JAIR 61: 863–905, ' + BE.cites('REF-Fernandez-2018') + ' cites</b>'
             '<ul class="list"><li><b>ขอบเขต</b>: ตาราง 1 จัดส่วนขยายของ SMOTE กว่า 85 วิธีตามคุณสมบัติ 7 ข้อของการออกแบบ (การเลือกตัวอย่างตั้งต้น, การรวมกับ undersampling, แบบของ interpolation, การทำงานกับการเปลี่ยนมิติ, การสร้างแบบ adaptive, การเปลี่ยน label, การกรองตัวอย่างสังเคราะห์ที่เป็น noise); '
             'ตาราง 2 คือ ensemble ที่ใช้ SMOTE; ตาราง 3 คือ 22 วิธีที่ใช้ SMOTE ใน learning paradigm อื่น 12 แบบ (data stream, time series, semi-supervised, active learning, multi-instance, multi-label, regression, ordinal regression, text, image retrieval, imprecise data, high-dimensional)</li>'
             '<li><b>ที่มาของ SMOTE</b> (ด้านการวัดผล): ข้อมูล mammography ต้นไม้ตัดสินใจได้ accuracy ราว 97% ขณะที่ทายคลาสใหญ่ทั้งหมดได้ 97.68% และความผิดพลาดแต่ละแบบมีต้นทุนต่างกัน จึงต้องดู trade-off ระหว่าง TP กับ FP ด้วย ROC</li>'
             '<li><b>หัวข้อ 3.4</b>: สรุปงานเปรียบเทียบเชิงประจักษ์ที่มีอยู่</li><li><b>ความท้าทาย (หัวข้อ 5)</b>: small disjunct, noise, overlap (วัดด้วย Fisher discriminant ratio F1), dataset shift ที่เกิดจากการแบ่ง fold และแนะนำ DOB-SCV, '
             'ข้อมูลมิติสูง (Blagus และ Lusa: SMOTE ช่วยน้อยในข้อมูลมิติสูงสำหรับ classifier ส่วนใหญ่), big data (SMOTE บน Spark แย่กว่า ROS และ RUS), real-time และ stream</li>'
             '<li><b>ที่ไม่มี</b>: ไม่วิเคราะห์ measure, protocol, การเลือกค่า หรือ statistical test ที่งานต่าง ๆ ใช้ ไม่มีตารางหรือสถิติของแนวปฏิบัติการวัดผล ส่วนการวัดผลของเราจึงเติมช่องนี้</li></ul></div>')
    body += table(['ข้อเสนอหรือประเด็นใน review', 'งานหลังจากนั้นทำตามไหม (ข้อมูลของเรา)'], [
        ['preprocessing กับ cost-sensitive learning ดีพอกัน (ย้ำ López et al. 2012)', 'มีคู่เทียบ cost-sensitive หรือ instance weighting แค่ 5 งาน (3 งานหลัง 2018); class weighting ตรง ๆ 1 งาน (CISO 2025)'],
        ['ใช้ DOB-SCV เพื่อเลี่ยง dataset shift จากการแบ่ง fold', 'ไม่มีงานใดใน 71 เรื่องใช้'],
        ['ความสัมพันธ์ระหว่างจุดสังเคราะห์กับลักษณะภายในของข้อมูล (small disjunct, noise, overlap) เป็นคำถามหลัก', 'วัดข้อมูลหลัง resample โดยตรง 5/36 งานตั้งแต่ 2019 เทียบกับ 1/35 ก่อนหน้า; นับ safe/borderline/rare แค่ 2 งาน (SPE 2020, GLOS 2023)'],
        ['22 วิธีสำหรับ paradigm อื่น แต่ละ paradigm มี measure ของตัวเอง', 'คลังของเรามีแค่ INOS (time series) และประเมินเป็น classification; ทั้ง 71 งานวัดผลด้วย classification'],
        ['ข้อมูลมิติสูงและ big data', 'ไม่มีงานใน 71 เรื่องที่ประเมินบน big data; งานที่ใช้ข้อมูลภาพมี 4 งานในช่วง 2018–20']], cls='wide')
    body += ('<div class="box warn"><b>ข้อที่ขัดกับการลงรหัสของเรา</b><p>review บรรยายผลของ SMOTE 2002 ว่าดีกว่าอย่างมีนัยสำคัญทางสถิติ แต่ใน paper SMOTE 2002 ไม่มี statistical test (ตรวจซ้ำแล้ว) จึงควรอ้างผลของ SMOTE 2002 ว่าเป็นการเทียบด้วย ROC และ AUC เท่านั้น</p></div>')
    body += ('<div class="box"><b>ใช้เป็นแนวทางการเขียนได้อย่างไร</b><ul class="list"><li>จัดกลุ่มตามคุณสมบัติที่อธิบายได้ (เหมือนตาราง 1) แล้วนับและแสดงตามเวลา</li><li>แยก "สิ่งที่วงการทำ" กับ "ความท้าทายที่ยังเปิด" ให้ชัด</li>'
             '<li>ตรวจข้อเสนอของงานก่อนหน้ากับข้อมูลจริง (เช่น DOB-SCV ที่ไม่มีใครใช้) ซึ่งเป็นสิ่งที่ review 15 ปีไม่ได้ทำ</li></ul></div>')
    body += note('หมายเหตุ: v4 ของ Section 7 มีย่อหน้าที่อ้าง review นี้เพิ่มเข้าไป (ยังรอการตัดสินใจว่าจะเก็บหรือถอดออก)')
    sec('d15', 'D15', 'review 15 ปีของ SMOTE รายงานอะไรเกี่ยวกับการวัดผล', 'What the fifteen-year review reports', body)


# ------------------------------------------------------------------ D16 team consistency, sources and limits
def d16():
    body = ask('ตัวเลขของเราตรงกับส่วน Method และ Data ไหม', 'ข้อมูลมาจากไหน มีข้อจำกัดอะไร', 'ไฟล์ไหนใช้สร้างหน้านี้')
    body += take(BE.cons, '9') + take(BE.sources, '10')
    body += ('<div class="box"><b>ไฟล์ที่ใช้สร้างหน้านี้</b><ul class="list"><li>data.json: 76 เรื่อง รหัสรอบ 1 และ 2 (r2)</li><li>v2/analysis.json: roadmap 46 แถว, citation ratio 24 แถว, ตระกูลชุดข้อมูล, แหล่งอ้างอิง</li>'
             '<li>evalpage/facts.json, why_facts (W), why_cards: การนับ learner และ measure ตามช่วงปีและเหตุผลรายแถว</li><li>evalpage/exp.json: ผลทดลองของเราที่วิเคราะห์ใหม่</li><li>guide/evaluation_guide.html: ข้อแนะนำ 10 หัวข้อ, การทดลองของเรา, checklist</li>'
             '<li>section07-pass2-verification.xlsx: หลักฐานรายรหัสพร้อมเลขหน้า</li></ul></div>')
    sec('d16', 'D16', 'ความสอดคล้องกับทีม แหล่งข้อมูล และข้อจำกัด', 'Team consistency, sources and limits', body)


# ================================================================== question index
def qindex():
    n = lambda f: sum(1 for p in E if f(p))
    S21 = F['per_all']['2021-2026']
    sv = X['smote_vs_none']
    G = [
        ('ภาพรวมและ SMOTE 2002', [
            ('คลังบทความมีกี่เรื่อง', '76 เรื่อง มีการทดลอง 71 ในนั้นเป็นตระกูล SMOTE ตามส่วน Method 37 (Binary 24, Multiclass 5, ทั้งสอง 8)', 'd0'),
            ('ร้อยละในหน้านี้คิดจากอะไร', 'จาก 71 งานที่มีการทดลอง หรือจากจำนวนงานในช่วงปีนั้น: ถึง 2009 = 14, 2010–15 = 13, 2016–20 = 20, 2021–26 = 24', 'd0'),
            ('หลักฐานสามระดับคืออะไร', 'ตรง (paper เขียนเหตุผลเอง), แวดล้อม (เวลาและความสัมพันธ์ไปทางเดียวกัน), ข้อสันนิษฐาน (กลไกที่เราเสนอ)', 'd0'),
            ('SMOTE 2002 วัดผลอย่างไร', '9 ชุดข้อมูล, C4.5 Ripper Naive Bayes, AUC TPR TNR กับ ROC curve, 10-fold CV รอบเดียว, ไม่มี statistical test', 'd1'),
            ('ตอนนี้ใช้ classifier และ measure กี่ตัว', 'งาน 2021–26 รวมกันใช้ classifier ' + str(S21['distinct_fam']) + ' กลุ่ม measure ' + str(S21['distinct_meas']) + ' ตัว แต่แต่ละงานยังใช้ราว 3 กับ 3 และ 24 งานมีชุด measure ต่างกัน 19 แบบ', 'd1'),
            ('learner ตัวไหนเพิ่ม ลด หายไป เพราะอะไร', 'C4.5 และ rule learner ลดเพราะ Weka/KEEL ถูกแทนด้วย Python; SVM k-NN RF GB เพิ่ม; การ์ดเหตุผลครบทุกแถวพร้อมระดับหลักฐาน', 'd1'),
            ('measure ตัวไหนเพิ่ม ลด หายไป เพราะอะไร', 'ROC curve ล้วนและ TNR แยกหายไป, recall ลดเพราะถูกรวมเข้า G-mean/F1, G-mean MCC และ measure หลายคลาสเพิ่ม; การ์ดเหตุผลครบทุกแถว', 'd1'),
            ('RF และ boosting เพิ่มขึ้นแค่ไหน', '7% ของงานถึง 2009 เป็น 33% ในช่วง 2021–26 (รวม 16 งาน) ตามเครื่องมือ Python และความสมจริงของ learner', 'd1'),
            ('MCC ใช้กี่งาน', '4 งาน ทั้งหมดตั้งแต่ 2020 (SPE, GMMSampling, GOIO, DGOT); Boughorbel 2017 ถูกอ้าง 3 งาน', 'd1')]),
        ('ข้อมูล learner และคู่เทียบ', [
            ('ใช้ข้อมูลจากไหน กี่ชุด', 'UCI ' + str(n(lambda p: p['uses_uci'])) + ' งาน, KEEL ' + str(n(lambda p: p['uses_keel'])) + ' งาน; ค่ากลาง 20 ชุดต่องาน (ข้อมูลจริง 18)', 'd2'),
            ('ให้เหตุผลการเลือกข้อมูลไหม', str(n(lambda p: p['r2'].get('data_stated'))) + ' งานให้เหตุผล: ต้องการลักษณะหลากหลาย 30, ระดับ IR 19, ทำตามงานก่อน 18, difficulty factor 17', 'd2'),
            ('ข้อมูลที่ดัดแปลงเปิดเผยไหม', 'ดัดแปลง 52 งาน เปิดเผยฉบับที่ดัดแปลงแค่ 10', 'd2'),
            ('KEEL ส่งผลต่อการวัดผลอย่างไร', 'ข้อมูลหลายสิบชุดและ 5-fold ที่แบ่งไว้แล้ว: ผู้ใช้ KEEL ใช้ 5-fold 13/33 เทียบกับ 7/38', 'd2'),
            ('วัดผลกับ task อื่นนอกจาก classification ไหม', 'ไม่: ทั้ง 71 งานวัดด้วย classification มีแค่ CTGAN (regression 1 ชุด, likelihood) และ GAMO (FID)', 'd2'),
            ('กี่งานใช้ข้อมูลภาพหรือ deep learning', '4 งานในช่วง 2018–20 (Buda, CTGAN, GAMO, NBU) แล้วไม่มีในช่วง 2021–26', 'd2'),
            ('กี่งานใช้ learner ตัวเดียว', '25 งาน (2021–26: 9 จาก 24) และ SVM เป็นตัวเดียวที่พบบ่อยในช่วงล่าสุด', 'd3'),
            ('งานเลือก learner ด้วยเหตุผลอะไร', 'นิยม 22, หลากหลายแนวคิด 15, ทำตามงานก่อน 11, ง่าย 10, เทียบอย่างยุติธรรม 8', 'd3'),
            ('เทียบกับคู่เทียบกี่วิธี มี baseline อะไรบ้าง', 'ค่ากลาง 7 วิธี; SMOTE 50, ไม่ resample 52, ROS 27, cost-sensitive หรือ instance weighting 5, class weighting 1, threshold moving 3 (ไม่นับ SMOTE 2002 ที่เลื่อน threshold ของ C4.5 เพื่อวาด ROC; v4 เขียนว่า 1 ต้องแก้)', 'd4'),
            ('มีงานคัดลอกผลคู่เทียบไหม', '6 งาน: SMOTE 2002, COG-OS, SplitBal, HDE, NROMM, QC-SMOTE', 'd4'),
            ('baseline ไม่ resample หายไปไหม', 'ยังมี 52 งาน แต่สัดส่วนลดจาก 86% (ถึง 2009) เหลือ 54% (2021–26)', 'd4'),
            ('ทำไม G-mean ที่สูงขึ้นยังไม่พอ', 'G-mean ให้รางวัลการขยับ operating point ไปทางสมดุล class weighting, threshold moving หรือ ROS จึงเพิ่ม G-mean ได้เหมือนกัน วิธีใหม่ต้องชนะ baseline เหล่านี้ด้วย', 'd4')]),
        ('measure', [
            ('มี measure กี่ตัว กี่หมวด', str(F['n_measures']) + ' ตัวใน 5 หมวด (overall 1, single 4, composite 7, ranking 4, multi-class 10) และ cost; ค่ากลาง 3 ตัวต่องาน 1–2 ตัว 23 งาน', 'q4'),
            ('measure ไหนใช้มากสุด ทำไม', 'G-mean 41 งาน เพราะวัดสมดุล TPR กับ TNR ที่ resampling เปลี่ยนจริง ไม่ขึ้นกับสัดส่วนคลาส ใช้กับ label ได้ ขยายเป็นหลายคลาสได้', 'q5'),
            ('G-mean ต่างจาก F1 อย่างไร', 'G-mean ใช้ TNR, F1 ใช้ precision ซึ่งขึ้นกับ IR: TPR 0.8 FPR 0.1 ได้ G-mean 0.849 ทุก IR แต่ F1 0.84 → 0.57 → 0.14 ที่ IR 1, 10, 100', 'q8'),
            ('แต่ละ measure นิยามอย่างไร', 'ตารางนิยามและสูตรครบทุกตัว พร้อมจำนวนงานและรายชื่อ', 'd5'),
            ('มีงานไหนนิยาม measure ผิด', '14 งาน เช่น "AUC" จาก label เดียว (balanced accuracy), G-mean เป็น √(R·P), MAUC จาก hard label; citation ratio 0.33 (CI 0.14–0.74)', 'd5'),
            ('measure หลักของแต่ละงานคืออะไร', 'AUC 16, ไม่ระบุ 15, G-mean 7 และที่เหลือกระจาย', 'd5'),
            ('ยังมีงานรายงาน accuracy ไหม', '13 งาน: 21% ถึง 2009, 38% 2010–15, 10% 2016–20, 12% 2021–26 มักรายงานคู่กับ measure อื่น', 'd5'),
            ('measure สำหรับหลายคลาสมีอะไร', '10 ตัว ใช้ใน 21 งาน: per-class recall, macro-F1, AvAcc, weighted-F1, macro-precision, Pmin, CBA, CEN, macro-recall, min-sensitivity และ MAUC ในหมวด ranking', 'd5'),
            ('ทำไม PR-AUC ยังใช้น้อย', 'Saito 2015 มี 5,156 cites แต่ PR-AUC ยังราว 8–10% เพราะไม่มีเครื่องมือหรือข้อกำหนดที่ทำให้ต้องใช้ และค่าไม่เทียบกันข้าม IR', 'q6')]),
        ('protocol, tuning, test, การรายงาน', [
            ('แบ่งข้อมูลอย่างไร', 'repeated k-fold 33, single k-fold 16, hold-out 8, repeated hold-out 6, 5x2 4, fixed split 3, ไม่ระบุ 1; k = 10 (23), 5 (20)', 'd7'),
            ('resample เฉพาะข้อมูลฝึกไหม มีการรั่วไหม', 'ระบุ 34 ไม่ระบุ 36 รั่ว 1 (AB-SMOTE); MC-NCLWO normalize ก่อนแบ่ง', 'd7'),
            ('ใช้ DOB-SCV ไหม', 'ไม่มีงานใดใช้ แม้ review 15 ปีแนะนำ', 'd7'),
            ('เลือก hyperparameter อย่างไร', 'บนข้อมูลที่ใช้วัดผล 35 (25 ชัด + 10 นัย), ค่าตายตัว 20, nested 9, ไม่ชัด 7; เกณฑ์ G-mean 15 AUC 12 F1 8; G-SMOTE 294 config เทียบ SMOTE 2', 'd7'),
            ('ใช้ statistical test อะไร', 'มี test 52 งาน: Wilcoxon 26, Friedman 25, Holm 10, t-test 7; ปรับแก้หลายคู่ 27, รายคู่ไม่ปรับแก้ 19, Bayesian 3, ไม่มี 19', 'd8'),
            ('อ้างแหล่งวิธีวิทยาอะไร', 'Demšar 2006 19 งาน, Friedman 1937 6, García 2010 5; อ้างแหล่งวิธีวิทยา 25 งาน', 'd8'),
            ('มีงานไหนใช้ test ผิด', 'SOUP (Nemenyi หลัง Friedman ไม่มีนัยสำคัญ), MC-MBRC (Nemenyi ไม่มี omnibus), MC-NCLWO, G-SMOTE, CBHSID', 'd8'),
            ('รายงานผลด้วยตารางและกราฟอะไร', 'ตารางรายชุดข้อมูล 58, ตัวหนา 42, rank 38, p-value 32, mean ± SD 24, W/T/L 19, CD diagram 4', 'd9'),
            ('ควรมีตารางและกราฟอะไร', 'mean ± SD พร้อมแถว rank, W/T/L, Holm p; CD diagram ราย measure; heatmap ของ rank; scatter เทียบ baseline; ผลต่างเทียบ IR (ตัวอย่างจริงจากผลของเรา)', 'q3'),
            ('กี่งานแจก code รายงาน runtime', 'แจก code 27 (ตามช่วงปี ' + '/'.join(map(str, W['code_era'])) + '), รายงาน runtime 14', 'd9')]),
        ('หลักฐานนอกคะแนน เหตุของการเปลี่ยน และ citation', [
            ('มีงานไหนวัดข้อมูลหลัง resample โดยตรง', '6 งาน (SMOTE-IPF, SPE, CTGAN, GAMO, GLOS, CISO) และไม่มีงานใดใช้แทน classifier; รูป 2 มิติ 33, วิเคราะห์ 31', 'q2'),
            ('การวัดตรงเพิ่มขึ้นหลัง review 15 ปีไหม', 'เพิ่มเล็กน้อย: 5/36 งานตั้งแต่ 2019 เทียบกับ 1/35 ก่อนหน้า', 'd6'),
            ('ทำไมวิธีวัดผลจึงเปลี่ยน', 'เปลี่ยนเมื่อมีของที่ทำให้ทำได้ง่ายและถูกคาดหวัง: Demšar, KEEL, โจทย์หลายคลาส, scikit-learn/imbalanced-learn; งานดังอย่างเดียวไม่พอ', 'q6'),
            ('ตัวขับ T A S P L R N คืออะไร', 'T เครื่องมือ, A การรวมค่าเดี่ยวเข้า composite, S ขนาด benchmark, P โจทย์และข้อมูล, L สายงาน, R ความสมจริงและคำวิจารณ์, N ใช้ไม่เกิน 2 งาน', 'd10'),
            ('แต่ละแนวปฏิบัติเริ่มเมื่อไร งานแรกคืออะไร', 'roadmap 46 แนวปฏิบัติพร้อมจำนวนตามช่วงปี แนวโน้ม งานแรกและงานล่าสุด', 'd10'),
            ('แนวปฏิบัติไหนสัมพันธ์กับการถูกอ้างอิง', 'วัดตรง 2.30, แจก code 2.01, มี SMOTE เป็นคู่เทียบ 1.89 แต่ CI คร่อม 1; มีแค่ปัญหานิยาม measure (0.33) ที่ CI ไม่คร่อม 1', 'd10'),
            ('งานที่ถูกอ้างมากที่สุดวัดผลอย่างไร', '10 งานแรก: ค่ากลาง 8 ชุดข้อมูลจริง, มี test 4 งาน, 7 งานก่อน 2010', 'd10')]),
        ('ผลลัพธ์ มาตรฐาน และข้อแนะนำ', [
            ('มีงานที่วิธีใหม่ไม่ชนะไหม', '68 จาก 69 งานที่เสนอวิธีสรุปว่าดีสุด; มีแค่ CISO 2025 ที่รายงานว่าไม่ดีกว่า class weighting ROS หรือ None', 'd11'),
            ('วิธีที่ชนะยังชนะในงานต่อมาไหม', 'ไม่สะสม: MDO เป็นคู่เทียบใน 13 งานต่อมา MC-CCR ใน 7 และทุกงานใหม่ชนะ', 'd11'),
            ('กี่งานผ่านมาตรฐาน 7 ข้อ', 'ครบ 7 ข้อมีแค่ RBO 2019; 6 ข้อ 4 งาน; ข้อที่ผ่านน้อยสุดคือแจก code (27), ไม่เลือกค่าบนข้อมูลที่ใช้วัดผล (29) และ test ที่ปรับแก้หรือ Bayesian (30)', 'd11'),
            ('งานใหม่ควรวัดผลอย่างไร', 'ข้อแนะนำ 10 หัวข้อ พร้อมสิ่งที่ต้องรายงานและ checklist', 'd12')]),
        ('ผลทดลองของเรา', [
            ('ในผลทดลองของเรา วิธีไหนชนะ', 'G-mean: SMOTE (rank 2.31 แบบรวม); F1: QC-SMOTE 2.66 และ CISO 2.67; PR-AUC: None 2.60 · ผู้ชนะขึ้นกับ measure', 'd13'),
            ('แยกวิธีได้อย่างมีนัยสำคัญไหม', 'CD = ' + f"{X['CD']:.2f}" + ' สำหรับ 5 วิธี 110 ชุด; ตาม G-mean CD แยก SMOTE จาก MWMOTE ไม่ได้ใน 4 จาก 5 classifier (แยกได้แค่ RF) แต่ Wilcoxon-Holm แยกได้ใน SVM, k-NN และ RF', 'd13'),
            ('SMOTE ดีกว่าไม่ resample จริงไหม', 'ขึ้นกับ measure: ชนะ None ' + str(sv['Gmean']['win']) + '/550 ด้วย G-mean, ' + str(sv['F1']['win']) + ' ด้วย F1, ' + str(sv['AUC']['win']) + ' ด้วย AUC, ' + str(sv['PR_AUC']['win']) + ' ด้วย PR-AUC', 'd13'),
            ('G-mean กับ F1 เลือกผู้ชนะตรงกันไหม', 'ตรงกัน ' + str(X['best_agree']['same']) + '/' + str(X['best_agree']['n']) + ' กรณี แม้ Spearman ของค่าจะ 0.94', 'd13'),
            ('ผลแปรตาม IR ไหม', 'gain ของ SMOTE ตาม G-mean สัมพันธ์กับ IR (ρ = 0.35) แต่ตาม PR-AUC ไม่สัมพันธ์ (ρ = 0.02)', 'd13'),
            ('ทำไมไม่ควรจัด rank บน dataset × classifier รวมกัน', 'block ไม่อิสระ (ชุดข้อมูลเดียวซ้ำ 5 ครั้ง) และผู้ชนะของ F1 กับ PR-AUC เปลี่ยน ควรจัด rank ต่อ classifier หรือเฉลี่ย classifier ก่อน', 'd13'),
            ('ผลต่างข้าม fold ใหญ่แค่ไหน', 'SD ข้าม fold ค่ากลาง AUC 0.039, PR-AUC 0.077, F1 0.075, G-mean 0.070 มากกว่าผลต่างของค่าเฉลี่ยระหว่าง 4 วิธี resample (ค่ากลาง 0.016 มากสุด 0.052)', 'd13')]),
        ('ค้นงานรายเรื่อง และงานอื่น', [
            ('งานเรื่อง X วัดผลอย่างไร', 'ตารางกรองและเรียงได้ทั้ง 71 งาน กดแถวเพื่อดูรหัสครบ', 'd14'),
            ('review 15 ปีรายงานเรื่องการวัดผลอะไร', 'เล่าที่มา (accuracy 97% เทียบ 97.68%), สรุปงานเปรียบเทียบ, ความท้าทาย, แนะนำ DOB-SCV; ไม่วิเคราะห์ measure protocol หรือ test', 'd15'),
            ('ตัวเลขตรงกับส่วน Method และ Data ไหม', 'ใช้รายชื่อเดียวกัน ตระกูล SMOTE 37 ตรงกับ Method; ตัวเลขของ Data ยังเป็น ai_draft จึงไม่อ้างใน manuscript', 'd16')])]
    h = '<section class="s" id="qi"><h2><span class="n">?</span><span>ดัชนีคำถาม <span class="en">Question index</span></span></h2><p>คำถามเกี่ยวกับการวัดผลที่เคยถามและวิเคราะห์มาทั้งหมด พร้อมคำตอบสั้น กดเพื่อไปยังหัวข้อที่มีหลักฐานครบ</p>'
    for g, qs in G:
        h += '<h3>' + g + '</h3><div class="qi">' + ''.join('<a href="#' + a + '"><span class="q">' + q + '</span><span class="a">' + t + '</span><span class="go">' + a.upper() + '</span></a>' for q, t, a in qs) + '</div>'
    TOC.insert(0, ('qi', '?', 'ดัชนีคำถาม'))
    return h + '</section>', sum(len(q) for _, q in G)


CSS_DB = r"""
.qi{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:8px;margin:.4em 0 1.2em}
.qi a{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:2px 10px;padding:10px 12px;border:1px solid var(--rule);border-radius:10px;background:var(--paper);color:inherit;text-decoration:none}
.qi a:hover{border-color:var(--accent)}
.qi .q{font-weight:600;font-size:14.5px;grid-column:1}
.qi .go{grid-column:2;grid-row:1;font-size:11px;color:var(--muted);font-variant-numeric:tabular-nums}
.qi .a{grid-column:1/3;font-size:13.5px;color:var(--ink-2);line-height:1.5}
.asks{border-left:3px solid var(--accent);background:var(--tint,rgba(127,127,127,.06));padding:8px 12px;border-radius:0 8px 8px 0;margin:.2em 0 1.2em;font-size:14px}
.asks ul{margin:.3em 0 0;padding-left:1.2em}
.asks li{margin:.15em 0}
.qblock{border-top:1px dashed var(--rule);margin-top:1.2em;padding-top:.6em;display:grid;gap:14px;min-width:0}
.qblock > h3.qh{margin:0}
.gtopic,.asks,.mapctl,.qi{min-width:0}
.gtopic{display:grid;gap:12px}
h3.qh{font-size:18px;display:flex;gap:8px;align-items:baseline;flex-wrap:wrap}
.qtag{font-size:12px;font-weight:600;color:#fff;background:var(--accent);border-radius:6px;padding:1px 7px}
.gtopic{border:1px solid var(--rule);border-radius:12px;padding:4px 16px 12px;margin:1.2em 0;background:var(--paper)}
.gtopic h2{font-size:18px}
table.compact td,table.compact th{padding:4px 6px;font-size:12.5px}
.mapctl{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin:.4em 0 .8em}
.mapctl input,.mapctl select{font:inherit;font-size:13.5px;padding:6px 8px;border:1px solid var(--rule);border-radius:8px;background:var(--paper);color:var(--ink);max-width:100%}
.mapctl input{flex:1 1 220px}
table.map2{font-size:12.5px}
table.map2 th{cursor:pointer;white-space:nowrap;user-select:none}
table.map2 th.sorted::after{content:" ↕";color:var(--accent)}
table.map2 tr.mr{cursor:pointer}
table.map2 tr.mr:hover td{background:rgba(127,127,127,.07)}
table.map2 td{max-width:240px}
dl.mdl{display:grid;grid-template-columns:200px minmax(0,1fr);gap:3px 12px;margin:4px 0;font-size:12.5px}
dl.mdl dt{color:var(--muted)}
dl.mdl dd{margin:0;overflow-wrap:anywhere}
@media (max-width:640px){.qi{grid-template-columns:minmax(0,1fr)}dl.mdl{grid-template-columns:minmax(0,1fr)}dl.mdl dd{margin-bottom:4px}h3.qh{font-size:16.5px}}
"""


def build():
    for f in (d0, d1, d2, d3, d4, d5, d6, d7, d8, d9, d10, d11, d12, d13, d14, d15, d16):
        f()
    qh, nq = qindex()
    css = open(R + 'guide/primer_style.css').read() + open(R + 'evalpage/extra.css').read() + GUIDE_CSS + CSS_DB
    js = open(R + 'evalpage/page.js').read()
    data = dict(meth=BE.METH, meas=BE.MEAS, CD=X['CD'], per={k: {kk: v[kk] for kk in ('ar', 'pF', 'FF', 'holm', 'mean')} for k, v in X['per'].items()}, vals=X['vals'])
    dj = json.dumps(data, separators=(',', ':')).replace('</', '<\\/')
    mj = json.dumps(map_rows(), ensure_ascii=False, separators=(',', ':')).replace('</', '<\\/')
    fj = json.dumps(MAPFIELDS, ensure_ascii=False, separators=(',', ':'))
    page = ('<title>SMOTE25 Evaluation Data Book</title>\n<meta name="claude:viewport-fit-sides" content="cover">\n'
            '<link rel="preconnect" href="https://fonts.googleapis.com">\n<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>\n'
            '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500&family=IBM+Plex+Sans+Thai:wght@400;500;600;700&family=Noto+Serif+Thai:wght@400;600&family=STIX+Two+Text:ital,wght@0,400;0,600;1,400&display=swap">\n'
            '<style>\n' + css + '</style>\n'
            '<div class="wrap"><header class="top"><div class="eyebrow">SMOTE25 · หัวข้อที่ 7 Evaluation · Data book · 8 พ.ย. 2026</div>'
            '<h1>ข้อมูลการวัดผลทั้งหมดที่วิเคราะห์มา: งานตระกูล SMOTE 71 เรื่อง และผลทดลองของเรา</h1>'
            '<p class="lede">หน้านี้รวมทุกตัวเลข ตาราง และเหตุผลที่วิเคราะห์ไว้สำหรับส่วน Evaluation โดยไม่ตัดออก เรียงตามโครงหัวข้อที่ร่างไว้ (D0–D16) '
            'เริ่มจากดัชนีคำถาม ' + str(nq) + ' ข้อที่เคยถาม แต่ละข้อมีคำตอบสั้นและลิงก์ไปยังหลักฐาน ทุกหัวข้อขึ้นต้นด้วยคำถามที่หัวข้อนั้นตอบ เป็นหน้าข้อมูล ไม่ใช่ข้อความของ paper</p></header>'
            '<div class="layout"><nav class="toc" aria-label="สารบัญ"><details id="tocd" open><summary>สารบัญ</summary><ol>' +
            ''.join('<li><a href="#' + a + '"><span>' + n + '</span><span>' + t + '</span></a></li>' for a, n, t in TOC) +
            '</ol></details></nav><main class="sheet">' + qh + '\n'.join(SECS) +
            '<div class="foot"><span>ข้อมูลที่ลงรหัสของหัวข้อที่ 7 (76 เรื่อง มีการทดลอง 71; รหัสรอบ 2 มีเลขหน้า) · ยอดอ้างอิงจาก OpenAlex ณ 18 ต.ค. 2026 · ตระกูล SMOTE 37 เรื่องจากส่วน Method (commit ea1eaa8) · ผลทดลองของเรา 31 ส.ค. 2026</span>'
            '<span>สร้างจาก databook/build_databook.py ซึ่งใช้ evalpage/, guide/ และ v2/analysis.json · ใช้คู่กับหน้า Evaluation ของ Tan, Guide และ Section 7 v4</span></div>'
            '</main></div></div>\n<script type="application/json" id="evdata">' + dj + '</script>\n'
            '<script type="application/json" id="mapdata">' + mj + '</script>\n<script type="application/json" id="mapfields">' + fj + '</script>\n'
            '<script>\n(function(){var d=document.getElementById("tocd");if(d&&window.matchMedia("(max-width:900px)").matches)d.open=false;})();\n' + js + '\n' + MAPJS + '</script>\n')
    assert '—' not in page, 'em-dash'
    open(OUT + 'smote25_evaluation_databook.html', 'w').write(page)
    i = page.index('</style>\n') + len('</style>\n')
    doc = ('<!doctype html>\n<html lang="th">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n'
           + page[:i] + '</head>\n<body>\n' + page[i:] + '\n</body>\n</html>\n')
    open(OUT + 'section07-evaluation-databook.html', 'w').write(doc)
    print('page bytes', len(page.encode()), 'sections', len(SECS), 'questions', nq)


if __name__ == '__main__':
    build()
