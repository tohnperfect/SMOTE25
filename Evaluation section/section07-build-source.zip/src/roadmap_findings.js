/* ---------------- your four questions, the answers, and why ----------------
   Thai-first explainer. Every block says what we looked at, what we found and what it means.
   Inline labels: ib() shows Thai as the main text and English as a small line (both mode). */
const F = D.F;
const fmt1 = x => x == null ? 'n/a' : (Math.round(x * 10) / 10).toString();
const pctOf = (a, b) => b ? Math.round(100 * a / b) : 0;
const ib = (en, th) => '<span class="xt">' + esc(th) + '</span><span class="xe' + (th === en ? ' xsame' : '') + '">' + esc(en) + '</span>';
const ibh = (en, th) => '<span class="xt">' + th + '</span><span class="xe">' + en + '</span>';
const tp = (en, th) => '<div class="pair tf"><p class="th">' + th + '</p><p class="en">' + en + '</p></div>';
const ofN = (a, b, pc) => ib(a + ' of ' + b + (pc ? ' (' + pctOf(a, b) + '%)' : ''), a + ' จาก ' + b + (pc ? ' (' + pctOf(a, b) + '%)' : ''));
const infRow = k => F.cites.influence.find(r => r.key === k);
const quoteHTML = e => e && e.quote ? '<blockquote class="qt">“' + esc(e.quote) + '”<cite>' + esc(e.short || '') + (e.where ? ' · ' + esc(e.where) : '') + '</cite></blockquote>' : '';
const qcard = (e, th, label) => '<div class="qc">' + (label ? '<span class="qk">' + label + '</span>' : '') + (th ? '<p class="qp"><span class="xt">' + esc(th) + '</span></p>' : '') + quoteHTML(e) + '</div>';
const exBox = (en, th, inner) => '<details class="ex"><summary>' + ib(en, th) + '</summary><div class="exb">' + inner + '</div></details>';

const TR = {'evaluation data': 'ข้อมูลที่ใช้รายงานผล', 'not stated': 'ไม่บอก', 'inner validation (training data only)': 'ข้อมูลตรวจสอบในข้อมูลฝึก', 'other': 'อื่น ๆ',
  'sampling rate': 'อัตราการสุ่ม', 'method parameters': 'พารามิเตอร์ของวิธี', 'classifier hyperparameters': 'hyperparameter ของ classifier', 'best variant': 'รุ่นที่ดีที่สุดของวิธี', 'none (fixed settings)': 'ไม่เลือก (ใช้ค่าคงที่)'};
const trList = v => { const parts = String(v || '').split(/,\s*/); return ib(parts.join(', '), parts.map(x => TR[x] || x).join(', ')); };
const LBL = {look: ['What we looked at', 'เราดูอะไร'], found: ['What we found', 'เจออะไร'], means: ['So', 'จึงสรุปว่า'], care: ['Be careful', 'ข้อควรระวัง']};
function why(n, en, th, rows, extra) {
  return '<div class="why"><div class="whyn">' + n + '</div><div class="whyb"><h4 class="wt">' + ibh(esc(en), esc(th)) + '</h4><dl class="how">' +
    rows.map(r => '<dt class="k-' + r.k + '">' + ib(LBL[r.k][0], LBL[r.k][1]) + '</dt><dd>' + (r.en != null ? tp(r.en, r.th) : '') + (r.html || '') + '</dd>').join('') +
    '</dl>' + (extra || '') + '</div></div>';
}
function qHead(n, id, qEn, qTh, aEn, aTh, sEn, sTh) {
  return '<section class="panel qa" id="' + id + '"><div class="qtop"><span class="qn">' + ib('Your question ' + n, 'คำถามที่ ' + n) + '</span><h2 class="qq">' + ibh(esc(qEn), esc(qTh)) + '</h2></div>' +
    '<div class="ans"><div class="ansl">' + ib('Short answer', 'คำตอบสั้น ๆ') + '</div><div class="ansb">' + ibh(esc(aEn), esc(aTh)) + '</div>' + tp(sEn, sTh) + '</div>' +
    '<h3 class="whyh">' + ib('Why the answer comes out this way', 'ทำไมถึงได้คำตอบแบบนี้') + '</h3>';
}

/* ---------- small charts ---------- */
function bars(items, max) {
  max = max || Math.max.apply(null, items.map(i => i.n)) || 1;
  return '<div class="bars">' + items.map(i => '<div class="bar" title="' + esc(i.en + ': ' + i.n + (i.of ? ' of ' + i.of : '')) + '"><span class="bl">' + ib(i.en, i.th) + '</span><span class="bt"><i style="width:' + (100 * i.n / (i.of || max)).toFixed(1) + '%;background:var(' + (i.c || '--c1') + ')"></i></span><span class="bv">' + (i.v || (i.n + (i.of ? '<em>/' + i.of + '</em>' : ''))) + '</span></div>').join('') + '</div>';
}
function tiles(items) {
  return '<div class="tiles">' + items.map(t => '<div class="tile' + (t.hl ? ' hl' : '') + '"><b>' + t.v + '</b><span>' + ib(t.en, t.th) + '</span></div>').join('') + '</div>';
}
function table(head, rows, cls) {
  return '<div class="scroll"><table class="cmp ' + (cls || '') + '"><thead><tr>' + head.map(h => '<th' + (h[2] ? ' class="r"' : '') + '>' + ib(h[0], h[1]) + '</th>').join('') + '</tr></thead><tbody>' +
    rows.map(r => '<tr>' + r.map((v, i) => '<td' + (head[i] && head[i][2] ? ' class="r"' : '') + '>' + v + '</td>').join('') + '</tr>').join('') + '</tbody></table></div>';
}
const LX = v => (Math.log(Math.min(10, Math.max(0.1, v))) - Math.log(0.1)) / Math.log(100) * 100;
const VERD = {low: ['whole range below ×1: really cited less', 'ต่ำกว่า ×1 ทั้งช่วง: ถูกอ้างอิงน้อยกว่าจริง', '--c2'],
  high: ['whole range above ×1: really cited more', 'สูงกว่า ×1 ทั้งช่วง: ถูกอ้างอิงมากกว่าจริง', '--c1'],
  near: ['range just touches ×1: not yet conclusive', 'ช่วงแตะ ×1 พอดี: ยังสรุปไม่ได้', '--c1'],
  none: ['range crosses ×1: no difference we can detect', 'ช่วงคร่อม ×1: ไม่พบความต่าง', '--c3']};
const verdOf = r => r.hi < 1 ? 'low' : r.lo > 1 ? 'high' : (r.lo >= 0.95 || r.hi <= 1.05) ? 'near' : 'none';
function ruler(items) {
  let h = '<div class="ruler"><div class="rl rlh"><span></span><span class="rlk">' + [0.25, 0.5, 1, 2, 4].map(t => '<b style="left:' + LX(t) + '%">×' + t + '</b>').join('') + '</span><span></span></div>';
  items.forEach(it => {
    if (it.group) { h += '<div class="rlg">' + ib(it.group[0], it.group[1]) + '</div>'; return; }
    const r = it.r, v = verdOf(r), c = VERD[v][2];
    const tip = (it.en || r.en) + ': ×' + r.ratio.toFixed(2) + ' (range ' + r.lo.toFixed(2) + ' to ' + r.hi.toFixed(2) + '); median citations per year ' + fmt1(r.med_cpy_users) + ' with the practice vs ' + fmt1(r.med_cpy_other) + ' without';
    h += '<div class="rl" title="' + esc(tip) + '"><span class="rll">' + ib(it.en || r.en, it.th || r.th) + '<em>' + ib(r.n_users + ' of ' + r.n + ' studies', r.n_users + ' จาก ' + r.n + ' เรื่อง') + '</em></span>' +
      '<span class="rlk"><i class="one"></i><i class="ci" style="left:' + LX(r.lo) + '%;width:' + (LX(r.hi) - LX(r.lo)).toFixed(1) + '%;background:var(' + c + ')"></i><i class="pt" style="left:' + LX(r.ratio) + '%;background:var(' + c + ')"></i></span>' +
      '<span class="rlv"><b>×' + r.ratio.toFixed(2) + '</b> <small>' + ib('range ' + r.lo.toFixed(2) + '–' + r.hi.toFixed(2), 'ช่วง ' + r.lo.toFixed(2) + '–' + r.hi.toFixed(2)) + '</small><span class="vchip v-' + v + '">' + ib(VERD[v][0], VERD[v][1]) + '</span></span></div>';
  });
  return h + '</div>';
}
function scatter(pts, line, hl) {
  const w = 640, h = 280, L = 52, R = 14, T = 12, B = 34, x0 = 1996, x1 = 2025, y1 = Math.log10(40000);
  const X = y => L + (w - L - R) * (y - x0) / (x1 - x0), Y = c => T + (h - T - B) * (1 - Math.log10(1 + c) / y1);
  const ly = yr => Math.expm1(line[0] + line[1] * yr);
  let s = '<div class="scroll"><svg viewBox="0 0 ' + w + ' ' + h + '" class="sc" role="img" aria-label="Citations of 62 studies against publication year, log scale, with the age trend">';
  [1, 10, 100, 1000, 10000].forEach(v => { s += '<line x1="' + L + '" x2="' + (w - R) + '" y1="' + Y(v) + '" y2="' + Y(v) + '" style="stroke:var(--grid)" /><text x="' + (L - 6) + '" y="' + (Y(v) + 4) + '" text-anchor="end" font-size="11" style="fill:var(--muted)">' + big(v) + '</text>'; });
  [2000, 2005, 2010, 2015, 2020, 2024].forEach(v => { s += '<text x="' + X(v) + '" y="' + (h - 12) + '" text-anchor="middle" font-size="11" style="fill:var(--muted)">' + v + '</text>'; });
  s += '<line x1="' + X(1997) + '" y1="' + Y(ly(1997)) + '" x2="' + X(2024) + '" y2="' + Y(ly(2024)) + '" stroke-width="2" stroke-dasharray="5 4" style="stroke:var(--ink-2)" />';
  pts.filter(p => hl.indexOf(p.key) >= 0).forEach(p => { s += '<line x1="' + X(p.year) + '" x2="' + X(p.year) + '" y1="' + Y(ly(p.year)) + '" y2="' + Y(p.cites) + '" stroke-width="1.5" stroke-dasharray="2 2" style="stroke:var(--ink-2)" />'; });
  pts.slice().sort((a, b) => a.issue - b.issue).forEach(p => {
    const c = p.issue ? '--c2' : '--c1', on = hl.indexOf(p.key) >= 0;
    s += '<circle cx="' + X(p.year) + '" cy="' + Y(p.cites) + '" r="' + (on ? 6.5 : p.issue ? 5.5 : 4.5) + '" stroke-width="2" style="fill:var(' + c + ');stroke:var(' + (on ? '--ink' : '--paper') + ')"><title>' + esc(p.short + ' ' + p.year + ': ' + big(p.cites) + ' citations' + (p.issue ? ' (measure defined incorrectly)' : '')) + '</title></circle>';
  });
  pts.filter(p => hl.indexOf(p.key) >= 0 || p.key === 'SMOTE-2002').forEach(p => {
    const rt = p.year >= 2015, xo = rt ? -10 : 10;
    s += '<text x="' + (X(p.year) + xo) + '" y="' + (Y(p.cites) + 4) + '" font-size="12" font-weight="600"' + (rt ? ' text-anchor="end"' : '') + ' style="fill:var(--ink);paint-order:stroke;stroke:var(--paper);stroke-width:3px">' + esc(p.short) + '</text>';
  });
  return s + '</svg></div>';
}
const legendSc = '<div class="legend"><span><i style="background:var(--c1)"></i>' + ib('one study', 'หนึ่งเรื่อง') + '</span><span><i style="background:var(--c2)"></i>' + ib('defines a measure incorrectly', 'นิยาม metric ผิด') + '</span><span><i class="dash"></i>' + ib('expected count for its year', 'ยอดที่คาดไว้ตามปีที่ตีพิมพ์') + '</span></div>';

/* ---------- plain-language maps ---------- */
const TEST = {'None': ['none', 'ไม่มี'], 'Corrected multiple comparison': ['yes, corrected', 'มี (แบบปรับแก้)'], 'Pairwise only (uncorrected)': ['yes, pairwise only', 'มี (เทียบรายคู่ ไม่ปรับแก้)']};
const ISSUE_TH = {
  'SCUT-2015': ['does not say how G-mean, F-measure and AUC are averaged over several classes', 'ไม่บอกว่าเฉลี่ย G-mean, F-measure และ AUC ข้ามหลายคลาสอย่างไร'],
  'CGMOS-2016': ['calls sqrt(Precision × Recall) "G-score" and reports it with each class as positive', 'เรียก sqrt(Precision × Recall) ว่า "G-score" และรายงานโดยให้แต่ละคลาสเป็นคลาสบวก'],
  'AMDO-2018': ['describes Pavg as precision but computes average accuracy', 'บอกว่า Pavg คือ precision แต่คำนวณเป็น average accuracy'],
  'SPE-2020': ['defines G-mean as sqrt(Recall × Precision) instead of sqrt(TPR × TNR)', 'นิยาม G-mean เป็น sqrt(Recall × Precision) แทนที่จะเป็น sqrt(TPR × TNR)'],
  'DLexiBoost-2020': ['calls (1 + TPR − FPR)/2 from hard predictions "AUC"; it is balanced accuracy', 'เรียกค่า (1 + TPR − FPR)/2 จากผลทำนายแบบตัดสินแล้วว่า "AUC" ซึ่งจริง ๆ คือ balanced accuracy'],
  'EMDO-2021': ['calls per-class precision "accuracy"', 'เรียก precision ของแต่ละคลาสว่า "accuracy"'],
  'GDO-2022': ['defines "AUC" as (Sens + Spec)/2, which is balanced accuracy at one threshold', 'นิยาม "AUC" เป็น (Sens + Spec)/2 ซึ่งคือ balanced accuracy ที่ค่าเกณฑ์เดียว'],
  'CBHSID-2022': ['does not say how Recall and F1 are averaged over classes; F1 defined incorrectly', 'ไม่บอกวิธีเฉลี่ย Recall และ F1 ข้ามคลาส และนิยาม F1 ผิด'],
  'SOS-2022': ['uses weighted F1, which the majority class dominates, as the only main measure', 'ใช้ weighted F1 ซึ่งถูกคลาสส่วนมากครอบงำ เป็นตัวชี้วัดหลักตัวเดียว'],
  'SHSampler-2022': ['computes MAUC from hard-label confusion matrices instead of scores', 'คำนวณ MAUC จาก confusion matrix ของผลทำนายแบบตัดสินแล้ว แทนที่จะใช้คะแนน'],
  'MC-MBRC-2024': ['defines AvAcc as mean one-vs-rest accuracy, which true negatives inflate', 'นิยาม AvAcc เป็นค่าเฉลี่ย accuracy แบบ one-vs-rest ซึ่งพองขึ้นเพราะ true negative']};
const DREASON = {varied_characteristics: ['a range of imbalance ratios, sizes or dimensions', 'ให้ครอบคลุม IR ขนาด และจำนวนมิติที่ต่างกัน'], imbalance_level: ['a target level of imbalance', 'ได้ระดับความไม่สมดุลที่ต้องการ'],
  follows_prior_work: ['the same set-up as a named earlier study', 'ใช้ตามการทดลองของ paper ก่อนหน้า'], difficulty_factors: ['overlap, noise or small disjuncts', 'มีการซ้อนทับ noise หรือกลุ่มย่อยเล็ก ๆ'],
  comparability: ['to compare with published results', 'เพื่อเทียบกับผลที่ตีพิมพ์แล้ว'], public_benchmark: ['publicly available', 'เพราะโหลดได้สาธารณะ'],
  application_domain: ['an application domain', 'เป็นโจทย์ของงานประยุกต์'], multiclass_availability: ['many classes', 'มีหลายคลาส']};
const DREASON_EX = {varied_characteristics: 'ชุดข้อมูลต่างกันทั้งขนาด จำนวนฟีเจอร์ และระดับความไม่สมดุล จึงประเมินได้น่าเชื่อถือ', imbalance_level: 'สุ่มตัดข้อมูลเพิ่ม เพื่อทดสอบกรณีที่ไม่สมดุลรุนแรงขึ้น',
  follows_prior_work: 'ใช้ชุดข้อมูลสองคลาสชุดเดียวกับงาน [37]', difficulty_factors: 'เลือกเฉพาะชุดที่ IR มากกว่า 10 และซ้อนทับกันมากกว่า 30%', comparability: 'ชุดจาก KEEL ที่ถูกใช้ในการประเมินของงานล่าสุดหลายเรื่อง',
  public_benchmark: 'ใช้ข้อมูลจาก UCI เพื่อให้นักวิจัยคนอื่นทำซ้ำและตรวจผลได้', application_domain: 'งานประยุกต์ตรวจจับคราบน้ำมันจากภาพเรดาร์', multiclass_availability: 'ภาพ hyperspectral เป็นงานที่ความไม่สมดุลหลายคลาสเกิดขึ้นเองตามธรรมชาติ'};
const LREASON = {popular: ['widely used or well known', 'นิยมใช้หรือเป็นที่รู้จัก'], diverse_paradigms: ['covers different kinds of learner', 'ครอบคลุม classifier หลายแบบ'],
  follows_prior_work: ['same learners as a named earlier study', 'ใช้ตาม paper ก่อนหน้า'], simplicity: ['simple, fast or interpretable', 'เรียบง่าย เร็ว หรือตีความได้'],
  fair_comparison: ['same learner for every method, for fairness', 'ใช้ตัวเดียวกันทุกวิธีเพื่อความยุติธรรม'], matches_mechanism: ['fits how the method works', 'เข้ากับกลไกของวิธี'], sensitive_to_imbalance: ['sensitive to class imbalance', 'ไวต่อความไม่สมดุลของคลาส']};
const LQ_TH = {'OSS-1997': 'เลือก 1-NN และ C4.5 เพราะใช้กันแพร่หลายและรู้สมรรถนะดี', 'MWMOTE-2014': 'ใช้หลาย classifier เพื่อดูว่าผลดีหรือไม่ดีไม่ขึ้นกับ classifier ที่เลือก', 'NROMM-2023': 'ใช้ classifier, CV และตัวชี้วัดเดียวกับ MC-CCR และ MC-RBO',
  'SPIDER2-2010': 'MODLEM และ C4.5 เคยถูกใช้ในงานก่อน และแสดงว่าไวต่อความไม่สมดุล', 'SMOTE-IPF-2015': 'C4.5 ไวต่อปัจจัยของข้อมูลไม่สมดุลมากกว่า SVM', 'GDHS-2025': 'ต้นไม้ตัดสินใจไวต่อความไม่สมดุลมากที่สุดในบรรดา classifier ที่ใช้กันทั่วไป (อ้าง Sáez et al.)',
  'MC-NCLWO-2025': 'k-NN ไวต่อความไม่สมดุลและการกระจายของข้อมูลเฉพาะที่ จึงเหมาะใช้ทดสอบวิธี oversampling'};
const CHAIN_TH = {'MC-RBO-2020': 'เลือกชุดข้อมูลตามงานก่อนหน้าของผู้เขียนเอง เรื่องความยากระดับตัวอย่างในข้อมูลหลายคลาส', 'MC-CCR-2020': 'เลือกตามงานของ Sáez et al. ที่แสดงว่าชุดเหล่านี้มีความยากหลายแบบ',
  'NROMM-2023': 'ใช้ 20 ชุดเดียวกันจาก KEEL ตามงาน [8, 13] ซึ่งคือ MC-CCR และ MC-RBO', 'EMDO-2021': 'ใช้ชุดข้อมูลเดียวกับงาน [43] ซึ่งคือ AMDO (ในการทดลองแรก)', 'SMOTE-IPF-2015': 'เลือกชุดข้อมูลจริงตามงาน [40] เรื่องตัวอย่าง noise และ borderline ซึ่งคือ SPIDER2',
  'GMMSampling-2024': 'ใช้ชุดจริง 11 ชุดและชุดจำลอง 4 ชุดที่งานที่เกี่ยวข้องใช้กัน', 'QC-SMOTE-2026': 'ใช้ benchmark เดียวกับ VS-SMOTE เพื่อเทียบกับผลที่ตีพิมพ์ได้ตรง ๆ'};
const CHAIN_SRC_TH = {0: 'Sáez, Krawczyk และ Woźniak 2016 (งานศึกษาความยากของข้อมูล ไม่อยู่ในคลังบทความ)', 1: 'AMDO 2018', 2: 'SPIDER2 2010 (Napierała, Stefanowski และ Wilk)', 3: 'Lango และ Stefanowski 2018; Janicka et al. 2019 (ไม่อยู่ในคลังบทความ)', 4: 'benchmark ของ VS-SMOTE (Qiu et al. 2025 ไม่อยู่ในคลังบทความ)'};
const DIRECT = {
  'SMOTE-IPF-2015': ['Counts what share of the points SMOTE created a noise filter then deletes.', 'นับว่าตัวอย่างที่ SMOTE สังเคราะห์ ถูกตัวกรอง noise ลบทิ้งไปกี่เปอร์เซ็นต์'],
  'CTGAN-2019': ['On simulated data whose true distribution is known, measures how likely the synthetic rows are under that distribution.', 'สร้างข้อมูลจำลองที่รู้การแจกแจงจริง แล้ววัดว่าแถวที่สังเคราะห์เข้ากับการแจกแจงจริงแค่ไหน (likelihood)'],
  'GAMO-2019': ['Reports FID, a distance between real and generated images (lower is closer).', 'วัด FID ซึ่งเป็นระยะห่างระหว่างภาพจริงกับภาพที่สร้าง (ยิ่งต่ำยิ่งเหมือน)'],
  'SPE-2020': ['Counts easy and hard majority examples left after under-sampling.', 'นับว่าคลาสส่วนมากที่เหลือหลังสุ่มตัด มีตัวอย่างง่ายและยากอย่างละเท่าไร'],
  'GLOS-2023': ['Counts safe, borderline and small-disjunct examples as a parameter changes.', 'นับจำนวนตัวอย่างแบบ safe, borderline และกลุ่มย่อยเล็ก เมื่อเปลี่ยนค่าพารามิเตอร์'],
  'CISO-2025': ['Measures MMD between synthetic points and held-out minority points, and trains a classifier to tell real from synthetic; this result goes against CISO itself.', 'วัด MMD ระหว่างตัวอย่างสังเคราะห์กับคลาสส่วนน้อยที่กันไว้ และใช้ classifier แยกของจริงกับของสังเคราะห์ ผลส่วนนี้ไม่เป็นผลดีต่อ CISO เอง']};
const MODEL_TH = {'SMOTE 2002': ['compares C4.5 tree sizes', 'เทียบขนาดต้นไม้ C4.5'], 'Batista et al. 2004': ['compares the number of rules', 'เทียบจำนวนกฎที่ได้'], 'Random Balance 2015': ['ensemble diversity diagrams', 'แผนภาพความหลากหลายของสมาชิก ensemble'],
  'SOUP 2019': ['compares tree node counts', 'เทียบจำนวนโหนดของต้นไม้'], 'OREM 2023': ['ensemble diversity (Q-statistic)', 'ความหลากหลายของ ensemble (Q-statistic)']};
const REPO_TH = l => l.replace('(method in corpus)', '(วิธีในคลังบทความ)').replace('UCI repository (Asuncion and Newman 2007 record)', 'คลังข้อมูล UCI (Asuncion และ Newman 2007)')
  .replace('KEEL data-set repository', 'คลังชุดข้อมูล KEEL').replace('KEEL software paper', 'บทความซอฟต์แวร์ KEEL').replace('imbalanced-learn (Lemaître et al. 2017, preprint record)', 'ไลบรารี imbalanced-learn (Lemaître et al. 2017)');

/* ================= question 1: citations ================= */
function q1() {
  const f = F.cites, tp_ = f.top_profile, rp = f.rest_profile, line = f.line;
  const exp = y => Math.expm1(line[0] + line[1] * y);
  const P = k => f.points.find(p => p.key === k);
  const ex = ['ADASYN-2008', 'SPE-2020', 'SHSampler-2022'].map(P);
  const mi = infRow('metric_issue'), cd = infRow('code'), sb = infRow('smote_base'), at = infRow('anytest');
  let h = qHead(1, 'q1', 'Were studies that evaluated in a particular way more successful, that is, more cited?', 'paper ที่ใช้วิธีประเมินผลแต่ละแบบ ประสบความสำเร็จ (ถูกอ้างอิงเยอะ) ไหม',
    'No. How a study was evaluated is not linked to its citations.', 'ไม่สัมพันธ์กันเลย',
    'Citations follow a paper\'s age and whether later work uses the method as a baseline. The one clear signal is negative: studies that define a measure incorrectly are cited about a third as often.',
    'จำนวนการอ้างอิงขึ้นกับอายุของ paper และการที่งานรุ่นหลังเอาวิธีนั้นไปเป็นคู่เทียบ ไม่ได้ขึ้นกับว่าประเมินผลละเอียดแค่ไหน สัญญาณเดียวที่ชัดเป็นทางลบ คือ paper ที่นิยาม metric ผิดถูกอ้างอิงประมาณหนึ่งในสามของเรื่องอื่น');
  h += '<p class="src">' + ib('Citation counts: OpenAlex, retrieved ' + f.retrieved + '. Studies analysed: the ' + f.eligible + ' empirical studies published up to 2024 (the ' + f.young + ' from 2025 and 2026 are too new; Global-CS 2006 has no record).',
    'ยอดอ้างอิงจาก OpenAlex ดึงวันที่ ' + f.retrieved + ' ใช้ ' + f.eligible + ' เรื่องที่มีการทดลองและตีพิมพ์ถึงปี 2024 (ตัด ' + f.young + ' เรื่องปี 2025 และ 2026 เพราะยังใหม่เกินไป และ Global-CS 2006 ที่ไม่มีข้อมูลใน OpenAlex)') + '</p>';

  h += why(1, 'The ten most cited papers are not the most carefully evaluated', '10 เรื่องที่ถูกอ้างอิงมากที่สุด ไม่ใช่เรื่องที่ประเมินผลละเอียดที่สุด', [
    {k: 'look', en: 'We ranked the ' + f.eligible + ' studies by citations and compared how the top ten were evaluated with the other ' + rp.n + '.', th: 'เรียง ' + f.eligible + ' เรื่องตามยอดอ้างอิง แล้วเทียบวิธีประเมินผลของ 10 อันดับแรกกับอีก ' + rp.n + ' เรื่อง'},
    {k: 'found', html: table([['', ''], ['Top 10 most cited', '10 อันดับแรก', 1], ['The other ' + rp.n, 'อีก ' + rp.n + ' เรื่อง', 1]], [
      [ib('Published before 2010', 'ตีพิมพ์ก่อนปี 2010'), ofN(tp_.pre2010, tp_.n), ofN(rp.pre2010, rp.n)],
      [ib('Real datasets used (median)', 'จำนวนชุดข้อมูลจริงที่ใช้ (ค่ากลาง)'), '<b>' + tp_.med_ds + '</b>', '<b>' + rp.med_ds + '</b>'],
      [ib('Ran a statistical test', 'มีการทดสอบทางสถิติ'), ofN(tp_.test, tp_.n), ofN(rp.test, rp.n, 1)],
      [ib('Released code', 'ปล่อยโค้ด'), ofN(tp_.code, tp_.n), ofN(rp.code, rp.n, 1)],
      [ib('Citations per year (median)', 'ยอดอ้างอิงต่อปี (ค่ากลาง)'), '<b>' + fmt1(tp_.med_cpy) + '</b>', '<b>' + fmt1(rp.med_cpy) + '</b>']], 'two-col') +
      exBox('Show the ten papers', 'ดูรายชื่อ 10 เรื่อง', table([['Paper', 'เรื่อง'], ['Year', 'ปี', 1], ['Citations', 'ยอดอ้างอิง', 1], ['Real datasets', 'ชุดข้อมูลจริง', 1], ['Statistical test', 'ทดสอบสถิติ'], ['Code', 'โค้ด']],
        f.top.map(p => ['<b>' + esc(p.short) + '</b>', p.year, big(p.cites), p.n_real == null ? 'n/a' : p.n_real, ib((TEST[p.test] || [p.test, p.test])[0], (TEST[p.test] || [p.test, p.test])[1]), p.code ? ib('yes', 'มี') : ib('no', 'ไม่มี')])))},
    {k: 'means', en: 'If careful evaluation brought citations, the top ten would use many datasets and statistical tests. They do the opposite. Most are first-generation methods such as SMOTE (2002), Borderline-SMOTE (2005) and ADASYN (2008), which almost every later paper runs as a competitor and therefore cites. Their citations come from being the baseline, not from how they were evaluated.',
      th: 'ถ้าการประเมินที่ละเอียดทำให้ถูกอ้างอิงมาก 10 อันดับแรกควรเป็นเรื่องที่ใช้ข้อมูลเยอะและทดสอบสถิติ แต่ผลกลับตรงข้าม ส่วนใหญ่เป็นวิธีรุ่นแรก เช่น SMOTE (2002) Borderline-SMOTE (2005) และ ADASYN (2008) ซึ่ง paper รุ่นหลังแทบทุกเรื่องเอาไปเป็นคู่เทียบและต้องอ้างอิง ยอดจึงมาจากการเป็นวิธีพื้นฐาน ไม่ได้มาจากวิธีประเมินผล'}]);

  h += why(2, 'But raw counts are unfair: older papers have had longer to collect citations', 'แต่เทียบยอดดิบตรง ๆ ไม่ยุติธรรม เพราะ paper เก่ามีเวลาสะสมยอดนานกว่า', [
    {k: 'look', en: 'We plotted every study\'s citations against its year and fitted the dashed line: the count a paper of that year would be expected to have.', th: 'พล็อตยอดอ้างอิงของทุกเรื่องเทียบกับปีที่ตีพิมพ์ แล้วลากเส้นประ ซึ่งบอกว่า paper ปีนั้นควรได้ยอดประมาณเท่าไร'},
    {k: 'found', html: legendSc + scatter(f.points, line, ex.map(p => p.key)) + tp('Each extra year of age multiplies the expected count by about ' + f.year_ratio.toFixed(2) + '. Three examples, marked on the chart, compare the real count with the line:', 'paper ที่เก่ากว่า 1 ปี ได้ยอดที่คาดไว้มากขึ้นประมาณ ' + f.year_ratio.toFixed(2) + ' เท่า ตัวอย่าง 3 เรื่องที่วงไว้ในกราฟ เทียบยอดจริงกับเส้น:') +
      table([['Paper', 'เรื่อง'], ['Real citations', 'ยอดจริง', 1], ['Expected for its year', 'ยอดที่คาดตามปี', 1], ['Real ÷ expected', 'ยอดจริง ÷ ยอดที่คาด', 1]],
        ex.map(p => { const e = exp(p.year), r = p.cites / e; return ['<b>' + esc(p.short) + '</b> ' + p.year, big(p.cites), big(Math.round(e)), '<b>×' + (r < 0.1 ? r.toFixed(2) : r.toFixed(1)) + '</b> ' + (r >= 1 ? ib('above the line', 'อยู่เหนือเส้น') : ib('below the line', 'อยู่ใต้เส้น'))]; }))},
    {k: 'means', en: 'So we compare each paper with the line, not with raw counts. For any practice (say, running a statistical test) we ask: on average, how far above the line are papers that follow it, compared with papers that do not? We call the answer the citation multiplier.',
      th: 'เราจึงเทียบแต่ละ paper กับเส้นนี้แทนยอดดิบ แล้วถามว่า paper ที่ทำแนวปฏิบัติหนึ่ง (เช่น ทดสอบสถิติ) โดยเฉลี่ยอยู่เหนือเส้นมากกว่า paper ที่ไม่ได้ทำกี่เท่า เรียกค่านี้ว่า “ตัวคูณการอ้างอิง”'}],
    '<div class="key"><b>' + ib('How to read a multiplier', 'วิธีอ่านตัวคูณ') + '</b>' +
      tp('<b>×1</b> cited the same as papers of the same age without the practice. <b>×2</b> twice as much. <b>×0.5</b> half as much. The <b>range</b> is where the true value probably lies (95% confidence). If the range <b>crosses ×1</b>, the data cannot tell the practice apart from no effect. If the <b>whole range</b> is on one side of ×1, the difference is real (statistically significant).',
        '<b>×1</b> ถูกอ้างอิงเท่ากับ paper อายุเท่ากันที่ไม่ได้ทำ <b>×2</b> มากกว่าสองเท่า <b>×0.5</b> ครึ่งเดียว <b>ช่วง</b> คือช่วงที่ค่าจริงน่าจะอยู่ (ความเชื่อมั่น 95%) ถ้าช่วง<b>คร่อม ×1</b> แปลว่าข้อมูลไม่พอจะบอกว่าต่างจากไม่มีผล ถ้า<b>ทั้งช่วง</b>อยู่ฝั่งเดียวของ ×1 ถือว่าต่างจริง (มีนัยสำคัญทางสถิติ)') + '</div>');

  const pr = [['repeated', 'Repeats the train and test split several times', 'แบ่งข้อมูลฝึกและทดสอบซ้ำหลายรอบ'], ['inside', 'Says resampling touches training data only', 'ระบุว่าปรับสมดุลเฉพาะข้อมูลฝึก ไม่แตะข้อมูลทดสอบ'],
    ['evalsel', 'Tunes settings on the data it reports (a flaw)', 'เลือกค่าพารามิเตอร์บนข้อมูลชุดที่ใช้รายงานผล (เป็นจุดอ่อน)'], ['anytest', 'Runs a significance test', 'ทดสอบนัยสำคัญทางสถิติ'],
    ['corr', 'Uses a corrected (e.g. Holm) or Bayesian test', 'ใช้การทดสอบแบบปรับแก้ (เช่น Holm) หรือแบบเบย์'], ['method_ref', 'Cites a testing guide (e.g. Demšar 2006)', 'อ้างอิงคู่มือวิธีทดสอบ (เช่น Demšar 2006)']];
  h += why(3, 'After allowing for age, protocol, tuning and testing make no difference', 'เมื่อปรับตามอายุแล้ว โปรโตคอล การปรับจูน และการทดสอบ ไม่สัมพันธ์กับการอ้างอิง', [
    {k: 'look', en: 'We computed the multiplier for each of the 24 practices we coded. These six are about protocol, tuning and testing; all 24 are listed at the end of this question.', th: 'คำนวณตัวคูณของแนวปฏิบัติทั้ง 24 แบบที่บันทึกไว้ 6 แบบนี้เกี่ยวกับโปรโตคอล การปรับจูน และการทดสอบ (ดูครบ 24 แบบได้ท้ายคำถามนี้)'},
    {k: 'found', html: ruler(pr.map(x => ({en: x[1], th: x[2], r: infRow(x[0])})))},
    {k: 'means', en: 'Every range crosses ×1, so none of these practices is linked to more or fewer citations. For example, papers that run a significance test sit at ×' + at.ratio.toFixed(2) + ', but the range runs from ' + at.lo.toFixed(2) + ' to ' + at.hi.toFixed(2) + ': the true value could be under half or over ' + at.hi.toFixed(1) + ' times. A good practice (training-only resampling) and a flawed one (tuning on the reported data) both sit near ×1: readers neither reward nor punish them.',
      th: 'ทุกช่วงคร่อม ×1 จึงไม่มีแนวปฏิบัติใดในกลุ่มนี้ที่ทำให้ถูกอ้างอิงมากขึ้นหรือน้อยลง เช่น paper ที่ทดสอบนัยสำคัญได้ ×' + at.ratio.toFixed(2) + ' แต่ช่วงคือ ' + at.lo.toFixed(2) + ' ถึง ' + at.hi.toFixed(2) + ' ค่าจริงอาจน้อยกว่าครึ่งหรือมากกว่า ' + at.hi.toFixed(1) + ' เท่าก็ได้ ทั้งแนวปฏิบัติที่ดี (ปรับสมดุลเฉพาะข้อมูลฝึก) และที่มีจุดอ่อน (เลือกค่าบนข้อมูลที่รายงาน) อยู่ใกล้ ×1 เหมือนกัน คนอ้างอิงไม่ได้ให้รางวัลหรือลงโทษเรื่องนี้'}]);

  h += why(4, 'The one clear signal: papers that define a measure incorrectly are cited about a third as often', 'สัญญาณเดียวที่ชัด: paper ที่นิยาม metric ผิด ถูกอ้างอิงประมาณหนึ่งในสาม', [
    {k: 'look', en: 'We checked the formula of every measure each paper reports against its standard definition. ' + f.issue_rows.length + ' of the ' + f.eligible + ' studies define a measure incorrectly or do not say how it is computed.', th: 'ตรวจสูตรของทุกตัวชี้วัดที่แต่ละ paper รายงาน เทียบกับนิยามมาตรฐาน พบ ' + f.issue_rows.length + ' จาก ' + f.eligible + ' เรื่องที่นิยามผิด หรือไม่บอกว่าคำนวณอย่างไร'},
    {k: 'found', html: ruler([{en: 'Defines a measure incorrectly', th: 'นิยาม metric ผิด', r: mi}]) +
      tiles([{v: fmt1(f.issue_med[0]), en: 'median citations per year, these ' + f.issue_rows.length + ' papers', th: 'ยอดอ้างอิงต่อปี (ค่ากลาง) ของ ' + f.issue_rows.length + ' เรื่องนี้', hl: 1}, {v: fmt1(f.issue_med[1]), en: 'median citations per year, the other papers', th: 'ยอดอ้างอิงต่อปี (ค่ากลาง) ของเรื่องอื่น'}]) +
      exBox('Show the ' + f.issue_rows.length + ' papers and what is wrong', 'ดู ' + f.issue_rows.length + ' เรื่อง และสิ่งที่ผิด', table([['Paper', 'เรื่อง'], ['Citations', 'ยอดอ้างอิง', 1], ['What is wrong', 'ผิดตรงไหน']],
        f.issue_rows.map(p => ['<b>' + esc(p.short) + '</b> ' + p.year, big(p.cites), ib((ISSUE_TH[p.key] || [p.problem])[0], (ISSUE_TH[p.key] || [p.problem, p.problem])[1])])))},
    {k: 'means', en: 'This is the only practice whose whole range lies below ×1. These papers are cited about a third as often as papers of the same age (×' + mi.ratio.toFixed(2) + ', range ' + mi.lo.toFixed(2) + '–' + mi.hi.toFixed(2) + ').',
      th: 'เป็นแนวปฏิบัติเดียวที่ทั้งช่วงอยู่ต่ำกว่า ×1 paper กลุ่มนี้ถูกอ้างอิงประมาณหนึ่งในสามของ paper อายุเท่ากัน (×' + mi.ratio.toFixed(2) + ' ช่วง ' + mi.lo.toFixed(2) + '–' + mi.hi.toFixed(2) + ')'},
    {k: 'care', en: 'We tested 24 practices. Even with no real effect anywhere, about one would look different by chance, so treat this as a hint, not proof. It also does not show that readers spot the wrong formula; these papers may simply appear in venues that are read less, which we did not adjust for.',
      th: 'เราทดสอบ 24 แนวปฏิบัติ ต่อให้ไม่มีผลจริงเลย ก็คาดได้ว่าจะมีราว 1 แบบที่ดูต่างโดยบังเอิญ จึงถือเป็นข้อบ่งชี้ ยังไม่ใช่ข้อพิสูจน์ และไม่ได้แปลว่าคนอ่านจับได้ว่าสูตรผิด อาจเป็นเพราะ paper กลุ่มนี้ตีพิมพ์ในที่ที่คนอ่านน้อยกว่า ซึ่งเราไม่ได้ปรับ'}]);

  h += why(5, 'Releasing code goes with about twice the citations, but it does not pass the test', 'การปล่อยโค้ดสัมพันธ์กับยอดอ้างอิงประมาณ 2 เท่า แต่ยังไม่ผ่านเกณฑ์นัยสำคัญ', [
    {k: 'look', en: 'The same multiplier for the two practices that came closest to the line: releasing code (' + cd.n_users + ' studies) and running SMOTE as a competitor (' + sb.n_users + ' studies).', th: 'ใช้ตัวคูณแบบเดียวกันกับ 2 แนวปฏิบัติที่เกือบผ่านเกณฑ์ คือปล่อยโค้ด (' + cd.n_users + ' เรื่อง) และมี SMOTE เป็นคู่เทียบ (' + sb.n_users + ' เรื่อง)'},
    {k: 'found', html: ruler([{en: 'Releases code', th: 'ปล่อยโค้ด', r: cd}, {en: 'Runs SMOTE as a competitor', th: 'มี SMOTE เป็นคู่เทียบ', r: sb}])},
    {k: 'means', en: 'Both ranges start just below ×1 (' + cd.lo.toFixed(2) + ' and ' + sb.lo.toFixed(2) + '), so we cannot yet say they make a difference. It is a signal worth watching: released code makes it easy for others to run the method as a competitor, and so to cite it.',
      th: 'ช่วงของทั้งสองเริ่มต่ำกว่า ×1 เพียงเล็กน้อย (' + cd.lo.toFixed(2) + ' และ ' + sb.lo.toFixed(2) + ') จึงยังสรุปไม่ได้ว่าต่างจริง แต่เป็นสัญญาณที่น่าติดตาม เพราะโค้ดที่เปิดให้ใช้ทำให้คนอื่นเอาวิธีไปเป็นคู่เทียบได้ง่าย และต้องอ้างอิงตามมา'}]);

  const topics = {data: ['Data', 'ข้อมูล'], learners: ['Learners and competitors', 'classifier และคู่เทียบ'], measures: ['Measures', 'ตัวชี้วัด'], protocol: ['Protocol and tuning', 'โปรโตคอลและการปรับจูน'], stats: ['Statistical testing', 'การทดสอบทางสถิติ'], reporting: ['Reporting', 'การรายงานผล'], outcomes: ['Outcomes', 'ผลลัพธ์']};
  const all = [];
  Object.keys(topics).forEach(t => { all.push({group: topics[t]}); f.influence.filter(r => r.topic === t && r.ratio != null).forEach(r => all.push({r: r})); });
  h += exBox('Show the multiplier for all 24 practices', 'ดูตัวคูณของทั้ง 24 แนวปฏิบัติ', ruler(all));
  return h + '</section>';
}

/* ================= question 2: data ================= */
function q2() {
  const f = F.data, a = f.access, ku = f.keel_uci, pubN = f.reasons.find(r => r.code === 'public_benchmark').n;
  let h = qHead(2, 'q2', 'Which test data do studies use, why, and are studies that use downloadable data cited more?', 'เอา data test อะไรมา ทำไมเลือกชุดนั้น และ paper ที่ใช้ data ที่คนอื่นโหลดได้ ถูกอ้างอิงเยอะกว่าไหม',
    'Mostly UCI and KEEL, and using them brings no extra citations.',
    'ส่วนใหญ่ใช้ UCI และ KEEL แต่การใช้ไม่ได้ทำให้ถูกอ้างอิงมากขึ้น',
    ku.uci + ' of ' + f.n + ' studies use UCI data and ' + ku.keel + ' use KEEL data. ' + f.stated + ' of ' + f.n + ' explain their choice, mostly to cover a range of imbalance ratios and sizes or to follow an earlier paper. The citations go to the repositories, not to the papers that use them. Datasets are handed down from paper to paper, and ' + a.modified + ' studies change the data before use but only ' + a.released.length + ' release the changed version.',
    ku.uci + ' จาก ' + f.n + ' เรื่องใช้ข้อมูลจาก UCI และ ' + ku.keel + ' เรื่องใช้ KEEL มี ' + f.stated + ' จาก ' + f.n + ' เรื่องที่บอกเหตุผลการเลือก ส่วนใหญ่เพื่อให้ครอบคลุม IR และขนาดที่หลากหลาย หรือใช้ตาม paper ก่อนหน้า ยอดอ้างอิงไปตกที่ตัวคลังข้อมูล ไม่ใช่ paper ที่ใช้ข้อมูล ชุดข้อมูลถูกส่งต่อจาก paper หนึ่งไปอีก paper และมี ' + a.modified + ' เรื่องที่ดัดแปลงข้อมูลก่อนใช้ แต่มีแค่ ' + a.released.length + ' เรื่องที่ปล่อยชุดที่ดัดแปลงแล้ว');

  h += why(1, f.stated + ' of ' + f.n + ' studies give a reason; most want variety in imbalance ratio and size, or follow an earlier paper', f.stated + ' จาก ' + f.n + ' เรื่องให้เหตุผล ส่วนใหญ่เพื่อให้ครอบคลุม IR และขนาดที่หลากหลาย และใช้ตาม paper ก่อนหน้า', [
    {k: 'look', en: 'We read the dataset section of every study, copied the sentence that says why those datasets were chosen with its page, and grouped the reasons. A study can give several. We counted only what is written, not what the authors might have meant.', th: 'อ่านส่วนที่อธิบายชุดข้อมูลของทุกเรื่อง คัดประโยคที่บอกว่าทำไมเลือกชุดนั้นพร้อมเลขหน้า แล้วจัดกลุ่มเหตุผล เรื่องหนึ่งให้ได้หลายเหตุผล นับเฉพาะที่เขียนไว้ ไม่เดาเจตนาผู้เขียน'},
    {k: 'found', html: bars(f.reasons.map(r => ({en: DREASON[r.code][0], th: DREASON[r.code][1], n: r.n, of: f.n, c: r.code === 'public_benchmark' ? '--c3' : '--c1'})), f.n) +
      exBox('Show one sentence for each reason', 'ดูประโยคตัวอย่างของแต่ละเหตุผล', '<div class="quotes">' + f.reasons.filter(r => r.ex).map(r => qcard(r.ex, DREASON_EX[r.code], ib(DREASON[r.code][0], DREASON[r.code][1]))).join('') + '</div>' +
        '<p class="note">' + ib('No reason given (' + f.not_stated.length + '): ', 'ไม่ให้เหตุผล (' + f.not_stated.length + ' เรื่อง): ') + esc(f.not_stated.join(', ')) + '</p>')},
    {k: 'means', en: 'Data are chosen to cover a spread of imbalance ratios and sizes, or because an earlier paper used them. Only ' + pubN + ' studies say they chose data because anyone can download it (grey bar).',
      th: 'ข้อมูลถูกเลือกเพื่อให้ครอบคลุม IR และขนาดที่หลากหลาย หรือเพราะ paper ก่อนหน้าใช้ มีเพียง ' + pubN + ' เรื่องที่บอกว่าเลือกเพราะใคร ๆ ก็โหลดได้ (แท่งสีเทา)'}]);

  h += why(2, 'Datasets are handed down in chains', 'ชุดข้อมูลถูกส่งต่อกันเป็นสาย', [
    {k: 'look', en: 'We kept only the cases where a paper itself says which earlier work its datasets come from.', th: 'เก็บเฉพาะกรณีที่ paper เขียนเองว่าชุดข้อมูลมาจากงานไหน'},
    {k: 'found', html: '<div class="chains">' + f.chains.map((c, i) => '<div class="chain"><div class="src">' + ib(c.source, CHAIN_SRC_TH[i] || c.source) + '</div>' + c.items.map(it => '<div class="ln"><span class="arrow">→</span><div><b>' + esc(it.short) + '</b>' + qcard(it, CHAIN_TH[it.key]) + '</div></div>').join('') + '</div>').join('') + '</div>'},
    {k: 'means', en: 'For example, Sáez et al. (2016) picked hard multi-class KEEL sets; MC-RBO and MC-CCR (2020) say they took them from that study, and NROMM (2023) says it uses the same 20 sets as MC-RBO and MC-CCR. This keeps results comparable, but the data are inherited rather than chosen for each new question.',
      th: 'ตัวอย่าง Sáez et al. (2016) คัดชุดข้อมูลหลายคลาสจาก KEEL ที่ยาก MC-RBO และ MC-CCR (2020) เขียนว่าเอามาจากงานนั้น แล้ว NROMM (2023) เขียนว่าใช้ 20 ชุดเดียวกับ MC-RBO และ MC-CCR ทำให้ผลเทียบกันได้ แต่ข้อมูลถูกสืบทอดมา ไม่ได้ถูกเลือกใหม่ตามคำถามของแต่ละงาน'}]);

  const repo = f.repo.slice();
  h += why(3, 'The credit goes to the repositories themselves', 'เครดิตไปตกที่ตัวคลังข้อมูลเอง', [
    {k: 'look', en: 'We looked up, in OpenAlex, the papers that introduce the KEEL and UCI repositories and the imbalanced-learn library, next to the best-known methods in our corpus.', th: 'ดึงยอดอ้างอิงจาก OpenAlex ของ paper ที่แนะนำคลังข้อมูล KEEL และ UCI และไลบรารี imbalanced-learn เทียบกับวิธีที่ดังที่สุดในคลังบทความ'},
    {k: 'found', html: bars(repo.map(r => ({en: r.label, th: REPO_TH(r.label), n: r.cites, v: big(r.cites), c: r.kind === 'method' ? '--c1' : '--c2'}))) +
      '<div class="legend"><span><i style="background:var(--c2)"></i>' + ib('repository or tool', 'คลังข้อมูลหรือเครื่องมือ') + '</span><span><i style="background:var(--c1)"></i>' + ib('method in the corpus', 'วิธีในคลังบทความ') + '</span></div>'},
    {k: 'means', en: 'Every paper that uses KEEL or UCI data cites the repository paper, so the citations pile up there. The UCI record (' + big(repo.find(r => r.label.indexOf('UCI') === 0).cites) + ') is cited more than any method except SMOTE.',
      th: 'ทุก paper ที่ใช้ข้อมูลจาก KEEL หรือ UCI ต้องอ้างอิง paper ของคลังนั้น ยอดอ้างอิงจึงไปรวมที่คลัง UCI (' + big(repo.find(r => r.label.indexOf('UCI') === 0).cites) + ') ถูกอ้างอิงมากกว่าทุกวิธี ยกเว้น SMOTE'}]);

  const dr = [['keel', 'Uses KEEL datasets', 'ใช้ชุดข้อมูลจาก KEEL'], ['uci', 'Uses UCI datasets', 'ใช้ชุดข้อมูลจาก UCI'], ['many_ds', 'Uses 18 or more real datasets (the median)', 'ใช้ชุดข้อมูลจริง 18 ชุดขึ้นไป (ค่ากลาง)'],
    ['data_reason', 'Explains why the data were chosen', 'อธิบายเหตุผลที่เลือกข้อมูล'], ['private', 'Some data cannot be downloaded', 'มีข้อมูลบางชุดที่โหลดไม่ได้']];
  const uci = infRow('uci');
  h += why(4, 'Papers that use KEEL or UCI are not cited any more', 'paper ที่ใช้ข้อมูล KEEL หรือ UCI ไม่ได้ถูกอ้างอิงมากขึ้นเลย', [
    {k: 'look', en: 'The same citation multiplier as in question 1: each paper is compared with papers of the same age.', th: 'ใช้ตัวคูณการอ้างอิงแบบเดียวกับคำถามที่ 1 คือเทียบแต่ละ paper กับ paper อายุเท่ากัน'},
    {k: 'found', html: ruler(dr.map(x => ({en: x[1], th: x[2], r: infRow(x[0])})))},
    {k: 'means', en: 'All five sit close to ×1 with ranges that cross it. The likely reason: almost everyone uses these repositories (' + uci.n_users + ' of ' + uci.n + ' use UCI), so using them does not make a paper stand out. Even papers with some data that cannot be downloaded are not cited less.',
      th: 'ทั้ง 5 แบบอยู่ใกล้ ×1 และช่วงคร่อม ×1 เหตุผลที่น่าจะเป็นคือ เกือบทุกเรื่องใช้คลังเหล่านี้อยู่แล้ว (' + uci.n_users + ' จาก ' + uci.n + ' เรื่องใช้ UCI) การใช้จึงไม่ทำให้ paper ไหนโดดเด่น แม้แต่ paper ที่มีข้อมูลบางชุดโหลดไม่ได้ ก็ไม่ได้ถูกอ้างอิงน้อยลง'}]);

  h += why(5, 'Downloadable, but not reproducible: ' + a.modified + ' studies change the data, only ' + a.released.length + ' release the changed version', 'โหลดได้ แต่ทำซ้ำไม่ได้: ' + a.modified + ' เรื่องดัดแปลงข้อมูลเอง แต่ปล่อยออกมาแค่ ' + a.released.length + ' เรื่อง', [
    {k: 'look', en: 'For each study we checked whether the original data are public, whether the authors changed them (merging classes into two, under-sampling to raise the imbalance ratio, adding noise) and, if so, whether they released the changed version.', th: 'ตรวจทุกเรื่องว่าข้อมูลต้นฉบับเปิดเผยไหม ผู้เขียนดัดแปลงข้อมูลไหม (เช่น รวมหลายคลาสให้เหลือ 2 คลาส สุ่มตัดเพื่อเพิ่ม IR หรือเติม noise) และถ้าดัดแปลง ได้ปล่อยชุดที่ดัดแปลงแล้วไหม'},
    {k: 'found', html: bars([{en: 'all real data can be downloaded', th: 'ข้อมูลจริงทุกชุดโหลดได้', n: a.all_public, of: f.n}, {en: 'says where each dataset comes from', th: 'บอกแหล่งของทุกชุดข้อมูล', n: a.per_src, of: f.n},
      {en: 'changes the data before use', th: 'ดัดแปลงข้อมูลก่อนใช้', n: a.modified, of: f.n, c: '--c2'}, {en: 'of these, releases the changed data', th: 'ในนั้น ปล่อยชุดที่ดัดแปลงแล้ว', n: a.released.length, of: a.modified, c: '--c2'}], f.n) +
      '<p class="note">' + ib('Released the changed data: ', 'ปล่อยชุดที่ดัดแปลงแล้ว: ') + esc(a.released.join(', ')) + '</p>'},
    {k: 'means', en: 'Anyone can download the originals, but without the changed version nobody can rebuild exactly the data in the paper (for instance, which examples were removed by under-sampling). So the data are open, yet the results are hard to reproduce.',
      th: 'ใคร ๆ ก็โหลดชุดต้นฉบับได้ แต่ถ้าไม่มีชุดที่ดัดแปลงแล้ว ก็สร้างข้อมูลให้ตรงกับใน paper ไม่ได้ (เช่น ไม่รู้ว่าสุ่มตัดตัวอย่างไหนออก) ข้อมูลจึงเปิด แต่ผลทำซ้ำได้ยาก'}]);
  return h + '</section>';
}

/* ================= question 3: beyond the classifier ================= */
function q3() {
  const f = F.beyond, g = f.groups, inf = f.inf_direct;
  let h = qHead(3, 'q3', 'Besides scoring a classifier, is there another way, such as measuring the data directly?', 'นอกจากวัดผลผ่าน classifier มีวิธีแบบอื่นไหม เช่นวัดข้อมูลตรง ๆ',
    'No study evaluates without a classifier.', 'ไม่มีเรื่องไหนประเมินโดยไม่ใช้ classifier เลย',
    'Only ' + g.direct + ' studies also measure the resampled data directly, and only as extra evidence. Other non-score evidence is mostly 2-D pictures (' + g.visual + ' studies) or theory and big-O (' + g.analytic + ' studies).',
    'มีแค่ ' + g.direct + ' เรื่องที่วัดข้อมูลหลังปรับสมดุลโดยตรง และใช้เป็นแค่หลักฐานเสริม หลักฐานอื่นที่ไม่ใช่คะแนน ส่วนใหญ่เป็นกราฟ 2 มิติ (' + g.visual + ' เรื่อง) หรือทฤษฎีและ big-O (' + g.analytic + ' เรื่อง)');

  h += why(1, 'All ' + f.n + ' studies judge resampling by a classifier\'s score', 'ทั้ง ' + f.n + ' เรื่องตัดสินการปรับสมดุลด้วยคะแนนของ classifier', [
    {k: 'look', en: 'We went through every results table and figure of every study and sorted each result: is it a classifier score (accuracy, G-mean, AUC and so on) or something else? Each non-score result was recorded with its page.', th: 'ไล่ดูทุกตารางและรูปผลการทดลองของทุกเรื่อง แยกว่าผลไหนเป็นคะแนนของ classifier (เช่น accuracy, G-mean, AUC) ผลไหนไม่ใช่ และบันทึกเลขหน้าของผลที่ไม่ใช่คะแนนทุกรายการ'},
    {k: 'found', html: tiles([{v: f.n + '/' + f.n, en: 'report classifier scores', th: 'มีคะแนนของ classifier'}, {v: f.without_classifier + '/' + f.n, en: 'evaluate without any classifier', th: 'ประเมินโดยไม่ใช้ classifier', hl: 1},
      {v: g.direct + '/' + f.n, en: 'also measure the resampled data directly', th: 'วัดข้อมูลหลังปรับสมดุลโดยตรงด้วย'}, {v: g.none + '/' + f.n, en: 'report classifier scores and nothing else', th: 'มีแค่คะแนน classifier ไม่มีหลักฐานอื่น'}])},
    {k: 'means', en: 'The standard recipe in this field is: resample the training data, train a classifier, score it on test data. The resampled data are always judged indirectly, through the classifier.',
      th: 'สูตรมาตรฐานของงานสายนี้คือ ปรับสมดุลข้อมูลฝึก แล้วฝึก classifier แล้ววัดคะแนนบนข้อมูลทดสอบ ข้อมูลที่ปรับแล้วจึงถูกตัดสินทางอ้อมผ่าน classifier เสมอ'}]);

  h += why(2, 'The ' + g.direct + ' studies that measure the data directly do so as a side check', g.direct + ' เรื่องที่วัดข้อมูลตรง ๆ ใช้เป็นแค่การตรวจเสริม', [
    {k: 'look', en: 'For these studies we noted what exactly is measured and where. An independent second reader checked each one.', th: 'บันทึกว่าแต่ละเรื่องวัดอะไรและอยู่หน้าไหน และให้ผู้ตรวจอีกคนตรวจซ้ำทุกเรื่อง'},
    {k: 'found', html: table([['Paper', 'เรื่อง'], ['What is measured, in plain words', 'วัดอะไร (ภาษาง่าย)'], ['Where', 'หน้า']],
      f.direct.map(p => ['<b>' + esc(p.short) + '</b>', ib((DIRECT[p.key] || [p.details])[0], (DIRECT[p.key] || [p.details, p.details])[1]), '<span class="sub">' + esc(p.where) + '</span>']))},
    {k: 'means', en: 'All six still use classifier scores as the main result that decides whether the method is better. CTGAN and GAMO are GAN-based and borrow their measures (likelihood, FID) from work on generative models. The ' + inf.n_users + ' of them old enough to count are cited ×' + inf.ratio.toFixed(1) + ', but the range (' + inf.lo.toFixed(2) + '–' + inf.hi.toFixed(2) + ') is too wide to conclude anything with so few papers.',
      th: 'ทั้ง 6 เรื่องยังใช้คะแนน classifier เป็นผลหลักในการตัดสินว่าวิธีดีกว่า CTGAN และ GAMO เป็นงานสาย GAN ซึ่งยืมตัววัด (likelihood, FID) มาจากงานสร้างข้อมูล ' + inf.n_users + ' เรื่องในกลุ่มนี้ที่เก่าพอจะนับยอดอ้างอิงได้ ×' + inf.ratio.toFixed(1) + ' แต่ช่วง (' + inf.lo.toFixed(2) + '–' + inf.hi.toFixed(2) + ') กว้างเกินจะสรุปได้ เพราะมีแค่ไม่กี่เรื่อง'}]);

  h += why(3, 'Other evidence is mostly pictures and theory, not measurement', 'หลักฐานแบบอื่นส่วนใหญ่เป็นภาพและทฤษฎี ไม่ใช่การวัด', [
    {k: 'look', en: 'The same sorting, for everything that is not a classifier score. A study can fall in several groups. Hand-drawn diagrams and plots of the original data only are not counted.', th: 'ใช้การแยกแบบเดียวกันกับผลทุกอย่างที่ไม่ใช่คะแนน เรื่องหนึ่งอยู่ได้หลายกลุ่ม ไม่นับภาพวาดแผนผังและกราฟของข้อมูลต้นฉบับอย่างเดียว'},
    {k: 'found', html: bars([{en: 'pictures: 2-D plots, PCA or t-SNE views, histograms', th: 'ภาพ: กราฟ 2 มิติ ภาพฉาย PCA หรือ t-SNE histogram', n: g.visual, of: f.n}, {en: 'analysis: theorems, bounds, big-O', th: 'การวิเคราะห์: ทฤษฎีบท ขอบเขต big-O', n: g.analytic, of: f.n},
      {en: 'model traits, e.g. tree size or number of rules', th: 'ลักษณะของโมเดล เช่น ขนาดต้นไม้ จำนวนกฎ', n: g.model, of: f.n}, {en: 'direct measurement of the resampled data', th: 'วัดข้อมูลหลังปรับสมดุลโดยตรง', n: g.direct, of: f.n, c: '--c2'},
      {en: 'nothing besides classifier scores', th: 'ไม่มีอะไรนอกจากคะแนน classifier', n: g.none, of: f.n, c: '--c3'}], f.n)},
    {k: 'means', en: 'A 2-D plot shows where synthetic points land on a toy dataset: useful to see, but it gives no number on real data. Theory and big-O say the method is sound and how long it takes, not how good the data it produces are. Five studies describe the trained model instead, for example SMOTE (2002) compares tree sizes and Batista et al. (2004) the number of rules.',
      th: 'กราฟ 2 มิติแสดงว่าจุดสังเคราะห์ไปตกตรงไหนบนข้อมูลตัวอย่างที่สร้างขึ้นเอง ช่วยให้เห็นภาพ แต่ไม่ได้ให้ตัวเลขบนข้อมูลจริง ทฤษฎีและ big-O บอกว่าวิธีถูกต้องและใช้เวลาเท่าไร ไม่ได้บอกว่าข้อมูลที่ได้ดีแค่ไหน อีก 5 เรื่องอธิบายลักษณะของโมเดลแทน เช่น SMOTE (2002) เทียบขนาดต้นไม้ และ Batista et al. (2004) เทียบจำนวนกฎ'}],
    exBox('Show the ' + f.model.length + ' model-trait studies and the ' + f.none.length + ' score-only studies', 'ดู ' + f.model.length + ' เรื่องที่รายงานลักษณะโมเดล และ ' + f.none.length + ' เรื่องที่มีแค่คะแนน',
      '<ul class="plain">' + f.model.map(p => '<li><b>' + esc(p.short) + '</b>: ' + ib((MODEL_TH[p.short] || [p.details])[0], (MODEL_TH[p.short] || [p.details, p.details])[1]) + '</li>').join('') + '</ul>' +
      '<p class="note">' + ib('Classifier scores only: ', 'มีแค่คะแนน classifier: ') + esc(f.none.join(', ')) + '</p>'));
  return h + '</section>';
}

/* ================= question 4: how models are chosen ================= */
function q4() {
  const f = F.select, sel = f.sel_n, named = f.named_n;
  const fam = Object.keys(f.clf_families).slice(0, 6);
  const pop = f.learner_reasons.find(r => r.code === 'popular').n;
  let h = qHead(4, 'q4', 'How are the models chosen? Is it by sensitivity alone?', 'model ที่ใช้ เลือกมาจากอะไร ใช้ sen (sensitivity) อย่างเดียวไหม',
    'No, in both senses of the question.', 'ไม่ใช่ ทั้งสองความหมายของคำถาม',
    'Classifiers are mostly chosen because they are common (' + pop + ' studies); only ' + f.sens.length + ' choose one because it is sensitive to imbalance. Settings are mostly chosen by G-mean or AUC; sensitivity alone decides in only ' + f.sens_only.length + ' studies, both as a rule inside the method.',
    'classifier ส่วนใหญ่ถูกเลือกเพราะนิยมใช้ (' + pop + ' เรื่อง) มีแค่ ' + f.sens.length + ' เรื่องที่เลือกเพราะไวต่อ imbalance ส่วนค่าพารามิเตอร์ถูกเลือกด้วย G-mean หรือ AUC เป็นหลัก ใช้ sensitivity อย่างเดียวมีแค่ ' + f.sens_only.length + ' เรื่อง และเป็นกฎภายในตัววิธีเอง');
  h += '<div class="key"><b>' + ib('Two readings of the question; we answer both', 'คำถามนี้ตีความได้ 2 แบบ เราตอบทั้งสองแบบ') + '</b>' +
    tp('<b>(a)</b> Which classifier is used, and why? For example, because it is sensitive to imbalance. <b>(b)</b> Which measure picks the best setting or variant? For example, sensitivity.',
      '<b>(ก)</b> ใช้ classifier ตัวไหน เพราะอะไร เช่น เพราะมันไวต่อ imbalance <b>(ข)</b> ใช้ตัวชี้วัดอะไรเลือกค่าพารามิเตอร์หรือรุ่นที่ดีที่สุด เช่น sensitivity') + '</div>';

  h += why(1, '(a) Classifiers are chosen because they are common; only ' + f.sens.length + ' studies choose one because it is sensitive to imbalance', '(ก) classifier ส่วนใหญ่ถูกเลือกเพราะนิยมใช้ มีแค่ ' + f.sens.length + ' เรื่องที่เลือกเพราะไวต่อ imbalance', [
    {k: 'look', en: 'We found the sentence where each study says why it uses its classifiers, with the page, and grouped the reasons.', th: 'หาประโยคที่แต่ละเรื่องบอกว่าทำไมใช้ classifier ตัวนั้น พร้อมเลขหน้า แล้วจัดกลุ่มเหตุผล'},
    {k: 'found', html: bars(f.learner_reasons.map(r => ({en: LREASON[r.code][0], th: LREASON[r.code][1], n: r.n, of: f.n, c: r.code === 'sensitive_to_imbalance' ? '--c2' : '--c1'})), f.n) +
      '<p class="note">' + ib(f.learner_stated + ' of ' + f.n + ' studies give a reason; ' + (f.n - f.learner_stated) + ' do not. Most used: ', f.learner_stated + ' จาก ' + f.n + ' เรื่องให้เหตุผล อีก ' + (f.n - f.learner_stated) + ' เรื่องไม่ให้ classifier ที่ใช้บ่อย: ') + esc(fam.map(k => k + ' (' + f.clf_families[k] + ')').join(', ')) + '</p>' +
      exBox('Show the ' + f.sens.length + ' studies that chose a classifier for its sensitivity, and other examples', 'ดู ' + f.sens.length + ' เรื่องที่เลือกเพราะไวต่อ imbalance และตัวอย่างอื่น',
        '<div class="quotes">' + f.sens.map(s => qcard(s, LQ_TH[s.key], ib(LREASON.sensitive_to_imbalance[0], LREASON.sensitive_to_imbalance[1]))).join('') +
        ['popular', 'diverse_paradigms', 'follows_prior_work'].map(c => { const r = f.learner_reasons.find(x => x.code === c); return r && r.ex ? qcard(r.ex, LQ_TH[r.ex.key], ib(LREASON[c][0], LREASON[c][1])) : ''; }).join('') + '</div>')},
    {k: 'means', en: 'Classifiers are picked for being widely used or for covering different kinds of learner, so results look general. Choosing one because it reacts to imbalance is rare.',
      th: 'classifier ถูกเลือกเพราะนิยมใช้ หรือเพื่อให้ครอบคลุมหลายแบบ ผลจะได้ดูทั่วไป การเลือกเพราะมันไวต่อ imbalance พบน้อยมาก'}]);

  h += why(2, '(b) ' + sel + ' studies pick a setting, only ' + named + ' say which measure decides, mostly G-mean or AUC', '(ข) ' + sel + ' เรื่องมีการเลือกค่า แต่บอกเกณฑ์แค่ ' + named + ' เรื่อง ส่วนใหญ่ใช้ G-mean และ AUC', [
    {k: 'look', en: 'For every study we recorded what is chosen (SMOTE\'s k, how many points to create, a classifier hyperparameter, or the best variant of the method), which measure decides, and on which data.', th: 'บันทึกทุกเรื่องว่ามีการเลือกอะไร (เช่น ค่า k ของ SMOTE จำนวนตัวอย่างที่จะสังเคราะห์ hyperparameter ของ classifier หรือรุ่นที่ดีที่สุดของวิธี) ใช้ตัวชี้วัดอะไรตัดสิน และตัดสินบนข้อมูลชุดไหน'},
    {k: 'found', html: '<div class="funnel"><div><b>' + f.n + '</b>' + ib('studies with experiments', 'เรื่องที่มีการทดลอง') + '</div><span>→</span><div><b>' + sel + '</b>' + ib('choose some setting', 'มีการเลือกค่า') + '</div><span>→</span><div><b>' + named + '</b>' + ib('name the measure', 'บอกตัวชี้วัดที่ใช้เลือก') + '</div><div class="side"><b>' + f.internal_n + '</b>' + ib('use a rule of the method (e.g. likelihood)', 'ใช้เกณฑ์ภายในของวิธี (เช่น likelihood)') + '</div><div class="side"><b>' + f.ns_n + '</b>' + ib('do not say', 'ไม่บอก') + '</div></div>' +
      '<h5>' + ib('Measure used to choose (number of studies)', 'ตัวชี้วัดที่ใช้เลือก (จำนวนเรื่อง)') + '</h5>' + bars(Object.keys(f.criteria).map(k => ({en: k, th: k, n: f.criteria[k], of: named, c: k === 'Sensitivity/Recall' ? '--c2' : '--c1'})), named)},
    {k: 'means', en: 'G-mean (' + f.criteria['G-mean'] + ') and AUC (' + f.criteria['AUC'] + ') do most of the choosing. Sensitivity is among the measures in ' + (f.criteria['Sensitivity/Recall'] || 0) + ' studies. Every measure used to choose is also one the study reports as a result.',
      th: 'G-mean (' + f.criteria['G-mean'] + ') และ AUC (' + f.criteria['AUC'] + ') เป็นเกณฑ์หลัก sensitivity อยู่ในเกณฑ์ของ ' + (f.criteria['Sensitivity/Recall'] || 0) + ' เรื่อง และทุกตัวชี้วัดที่ใช้เลือก เป็นตัวเดียวกับที่รายงานเป็นผลด้วย'}]);

  const SO = {'RACOG-2015': ['Keeps adding synthetic points and stops when sensitivity on validation data stops improving (the spread over the last 10 rounds falls below 0.02). The authors note precision or F-measure could be used instead.', 'เพิ่มตัวอย่างสังเคราะห์ไปเรื่อย ๆ และหยุดเมื่อ sensitivity บนข้อมูลตรวจสอบไม่ดีขึ้นแล้ว (ความแปรปรวนของ 10 รอบล่าสุดต่ำกว่า 0.02) ผู้เขียนบอกเองว่าใช้ precision หรือ F-measure แทนได้'],
    'OBU-2018': ['Trains two models from two ways of under-sampling and keeps the one with higher positive-class accuracy, which is sensitivity. The paper does not say on which data this is measured.', 'ฝึกโมเดล 2 ตัวจากการสุ่มตัด 2 แบบ แล้วเก็บตัวที่ accuracy ของคลาสบวก (คือ sensitivity) สูงกว่า paper ไม่ได้บอกว่าวัดบนข้อมูลชุดไหน']};
  h += why(3, 'Sensitivity alone decides in only ' + f.sens_only.length + ' studies, as a rule inside the method', 'ใช้ sensitivity อย่างเดียวมีแค่ ' + f.sens_only.length + ' เรื่อง และเป็นกฎภายในตัววิธีเอง', [
    {k: 'look', en: 'We picked out the studies whose only deciding measure is sensitivity and had a second reader check them against the paper.', th: 'คัดเรื่องที่ใช้ sensitivity เป็นเกณฑ์ตัดสินเพียงตัวเดียว แล้วให้ผู้ตรวจอีกคนตรวจกับต้นฉบับ'},
    {k: 'found', html: '<div class="two">' + f.sens_only.map(s => '<div class="card"><h5>' + esc(s.short) + '</h5>' + tp((SO[s.key] || ['', ''])[0], (SO[s.key] || ['', ''])[1]) + quoteHTML(s) + '</div>').join('') + '</div>'},
    {k: 'means', en: 'Both use sensitivity as a stopping or keep-the-better-model rule inside the method. Neither uses it to choose a classifier or to decide the experiment\'s result.',
      th: 'ทั้งสองเรื่องใช้ sensitivity เป็นกฎหยุด หรือกฎเลือกเก็บโมเดลที่ดีกว่า ภายในขั้นตอนของวิธีเอง ไม่ได้ใช้เลือก classifier หรือใช้ตัดสินผลการทดลอง'}]);

  const du = f.data_used;
  h += why(4, 'A bigger worry: ' + (du['evaluation data'] || 0) + ' of ' + sel + ' choose settings on the same data they report', 'สิ่งที่น่ากังวลกว่า: ' + (du['evaluation data'] || 0) + ' จาก ' + sel + ' เรื่องเลือกค่าบนข้อมูลชุดเดียวกับที่รายงานผล', [
    {k: 'look', en: 'For the ' + sel + ' studies that choose a setting, on which data the choice is made.', th: 'ใน ' + sel + ' เรื่องที่มีการเลือกค่า เลือกบนข้อมูลชุดไหน'},
    {k: 'found', html: bars([{en: 'the test folds that are reported', th: 'fold ทดสอบชุดเดียวกับที่รายงานผล', n: du['evaluation data'] || 0, of: sel, c: '--c2'}, {en: 'not stated', th: 'ไม่บอก', n: du['not stated'] || 0, of: sel, c: '--c3'},
      {en: 'separate validation data inside the training data', th: 'ข้อมูลตรวจสอบที่แยกไว้ในข้อมูลฝึก', n: du['inner validation (training data only)'] || 0, of: sel}, {en: 'separate tuning datasets', th: 'ชุดข้อมูลสำหรับปรับจูนแยกต่างหาก', n: du['other'] || 0, of: sel}], sel) +
      exBox('Show all ' + sel + ' studies with their quotes', 'ดูทั้ง ' + sel + ' เรื่องพร้อมข้อความจากบทความ', table([['Paper', 'เรื่อง'], ['Chosen', 'สิ่งที่เลือก'], ['Measure', 'ตัวชี้วัด'], ['Data', 'ข้อมูล'], ['Quote and page', 'ข้อความและเลขหน้า']],
        f.table.map(r => ['<b>' + esc(r.short) + '</b>', trList(r.selected), esc(r.criterion), trList(r.data), (r.quote ? '“' + esc(r.quote) + '”' : '') + '<div class="sub">' + esc(r.where || '') + '</div>'])))},
    {k: 'means', en: 'If you pick the setting that scores best on the test folds and then report the score on those same folds, the proposed method looks better than it really is. Only ' + (du['inner validation (training data only)'] || 0) + ' studies keep a separate validation set inside the training data.',
      th: 'ถ้าเลือกค่าที่ทำให้คะแนนบน fold ทดสอบสูงสุด แล้วรายงานคะแนนบน fold เดียวกันนั้น วิธีที่เสนอจะดูดีเกินจริง มีแค่ ' + (du['inner validation (training data only)'] || 0) + ' เรื่องที่แยกข้อมูลตรวจสอบไว้ในข้อมูลฝึก'}]);
  return h + '</section>';
}

function findings() {
  const q = [['q1', 'Evaluation method and citations', 'วิธีประเมินกับยอดอ้างอิง', 'Not linked', 'ไม่สัมพันธ์กัน'], ['q2', 'Test data and why', 'data test และเหตุผลที่เลือก', 'UCI and KEEL; no citation gain', 'UCI และ KEEL; ไม่ได้ทำให้ถูกอ้างอิงเพิ่ม'],
    ['q3', 'Measuring without a classifier', 'วัดตรงโดยไม่ผ่าน classifier', 'None; 6 add a direct check', 'ไม่มี; 6 เรื่องวัดตรงเป็นส่วนเสริม'], ['q4', 'How models are chosen', 'เลือก model จากอะไร', 'Not by sensitivity alone', 'ไม่ได้ใช้ sensitivity อย่างเดียว']];
  return '<section class="panel intro"><h2 class="qi">' + ib('Your four questions: the answers and why', 'คำถาม 4 ข้อของคุณ: คำตอบ และทำไมถึงได้คำตอบนั้น') + '</h2>' +
    tp('Each question starts with a short answer. Below it, every reason says <b>what we looked at</b>, <b>what we found</b> and <b>what it means</b>. Paper lists and quotes are folded away; open them if you want to check.',
      'แต่ละคำถามเริ่มด้วยคำตอบสั้น ๆ ข้างล่างเป็นเหตุผลทีละข้อ แต่ละข้อบอกว่า <b>เราดูอะไร</b> <b>เจออะไร</b> และ<b>จึงสรุปว่าอะไร</b> รายชื่อ paper และข้อความที่ยกมาถูกพับไว้ กดเปิดเมื่ออยากตรวจ') +
    '<nav class="fidx">' + q.map((x, i) => '<a href="#' + x[0] + '"><span class="fno">' + (i + 1) + '</span><span><b>' + ib(x[1], x[2]) + '</b><small>' + ib(x[3], x[4]) + '</small></span></a>').join('') + '</nav>' +
    '<p class="src">' + ib('Corpus: 76 papers, of which 71 run experiments. Every count comes from the coded data behind Section 7; every quote carries its page.', 'คลังบทความ 76 เรื่อง มีการทดลอง 71 เรื่อง ตัวเลขทุกตัวมาจากข้อมูลที่บันทึกไว้สำหรับหัวข้อที่ 7 และข้อความที่ยกมาทุกข้อมีเลขหน้า') + '</p></section>' +
    q1() + q2() + q3() + q4();
}
