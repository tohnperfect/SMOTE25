(function () {
'use strict';
const D = JSON.parse(document.getElementById('rm-data').textContent);
const ERAS = ['≤2009', '2010-2015', '2016-2020', '2021-2026'];
const ERA_EN = {'≤2009': '1997–2009', '2010-2015': '2010–2015', '2016-2020': '2016–2020', '2021-2026': '2021–2026'};
const BY = Object.fromEntries(D.emp.map(p => [p.key, p]));
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c]));
const big = n => n == null ? 'n/a' : String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
const TOPICS = [
  ['data', 'Data', 'ข้อมูล'], ['learners', 'Learners and competitors', 'ตัวจำแนกและคู่เทียบ'], ['measures', 'Measures and other evidence', 'ตัวชี้วัดและหลักฐานอื่น'],
  ['protocol', 'Protocol and tuning', 'โปรโตคอลและการปรับจูน'], ['stats', 'Statistical testing', 'การทดสอบทางสถิติ'], ['reporting', 'Reporting', 'การรายงานผล']];
const TH = {
  'UCI repository': 'คลัง UCI', 'KEEL repository': 'คลัง KEEL', 'Synthetic data': 'ข้อมูลสังเคราะห์', 'Private or application data': 'ข้อมูลเฉพาะหรือข้อมูลจากการใช้งานจริง',
  'Image data': 'ข้อมูลภาพ', 'Fewer than 10 real datasets': 'ใช้ข้อมูลจริงน้อยกว่า 10 ชุด', 'Reason for data stated': 'ระบุเหตุผลที่เลือกข้อมูล',
  'C4.5/C5.0': 'C4.5/C5.0', 'k-NN': 'k-NN', 'SVM': 'SVM', 'Rule learner (RIPPER etc.)': 'ตัวเรียนรู้กฎ (RIPPER ฯลฯ)', 'Naive Bayes': 'Naive Bayes', 'MLP/NN': 'MLP/โครงข่ายประสาทเทียม',
  'Random forest or gradient boosting': 'Random forest หรือ gradient boosting', 'Single base learner': 'ใช้ตัวจำแนกตัวเดียว', 'No-resampling baseline': 'มีเส้นฐานที่ไม่ปรับสมดุล',
  'Reason for learners stated': 'ระบุเหตุผลที่เลือกตัวจำแนก', 'Accuracy or error rate': 'Accuracy หรืออัตราความผิดพลาด', 'ROC curve only (no AUC value)': 'เส้นโค้ง ROC อย่างเดียว (ไม่มีค่า AUC)',
  'AUC': 'AUC', 'G-mean': 'G-mean', 'F1 / F-measure': 'F1 / F-measure', 'Recall / TPR': 'Recall / TPR', 'MAUC': 'MAUC', 'MCC': 'MCC', 'PR-AUC': 'PR-AUC',
  'Direct measure of resampled data': 'วัดข้อมูลหลังปรับสมดุลโดยตรง', '2-D or projected plots of samples': 'กราฟสองมิติหรือภาพฉายของตัวอย่าง',
  'Single hold-out': 'hold-out ครั้งเดียว', 'Single k-fold CV': 'k-fold CV รอบเดียว', 'Repeated k-fold CV / 5x2 CV': 'k-fold CV แบบทำซ้ำ / 5×2 CV',
  'Train-only resampling stated': 'ระบุว่าปรับสมดุลเฉพาะข้อมูลฝึก', 'Settings chosen on evaluation data': 'เลือกค่าบนข้อมูลที่ใช้ประเมิน', 'Nested or held-out tuning': 'ปรับจูนแบบ nested หรือชุดแยก',
  'No significance test': 'ไม่มีการทดสอบนัยสำคัญ', 't-test': 't-test', 'Wilcoxon signed-rank': 'Wilcoxon signed-rank', 'Friedman': 'Friedman',
  'Corrected multiple comparison': 'การเปรียบเทียบพหุคูณแบบปรับแก้', 'Bayesian test': 'การทดสอบแบบเบย์', 'Cites Demšar (2006)': 'อ้าง Demšar (2006)',
  'Mean ± standard deviation': 'ค่าเฉลี่ย ± ส่วนเบี่ยงเบนมาตรฐาน', 'Average-rank table': 'ตารางอันดับเฉลี่ย', 'Win/tie/loss counts': 'นับชนะ/เสมอ/แพ้',
  'Running time': 'เวลาประมวลผล', 'Code released': 'เผยแพร่โค้ด'};
const TREND = {
  new: ['New since 2016', 'เกิดขึ้นใหม่ตั้งแต่ปี 2016', 'first used in 2016 or later'],
  rising: ['Rising', 'เพิ่มขึ้น', 'share at least 20 points higher in 2021–2026 than in 1997–2009'],
  declining: ['Declining', 'ลดลง', 'share at least 20 points lower in 2021–2026 than in 1997–2009'],
  abandoned: ['Abandoned', 'เลิกใช้', 'last used in 2015 or earlier'],
  stable: ['Stable', 'คงที่', 'change of less than 20 points']};
const TREND_ORDER = ['new', 'rising', 'declining', 'abandoned', 'stable'];
let lang = 'both', topic = 'all', open = {};
try { const s = JSON.parse(localStorage.getItem('smote25-roadmap') || '{}'); if (s.lang) lang = s.lang; if (s.topic) topic = s.topic; } catch (e) {}
const save = () => { try { localStorage.setItem('smote25-roadmap', JSON.stringify({lang: lang, topic: topic})); } catch (e) {} };
const bi = (en, th) => '<span class="el">' + esc(en) + '</span><span class="tl' + (th === en ? ' tl-same' : '') + '">' + esc(th) + '</span>';
const pair = (en, th) => '<div class="pair"><p class="en">' + en + '</p><p class="th">' + th + '</p></div>';
const chip = t => '<span class="chip t-' + t + '">' + bi(TREND[t][0], TREND[t][1]) + '</span>';
const shortOf = k => BY[k] ? BY[k].short + ' ' + BY[k].year : k;

function strip(keys) {
  const w = 230, h = 30, x0 = 1996.5, x1 = 2026.5, X = y => 6 + (w - 12) * (y - x0) / (x1 - x0);
  let s = '<svg width="' + w + '" height="' + h + '" viewBox="0 0 ' + w + ' ' + h + '" role="img" aria-label="years of the studies that used this practice">';
  s += '<line x1="6" x2="' + (w - 6) + '" y1="' + (h - 5) + '" y2="' + (h - 5) + '" stroke-width="1" style="stroke:var(--tick)" />';
  [2000, 2010, 2020].forEach(y => { s += '<line x1="' + X(y) + '" x2="' + X(y) + '" y1="2" y2="' + (h - 5) + '" style="stroke:var(--grid)" />'; });
  D.emp.forEach(p => { s += '<circle cx="' + X(p.year) + '" cy="' + (h - 5) + '" r="1.6" style="fill:var(--tick)" />'; });
  const seen = {};
  keys.forEach(k => { const p = BY[k]; if (!p) return; seen[p.year] = (seen[p.year] || 0) + 1; const cy = h - 5 - 6 * (seen[p.year] - 1) - 4;
    s += '<circle cx="' + X(p.year) + '" cy="' + Math.max(3, cy) + '" r="3" style="fill:var(--dot)"><title>' + esc(p.short + ' ' + p.year) + '</title></circle>'; });
  return s + '</svg>';
}
function cell(r, e) {
  const sh = r.share[e], n = r.by_era[e], N = D.era_n[e];
  return '<div class="cell' + (sh >= 55 ? ' hi' : '') + '" title="' + esc(n + ' of ' + N + ' studies in ' + ERA_EN[e]) + '"><i style="width:' + sh + '%"></i><span><b>' + sh + '%</b><em>' + n + '/' + N + '</em></span></div>';
}
function changes() {
  return '<section class="panel"><h2>What changed <span class="th">อะไรเปลี่ยนไปบ้าง</span></h2>' +
    pair('Each practice is labelled by comparing its share of studies in 1997–2009 with its share in 2021–2026. A practice first used in 2016 or later is new; one last used in 2015 or earlier is abandoned.',
      'แต่ละแนวปฏิบัติถูกจัดกลุ่มโดยเทียบสัดส่วนงานที่ใช้ในช่วง 1997–2009 กับช่วง 2021–2026 แนวปฏิบัติที่เริ่มใช้ตั้งแต่ปี 2016 เป็นต้นมาถือว่าเกิดขึ้นใหม่ ส่วนแนวปฏิบัติที่ใช้ครั้งสุดท้ายในปี 2015 หรือก่อนหน้าถือว่าเลิกใช้') +
    '<div class="changes">' + TREND_ORDER.filter(t => t !== 'stable').map(t => {
      const rows = D.roadmap.filter(r => r.trend === t);
      return '<div class="chg"><h3>' + chip(t) + '<span class="note">' + rows.length + '</span></h3><ul>' + rows.map(r => '<li><b>' + bi(r.label, TH[r.label] || r.label) + '</b> · ' +
        (t === 'new' ? 'from ' + r.first : t === 'abandoned' ? r.first + '–' + r.last : r.share[ERAS[0]] + '% → ' + r.share[ERAS[3]] + '%') + '</li>').join('') + '</ul></div>';
    }).join('') + '</div>' +
    '<div class="periods">' + ERAS.map(e => '<span>' + ERA_EN[e] + ': ' + D.era_n[e] + ' studies</span>').join('') + '</div></section>';
}
function ledger() {
  const T = topic === 'all' ? TOPICS : TOPICS.filter(t => t[0] === topic);
  let h = '<section class="panel"><h2>Practice ledger <span class="th">ตารางแนวปฏิบัติรายช่วงเวลา</span></h2>' +
    pair('Shaded cells give the share of studies in each period that follow the practice. The strip places every study that follows it on a 1997–2026 axis; grey ticks mark all empirical studies. Select a practice to list its studies.',
      'ช่องแรเงาแสดงสัดส่วนของงานในแต่ละช่วงที่ใช้แนวปฏิบัตินั้น แถบจุดวางงานทุกเรื่องที่ใช้แนวปฏิบัตินั้นบนแกนปี 1997–2026 ขีดสีเทาคืองานเชิงทดลองทั้งหมด เลือกแนวปฏิบัติเพื่อดูรายชื่องาน') +
    '<div class="tabs" role="group" aria-label="Topic"><button id="tp-all" data-topic="all" aria-pressed="' + (topic === 'all') + '">' + bi('All', 'ทั้งหมด') + '</button>' +
    TOPICS.map(t => '<button id="tp-' + t[0] + '" data-topic="' + t[0] + '" aria-pressed="' + (topic === t[0]) + '">' + bi(t[1], t[2]) + '</button>').join('') + '</div>' +
    '<div class="scroll"><table class="rm"><thead><tr><th>' + bi('Practice', 'แนวปฏิบัติ') + '</th>' + ERAS.map(e => '<th>' + ERA_EN[e] + '<small>n = ' + D.era_n[e] + '</small></th>').join('') +
    '<th>' + bi('Studies over time', 'งานตามช่วงเวลา') + '<small>1997 · 2026</small></th><th>' + bi('First', 'ครั้งแรก') + '</th><th>' + bi('Last', 'ครั้งล่าสุด') + '</th><th>' + bi('Trend', 'แนวโน้ม') + '</th></tr></thead><tbody>';
  T.forEach(t => {
    h += '<tr class="topic"><td colspan="9">' + bi(t[1], t[2]) + '</td></tr>';
    D.roadmap.filter(r => r.topic === t[0]).forEach((r, i) => {
      const id = t[0] + '-' + i, isOpen = !!open[id];
      h += '<tr class="' + (isOpen ? 'open' : '') + '"><td><button class="rowbtn" id="row-' + id + '" data-row="' + id + '" aria-expanded="' + isOpen + '">' + bi(r.label, TH[r.label] || r.label) + '</button><span class="note">' + r.n + ' studies</span></td>' +
        ERAS.map(e => '<td>' + cell(r, e) + '</td>').join('') + '<td class="strip">' + strip(r.keys || []) + '</td>' +
        '<td class="yr">' + (r.first || '–') + '<small>' + esc(r.first_key ? shortOf(r.first_key) : '') + '</small></td><td class="yr">' + (r.last || '–') + '<small>' + esc(r.last_key ? shortOf(r.last_key) : '') + '</small></td><td>' + chip(r.trend) + '</td></tr>';
      if (isOpen) h += '<tr class="detail"><td colspan="9"><div class="who">' + (r.keys || []).map(k => '<span>' + esc(shortOf(k)) + '</span>').join('') + '</div></td></tr>';
    });
  });
  return h + '</tbody></table></div><p class="note">' + bi('Counts come from the coded evaluation designs of the 71 empirical studies. Reasons, direct measures and the explicit or implied selection of settings come from the second, page-referenced reading.', 'ตัวเลขมาจากการลงรหัสการออกแบบการประเมินผลของงานเชิงทดลอง 71 เรื่อง ส่วนเหตุผล การวัดโดยตรง และการเลือกค่าบนข้อมูลประเมินมาจากการอ่านรอบที่สองที่มีเลขหน้ากำกับ') + '</p></section>';
}
function leaders() {
  const rows = ERAS.map(e => {
    const E = D.emp.filter(p => p.era === e && p.cpy != null && p.year <= 2024).sort((a, b) => b.cpy - a.cpy).slice(0, 3);
    return '<tr class="era"><td colspan="8">' + ERA_EN[e] + '</td></tr>' + E.map(p => '<tr><td><b>' + esc(p.short) + '</b> ' + p.year + '</td><td class="r">' + big(p.cites) + '</td><td class="r">' + p.cpy.toFixed(1) + '</td><td class="r">' + (p.n_real == null ? 'n/a' : p.n_real) + '</td><td class="r">' + p.n_clf + '</td><td>' + esc(p.test_class) + '</td><td>' + esc(p.tuning_class === 'Unclear' ? 'Not stated' : p.tuning_class) + '</td><td>' + (p.has_code ? 'yes' : 'no') + '</td></tr>').join('');
  }).join('');
  return '<section class="panel"><h2>Most cited studies of each period <span class="th">งานที่ถูกอ้างอิงมากที่สุดในแต่ละช่วง</span></h2>' +
    pair('Citations from OpenAlex, retrieved ' + esc(D.retrieved) + ', divided by years since publication. Studies from 2025 and 2026 are left out because their counts are too young. The most cited studies of the early periods used few datasets and seldom tested; later leaders test more but are cited far less, in part because they are younger.',
      'จำนวนการอ้างอิงจาก OpenAlex ดึงเมื่อ ' + esc(D.retrieved) + ' หารด้วยจำนวนปีนับจากปีที่ตีพิมพ์ ไม่รวมงานปี 2025 และ 2026 เพราะยังใหม่เกินไป งานที่ถูกอ้างอิงมากที่สุดในช่วงแรกใช้ชุดข้อมูลน้อยและแทบไม่ทดสอบทางสถิติ งานที่นำในช่วงหลังทดสอบมากขึ้นแต่ถูกอ้างอิงน้อยกว่ามาก ส่วนหนึ่งเพราะยังใหม่') +
    '<div class="scroll" style="margin-top:12px"><table class="lead"><thead><tr><th>' + bi('Study', 'งาน') + '</th><th class="r">' + bi('Citations', 'การอ้างอิง') + '</th><th class="r">' + bi('Per year', 'ต่อปี') + '</th><th class="r">' + bi('Real datasets', 'ชุดข้อมูลจริง') + '</th><th class="r">' + bi('Learners', 'ตัวจำแนก') + '</th><th>' + bi('Test', 'การทดสอบ') + '</th><th>' + bi('Settings', 'การเลือกค่า') + '</th><th>' + bi('Code', 'โค้ด') + '</th></tr></thead><tbody>' + rows + '</tbody></table></div></section>';
}
function families() {
  const F = D.families.slice(0, 12);
  return '<section class="panel"><h2>Dataset families by period <span class="th">ตระกูลชุดข้อมูลตามช่วงเวลา</span></h2>' +
    '<p class="warn">' + bi('Exploratory. Built from the draft extraction of the Data section, whose rows have not been verified against the papers. Do not quote these counts in the manuscript.', 'สำรวจเบื้องต้น สร้างจากข้อมูลที่ Data section สกัดไว้ในรอบร่างซึ่งยังไม่ได้ตรวจกับต้นฉบับ ห้ามอ้างตัวเลขเหล่านี้ในบทความ') + '</p>' +
    '<div class="scroll" style="margin-top:12px"><table class="lead"><thead><tr><th>' + bi('Family', 'ตระกูล') + '</th><th class="r">' + bi('Studies', 'งาน') + '</th>' + ERAS.map(e => '<th class="r">' + ERA_EN[e] + '</th>').join('') + '<th class="r">' + bi('First', 'ครั้งแรก') + '</th><th class="r">' + bi('Last', 'ครั้งล่าสุด') + '</th></tr></thead><tbody>' +
    F.map(f => '<tr><td><b>' + esc(f.family) + '</b></td><td class="r">' + f.n + '</td>' + ERAS.map(e => '<td class="r">' + f.by_era[e] + '</td>').join('') + '<td class="r">' + f.first + '</td><td class="r">' + f.last + '</td></tr>').join('') + '</tbody></table></div></section>';
}
function foot() {
  return '<section class="foot"><div>' + bi('Trend labels: ', 'ความหมายของแนวโน้ม: ') + TREND_ORDER.map(t => '<b>' + TREND[t][0] + '</b> ' + TREND[t][2]).join(' · ') + '.</div>' +
    '<div>' + bi('Source: SMOTE25 Section 7 coded data (76 papers, 71 empirical), second reading with page references, OpenAlex citation counts. Companion to the Section 7 draft.', 'ที่มา: ข้อมูลที่ลงรหัสสำหรับหัวข้อที่ 7 ของ SMOTE25 (76 เรื่อง เชิงทดลอง 71 เรื่อง) การอ่านรอบที่สองที่มีเลขหน้ากำกับ และจำนวนการอ้างอิงจาก OpenAlex') + '</div></section>';
}
function render() {
  document.body.classList.remove('lang-both', 'lang-en', 'lang-th'); document.body.classList.add('lang-' + lang);
  document.querySelectorAll('[data-lang]').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.lang === lang)));
  document.getElementById('app').innerHTML = findings() + changes() + ledger() + leaders() + families() + foot();
}
document.addEventListener('click', e => {
  const l = e.target.closest('[data-lang]'); if (l) { lang = l.dataset.lang; save(); render(); return; }
  const t = e.target.closest('[data-topic]'); if (t) { topic = t.dataset.topic; save(); render(); document.getElementById('tp-' + topic).focus(); return; }
  const r = e.target.closest('[data-row]'); if (r) { const id = r.dataset.row; open[id] = !open[id]; render(); const b = document.getElementById('row-' + id); if (b) b.focus(); }
});
render();
})();
