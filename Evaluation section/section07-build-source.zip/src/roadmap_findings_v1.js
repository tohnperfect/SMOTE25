/* ---------------- findings and the evidence behind them ---------------- */
const F = D.F;
const fmt1 = x => x == null ? 'n/a' : (Math.round(x * 10) / 10).toString();
const pctOf = (a, b) => b ? Math.round(100 * a / b) : 0;
const quoteHTML = e => e && e.quote ? '<blockquote class="qt">“' + esc(e.quote) + '”<cite>' + esc(e.short || '') + (e.where ? ' · ' + esc(e.where) : '') + '</cite></blockquote>' : '';
const step = (n, en, th) => '<h4 class="ev"><span class="evn">' + n + '</span>' + bi(en, th) + '</h4>';
const REASON = {
  varied_characteristics: ['range of IR, size or dimension', 'ครอบคลุม IR ขนาด หรือจำนวนมิติ'], imbalance_level: ['a target imbalance level', 'ระดับความไม่สมดุลที่ต้องการ'],
  follows_prior_work: ['set-up of a named earlier study', 'ตามการทดลองของงานก่อนหน้า'], difficulty_factors: ['overlap, noise or small disjuncts', 'การซ้อนทับ สัญญาณรบกวน หรือกลุ่มย่อยเล็ก'],
  comparability: ['comparable with published results', 'เทียบกับผลที่ตีพิมพ์แล้วได้'], public_benchmark: ['publicly available', 'เปิดเผยต่อสาธารณะ'],
  application_domain: ['an application domain', 'โดเมนการใช้งาน'], multiclass_availability: ['many classes', 'มีหลายคลาส'],
  popular: ['widely used or well known', 'นิยมใช้หรือเป็นที่รู้จัก'], diverse_paradigms: ['different learning paradigms', 'ครอบคลุมกระบวนทัศน์การเรียนรู้ต่างกัน'],
  simplicity: ['simple, fast or interpretable', 'เรียบง่าย เร็ว หรือตีความได้'], fair_comparison: ['same learner for all methods', 'ใช้ตัวจำแนกเดียวกันกับทุกวิธี'],
  matches_mechanism: ['matches how the method works', 'สอดคล้องกับกลไกของวิธี'], sensitive_to_imbalance: ['sensitive to class imbalance', 'ไวต่อความไม่สมดุลของคลาส']};
const KIND = {toy_2d_visualization: ['2-D plots of synthetic points', 'กราฟสองมิติของตัวอย่างสังเคราะห์'], projection_visualization: ['PCA or t-SNE projections', 'ภาพฉาย PCA หรือ t-SNE'],
  theoretical_analysis: ['theorems or bounds', 'ทฤษฎีบทหรือขอบเขต'], complexity_analysis: ['big-O cost', 'ความซับซ้อนเชิงเวลา'], distribution_distance: ['distance or likelihood between distributions', 'ระยะห่างหรือ likelihood ระหว่างการแจกแจง'],
  privacy_or_fidelity: ['fidelity or privacy', 'ความเที่ยงตรงหรือความเป็นส่วนตัว'], noise_count: ['synthetic examples removed as noise', 'ตัวอย่างสังเคราะห์ที่ถูกลบเป็นสัญญาณรบกวน'],
  example_type_analysis: ['safe, borderline or hard composition', 'สัดส่วนตัวอย่าง safe, borderline หรือตัวอย่างยาก'], diversity_measure: ['diversity of ensemble members', 'ความหลากหลายของสมาชิก ensemble']};
const DATA_USED = {'evaluation data': ['evaluation data (the folds that are reported)', 'ข้อมูลที่ใช้ประเมิน (fold ที่รายงานผล)'], 'inner validation (training data only)': ['inner validation inside the training data', 'ข้อมูลตรวจสอบภายในข้อมูลฝึก'],
  'not stated': ['not stated', 'ไม่ระบุ'], 'other': ['separate tuning datasets', 'ชุดข้อมูลปรับจูนที่แยกต่างหาก']};

function bars(items, max, cls) {
  max = max || Math.max.apply(null, items.map(i => i.n)) || 1;
  return '<div class="bars ' + (cls || '') + '">' + items.map(i => '<div class="bar" title="' + esc(i.title || (i.en + ': ' + i.n)) + '"><span class="bl">' + bi(i.en, i.th || i.en) + '</span><span class="bt"><i style="width:' + (100 * i.n / max).toFixed(1) + '%;background:var(' + (i.c || '--c1') + ')"></i></span><span class="bv">' + i.n + (i.of ? '<em>/' + i.of + '</em>' : '') + '</span></div>').join('') + '</div>';
}
const LX = v => (Math.log(Math.min(10, Math.max(0.1, v))) - Math.log(0.1)) / (Math.log(10) - Math.log(0.1)) * 100;
function forestHTML(rows) {
  const topics = {data: ['Data', 'ข้อมูล'], learners: ['Learners and competitors', 'ตัวจำแนกและคู่เทียบ'], measures: ['Measures', 'ตัวชี้วัด'], protocol: ['Protocol and tuning', 'โปรโตคอลและการปรับจูน'], stats: ['Statistical testing', 'การทดสอบทางสถิติ'], reporting: ['Reporting', 'การรายงานผล'], outcomes: ['Outcomes', 'ผลลัพธ์']};
  let h = '<div class="forest"><div class="fr fh"><span></span><span class="ft">' + [0.1, 0.25, 0.5, 1, 2, 4, 10].map(t => '<b style="left:' + LX(t) + '%">' + t + '</b>').join('') + '</span><span class="fn">' + bi('n / 62', 'n / 62') + '</span></div>';
  Object.keys(topics).forEach(t => {
    h += '<div class="fr ftop"><span>' + bi(topics[t][0], topics[t][1]) + '</span><span></span><span></span></div>';
    rows.filter(r => r.topic === t && r.ratio != null).forEach(r => {
      const sig = r.lo > 1 || r.hi < 1, c = sig ? '--c2' : '--c1';
      const tip = r.en + ': ratio ' + r.ratio.toFixed(2) + ' (95% CI ' + r.lo.toFixed(2) + ' to ' + r.hi.toFixed(2) + '); median citations per year ' + fmt1(r.med_cpy_users) + ' for the ' + r.n_users + ' studies that follow it vs ' + fmt1(r.med_cpy_other) + ' for the others';
      h += '<div class="fr" title="' + esc(tip) + '"><span class="fl">' + bi(r.en, r.th) + '</span><span class="ftrack"><i class="one"></i><i class="ci" style="left:' + LX(r.lo) + '%;width:' + (LX(r.hi) - LX(r.lo)) + '%;background:var(' + c + ')"></i><i class="pt" style="left:' + LX(r.ratio) + '%;background:var(' + c + ')"></i></span><span class="fn">' + r.n_users + '<em> · ' + r.ratio.toFixed(2) + '</em></span></div>';
    });
  });
  return h + '<div class="fr fh"><span></span><span class="ft ftl"><b style="left:0">' + bi('cited less', 'ถูกอ้างอิงน้อยกว่า') + '</b><b style="left:100%;transform:translateX(-100%)">' + bi('cited more', 'ถูกอ้างอิงมากกว่า') + '</b></span><span></span></div></div>';
}
function scatterSVG(pts, line) {
  const w = 640, h = 280, L = 52, R = 14, T = 12, B = 34, x0 = 1996, x1 = 2025, y1 = Math.log10(40000);
  const X = y => L + (w - L - R) * (y - x0) / (x1 - x0), Y = c => T + (h - T - B) * (1 - Math.log10(1 + c) / y1);
  let s = '<div class="scroll"><svg viewBox="0 0 ' + w + ' ' + h + '" class="sc" role="img" aria-label="Citations against publication year, log scale">';
  [1, 10, 100, 1000, 10000].forEach(v => { s += '<line x1="' + L + '" x2="' + (w - R) + '" y1="' + Y(v) + '" y2="' + Y(v) + '" style="stroke:var(--grid)" /><text x="' + (L - 6) + '" y="' + (Y(v) + 4) + '" text-anchor="end" font-size="11" style="fill:var(--muted)">' + big(v) + '</text>'; });
  [2000, 2005, 2010, 2015, 2020, 2024].forEach(v => { s += '<text x="' + X(v) + '" y="' + (h - 12) + '" text-anchor="middle" font-size="11" style="fill:var(--muted)">' + v + '</text>'; });
  const ly = yr => Math.expm1(line[0] + line[1] * yr);
  s += '<line x1="' + X(1997) + '" y1="' + Y(ly(1997)) + '" x2="' + X(2024) + '" y2="' + Y(ly(2024)) + '" stroke-width="2" stroke-dasharray="5 4" style="stroke:var(--ink-2)" />';
  pts.slice().sort((a, b) => a.issue - b.issue).forEach(p => {
    const c = p.issue ? '--c2' : '--c1';
    s += '<circle cx="' + X(p.year) + '" cy="' + Y(p.cites) + '" r="' + (p.issue ? 5.5 : 4.5) + '" stroke-width="2" style="fill:var(' + c + ');stroke:var(--paper)"><title>' + esc(p.short + ' ' + p.year + ': ' + big(p.cites) + ' citations' + (p.issue ? ' (measure-definition problem)' : '')) + '</title></circle>';
  });
  const lab = ['SMOTE-2002', 'ADASYN-2008', 'ROS-Buda-2018'];
  pts.filter(p => lab.indexOf(p.key) >= 0).forEach(p => { const rt = p.year >= 2020; s += '<text x="' + (X(p.year) + (rt ? -8 : 8)) + '" y="' + (Y(p.cites) + 4) + '" font-size="11"' + (rt ? ' text-anchor="end"' : '') + ' style="fill:var(--ink-2)">' + esc(p.short) + '</text>'; });
  return s + '</svg></div>';
}
function tableHTML(head, rows, cls) {
  return '<div class="scroll"><table class="lead ' + (cls || '') + '"><thead><tr>' + head.map(h => '<th' + (h[2] ? ' class="r"' : '') + '>' + bi(h[0], h[1]) + '</th>').join('') + '</tr></thead><tbody>' +
    rows.map(r => '<tr>' + r.map((v, i) => '<td' + (head[i] && head[i][2] ? ' class="r"' : '') + '>' + v + '</td>').join('') + '</tr>').join('') + '</tbody></table></div>';
}
const infRow = k => F.cites.influence.find(r => r.key === k);
const infTxt = r => r.ratio.toFixed(2) + ', 95% CI ' + r.lo.toFixed(2) + '–' + r.hi.toFixed(2);
const infCell = r => r.ratio.toFixed(2) + ' (' + r.lo.toFixed(2) + '–' + r.hi.toFixed(2) + ')';
const verdict = (en, th) => '<div class="verdict">' + pair(en, th) + '</div>';
const caveat = (en, th) => '<div class="caveat"><b>' + bi('Limits of this evidence', 'ข้อจำกัดของหลักฐานนี้') + '</b>' + pair(en, th) + '</div>';

function finding1() {
  const f = F.cites, tp = f.top_profile, rp = f.rest_profile, mi = infRow('metric_issue'), cd = infRow('code'), sb = infRow('smote_base');
  const sig = f.influence.filter(r => r.ratio != null && (r.lo > 1 || r.hi < 1)).length, nComp = f.influence.filter(r => r.ratio != null).length;
  let h = '<section class="panel finding" id="f-cites"><div class="fhead"><span class="fno">1</span><h2>' + bi('Citations do not follow the rigour of the evaluation', 'จำนวนการอ้างอิงไม่ได้ตามความรัดกุมของการประเมินผล') + '</h2></div>';
  h += verdict('Highly cited SMOTE-family studies were mostly evaluated on small designs, and once age is accounted for no practice of protocol, tuning or testing is associated with citations. The one clear association is negative: studies with a measure-definition problem are cited about a third as often.',
    'งานตระกูล SMOTE ที่ถูกอ้างอิงมากส่วนใหญ่ประเมินผลด้วยการออกแบบขนาดเล็ก และเมื่อคำนึงถึงอายุของบทความแล้ว ไม่มีแนวปฏิบัติด้านโปรโตคอล การปรับจูน หรือการทดสอบใดที่สัมพันธ์กับการอ้างอิง ความสัมพันธ์ที่ชัดเจนมีเพียงทางลบ คืองานที่นิยามตัวชี้วัดผิดถูกอ้างอิงประมาณหนึ่งในสาม');
  h += step('A', 'How it was measured', 'วิธีวัด') + pair(
    'Citation counts come from OpenAlex, retrieved ' + esc(f.retrieved) + '. ' + f.found + ' of the ' + f.all + ' papers have a record; the AAAI 2006 version of Global-CS does not. Raw counts cannot be compared across years because older papers have had longer to be cited: across the ' + f.eligible + ' empirical studies published up to 2024, each extra year of age multiplies the expected count by ' + f.year_ratio.toFixed(2) + ' (dashed line in step C). For each practice we fit log(1 + citations) = a + b·year + c·practice and report the citation ratio exp(c) with a 95% interval: 2 means cited twice as often as studies of the same year without the practice, 0.5 half as often. The ' + f.young + ' studies from 2025 and 2026 are left out because their counts are too young.',
    'จำนวนการอ้างอิงมาจาก OpenAlex ดึงเมื่อ ' + esc(f.retrieved) + ' มีข้อมูล ' + f.found + ' จาก ' + f.all + ' เรื่อง (ไม่มีเฉพาะ Global-CS ฉบับ AAAI 2006) เปรียบเทียบจำนวนดิบข้ามปีไม่ได้ เพราะบทความเก่ามีเวลาถูกอ้างอิงนานกว่า ในงานเชิงทดลอง ' + f.eligible + ' เรื่องที่ตีพิมพ์ถึงปี 2024 อายุที่มากขึ้นทุกหนึ่งปีทำให้จำนวนที่คาดไว้คูณด้วย ' + f.year_ratio.toFixed(2) + ' (เส้นประในขั้น C) สำหรับแต่ละแนวปฏิบัติ เราประมาณ log(1 + จำนวนการอ้างอิง) = a + b·ปี + c·แนวปฏิบัติ แล้วรายงานอัตราส่วนการอ้างอิง exp(c) พร้อมช่วงความเชื่อมั่น 95% ค่า 2 หมายถึงถูกอ้างอิงเป็นสองเท่าของงานปีเดียวกันที่ไม่ได้ใช้แนวปฏิบัตินั้น ค่า 0.5 คือครึ่งหนึ่ง งาน ' + f.young + ' เรื่องจากปี 2025 และ 2026 ไม่นำมาคิดเพราะยังใหม่เกินไป');
  h += step('B', 'The ten most cited studies against the rest', 'งาน 10 เรื่องที่ถูกอ้างอิงมากที่สุดเทียบกับงานที่เหลือ') +
    tableHTML([['Study', 'งาน'], ['Year', 'ปี', 1], ['Citations', 'การอ้างอิง', 1], ['Per year', 'ต่อปี', 1], ['Real datasets', 'ชุดข้อมูลจริง', 1], ['Learners', 'ตัวจำแนก', 1], ['Test', 'การทดสอบ'], ['Code', 'โค้ด']],
      f.top.map(p => ['<b>' + esc(p.short) + '</b>', p.year, big(p.cites), fmt1(p.cpy), p.n_real == null ? 'n/a' : p.n_real, p.n_clf, esc(p.test), p.code ? 'yes' : 'no'])) +
    tableHTML([['Group', 'กลุ่ม'], ['Studies', 'งาน', 1], ['Published before 2010', 'ตีพิมพ์ก่อน 2010', 1], ['Median datasets', 'มัธยฐานชุดข้อมูล', 1], ['One learner', 'ตัวจำแนกตัวเดียว', 1], ['Any test', 'มีการทดสอบ', 1], ['Corrected or Bayesian', 'ปรับแก้หรือแบบเบย์', 1], ['Code', 'โค้ด', 1], ['Median cites/yr', 'มัธยฐานการอ้างอิงต่อปี', 1]],
      [[bi('Ten most cited', '10 เรื่องที่ถูกอ้างอิงมากที่สุด'), tp.n, tp.pre2010, tp.med_ds, tp.single, tp.test, tp.corr, tp.code, fmt1(tp.med_cpy)], [bi('Other eligible studies', 'งานอื่นที่นำมาคิด'), rp.n, rp.pre2010, rp.med_ds, rp.single + ' (' + pctOf(rp.single, rp.n) + '%)', rp.test + ' (' + pctOf(rp.test, rp.n) + '%)', rp.corr + ' (' + pctOf(rp.corr, rp.n) + '%)', rp.code + ' (' + pctOf(rp.code, rp.n) + '%)', fmt1(rp.med_cpy)]], 'sum') +
    pair('The most cited group is older and was evaluated on fewer datasets, with fewer tests and almost no released code. Their influence comes from being early, simple methods that later studies use as competitors, not from how they were evaluated.',
      'กลุ่มที่ถูกอ้างอิงมากที่สุดเก่ากว่า ใช้ชุดข้อมูลน้อยกว่า ทดสอบทางสถิติน้อยกว่า และแทบไม่เผยแพร่โค้ด อิทธิพลของงานกลุ่มนี้มาจากการเป็นวิธีแรก ๆ ที่เรียบง่ายและถูกงานถัดมานำไปเป็นคู่เทียบ ไม่ได้มาจากวิธีประเมินผล');
  h += step('C', 'Citations against year', 'การอ้างอิงเทียบกับปีที่ตีพิมพ์') +
    '<div class="legend"><span><i style="background:var(--c1)"></i>' + bi('study', 'งาน') + '</span><span><i style="background:var(--c2)"></i>' + bi('measure-definition problem', 'นิยามตัวชี้วัดผิด') + '</span><span><i class="dash"></i>' + bi('fitted age trend', 'แนวโน้มตามอายุที่ประมาณได้') + '</span></div>' + scatterSVG(f.points, f.line) +
    pair('Each dot is one of the ' + f.eligible + ' studies (log scale). The dashed line is the age trend that every ratio below is measured against: a study above the line is cited more than its year predicts.',
      'จุดแต่ละจุดคืองานหนึ่งเรื่องใน ' + f.eligible + ' เรื่อง (สเกลลอการิทึม) เส้นประคือแนวโน้มตามอายุที่ใช้เป็นฐานของอัตราส่วนทั้งหมดด้านล่าง งานที่อยู่เหนือเส้นถูกอ้างอิงมากกว่าที่ปีของมันคาดไว้');
  h += step('D', 'Citation ratio of each practice', 'อัตราส่วนการอ้างอิงของแต่ละแนวปฏิบัติ') + forestHTML(f.influence) +
    pair(sig + ' of ' + nComp + (sig === 1 ? ' intervals excludes 1.' : ' intervals exclude 1.') + ' With ' + nComp + ' comparisons, about one would do so by chance, so the measure-definition result (' + infTxt(mi) + ') is suggestive rather than proven. Code release (' + infTxt(cd) + ') and including SMOTE as a competitor (' + infTxt(sb) + ') come close. Every practice of protocol, tuning and testing sits near 1. Hover a row for the median citations per year of each group.',
      'มี ' + sig + ' จาก ' + nComp + ' ช่วงที่ไม่ครอบคลุม 1 เมื่อเปรียบเทียบ ' + nComp + ' รายการ คาดได้ว่าจะมีราวหนึ่งรายการที่เป็นเช่นนั้นโดยบังเอิญ ผลเรื่องนิยามตัวชี้วัด (' + infTxt(mi) + ') จึงเป็นเพียงข้อบ่งชี้ ยังไม่ใช่ข้อพิสูจน์ การเผยแพร่โค้ด (' + infTxt(cd) + ') และการมี SMOTE เป็นคู่เทียบ (' + infTxt(sb) + ') ใกล้เกณฑ์ แนวปฏิบัติด้านโปรโตคอล การปรับจูน และการทดสอบทุกรายการอยู่ใกล้ 1 ชี้ที่แถวเพื่อดูมัธยฐานการอ้างอิงต่อปีของแต่ละกลุ่ม');
  h += step('E', 'The studies behind the one clear result', 'งานที่อยู่เบื้องหลังผลที่ชัดเจนเพียงรายการเดียว') +
    tableHTML([['Study', 'งาน'], ['Year', 'ปี', 1], ['Citations', 'การอ้างอิง', 1], ['Per year', 'ต่อปี', 1], ['Percentile in period', 'เปอร์เซ็นไทล์ในช่วงเวลา', 1], ['Problem', 'ปัญหา']],
      f.issue_rows.map(p => ['<b>' + esc(p.short) + '</b>', p.year, big(p.cites), fmt1(p.cpy), p.pct == null ? 'n/a' : p.pct, esc(p.problem)])) +
    pair('Median citations per year: ' + f.issue_med[0] + ' for these ' + f.issue_rows.length + ' studies against ' + f.issue_med[1] + ' for the other eligible studies. For code release the medians are ' + f.code_med[0] + ' against ' + f.code_med[1] + '.',
      'มัธยฐานการอ้างอิงต่อปี: ' + f.issue_med[0] + ' สำหรับงาน ' + f.issue_rows.length + ' เรื่องนี้ เทียบกับ ' + f.issue_med[1] + ' สำหรับงานอื่น สำหรับการเผยแพร่โค้ด มัธยฐานคือ ' + f.code_med[0] + ' เทียบกับ ' + f.code_med[1]);
  h += caveat('Associations, not effects. Venue, the novelty of the idea and the authors drive citations and are not controlled. OpenAlex counts are lower than Google Scholar\'s and some papers are split over several records (one merged here). The ratio for a practice used by only a handful of studies has a wide interval.',
    'เป็นความสัมพันธ์ ไม่ใช่ผลกระทบ แหล่งตีพิมพ์ ความใหม่ของแนวคิด และตัวผู้เขียนมีผลต่อการอ้างอิงแต่ไม่ได้ควบคุม จำนวนใน OpenAlex ต่ำกว่า Google Scholar และบางบทความถูกแยกเป็นหลายระเบียน (รวมไปแล้วหนึ่งรายการ) อัตราส่วนของแนวปฏิบัติที่มีงานใช้น้อยจะมีช่วงความเชื่อมั่นกว้าง');
  return h + '</section>';
}
function finding2() {
  const f = F.data, a = f.access;
  let h = '<section class="panel finding" id="f-data"><div class="fhead"><span class="fno">2</span><h2>' + bi('Data are chosen for coverage and passed down; the credit goes to the repositories', 'ข้อมูลถูกเลือกเพื่อความครอบคลุมและส่งต่อกันมา เครดิตตกอยู่กับคลังข้อมูล') + '</h2></div>';
  h += verdict(f.stated + ' of ' + f.n + ' studies say why they chose their data, and the reasons are about covering a range of imbalance, size and difficulty or about following an earlier study. The repositories that supply the data are among the most cited works in the field, but using them brings a study no extra citations. Most studies change the data they download and few release the changed versions.',
    f.stated + ' จาก ' + f.n + ' เรื่องระบุเหตุผลที่เลือกข้อมูล และเหตุผลเกี่ยวกับการครอบคลุมระดับความไม่สมดุล ขนาด และความยาก หรือการทำตามงานก่อนหน้า คลังข้อมูลที่เป็นแหล่งข้อมูลเป็นงานที่ถูกอ้างอิงมากที่สุดกลุ่มหนึ่ง แต่การใช้คลังเหล่านั้นไม่ได้ทำให้งานถูกอ้างอิงมากขึ้น งานส่วนใหญ่ดัดแปลงข้อมูลที่ดาวน์โหลดมา และน้อยเรื่องที่เผยแพร่ข้อมูลฉบับดัดแปลง');
  h += step('A', 'How it was measured', 'วิธีวัด') + pair('In a second reading of each paper, a data reason was coded only when the text ties a property of the data to the choice (a description of the data alone does not count), with a verbatim quote and the page. A study can give several reasons. Access was coded from the data section of each paper; citation counts of the repository papers come from OpenAlex.',
    'ในการอ่านรอบที่สอง เหตุผลด้านข้อมูลจะถูกบันทึกเฉพาะเมื่อเนื้อความโยงคุณสมบัติของข้อมูลกับการเลือก (การบรรยายข้อมูลเฉย ๆ ไม่นับ) พร้อมข้อความที่ยกมาและเลขหน้า งานหนึ่งให้ได้หลายเหตุผล การเข้าถึงข้อมูลบันทึกจากส่วนข้อมูลของแต่ละบทความ และจำนวนการอ้างอิงของบทความคลังข้อมูลมาจาก OpenAlex');
  h += step('B', 'Reasons given, with one example each', 'เหตุผลที่ให้ไว้ พร้อมตัวอย่างอย่างละหนึ่ง') +
    bars(f.reasons.map(r => ({en: REASON[r.code][0], th: REASON[r.code][1], n: r.n, of: f.n})), f.n) +
    '<div class="quotes">' + f.reasons.filter(r => r.ex).map(r => '<div><span class="qk">' + bi(REASON[r.code][0], REASON[r.code][1]) + '</span>' + quoteHTML(r.ex) + '</div>').join('') + '</div>' +
    '<p class="note">' + bi('No reason given (' + f.not_stated.length + '): ', 'ไม่ระบุเหตุผล (' + f.not_stated.length + '): ') + esc(f.not_stated.join(', ')) + '</p>';
  h += step('C', 'How collections are passed down', 'ชุดข้อมูลถูกส่งต่ออย่างไร') + '<div class="chains">' + f.chains.map(c => '<div class="chain"><div class="src">' + esc(c.source) + '</div>' + c.items.map(i => '<div class="ln"><span class="arrow">→</span><div><b>' + esc(i.short) + '</b>' + quoteHTML(i) + '</div></div>').join('') + '</div>').join('') + '</div>' +
    pair('Each arrow is a study that says, in its own words, where its benchmark came from. The KEEL multi-class sets picked for their difficulty factors in 2016 reappear in MC-RBO and MC-CCR and then in NROMM; EMDO reuses the AMDO sets in its first experiment.',
      'ลูกศรแต่ละตัวคืองานที่ระบุเองว่าชุดข้อมูลมาจากที่ใด ชุดข้อมูลหลายคลาสจาก KEEL ที่ถูกคัดเพราะปัจจัยความยากในปี 2016 ปรากฏอีกครั้งใน MC-RBO และ MC-CCR แล้วต่อไปยัง NROMM ส่วน EMDO ใช้ชุดข้อมูลของ AMDO ในการทดลองแรก');
  const maxC = Math.max.apply(null, f.repo.map(r => r.cites));
  h += step('D', 'Who collects the credit', 'ใครได้เครดิต') +
    bars(f.repo.map(r => ({en: r.label, th: r.label, n: r.cites, c: r.kind === 'method' ? '--c1' : '--c3', title: r.label + ': ' + big(r.cites) + ' citations'})), maxC, 'big') +
    '<div class="legend"><span><i style="background:var(--c3)"></i>' + bi('repository or tool', 'คลังข้อมูลหรือเครื่องมือ') + '</span><span><i style="background:var(--c1)"></i>' + bi('method in the corpus', 'วิธีในคลังบทความ') + '</span></div>' +
    tableHTML([['Practice', 'แนวปฏิบัติ'], ['Studies', 'งาน', 1], ['Median cites/yr, follow', 'มัธยฐานต่อปี ใช้', 1], ['Median cites/yr, others', 'มัธยฐานต่อปี ไม่ใช้', 1], ['Citation ratio (95% CI)', 'อัตราส่วน (95% CI)', 1]],
      ['keel', 'uci', 'many_ds', 'data_reason', 'private'].map(k => { const r = infRow(k); return [bi(r.en, r.th), r.n_users + '/' + r.n, fmt1(r.med_cpy_users), fmt1(r.med_cpy_other), infCell(r)]; })) +
    pair('The UCI and KEEL papers are cited thousands of times, yet studies that use KEEL or UCI data, use many datasets or explain their choice of data are cited about as often as studies of the same age that do not: every ratio is close to 1.',
      'บทความของ UCI และ KEEL ถูกอ้างอิงหลายพันครั้ง แต่งานที่ใช้ข้อมูลจาก KEEL หรือ UCI ใช้ชุดข้อมูลจำนวนมาก หรืออธิบายเหตุผลในการเลือกข้อมูล ถูกอ้างอิงพอ ๆ กับงานอายุเท่ากันที่ไม่ได้ทำ อัตราส่วนทุกค่าใกล้ 1');
  h += step('E', 'Downloadable is not reproducible', 'ดาวน์โหลดได้ไม่ได้แปลว่าทำซ้ำได้') +
    bars([{en: 'all real data public', th: 'ข้อมูลจริงเปิดเผยทั้งหมด', n: a.all_public, of: f.n}, {en: 'source given for each dataset', th: 'ระบุแหล่งของแต่ละชุดข้อมูล', n: a.per_src, of: f.n}, {en: 'links or repository IDs given', th: 'มีลิงก์หรือรหัสในคลัง', n: a.links, of: f.n},
      {en: 'data changed by the authors', th: 'ผู้เขียนดัดแปลงข้อมูล', n: a.modified, of: f.n, c: '--c2'}, {en: 'changed data released', th: 'เผยแพร่ข้อมูลที่ดัดแปลง', n: a.released.length, of: f.n, c: '--c2'}], f.n) +
    '<p class="note">' + bi('Released changed data: ', 'เผยแพร่ข้อมูลที่ดัดแปลง: ') + esc(a.released.join(', ')) + '. ' + bi('Changes include binarising classes, merging classes, injecting noise and subsampling to raise the imbalance ratio.', 'การดัดแปลงได้แก่ การแปลงเป็นสองคลาส การรวมคลาส การใส่สัญญาณรบกวน และการสุ่มตัดเพื่อเพิ่ม IR') + '</p>';
  h += caveat('Reasons are what the papers say, not why the authors really chose the data. The reuse chains are those the papers state; unstated reuse is not counted. The independent check confirmed the MC-RBO, MC-CCR, NROMM and SMOTE-IPF statements and narrowed the EMDO one to its first experiment.',
    'เหตุผลคือสิ่งที่บทความเขียนไว้ ไม่ใช่เหตุผลที่แท้จริงของผู้เขียน สายการส่งต่อนับเฉพาะที่บทความระบุ การนำมาใช้ซ้ำที่ไม่ได้ระบุไม่ถูกนับ การตรวจซ้ำยืนยันข้อความของ MC-RBO, MC-CCR, NROMM และ SMOTE-IPF และแก้ข้อความของ EMDO ให้แคบลงเหลือการทดลองแรก');
  return h + '</section>';
}
function finding3() {
  const f = F.beyond, g = f.groups, inf = f.inf_direct;
  let h = '<section class="panel finding" id="f-beyond"><div class="fhead"><span class="fno">3</span><h2>' + bi('Every study judges resampling through a classifier', 'ทุกงานตัดสินการปรับสมดุลผ่านตัวจำแนก') + '</h2></div>';
  h += verdict('None of the ' + f.n + ' studies evaluates a resampler without training a classifier on its output. Other evidence is common but mostly pictures and analysis; only ' + g.direct + ' studies measure the resampled data directly.',
    'ไม่มีงานใดใน ' + f.n + ' เรื่องที่ประเมินวิธีปรับสมดุลโดยไม่ฝึกตัวจำแนกด้วยข้อมูลที่ได้ หลักฐานแบบอื่นพบบ่อยแต่ส่วนใหญ่เป็นภาพและการวิเคราะห์ มีเพียง ' + g.direct + ' เรื่องที่วัดข้อมูลหลังปรับสมดุลโดยตรง');
  h += step('A', 'How it was measured', 'วิธีวัด') + pair('Every result that is not a classifier score was recorded with its figure or table and page, then grouped. Hand-drawn schematics and plots of the original data only are not counted. A study can appear in several groups.',
    'ผลทุกอย่างที่ไม่ใช่คะแนนของตัวจำแนกถูกบันทึกพร้อมรูปหรือตารางและเลขหน้า แล้วจัดกลุ่ม ภาพวาดแผนผังและกราฟของข้อมูลต้นฉบับอย่างเดียวไม่นับ งานหนึ่งอยู่ได้หลายกลุ่ม');
  h += step('B', 'Kinds of evidence beyond classifier scores', 'ประเภทหลักฐานนอกเหนือจากคะแนนของตัวจำแนก') +
    bars([{en: 'visual: 2-D plots, projections, histograms', th: 'ภาพ: กราฟสองมิติ ภาพฉาย ฮิสโทแกรม', n: g.visual, of: f.n}, {en: 'analytical: theorems, bounds, big-O', th: 'การวิเคราะห์: ทฤษฎีบท ขอบเขต big-O', n: g.analytic, of: f.n},
      {en: 'model diagnostics without a score', th: 'การวินิจฉัยแบบจำลองที่ไม่ใช่คะแนน', n: g.model, of: f.n}, {en: 'direct measurement of resampled data', th: 'วัดข้อมูลหลังปรับสมดุลโดยตรง', n: g.direct, of: f.n, c: '--c2'},
      {en: 'classifier scores only', th: 'มีเพียงคะแนนของตัวจำแนก', n: g.none, of: f.n}, {en: 'evaluation without any classifier', th: 'ประเมินโดยไม่ใช้ตัวจำแนกเลย', n: f.without_classifier, of: f.n}], f.n) +
    '<p class="note">' + bi('By kind of evidence (a study can report several):', 'แยกตามชนิดของหลักฐาน (งานหนึ่งรายงานได้หลายชนิด):') + '</p>' +
    bars(Object.keys(KIND).filter(k => f.kinds[k]).map(k => ({en: KIND[k][0], th: KIND[k][1], n: f.kinds[k], of: f.n})), f.n);
  h += step('C', 'The studies that measure the data directly', 'งานที่วัดข้อมูลโดยตรง') +
    tableHTML([['Study', 'งาน'], ['What is measured', 'สิ่งที่วัด'], ['Where', 'ตำแหน่ง'], ['Check', 'ตรวจซ้ำ']], f.direct.map(p => ['<b>' + esc(p.short) + '</b>', esc(p.kinds.map(k => KIND[k][0]).join('; ')) + '<div class="sub">' + esc(p.details) + '</div>', esc(p.where), esc(p.check || '')])) +
    pair('These measures can show why a sampler helps or fails on a dataset: whether synthetic points match the minority distribution, land among the majority, or are removed again as noise. The ' + inf.n_users + ' eligible studies among them are cited more than their age predicts (' + infTxt(inf) + '), but with so few studies the interval is wide.',
      'การวัดแบบนี้บอกได้ว่าทำไมวิธีหนึ่งจึงช่วยหรือไม่ช่วยกับชุดข้อมูลหนึ่ง เช่น ตัวอย่างสังเคราะห์ตรงกับการแจกแจงของคลาสส่วนน้อยหรือไม่ ตกไปอยู่ในบริเวณคลาสส่วนมากหรือไม่ หรือถูกลบออกเป็นสัญญาณรบกวน งาน ' + inf.n_users + ' เรื่องในกลุ่มนี้ที่นำมาคิดได้ถูกอ้างอิงมากกว่าที่อายุคาดไว้ (' + infTxt(inf) + ') แต่จำนวนงานน้อยมาก ช่วงความเชื่อมั่นจึงกว้าง');
  h += step('D', 'Model diagnostics that do not use a score', 'การวินิจฉัยแบบจำลองที่ไม่ใช้คะแนน') +
    tableHTML([['Study', 'งาน'], ['What is reported', 'สิ่งที่รายงาน'], ['Where', 'ตำแหน่ง']], f.model.map(p => ['<b>' + esc(p.short) + '</b>', esc(p.details), esc(p.where)])) +
    '<p class="note">' + bi('Classifier scores only (' + f.none.length + '): ', 'มีเพียงคะแนนของตัวจำแนก (' + f.none.length + '): ') + esc(f.none.join(', ')) + '</p>';
  h += caveat('The independent check confirmed the CTGAN likelihood fitness and the GAMO FID, and noted that the CISO MMD result goes against CISO itself and that GLOS plots its composition counts next to classifier scores. A 2-D plot is evidence of where points fall, not a measurement.',
    'การตรวจซ้ำยืนยัน likelihood fitness ของ CTGAN และ FID ของ GAMO และพบว่าผล MMD ของ CISO ไม่เป็นผลดีต่อ CISO เอง ส่วน GLOS แสดงจำนวนตัวอย่างแต่ละประเภทคู่กับคะแนนของตัวจำแนก กราฟสองมิติเป็นหลักฐานว่าจุดตกที่ใด ไม่ใช่การวัด');
  return h + '</section>';
}
function finding4() {
  const f = F.select;
  const named = f.named_n, sel = f.sel_n;
  let h = '<section class="panel finding" id="f-select"><div class="fhead"><span class="fno">4</span><h2>' + bi('Learners are chosen because they are common; settings are seldom chosen by sensitivity alone', 'ตัวจำแนกถูกเลือกเพราะนิยมใช้ และค่าพารามิเตอร์แทบไม่ได้ถูกเลือกด้วย sensitivity อย่างเดียว') + '</h2></div>';
  h += verdict(f.learner_stated + ' of ' + f.n + ' studies explain their learners, most often as widely used; only ' + f.sens.length + ' choose a learner because it is sensitive to imbalance. Of the ' + sel + ' studies that select a setting, ' + named + ' name the measure that decides it, usually G-mean or AUC. Sensitivity alone decides in only ' + f.sens_only.length + ', both inside a rule of the method itself.',
    f.learner_stated + ' จาก ' + f.n + ' เรื่องอธิบายการเลือกตัวจำแนก ส่วนใหญ่เพราะนิยมใช้ มีเพียง ' + f.sens.length + ' เรื่องที่เลือกเพราะไวต่อความไม่สมดุล ในงาน ' + sel + ' เรื่องที่มีการเลือกค่า มี ' + named + ' เรื่องที่ระบุตัวชี้วัดที่ใช้ตัดสิน ส่วนใหญ่เป็น G-mean หรือ AUC มีเพียง ' + f.sens_only.length + ' เรื่องที่ใช้ sensitivity อย่างเดียว และทั้งสองเป็นกฎภายในของวิธีเอง');
  h += step('A', 'How it was measured', 'วิธีวัด') + pair('Two questions were coded with quotes and pages. Why these base learners: only reasons the paper states. How settings are chosen: what is selected (a method parameter, a classifier hyperparameter, the resampling amount or the best variant), the measure that decides, and the data on which it is decided.',
    'บันทึกสองคำถามพร้อมข้อความที่ยกมาและเลขหน้า คำถามแรก ทำไมจึงเลือกตัวจำแนกเหล่านี้ โดยนับเฉพาะเหตุผลที่บทความเขียนไว้ คำถามที่สอง เลือกค่าอย่างไร ได้แก่ เลือกอะไร (พารามิเตอร์ของวิธี ไฮเปอร์พารามิเตอร์ของตัวจำแนก ปริมาณการสุ่ม หรือรูปแบบที่ดีที่สุด) ใช้ตัวชี้วัดใดตัดสิน และตัดสินบนข้อมูลชุดใด');
  h += step('B', 'Why these learners', 'ทำไมจึงเลือกตัวจำแนกเหล่านี้') +
    bars(f.learner_reasons.map(r => ({en: REASON[r.code][0], th: REASON[r.code][1], n: r.n, of: f.n, c: r.code === 'sensitive_to_imbalance' ? '--c2' : '--c1'})), f.n) +
    '<p class="note">' + bi(f.learner_other + ' further reasons are specific to one paper (for example, C4.5 gives deterministic results). ' + (f.n - f.learner_stated) + ' studies give no reason.', 'อีก ' + f.learner_other + ' เหตุผลเฉพาะของแต่ละบทความ (เช่น C4.5 ให้ผลคงที่) และ ' + (f.n - f.learner_stated) + ' เรื่องไม่ให้เหตุผล') + '</p>' +
    '<div class="quotes">' + ['popular', 'diverse_paradigms', 'follows_prior_work'].map(c => { const r = f.learner_reasons.find(x => x.code === c); return r && r.ex ? '<div><span class="qk">' + bi(REASON[c][0], REASON[c][1]) + '</span>' + quoteHTML(r.ex) + '</div>' : ''; }).join('') +
    f.sens.map((s, i) => '<div><span class="qk">' + bi(REASON.sensitive_to_imbalance[0] + ' · ' + (i + 1) + ' of ' + f.sens.length, REASON.sensitive_to_imbalance[1] + ' · ' + (i + 1) + '/' + f.sens.length) + '</span>' + quoteHTML(s) + '</div>').join('') + '</div>';
  h += step('C', 'How settings are chosen', 'เลือกค่าพารามิเตอร์อย่างไร') +
    '<div class="funnel"><div><b>' + f.n + '</b>' + bi('empirical studies', 'งานเชิงทดลอง') + '</div><span>→</span><div><b>' + sel + '</b>' + bi('select a setting', 'มีการเลือกค่า') + '</div><span>→</span><div><b>' + named + '</b>' + bi('name the measure', 'ระบุตัวชี้วัด') + '</div><div class="side"><b>' + f.internal_n + '</b>' + bi('internal criterion (likelihood etc.)', 'เกณฑ์ภายในของวิธี (likelihood ฯลฯ)') + '</div><div class="side"><b>' + f.ns_n + '</b>' + bi('do not say', 'ไม่ระบุ') + '</div></div>' +
    '<div class="two"><div>' + '<h5>' + bi('Measure that decides (studies)', 'ตัวชี้วัดที่ใช้ตัดสิน (จำนวนงาน)') + '</h5>' + bars(Object.keys(f.criteria).map(k => ({en: k, th: k, n: f.criteria[k], of: named, c: k === 'Sensitivity/Recall' ? '--c2' : '--c1'})), named, 'small') + '</div>' +
    '<div><h5>' + bi('Data on which it is decided', 'ข้อมูลที่ใช้ตัดสิน') + '</h5>' + bars(Object.keys(f.data_used).map(k => ({en: DATA_USED[k][0], th: DATA_USED[k][1], n: f.data_used[k], of: sel, c: k === 'evaluation data' ? '--c2' : '--c1'})), sel, 'small') + '</div></div>' +
    pair('Sensitivity appears among the criteria of ' + (f.criteria['Sensitivity/Recall'] || 0) + ' studies but decides alone in only ' + f.sens_only.length + '. Every named criterion is also a measure the study reports, and ' + (f.data_used['evaluation data'] || 0) + ' of the ' + sel + ' decide on the same folds they report, so the proposal is tuned on exactly the number the reader sees.',
      'sensitivity อยู่ในเกณฑ์ของ ' + (f.criteria['Sensitivity/Recall'] || 0) + ' เรื่อง แต่ใช้ตัดสินเพียงตัวเดียวใน ' + f.sens_only.length + ' เรื่องเท่านั้น เกณฑ์ทุกตัวที่ระบุเป็นตัวชี้วัดที่รายงานผลด้วย และ ' + (f.data_used['evaluation data'] || 0) + ' จาก ' + sel + ' เรื่องตัดสินบน fold เดียวกับที่รายงาน วิธีที่เสนอจึงถูกปรับให้ดีบนตัวเลขเดียวกับที่ผู้อ่านเห็น');
  h += step('D', 'The two studies that select on sensitivity alone', 'สองงานที่เลือกด้วย sensitivity อย่างเดียว') +
    '<div class="quotes">' + f.sens_only.map(s => '<div>' + quoteHTML(s) + (s.check ? '<p class="note">' + bi('Independent check: ', 'ตรวจซ้ำ: ') + esc(s.check) + '</p>' : '') + '</div>').join('') + '</div>';
  h += step('E', 'Every study that selects a setting', 'ทุกงานที่มีการเลือกค่า') +
    '<details class="all"><summary>' + bi('Show the ' + sel + ' studies with their quotes', 'แสดงงาน ' + sel + ' เรื่องพร้อมข้อความที่ยกมา') + '</summary>' +
    tableHTML([['Study', 'งาน'], ['Selected', 'สิ่งที่เลือก'], ['Measure', 'ตัวชี้วัด'], ['Data', 'ข้อมูล'], ['Quote and page', 'ข้อความและเลขหน้า']], f.table.map(r => ['<b>' + esc(r.short) + '</b>', esc(r.selected), esc(r.criterion), esc(r.data), (r.quote ? '“' + esc(r.quote) + '”' : '') + '<div class="sub">' + esc(r.where || '') + '</div>'])) + '</details>';
  h += caveat('The independent check confirmed the OBU rule and narrowed RACOG to its stopping rule. One code was changed after the check: SHRINK 1998 describes C4.5 and 1-NN as hurt by imbalance but does not give this as the reason for choosing them, so it no longer counts as a sensitivity reason.',
    'การตรวจซ้ำยืนยันกฎของ OBU และแก้ RACOG ให้เหลือเฉพาะกฎการหยุด มีหนึ่งรหัสที่เปลี่ยนหลังการตรวจ คือ SHRINK 1998 บรรยายว่า C4.5 และ 1-NN ได้รับผลจากความไม่สมดุล แต่ไม่ได้ให้เป็นเหตุผลในการเลือก จึงไม่นับเป็นเหตุผลด้านความไวต่อความไม่สมดุลอีกต่อไป');
  return h + '</section>';
}
function findings() {
  const idx = [['f-cites', 'Citations do not follow rigour', 'การอ้างอิงไม่ได้ตามความรัดกุม'], ['f-data', 'Data: coverage, inheritance, repositories', 'ข้อมูล: ความครอบคลุม การส่งต่อ คลังข้อมูล'], ['f-beyond', 'Always through a classifier', 'ผ่านตัวจำแนกเสมอ'], ['f-select', 'Learner choice and selection criteria', 'การเลือกตัวจำแนกและเกณฑ์การเลือกค่า']];
  return '<section class="panel intro"><h2>' + bi('Four findings and the evidence behind them', 'ข้อค้นพบ 4 ข้อและหลักฐานเบื้องหลัง') + '</h2>' +
    pair('Each finding below states the conclusion, how it was measured, the numbers and studies it rests on, and its limits. Every count can be traced to a study in the Section 7 coded data; every quote carries a page.',
      'ข้อค้นพบแต่ละข้อด้านล่างระบุข้อสรุป วิธีวัด ตัวเลขและงานที่เป็นฐาน และข้อจำกัด ตัวเลขทุกตัวย้อนกลับไปหางานในข้อมูลที่ลงรหัสของหัวข้อที่ 7 ได้ และข้อความที่ยกมาทุกข้อมีเลขหน้ากำกับ') +
    '<nav class="fidx">' + idx.map((x, i) => '<a href="#' + x[0] + '"><span class="fno">' + (i + 1) + '</span>' + bi(x[1], x[2]) + '</a>').join('') + '</nav></section>' + finding1() + finding2() + finding3() + finding4();
}
