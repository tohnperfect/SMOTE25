(function () {
'use strict';
function boot() {
  try { main(); }
  catch (e) {
    var er = document.getElementById('err');
    er.hidden = false; er.textContent = 'This page hit a script error: ' + e.message + '. Reload to try again.';
    console.error(e);
  }
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();

function main() {
const ALL = JSON.parse(document.getElementById('data').textContent);
const BY = Object.fromEntries(ALL.map(p => [p.key, p]));
const EMP = ALL.filter(p => p.empirical);
const AN = JSON.parse(document.getElementById('analysis').textContent);
const REFS = Object.fromEntries(AN.refs.map(r => [r.key, r]));
const INF = Object.fromEntries(AN.influence.map(r => [r.key, r]));
const big = n => n == null ? 'n/a' : String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
const tokKey = k => k.toLowerCase().replace(/^ref-/, '').replace(/[^a-z0-9]+/g, '_');
const ERAS = ['≤2009', '2010-2015', '2016-2020', '2021-2026'];
const ERA_EN = {'≤2009': 'before 2010', '2010-2015': '2010–2015', '2016-2020': '2016–2020', '2021-2026': '2021–2026'};
const SETTINGS = [{k: 'binary', en: 'Binary', th: 'สองคลาส', c: '--s1'}, {k: 'multiclass', en: 'Multi-class', th: 'หลายคลาส', c: '--s2'}, {k: 'both', en: 'Both', th: 'ทั้งสองแบบ', c: '--s3'}];
const TEST_CATS = [
  {k: 'None', en: 'No test', c: '--o0'},
  {k: 'Pairwise only (uncorrected)', en: 'Pairwise, uncorrected', c: '--o1'},
  {k: 'Omnibus, no corrected post-hoc', en: 'Omnibus only', c: '--o2'},
  {k: 'Corrected multiple comparison', en: 'Corrected multiple comparison', c: '--o3'},
  {k: 'Bayesian', en: 'Bayesian', c: '--s3'}];
const TUNE_CATS = [
  {k: 'Nested / held-out tuning', en: 'Nested or held-out tuning', c: '--o3'},
  {k: 'Fixed / default settings', en: 'Fixed or default settings', c: '--o1'},
  {k: 'Unclear', en: 'Not stated', c: '--o0'},
  {k: 'Selected on evaluation data', en: 'Selected on evaluation data', c: '--s2'}];
const PROTO_ORDER = ['Repeated k-fold CV', 'Single k-fold CV', '5x2 CV', 'Repeated hold-out', 'Single hold-out', 'Fixed benchmark split', 'Not stated'];
const PERIODS = [[1997, 2001], [2002, 2005], [2006, 2009], [2010, 2013], [2014, 2017], [2018, 2021], [2022, 2026]];
const THRFREE = ['AUC', 'ROC curve', 'AUPRC', 'MAUC', 'AUCm'];
const has = (p, m) => p.metrics_n.indexOf(m) >= 0;
const cnt = (S, f) => S.filter(f).length;
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c]));
const pct = (c, n) => n ? Math.round(100 * c / n) : 0;
function median(a) { a = a.filter(x => x != null).sort((x, y) => x - y); if (!a.length) return null; const m = a.length / 2; return a.length % 2 ? a[Math.floor(m)] : (a[m - 1] + a[m]) / 2; }
function quantExcl(a, q) { a = a.filter(x => x != null).sort((x, y) => x - y); const n = a.length, m = (n + 1) * q, j = Math.floor(m), f = m - j; if (j < 1) return a[0]; if (j >= n) return a[n - 1]; return a[j - 1] + f * (a[j] - a[j - 1]); }
const fmtNum = x => (x == null ? 'n/a' : (Math.round(x * 10) / 10).toString());
const OUT_LABEL = {A: 'Best, no stated exception', B: 'Best, with stated exceptions', C: 'No advantage over simple baselines', D: 'Comparative study'};

const state = {view: 'draft', lang: 'both', f: {q: '', setting: 'all', era: 'all', approach: 'all', test: 'all', tune: 'all', proto: 'all', outcome: 'all', issues: false, all: false}, sort: {k: 'year', dir: 1}, latexScope: 'all'};
try { const s = JSON.parse(localStorage.getItem('smote25-eval') || '{}'); if (s.lang) state.lang = s.lang; if (s.view) state.view = s.view; } catch (e) {}
const hv = location.hash.replace('#', ''); if (['draft', 'explorer', 'latex', 'notes'].indexOf(hv) >= 0) state.view = hv;
function save() { try { localStorage.setItem('smote25-eval', JSON.stringify({lang: state.lang, view: state.view})); } catch (e) {} }

/* ---------------- statistics: the single source of every number ---------------- */
function usersOf(rx, selfKey) { return EMP.filter(p => p.key !== selfKey && (p.baselines || []).some(b => rx.test(b))).length; }
function computeStats(S) {
  const N = S.length, era = e => S.filter(p => p.era === e);
  const E1 = era(ERAS[0]), E3 = era(ERAS[2]), E4 = era(ERAS[3]);
  const nr = S.map(p => p.datasets.n_real);
  const repeated = p => ['Repeated k-fold CV', '5x2 CV', 'Repeated hold-out'].indexOf(p.protocol_class) >= 0;
  const corr = p => p.test_class === 'Corrected multiple comparison' || p.test_class === 'Bayesian';
  const ens = p => p.clf_families.indexOf('Random Forest') >= 0 || p.clf_families.indexOf('Gradient boosting') >= 0;
  const pre16 = S.filter(p => p.year < 2016);
  const pw = S.filter(p => p.test_class === 'Pairwise only (uncorrected)');
  const tcorr = S.filter(p => p.test_class === 'Corrected multiple comparison');
  const c = {
    all: ALL.length, emp: N, nonemp: ALL.length - EMP.length,
    bin: cnt(S, p => p.setting === 'binary'), mc: cnt(S, p => p.setting === 'multiclass'), both: cnt(S, p => p.setting === 'both'),
    ds_med: median(nr), ds_q1: quantExcl(nr, .25), ds_q3: quantExcl(nr, .75), ds_min: Math.min.apply(null, nr.filter(x => x != null)), ds_max: Math.max.apply(null, nr.filter(x => x != null)),
    med_e1: median(E1.map(p => p.datasets.n_real)), med_e4: median(E4.map(p => p.datasets.n_real)),
    uci: cnt(S, p => p.uses_uci), keel: cnt(S, p => p.uses_keel), syn: cnt(S, p => (p.datasets.n_synthetic || 0) > 0),
    ir: cnt(S, p => !!p.datasets.ir_range), nontab: cnt(S, p => p.data_type !== 'tabular'),
    c45: cnt(S, p => p.clf_families.indexOf('C4.5/C5.0') >= 0), knn: cnt(S, p => p.clf_families.indexOf('k-NN') >= 0),
    svm: cnt(S, p => p.clf_families.indexOf('SVM') >= 0), cart: cnt(S, p => p.clf_families.indexOf('CART/DT') >= 0),
    mlp: cnt(S, p => p.clf_families.indexOf('MLP/NN') >= 0), clf_med: median(S.map(p => p.n_clf)), clf1: cnt(S, p => p.n_clf === 1),
    base_med: median(S.map(p => p.n_baselines)), smote: cnt(S, p => p.smote_baseline), nores: cnt(S, p => p.no_resampling_baseline),
    copied: cnt(S, p => p.integrity.some(i => /copied|quoted|taken from/.test(i))),
    acc: cnt(S, p => has(p, 'Accuracy/Error')), gmean: cnt(S, p => has(p, 'G-mean')), auc: cnt(S, p => has(p, 'AUC')),
    recall: cnt(S, p => has(p, 'Recall/TPR')), f1: cnt(S, p => has(p, 'F1')), prec: cnt(S, p => has(p, 'Precision')),
    met_med: median(S.map(p => p.metrics_n.filter(m => m !== 'Other').length)), mauc: cnt(S, p => has(p, 'MAUC')),
    thrfree: cnt(S, p => THRFREE.some(m => has(p, m))), auprc: cnt(S, p => has(p, 'AUPRC')), mcc: cnt(S, p => has(p, 'MCC')),
    metissue: cnt(S, p => !!p.metric_issue),
    repcv: cnt(S, p => p.protocol_class === 'Repeated k-fold CV'), singlecv: cnt(S, p => p.protocol_class === 'Single k-fold CV'),
    k10: cnt(S, p => p.cv_k === 10), k5: cnt(S, p => p.cv_k === 5), x52: cnt(S, p => p.protocol_class === '5x2 CV'),
    hold1: cnt(S, p => p.protocol_class === 'Single hold-out'), holdrep: cnt(S, p => p.protocol_class === 'Repeated hold-out'),
    fixed: cnt(S, p => p.protocol_class === 'Fixed benchmark split'), repeated: cnt(S, repeated),
    inside: cnt(S, p => p.resampling_inside_cv === true), insidenull: cnt(S, p => p.resampling_inside_cv == null),
    nested: cnt(S, p => p.tuning_class === 'Nested / held-out tuning'), fixedt: cnt(S, p => p.tuning_class === 'Fixed / default settings'),
    evalsel: cnt(S, p => p.tuning_class === 'Selected on evaluation data'), unclear: cnt(S, p => p.tuning_class === 'Unclear'),
    anytest: cnt(S, p => p.test_class !== 'None'),
    wilcoxon: cnt(S, p => p.tests_n.indexOf('Wilcoxon signed-rank') >= 0), friedman: cnt(S, p => p.tests_n.indexOf('Friedman') >= 0),
    holm: cnt(S, p => p.tests_n.indexOf('Holm') >= 0), bd: cnt(S, p => p.tests_n.indexOf('Bonferroni-Dunn') >= 0),
    shaffer: cnt(S, p => p.tests_n.indexOf('Shaffer') >= 0), nemenyi: cnt(S, p => p.tests_n.indexOf('Nemenyi') >= 0),
    tcorr: tcorr.length, tcorr_fried: cnt(tcorr, p => ['Friedman', 'Iman-Davenport', 'Friedman aligned ranks'].some(t => p.tests_n.indexOf(t) >= 0)),
    tpair: pw.length, tomni: cnt(S, p => p.test_class === 'Omnibus, no corrected post-hoc'), tbayes: cnt(S, p => p.test_class === 'Bayesian'),
    tnone: cnt(S, p => p.test_class === 'None'), pw_base_med: median(pw.map(p => p.n_baselines)),
    perds: cnt(S, p => p.reporting.indexOf('per-dataset table') >= 0), rank: cnt(S, p => p.reporting.indexOf('average rank table') >= 0),
    pval: cnt(S, p => p.reporting.indexOf('p-value table') >= 0), wtl: cnt(S, p => p.reporting.indexOf('win/tie/loss counts') >= 0),
    std: cnt(S, p => p.reporting.indexOf('mean +/- std') >= 0), scatter: cnt(S, p => p.reporting.indexOf('scatter/2D visualization of synthetic samples') >= 0),
    sens: cnt(S, p => p.reporting.indexOf('parameter sensitivity') >= 0), ablation: cnt(S, p => p.reporting.indexOf('ablation study') >= 0),
    rocplot: cnt(S, p => p.reporting.indexOf('ROC plot') >= 0), box: cnt(S, p => p.reporting.indexOf('box plot') >= 0),
    cd: cnt(S, p => p.reporting.indexOf('CD diagram') >= 0 || (p.stat_tests || []).indexOf('Critical difference diagram') >= 0),
    runtime: cnt(S, p => !!p.runtime_reported), code: cnt(S, p => p.has_code), supp: cnt(S, p => p.reporting.indexOf('supplementary tables') >= 0),
    outA: cnt(S, p => p.outcome === 'A'), outB: cnt(S, p => p.outcome === 'B'), outC: cnt(S, p => p.outcome === 'C'), outD: cnt(S, p => p.outcome === 'D'),
    mdo_users: usersOf(/\bMDO\b|\bMBO\b/, 'MDO-2016'), mccr_users: usersOf(/MC-CCR/, 'MC-CCR-2020')
  };
  /* pass 2: stated reasons, model selection, evidence beyond classifier scores */
  const r2 = S.filter(p => p.r2), hasR = (p, f, code) => (p.r2[f] || []).indexOf(code) >= 0;
  const rc = (f, code) => cnt(r2, p => hasR(p, f, code));
  Object.assign(c, {
    data_stated: cnt(r2, p => p.r2.data_stated), learner_stated: cnt(r2, p => p.r2.learner_stated), measure_stated: cnt(r2, p => p.r2.measure_stated),
    dr_varied: rc('data_reasons', 'varied_characteristics'), dr_imb: rc('data_reasons', 'imbalance_level'), dr_follow: rc('data_reasons', 'follows_prior_work'),
    dr_diff: rc('data_reasons', 'difficulty_factors'), dr_comp: rc('data_reasons', 'comparability'), dr_public: rc('data_reasons', 'public_benchmark'),
    dr_app: rc('data_reasons', 'application_domain'), dr_mc: rc('data_reasons', 'multiclass_availability'),
    lr_popular: rc('learner_reasons', 'popular'), lr_diverse: rc('learner_reasons', 'diverse_paradigms'), lr_follow: rc('learner_reasons', 'follows_prior_work'),
    lr_simple: rc('learner_reasons', 'simplicity'), lr_fair: rc('learner_reasons', 'fair_comparison'), lr_sens: rc('learner_reasons', 'sensitive_to_imbalance'),
    lr_mech: rc('learner_reasons', 'matches_mechanism'),
    mr_std: rc('measure_reasons', 'standard_in_literature'), mr_acc: rc('measure_reasons', 'accuracy_misleading'), mr_min: rc('measure_reasons', 'minority_focus'),
    mr_thr: rc('measure_reasons', 'threshold_free'), mr_mc: rc('measure_reasons', 'multiclass_suitability'), mr_cost: rc('measure_reasons', 'cost'),
    pub_all: cnt(r2, p => p.r2.all_public === true), pub_not: cnt(r2, p => p.r2.all_public === false), per_src: cnt(r2, p => p.r2.per_ds_source === true),
    links: cnt(r2, p => p.r2.links === true), modified: cnt(r2, p => p.r2.mod_released != null), mod_rel: cnt(r2, p => p.r2.mod_released === true),
    beyond_any: cnt(S, p => !p.beyond_none), beyond_none: cnt(S, p => p.beyond_none), beyond_direct: cnt(S, p => p.beyond_direct),
    beyond_visual: cnt(S, p => p.beyond_visual), beyond_analytic: cnt(S, p => p.beyond_analytic), beyond_model: cnt(S, p => p.beyond_model),
    bk_toy: rc('beyond_kinds', 'toy_2d_visualization'), bk_proj: rc('beyond_kinds', 'projection_visualization'), bk_theory: rc('beyond_kinds', 'theoretical_analysis'),
    bk_complex: rc('beyond_kinds', 'complexity_analysis'), bk_dist: cnt(r2, p => hasR(p, 'beyond_kinds', 'distribution_distance') || hasR(p, 'beyond_kinds', 'privacy_or_fidelity')),
    bk_noise: rc('beyond_kinds', 'noise_count'), bk_types: rc('beyond_kinds', 'example_type_analysis'), bk_div: rc('beyond_kinds', 'diversity_measure'),
    method_ref: cnt(r2, p => p.r2.stats_method_ref), demsar_users: cnt(r2, p => (p.r2.stats_cited || []).some(x => /Dem[sš]ar/.test(x))),
    tun_explicit: cnt(S, p => p.tuning_evidence === 'explicit'), tun_implied: cnt(S, p => p.tuning_evidence === 'implied'),
    tun_v1: cnt(S, p => p.tuning_class_v1 === 'Selected on evaluation data')
  });
  const msSel = r2.filter(p => !(p.r2.ms_selected || []).every(x => x === 'none (fixed settings)' || x === 'not stated'));
  const named = p => (p.r2.ms_criterion || []).filter(x => x !== 'not stated' && x !== 'not applicable' && x.indexOf('other') !== 0);
  const crit = (x) => cnt(msSel, p => named(p).indexOf(x) >= 0);
  Object.assign(c, {
    ms_n: msSel.length, ms_crit: cnt(msSel, p => named(p).length > 0), ms_internal: cnt(msSel, p => !named(p).length && (p.r2.ms_criterion || []).some(x => x.indexOf('other') === 0)),
    msc_gmean: crit('G-mean'), msc_auc: crit('AUC'), msc_f1: crit('F1'), msc_sens: crit('Sensitivity/Recall'), msc_avacc: crit('AvAcc'), msc_mauc: crit('MAUC'),
    sens_only: cnt(r2, p => p.r2.ms_sens_only)
  });
  c.ms_ns = c.ms_n - c.ms_crit - c.ms_internal;
  /* citations */
  const EL = S.filter(p => p.cite_eligible), byC = EL.slice().sort((a, b) => b.cites - a.cites), top = byC.slice(0, 10), rest = byC.slice(10);
  Object.assign(c, {
    cite_n: EL.length, cite_found: cnt(ALL, p => p.cites != null), cite_young: cnt(S, p => p.year > 2024), ncomp: AN.influence.filter(r => r.ratio != null).length,
    year_ratio: AN.year_ratio, top10_ds: median(top.map(p => p.datasets.n_real)), rest_ds: median(rest.map(p => p.datasets.n_real)),
    top10_year: median(top.map(p => p.year)), rest_year: median(rest.map(p => p.year)), rest_n: rest.length,
    top10_pre: cnt(top, p => p.year < 2010), top10_test: cnt(top, p => p.test_class !== 'None'), top10_code: cnt(top, p => p.has_code)
  });
  c.learner_notstated = N - c.learner_stated; c.mod_notrel = c.modified - c.mod_rel; c.nodirect = N - c.beyond_direct;
  c.fr = {top10_test: [cnt(top, p => p.test_class !== 'None'), top.length], rest_test: [cnt(rest, p => p.test_class !== 'None'), rest.length],
    top10_single: [cnt(top, p => p.n_clf === 1), top.length], rest_single: [cnt(rest, p => p.n_clf === 1), rest.length],
    top10_code: [cnt(top, p => p.has_code), top.length], rest_code: [cnt(rest, p => p.has_code), rest.length],
    classic: [cnt(S, p => p.uses_classic), N]};
  const CRIT_RX = {'G-mean': /G-mean|^MG$/, 'AUC': /^AUC$/, 'F1': /F1|F-measure/, 'Sensitivity/Recall': /Recall/, 'AvAcc': /AvAcc/, 'MAUC': /MAUC/, 'PR-AUC': /AUPRC/, 'AUPRC': /AUPRC/, 'mGM': /^MG$|G-mean/, 'CBA': /CBA/, 'Accuracy': /Accuracy/};
  const critReported = p => named(p).some(x => CRIT_RX[x] && p.metrics_n.some(m => CRIT_RX[x].test(m)));
  c.fr.crit_reported = [cnt(msSel, p => named(p).length && critReported(p)), c.ms_crit];
  c.outAB = c.outA + c.outB; c.nmethod = c.outA + c.outB + c.outC;
  c.nonores = N - c.nores; c.thrdep = N - c.thrfree; c.insidenot = N - c.inside; c.testweak = c.tnone + c.tpair;
  c.nostd = N - c.std; c.nort = N - c.runtime; c.nocode = N - c.code;
  const eraPair = (f, E) => [cnt(E, f), E.length];
  const eraVals = {
    single_e4: eraPair(p => p.n_clf === 1, E4), ens_e4: eraPair(ens, E4),
    evalsel_e1: eraPair(p => p.tuning_class === 'Selected on evaluation data', E1), evalsel_e4: eraPair(p => p.tuning_class === 'Selected on evaluation data', E4),
    anytest_e1: eraPair(p => p.test_class !== 'None', E1), anytest_e4: eraPair(p => p.test_class !== 'None', E4),
    corr_e1: eraPair(corr, E1), corr_e4: eraPair(corr, E4),
    code_e3: eraPair(p => p.has_code, E3), code_e4: eraPair(p => p.has_code, E4)
  };
  return {N: N, c: c, eraVals: eraVals, ensPre: [cnt(pre16, ens), pre16.length], repeated: repeated, corr: corr};
}
const ST = computeStats(EMP);
function tokenValue(name, lang) {
  name = name.replace(/_cap$/, '');
  const c = ST.c, N = ST.N;
  if (name.slice(-4) === '_ofp') { const v = c[name.slice(0, -4)]; return lang === 'th' ? v + ' จาก ' + N + ' เรื่อง คิดเป็น ' + pct(v, N) + '%' : v + ' of ' + N + ' studies, ' + pct(v, N) + '%'; }
  if (name.slice(-3) === '_of') { const v = c[name.slice(0, -3)]; return lang === 'th' ? v + ' จาก ' + N + ' เรื่อง (' + pct(v, N) + '%)' : v + ' of ' + N + ' studies (' + pct(v, N) + '%)'; }
  if (ST.eraVals[name]) { const ev = ST.eraVals[name]; return lang === 'th' ? pct(ev[0], ev[1]) + '% (' + ev[0] + ' จาก ' + ev[1] + ' เรื่อง)' : pct(ev[0], ev[1]) + '% (' + ev[0] + ' of ' + ev[1] + ')'; }
  if (name === 'ens_pre') return lang === 'th' ? ST.ensPre[0] + ' จาก ' + ST.ensPre[1] : ST.ensPre[0] + ' of ' + ST.ensPre[1];
  if (name.indexOf('fr_') === 0 || name.indexOf('frp_') === 0) {
    const v = c.fr[name.slice(name.indexOf('_') + 1)]; if (!v) { console.warn('missing token', name); return '[' + name + ']'; }
    const base = lang === 'th' ? v[0] + ' จาก ' + v[1] : v[0] + ' of ' + v[1];
    return name.indexOf('frp_') === 0 ? base + ' (' + pct(v[0], v[1]) + '%)' : base;
  }
  if (name.indexOf('inf_') === 0) {
    const r = INF[name.slice(4)]; if (!r || r.ratio == null) { console.warn('missing token', name); return '[' + name + ']'; }
    return lang === 'th' ? r.ratio.toFixed(2) + ' (ช่วงความเชื่อมั่น 95% ' + r.lo.toFixed(2) + ' ถึง ' + r.hi.toFixed(2) + ')' : r.ratio.toFixed(2) + ' (95% CI ' + r.lo.toFixed(2) + ' to ' + r.hi.toFixed(2) + ')';
  }
  if (name.indexOf('rc_') === 0) { const r = AN.refs.find(x => tokKey(x.key) === name.slice(3)); if (!r) { console.warn('missing token', name); return '[' + name + ']'; } return big(r.cites); }
  if (name.indexOf('pc_') === 0) { const p = ALL.find(x => tokKey(x.key) === name.slice(3)); if (!p) { console.warn('missing token', name); return '[' + name + ']'; } return big(p.cites); }
  if (name === 'cite_date') { const d = new Date(AN.retrieved + 'T00:00:00'); const m = d.getMonth(); return lang === 'th' ? d.getDate() + ' ' + ['มกราคม', 'กุมภาพันธ์', 'มีนาคม', 'เมษายน', 'พฤษภาคม', 'มิถุนายน', 'กรกฎาคม', 'สิงหาคม', 'กันยายน', 'ตุลาคม', 'พฤศจิกายน', 'ธันวาคม'][m] + ' ' + d.getFullYear() : d.getDate() + ' ' + ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'][m] + ' ' + d.getFullYear(); }
  if (name === 'year_ratio') return c.year_ratio.toFixed(2);
  if (name.indexOf('infn_') === 0) { const r = INF[name.slice(5)]; return r ? String(r.n_users) : '[' + name + ']'; }
  if (name.indexOf('fam_') === 0) { const f = AN.families.find(x => x.family === name.slice(4).replace(/_/g, '-')); if (!f) { console.warn('missing token', name); return '[' + name + ']'; } return String(f.n); }
  if (c[name] == null) { console.warn('missing token', name); return '[' + name + ']'; }
  return fmtNum(c[name]);
}

/* ---------------- references and numbering ---------------- */
const SEC_NUM = {}; PROSE.forEach((s, i) => { SEC_NUM[s.id] = SECTION.num + '.' + (i + 1); });
const SEC_BY = Object.fromEntries(PROSE.map(s => [s.id, s]));
function citeLabel(k) { const p = BY[k]; if (p) return p.short + ' ' + p.year; const r = REFS[k]; return r ? r.label : k; }
function bibkey(k) { return BY[k] ? BY[k].bibkey : REFS[k] ? REFS[k].bibkey : k; }
function refLabel(id, lang) {
  const th = lang === 'th';
  if (id.indexOf('fig-') === 0) return (th ? 'รูปที่ ' : 'Figure ') + FIGS[id].n;
  if (id.indexOf('tab-') === 0) return (th ? 'ตารางที่ ' : 'Table ') + TABS[id].n;
  if (id.indexOf('eq-') === 0) return '(' + EQS[id.slice(3)].n + ')';
  if (id.indexOf('sec-') === 0) return (th ? 'หัวข้อ ' : 'Section ') + SEC_NUM[id.slice(4)];
  return id;
}
function refTex(id) {
  if (id.indexOf('fig-') === 0) return 'Figure~\\ref{' + FIGS[id].label + '}';
  if (id.indexOf('tab-') === 0) return 'Table~\\ref{' + TABS[id].label + '}';
  if (id.indexOf('eq-') === 0) return '(\\ref{' + EQS[id.slice(3)].label + '})';
  if (id.indexOf('sec-') === 0) return 'Section~\\ref{' + SEC_BY[id.slice(4)].label + '}';
  return id;
}
const TOK = /\{t:([a-z0-9_]+)\}|\[\[([^\]]+)\]\]|\{ref:([a-z0-9-]+)\}|\{\{todo:([^}]+)\}\}|(<b>|<\/b>)/gi;
function renderText(str, lang) {
  let out = '', last = 0, m;
  TOK.lastIndex = 0;
  while ((m = TOK.exec(str))) {
    out += richText(str.slice(last, m.index));
    if (m[1]) out += '<span class="num">' + esc(tokenValue(m[1], lang)) + '</span>';
    else if (m[2]) { const ks = m[2].split(',').map(k => k.trim()); out += '<span class="cites">' + ks.map((k, i) => '<span class="nb">' + (i === 0 ? '(' : '') + '<button class="cite" data-key="' + esc(k) + '">' + esc(citeLabel(k)) + '</button>' + (i === ks.length - 1 ? ')' : ';') + '</span>').join(' ') + '</span>'; }
    else if (m[3]) { const id = m[3]; const href = id.indexOf('sec-') === 0 ? 'sec-' + id.slice(4) : id; out += '<a class="xref" href="#' + href + '" data-jump="' + href + '">' + esc(refLabel(id, lang)) + '</a>'; }
    else if (m[4]) out += '<mark class="todo">TODO: ' + esc(m[4]) + '</mark>';
    else if (m[5]) out += m[5];
    last = TOK.lastIndex;
  }
  return out + richText(str.slice(last));
}
function texEsc(s) {
  const keep = [];
  const hold = x => { keep.push(x); return '\u0001' + (keep.length - 1) + '\u0001'; };
  s = String(s).replace(/\bR_i\b/g, () => hold('$R_i$')).replace(/\bm_ij\b/g, () => hold('$m_{ij}$')).replace(/A\(i\|j\)/g, () => hold('$A(i\\mid j)$')).replace(/β/g, () => hold('$\\beta$'))
    .replace(/×/g, () => hold('$\\times$')).replace(/±/g, () => hold('$\\pm$')).replace(/≥/g, () => hold('$\\geq$')).replace(/≤/g, () => hold('$\\leq$'));
  s = s.replace(/\\/g, '\\textbackslash{}').replace(/([%&#_$])/g, '\\$1').replace(/–/g, '--');
  return s.replace(/\u0001(\d+)\u0001/g, (m, i) => keep[+i]);
}
function richText(s) {
  return esc(s).replace(/\bR_i\b/g, '<i>R</i><sub><i>i</i></sub>').replace(/\bm_ij\b/g, '<i>m</i><sub><i>ij</i></sub>').replace(/A\(i\|j\)/g, '<i>A</i>(<i>i</i>&#8202;|&#8202;<i>j</i>)');
}
function latexText(str) {
  let out = '', last = 0, m;
  TOK.lastIndex = 0;
  while ((m = TOK.exec(str))) {
    const pre = texEsc(str.slice(last, m.index));
    if (m[1]) out += pre + texEsc(tokenValue(m[1], 'en'));
    else if (m[2]) out += pre.replace(/\s+$/, '') + '~\\parencite{' + m[2].split(',').map(s => bibkey(s.trim())).join(',') + '}';
    else if (m[3]) out += pre + refTex(m[3]);
    else if (m[4]) out += pre + '\\TODO{' + texEsc(m[4]) + '}';
    else if (m[5]) out += pre + (m[5] === '<b>' ? '\\textbf{' : '}');
    last = TOK.lastIndex;
  }
  return out + texEsc(str.slice(last));
}
function citesHTML(keys) { return keys.map(k => '<button class="cite" data-key="' + esc(k) + '">' + esc(citeLabel(k)) + '</button>').join('; '); }
function citesTex(keys) { return keys.length ? '\\parencite{' + keys.map(bibkey).join(',') + '}' : ''; }
function mathHTML(tex) {
  try { if (window.katex) return window.katex.renderToString(tex, {displayMode: true, output: 'mathml', throwOnError: false}); } catch (e) {}
  return '<code class="texsrc">' + esc(tex) + '</code>';
}

/* ---------------- charts ---------------- */
const charts = [];
function cssVar(n) { return getComputedStyle(document.documentElement).getPropertyValue(n).trim() || '#888'; }
function lum(hex) {
  hex = hex.replace('#', ''); if (hex.length === 3) hex = hex.split('').map(x => x + x).join('');
  const v = [0, 2, 4].map(i => parseInt(hex.substr(i, 2), 16) / 255).map(x => x <= .03928 ? x / 12.92 : Math.pow((x + .055) / 1.055, 2.4));
  return .2126 * v[0] + .7152 * v[1] + .0722 * v[2];
}
function textOn(varName) { const c = cssVar(varName); return /^#/.test(c) && lum(c) > .36 ? '#15202b' : '#ffffff'; }
function rr(x, y, w, h, r) { r = Math.min(r, w / 2, h / 2); if (w <= 0) return ''; return 'M' + x + ',' + y + 'h' + (w - r) + 'a' + r + ',' + r + ' 0 0 1 ' + r + ',' + r + 'v' + (h - 2 * r) + 'a' + r + ',' + r + ' 0 0 1 -' + r + ',' + r + 'h-' + (w - r) + 'z'; }
function rt(x, y, w, h, r) { r = Math.min(r, w / 2, h / 2); if (h <= 0) return ''; return 'M' + x + ',' + (y + h) + 'v-' + (h - r) + 'a' + r + ',' + r + ' 0 0 1 ' + r + ',-' + r + 'h' + (w - 2 * r) + 'a' + r + ',' + r + ' 0 0 1 ' + r + ',' + r + 'v' + (h - r) + 'z'; }
function fitLabel(t, px) { t = String(t); const cw = 6.5; return t.length * cw > px ? t.slice(0, Math.max(3, Math.floor(px / cw) - 1)) + '…' : t; }
function legendHTML(items, line) { return '<div class="legend">' + items.map(i => '<span><i class="' + (line ? 'line' : '') + '" style="background:var(' + i.c + ')"></i>' + esc(i.en) + '</span>').join('') + '</div>'; }
function register(el, fn) { charts.push({el: el, fn: fn}); fn(); }
function rerenderAll() { charts.forEach(c => { if (c.el.isConnected && c.el.offsetParent !== null) c.fn(); }); }

function hbar(el, items, opt) {
  opt = opt || {};
  const w = Math.max(280, el.clientWidth || 600), labelW = Math.min(opt.labelW || 190, Math.round(w * .42)), rowH = 26, barH = 14, right = 70;
  const max = opt.max || Math.max.apply(null, items.map(i => i.value)) || 1, plotW = w - labelW - right, h = items.length * rowH + 6;
  let s = '<svg width="' + w + '" height="' + h + '" viewBox="0 0 ' + w + ' ' + h + '" role="img" aria-label="' + esc(opt.aria || 'bar chart') + '">';
  s += '<line x1="' + labelW + '" x2="' + labelW + '" y1="0" y2="' + (h - 4) + '" style="stroke:var(--axis)" />';
  items.forEach((it, i) => {
    const y = i * rowH + (rowH - barH) / 2, bw = Math.max(1, plotW * it.value / max);
    s += '<g data-tip="' + esc(it.tip) + '" tabindex="0"><rect x="0" y="' + (i * rowH) + '" width="' + w + '" height="' + rowH + '" style="fill:transparent" />';
    s += '<text x="' + (labelW - 8) + '" y="' + (y + barH - 3) + '" text-anchor="end" font-size="12" style="fill:var(--ink-2)">' + esc(fitLabel(it.label, labelW - 12)) + '</text>';
    s += '<path d="' + rr(labelW + 1, y, bw, barH, 4) + '" style="fill:var(' + (it.color || opt.color || '--s1') + ')" />';
    s += '<text x="' + (labelW + bw + 6) + '" y="' + (y + barH - 3) + '" font-size="12" style="fill:var(--ink)">' + esc(it.valueLabel != null ? it.valueLabel : it.value) + '</text></g>';
  });
  el.innerHTML = s + '</svg>';
}
function stackCounts(el, rows, cats, opt) {
  opt = opt || {};
  const w = Math.max(280, el.clientWidth || 600), labelW = Math.min(opt.labelW || 150, Math.round(w * .36)), rowH = 26, barH = 14, right = 40;
  const max = Math.max.apply(null, rows.map(r => r.total)) || 1, plotW = w - labelW - right, h = rows.length * rowH + 6;
  let s = '<svg width="' + w + '" height="' + h + '" viewBox="0 0 ' + w + ' ' + h + '" role="img" aria-label="' + esc(opt.aria || 'stacked bar chart') + '">';
  s += '<line x1="' + labelW + '" x2="' + labelW + '" y1="0" y2="' + (h - 4) + '" style="stroke:var(--axis)" />';
  rows.forEach((r, i) => {
    const y = i * rowH + (rowH - barH) / 2; let x0 = labelW + 1;
    s += '<text x="' + (labelW - 8) + '" y="' + (y + barH - 3) + '" text-anchor="end" font-size="12" style="fill:var(--ink-2)">' + esc(fitLabel(r.label, labelW - 12)) + '</text>';
    const segs = cats.filter(c => r.counts[c.k] > 0);
    segs.forEach((c, j) => {
      const full = plotW * r.counts[c.k] / max, gap = j < segs.length - 1 ? 2 : 0, bw = Math.max(1, full - gap);
      const d = j === segs.length - 1 ? rr(x0, y, bw, barH, 4) : 'M' + x0 + ',' + y + 'h' + bw + 'v' + barH + 'h-' + bw + 'z';
      s += '<path d="' + d + '" data-tip="' + esc(r.label + '\n' + c.en + ': ' + r.counts[c.k] + ' studies') + '" tabindex="0" style="fill:var(' + c.c + ')" />';
      x0 += full;
    });
    s += '<text x="' + (x0 + 6) + '" y="' + (y + barH - 3) + '" font-size="12" style="fill:var(--ink)">' + r.total + '</text>';
  });
  el.innerHTML = s + '</svg>';
}
function colStack(el, rows, cats) {
  const w = Math.max(280, el.clientWidth || 600), h = 230, L = 34, R = 10, T = 18, B = 34, pw = w - L - R, ph = h - T - B;
  const max = Math.max.apply(null, rows.map(r => r.total)), ymax = Math.ceil(max / 5) * 5 || 5, band = pw / rows.length, bw = Math.min(24, band * .6);
  const Y = v => T + ph * (1 - v / ymax);
  let s = '<svg width="' + w + '" height="' + h + '" viewBox="0 0 ' + w + ' ' + h + '" role="img" aria-label="studies per period by setting">';
  for (let t = 0; t <= ymax; t += 5) s += '<line x1="' + L + '" x2="' + (w - R) + '" y1="' + Y(t) + '" y2="' + Y(t) + '" style="stroke:' + (t === 0 ? 'var(--axis)' : 'var(--grid)') + '" /><text x="' + (L - 6) + '" y="' + (Y(t) + 4) + '" font-size="11" text-anchor="end" style="fill:var(--muted)">' + t + '</text>';
  rows.forEach((r, i) => {
    const cx = L + band * i + band / 2, x = cx - bw / 2; let y0 = Y(0);
    const segs = cats.filter(c => r.counts[c.k] > 0);
    segs.forEach((c, j) => {
      const full = ph * r.counts[c.k] / ymax, gap = j < segs.length - 1 ? 2 : 0, bh = Math.max(1, full - gap), y = y0 - full + gap;
      const d = j === segs.length - 1 ? rt(x, y0 - full, bw, bh, 4) : 'M' + x + ',' + y + 'h' + bw + 'v' + bh + 'h-' + bw + 'z';
      s += '<path d="' + d + '" data-tip="' + esc(r.label + '\n' + c.en + ': ' + r.counts[c.k] + ' studies') + '" tabindex="0" style="fill:var(' + c.c + ')" />';
      y0 -= full;
    });
    s += '<text x="' + cx + '" y="' + (Y(r.total) - 6) + '" font-size="11" text-anchor="middle" style="fill:var(--ink)">' + r.total + '</text>';
    s += '<text x="' + cx + '" y="' + (h - 14) + '" font-size="10.5" text-anchor="middle" style="fill:var(--muted)">' + esc(r.label) + '</text>';
  });
  el.innerHTML = s + '</svg>';
}
function stack100(el, rows, cats, opt) {
  opt = opt || {};
  const w = Math.max(280, el.clientWidth || 600), labelW = Math.min(118, Math.round(w * .3)), rowH = 34, barH = 22, right = 8, h = rows.length * rowH + 22, plotW = w - labelW - right;
  let s = '<svg width="' + w + '" height="' + h + '" viewBox="0 0 ' + w + ' ' + h + '" role="img" aria-label="' + esc(opt.aria || '100% stacked bars') + '">';
  [0, 25, 50, 75, 100].forEach(t => { const xx = labelW + plotW * t / 100; s += '<line x1="' + xx + '" x2="' + xx + '" y1="0" y2="' + (h - 18) + '" style="stroke:var(--grid)" /><text x="' + xx + '" y="' + (h - 4) + '" font-size="11" text-anchor="middle" style="fill:var(--muted)">' + t + '%</text>'; });
  rows.forEach((r, i) => {
    const y = i * rowH + (rowH - barH) / 2; let x0 = labelW;
    s += '<text x="' + (labelW - 8) + '" y="' + (y + barH / 2 - 1) + '" text-anchor="end" font-size="12" style="fill:var(--ink)">' + esc(r.label) + '</text>';
    s += '<text x="' + (labelW - 8) + '" y="' + (y + barH / 2 + 12) + '" text-anchor="end" font-size="10.5" style="fill:var(--muted)">n = ' + r.n + '</text>';
    const segs = cats.filter(c => r.counts[c.k] > 0);
    segs.forEach((c, j) => {
      const full = plotW * r.counts[c.k] / r.n, gap = j < segs.length - 1 ? 2 : 0, bw = Math.max(1, full - gap), pc = pct(r.counts[c.k], r.n);
      const d = j === segs.length - 1 ? rr(x0, y, bw, barH, 4) : 'M' + x0 + ',' + y + 'h' + bw + 'v' + barH + 'h-' + bw + 'z';
      s += '<g data-tip="' + esc(r.label + '\n' + c.en + ': ' + pc + '% (' + r.counts[c.k] + ' of ' + r.n + ')') + '" tabindex="0"><path d="' + d + '" style="fill:var(' + c.c + ')" />';
      if (bw > 34) s += '<text x="' + (x0 + bw / 2) + '" y="' + (y + barH / 2 + 4) + '" font-size="11" text-anchor="middle" fill="' + textOn(c.c) + '">' + pc + '%</text>';
      s += '</g>'; x0 += full;
    });
  });
  el.innerHTML = s + '</svg>';
}
function lineChart(el, series, labels) {
  const w = Math.max(280, el.clientWidth || 600), h = 250, L = 42, R = 16, T = 12, B = 30, pw = w - L - R, ph = h - T - B;
  const X = i => L + pw * i / (labels.length - 1), Y = v => T + ph * (1 - v / 100);
  let s = '<svg width="' + w + '" height="' + h + '" viewBox="0 0 ' + w + ' ' + h + '" role="img" aria-label="trend lines">';
  [0, 25, 50, 75, 100].forEach(t => { s += '<line x1="' + L + '" x2="' + (w - R) + '" y1="' + Y(t) + '" y2="' + Y(t) + '" style="stroke:' + (t === 0 ? 'var(--axis)' : 'var(--grid)') + '" /><text x="' + (L - 6) + '" y="' + (Y(t) + 4) + '" font-size="11" text-anchor="end" style="fill:var(--muted)">' + t + '%</text>'; });
  labels.forEach((lb, i) => { s += '<text x="' + X(i) + '" y="' + (h - 8) + '" font-size="11" text-anchor="' + (i === 0 ? 'start' : i === labels.length - 1 ? 'end' : 'middle') + '" style="fill:var(--muted)">' + esc(lb) + '</text>'; });
  series.forEach(se => {
    s += '<polyline fill="none" stroke-width="2" stroke-linejoin="round" stroke-linecap="round" points="' + se.values.map((v, i) => X(i) + ',' + Y(v.p)).join(' ') + '" style="stroke:var(' + se.c + ')" />';
    se.values.forEach((v, i) => { s += '<circle cx="' + X(i) + '" cy="' + Y(v.p) + '" r="4" stroke-width="2" style="fill:var(' + se.c + ');stroke:var(--paper)" />'; });
  });
  labels.forEach((lb, i) => {
    const bandW = pw / (labels.length - 1), a = Math.max(L, X(i) - bandW / 2), b = Math.min(w - R, X(i) + bandW / 2);
    const tip = lb + '\n' + series.map(se => se.en + ': ' + se.values[i].p + '% (' + se.values[i].c + ' of ' + se.values[i].n + ')').join('\n');
    s += '<rect x="' + a + '" y="' + T + '" width="' + (b - a) + '" height="' + ph + '" data-tip="' + esc(tip) + '" tabindex="0" style="fill:transparent" />';
  });
  el.innerHTML = s + '</svg>';
}
function scatter(el, pts) {
  const w = Math.max(280, el.clientWidth || 600), h = 280, L = 40, R = 14, T = 10, B = 30, pw = w - L - R, ph = h - T - B, x0 = 1996, x1 = 2027, ymax = 90;
  const X = v => L + pw * (v - x0) / (x1 - x0), Y = v => T + ph * (1 - Math.min(v, ymax) / ymax);
  let s = '<svg width="' + w + '" height="' + h + '" viewBox="0 0 ' + w + ' ' + h + '" role="img" aria-label="datasets per study by year">';
  [0, 20, 40, 60, 80].forEach(t => { s += '<line x1="' + L + '" x2="' + (w - R) + '" y1="' + Y(t) + '" y2="' + Y(t) + '" style="stroke:' + (t === 0 ? 'var(--axis)' : 'var(--grid)') + '" /><text x="' + (L - 6) + '" y="' + (Y(t) + 4) + '" font-size="11" text-anchor="end" style="fill:var(--muted)">' + t + '</text>'; });
  [2000, 2005, 2010, 2015, 2020, 2025].forEach(t => { s += '<text x="' + X(t) + '" y="' + (h - 8) + '" font-size="11" text-anchor="middle" style="fill:var(--muted)">' + t + '</text>'; });
  const seen = {};
  pts.forEach(p => {
    const k = p.year + ':' + p.y; seen[k] = (seen[k] || 0) + 1; const cx = X(p.year + (seen[k] - 1) * 0.35), cy = Y(p.y);
    s += '<g data-tip="' + esc(p.tip) + '" tabindex="0" data-key="' + esc(p.key) + '" class="pt"><circle cx="' + cx + '" cy="' + cy + '" r="11" style="fill:transparent" /><circle cx="' + cx + '" cy="' + cy + '" r="4.5" stroke-width="2" style="fill:var(' + p.c + ');stroke:var(--paper)" /></g>';
  });
  el.innerHTML = s + '</svg>';
}

/* chart data on the full empirical corpus */
function metricRows(S, minN) {
  const ms = {}; S.forEach(p => p.metrics_n.forEach(m => { if (m === 'Other') return; ms[m] = ms[m] || {binary: 0, multiclass: 0, both: 0, total: 0}; ms[m][p.setting]++; ms[m].total++; }));
  return Object.keys(ms).filter(m => ms[m].total >= (minN || 1)).sort((a, b) => ms[b].total - ms[a].total || a.localeCompare(b)).map(m => ({label: m, total: ms[m].total, counts: ms[m]}));
}
function protoItems(S) { return PROTO_ORDER.map(k => ({label: k, value: cnt(S, p => p.protocol_class === k)})).filter(i => i.value > 0).map(i => Object.assign(i, {valueLabel: i.value + ' (' + pct(i.value, S.length) + '%)', tip: i.label + '\n' + i.value + ' of ' + S.length + ' studies'})); }
function eraRows(S, field, cats) { return ERAS.map(e => { const E = S.filter(p => p.era === e), counts = {}; cats.forEach(c => { counts[c.k] = cnt(E, p => p[field] === c.k); }); return {label: ERA_EN[e], n: E.length, counts: counts}; }).filter(r => r.n > 0); }
function periodRows() { return PERIODS.map(pr => { const E = EMP.filter(p => p.year >= pr[0] && p.year <= pr[1]), counts = {}; SETTINGS.forEach(s => { counts[s.k] = cnt(E, p => p.setting === s.k); }); return {label: pr[0] + '–' + String(pr[1]).slice(2), from: pr[0], to: pr[1], total: E.length, counts: counts}; }); }
function learnerItems(S) { const c = {}; S.forEach(p => p.clf_families.forEach(f => { c[f] = (c[f] || 0) + 1; })); return Object.keys(c).sort((a, b) => c[b] - c[a] || a.localeCompare(b)).map(f => ({label: f, value: c[f], valueLabel: c[f] + ' (' + pct(c[f], S.length) + '%)', tip: f + '\n' + c[f] + ' of ' + S.length + ' studies'})); }
function trendSeries(S) {
  const defs = [{en: 'Repeated partitions', c: '--s1', f: ST.repeated}, {en: 'Std. dev. reported', c: '--s2', f: p => p.reporting.indexOf('mean +/- std') >= 0}, {en: 'Runtime measured', c: '--s3', f: p => !!p.runtime_reported}, {en: 'Code released', c: '--s4', f: p => p.has_code}];
  return defs.map(d => ({en: d.en, c: d.c, values: ERAS.map(e => { const E = S.filter(p => p.era === e), c = cnt(E, d.f); return {c: c, n: E.length, p: pct(c, E.length)}; })}));
}
function pipelineStats() {
  const c = ST.c, N = ST.N, f = (a) => a + '/' + N;
  return {split: f(c.repeated), resample: f(c.inside), tune: f(c.nested), tuneBad: f(c.evalsel), score: f(c.thrfree), agg: f(c.std), comp: f(c.tcorr + c.tbayes)};
}
function pipelineSVG() {
  const P = pipelineStats(), bw = 128, bh = 44;
  const box = (x, y, t1, t2, stat, statLab, above) => '<g><rect x="' + x + '" y="' + y + '" width="' + bw + '" height="' + bh + '" rx="6" style="fill:var(--paper);stroke:var(--ink-2)" stroke-width="1.2" />' +
    '<text x="' + (x + bw / 2) + '" y="' + (y + (t2 ? 18 : 27)) + '" font-size="12.5" font-weight="600" text-anchor="middle" style="fill:var(--ink)">' + esc(t1) + '</text>' +
    (t2 ? '<text x="' + (x + bw / 2) + '" y="' + (y + 33) + '" font-size="11" text-anchor="middle" style="fill:var(--ink-2)">' + esc(t2) + '</text>' : '') +
    (stat ? '<text x="' + (x + bw / 2) + '" y="' + (above ? y - 8 : y + bh + 15) + '" font-size="11" text-anchor="middle" style="fill:var(--muted)"><tspan style="fill:var(--ink);font-weight:600">' + esc(stat) + '</tspan> ' + esc(statLab) + '</text>' : '') + '</g>';
  const arrow = (d, lab, lx, ly, accent, anchor) => '<path d="' + d + '" fill="none" stroke-width="' + (accent ? 2 : 1.4) + '" ' + (accent ? 'stroke-dasharray="6 4" ' : '') + 'marker-end="url(#' + (accent ? 'ahA' : 'ah') + ')" style="stroke:var(' + (accent ? '--s2' : '--ink-2') + ')" />' +
    (lab ? '<text x="' + lx + '" y="' + ly + '" font-size="11" text-anchor="' + (anchor || 'middle') + '" style="fill:var(' + (accent ? '--flag' : '--ink-2') + ')' + (accent ? ';font-weight:600' : '') + '">' + esc(lab) + '</text>' : '');
  let s = '<svg viewBox="0 0 990 330" width="990" height="330" role="img" aria-label="Flow of one evaluation run: data are split, resampling and tuning sit inside the training part, the model scores the untouched test part, scores are aggregated and compared; two shortcuts cross the training boundary.">';
  s += '<defs><marker id="ah" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" style="fill:var(--ink-2)" /></marker>' +
       '<marker id="ahA" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" style="fill:var(--s2)" /></marker></defs>';
  s += '<rect x="330" y="28" width="476" height="112" rx="10" fill="none" stroke-width="1.2" stroke-dasharray="4 4" style="stroke:var(--muted)" />';
  s += '<text x="342" y="22" font-size="11" style="fill:var(--muted)">fitted on the training part only</text>';
  s += box(12, 128, 'Benchmark data', 'datasets, IR', null);
  s += box(180, 128, 'Split', 'folds or hold-out', P.split, 'repeated');
  s += box(346, 46, 'Resample', 'training part', P.resample, 'stated');
  s += box(502, 46, 'Tune settings', 'inner validation', P.tune, 'nested');
  s += box(658, 46, 'Fit learner', 'base classifier', null);
  s += box(658, 218, 'Score', 'test part', P.score, 'threshold-free');
  s += box(840, 218, 'Aggregate', 'over folds, repeats', P.agg, 'with std');
  s += box(840, 46, 'Compare', 'across datasets', P.comp, 'corrected test', true);
  s += arrow('M140,150 L176,150', '', 0, 0);
  s += arrow('M308,140 C326,140 326,68 342,68', 'training part', 316, 104, false, 'end');
  s += arrow('M474,68 L498,68', '', 0, 0);
  s += arrow('M630,68 L654,68', '', 0, 0);
  s += arrow('M722,90 L722,214', 'fitted model', 730, 160, false, 'start');
  s += arrow('M308,162 C326,162 326,240 342,240 L654,240', 'test part, untouched', 500, 258);
  s += arrow('M786,240 L836,240', '', 0, 0);
  s += arrow('M904,218 L904,94', 'per dataset', 912, 160, false, 'start');
  s += arrow('M60,128 C60,20 250,14 344,58', 'shortcut: resampled before split (1 inferred)', 70, 20, true, 'start');
  s += arrow('M694,218 C690,170 650,124 622,94', 'shortcut: settings picked from test scores (' + P.tuneBad + ')', 594, 196, true, 'end');
  return s + '</svg>';
}
/* influence (citation ratio) forest plot: rows grouped by topic */
const INF_TOPICS = ['data', 'learners', 'measures', 'protocol', 'stats', 'reporting', 'outcomes'];
function influenceRows() {
  const out = [];
  INF_TOPICS.forEach(t => { out.push({head: true, label: AN.topics[t][0]}); AN.influence.filter(r => r.topic === t && r.ratio != null).forEach(r => out.push(r)); });
  return out;
}
function forest(el, rows) {
  const w = Math.max(300, el.clientWidth || 640), narrow = w < 560, labelW = narrow ? 8 : Math.min(270, Math.round(w * .42)), right = 48, rowH = narrow ? 34 : 22, top = 8, axisH = 34;
  const plotW = w - labelW - right, h = top + rows.length * rowH + axisH, lmin = Math.log(0.1), lmax = Math.log(10);
  const X = v => labelW + plotW * (Math.log(Math.min(10, Math.max(0.1, v))) - lmin) / (lmax - lmin);
  let s = '<svg width="' + w + '" height="' + h + '" viewBox="0 0 ' + w + ' ' + h + '" role="img" aria-label="Age-adjusted citation ratio with 95% interval for each evaluation practice">';
  (narrow ? [0.1, 0.5, 1, 2, 10] : [0.1, 0.25, 0.5, 1, 2, 4, 10]).forEach(t => { const x = X(t); s += '<line x1="' + x + '" x2="' + x + '" y1="' + top + '" y2="' + (h - axisH + 4) + '" style="stroke:' + (t === 1 ? 'var(--axis)' : 'var(--grid)') + '" ' + (t === 1 ? 'stroke-width="1.4"' : '') + ' /><text x="' + x + '" y="' + (h - axisH + 18) + '" font-size="11" text-anchor="middle" style="fill:var(--muted)">' + t + '</text>'; });
  s += '<text x="' + X(0.1) + '" y="' + (h - 3) + '" font-size="10.5" style="fill:var(--muted)">cited less</text><text x="' + X(10) + '" y="' + (h - 3) + '" font-size="10.5" text-anchor="end" style="fill:var(--muted)">cited more</text>';
  rows.forEach((r, i) => {
    const y = top + i * rowH + (narrow ? rowH - 10 : rowH / 2);
    if (r.head) { s += '<text x="4" y="' + (narrow ? y - 4 : y + 4) + '" font-size="11.5" font-weight="600" style="fill:var(--ink)">' + esc(r.label) + '</text>'; return; }
    const sig = r.lo > 1 || r.hi < 1, col = sig ? '--s2' : '--s1';
    const tip = r.en + '\nratio ' + r.ratio.toFixed(2) + ' (95% CI ' + r.lo.toFixed(2) + ' to ' + r.hi.toFixed(2) + ')\n' + r.n_users + ' of ' + r.n + ' studies follow it\nmedian citations per year ' + fmtNum(r.med_cpy_users) + ' vs ' + fmtNum(r.med_cpy_other);
    s += '<g data-tip="' + esc(tip) + '" tabindex="0"><rect x="0" y="' + (y - rowH / 2) + '" width="' + w + '" height="' + rowH + '" style="fill:transparent" />';
    s += narrow ? '<text x="' + labelW + '" y="' + (y - 9) + '" font-size="11.5" style="fill:var(--ink-2)">' + esc(fitLabel(r.en, w - 60)) + '</text>' : '<text x="' + (labelW - 8) + '" y="' + (y + 4) + '" text-anchor="end" font-size="12" style="fill:var(--ink-2)">' + esc(fitLabel(r.en, labelW - 16)) + '</text>';
    s += '<line x1="' + X(r.lo) + '" x2="' + X(r.hi) + '" y1="' + y + '" y2="' + y + '" stroke-width="2" stroke-linecap="round" style="stroke:var(' + col + ')" />';
    s += '<circle cx="' + X(r.ratio) + '" cy="' + y + '" r="4.5" stroke-width="2" style="fill:var(' + col + ');stroke:var(--paper)" />';
    s += '<text x="' + (w - 4) + '" y="' + (y + 4) + '" text-anchor="end" font-size="11" style="fill:var(--muted)">' + r.n_users + '/' + r.n + '</text></g>';
  });
  el.innerHTML = s + '</svg>';
}
function dataTable(head, rows) { return '<details class="data"><summary>Show data table</summary><div class="tbl-wrap"><table class="t"><thead><tr>' + head.map((h, i) => '<th' + (i ? ' class="r"' : '') + '>' + esc(h) + '</th>').join('') + '</tr></thead><tbody>' + rows.map(r => '<tr>' + r.map((v, i) => '<td' + (i ? ' class="r"' : '') + '>' + esc(v) + '</td>').join('') + '</tr>').join('') + '</tbody></table></div></details>'; }

const FIG_RENDER = {
  'fig-influence': function (box) {
    const rows = influenceRows();
    box.innerHTML = '<div class="legend"><span><i style="background:var(--s1)"></i>95% interval includes 1</span><span><i style="background:var(--s2)"></i>interval excludes 1</span><span style="color:var(--muted)">right column: studies following the practice / eligible studies</span></div><div class="chart"></div>' +
      dataTable(['Practice', 'Studies', 'Ratio', '95% CI', 'Median cites/yr (follow)', 'Median cites/yr (others)'], rows.filter(r => !r.head).map(r => [r.en, r.n_users + ' of ' + r.n, r.ratio.toFixed(2), r.lo.toFixed(2) + ' to ' + r.hi.toFixed(2), fmtNum(r.med_cpy_users), fmtNum(r.med_cpy_other)]));
    const el = box.querySelector('.chart'); register(el, () => forest(el, rows));
  },
  'fig-corpus': function (box) {
    const rows = periodRows();
    box.innerHTML = legendHTML(SETTINGS) + '<div class="chart"></div>' + dataTable(['Period', 'Binary', 'Multi-class', 'Both', 'Total'], rows.map(r => [r.from + '–' + r.to, r.counts.binary, r.counts.multiclass, r.counts.both, r.total]));
    const el = box.querySelector('.chart'); register(el, () => colStack(el, rows, SETTINGS));
  },
  'fig-datasets': function (box) {
    box.innerHTML = legendHTML(SETTINGS) + '<div class="chart"></div>' + dataTable(['Study', 'Year', 'Setting', 'Real datasets'], EMP.filter(p => p.datasets.n_real != null).sort((a, b) => a.year - b.year).map(p => [p.short, p.year, p.setting, p.datasets.n_real]));
    const el = box.querySelector('.chart');
    register(el, () => scatter(el, EMP.filter(p => p.datasets.n_real != null).map(p => ({key: p.key, year: p.year, y: p.datasets.n_real, c: SETTINGS.find(s => s.k === p.setting).c, tip: p.datasets.n_real + ' real datasets\n' + p.short + ' (' + p.year + '), ' + p.setting}))));
  },
  'fig-learners': function (box) {
    const items = learnerItems(EMP);
    box.innerHTML = '<div class="chart"></div>' + dataTable(['Learner family', 'Studies'], items.map(i => [i.label, i.value]));
    const el = box.querySelector('.chart'); register(el, () => hbar(el, items, {aria: 'base learner families', labelW: 160}));
  },
  'fig-metrics': function (box) {
    const rows = metricRows(EMP, 3);
    box.innerHTML = legendHTML(SETTINGS) + '<div class="chart"></div>' + dataTable(['Measure', 'Binary', 'Multi-class', 'Both', 'Total'], rows.map(r => [r.label, r.counts.binary, r.counts.multiclass, r.counts.both, r.total]));
    const el = box.querySelector('.chart'); register(el, () => stackCounts(el, rows, SETTINGS, {aria: 'measure usage by setting'}));
  },
  'fig-pipeline': function (box) {
    const P = pipelineStats();
    box.innerHTML = '<div class="diagram">' + pipelineSVG() + '</div>' + dataTable(['Step', 'Studies doing it as recommended'], [['Split: repeated partitions', P.split], ['Resample: train-only stated', P.resample], ['Tune: nested or held-out', P.tune], ['Tune: chosen on evaluation data (shortcut)', P.tuneBad], ['Score: threshold-free measure', P.score], ['Aggregate: std reported', P.agg], ['Compare: corrected or Bayesian test', P.comp]]);
  },
  'fig-tuning': function (box) {
    const rows = eraRows(EMP, 'tuning_class', TUNE_CATS);
    box.innerHTML = legendHTML(TUNE_CATS) + '<div class="chart"></div>' + dataTable(['Period'].concat(TUNE_CATS.map(c => c.en)).concat(['n']), rows.map(r => [r.label].concat(TUNE_CATS.map(c => r.counts[c.k])).concat([r.n])));
    const el = box.querySelector('.chart'); register(el, () => stack100(el, rows, TUNE_CATS, {aria: 'hyperparameter selection by period'}));
  },
  'fig-tests': function (box) {
    const rows = eraRows(EMP, 'test_class', TEST_CATS);
    box.innerHTML = legendHTML(TEST_CATS) + '<div class="chart"></div>' + dataTable(['Period'].concat(TEST_CATS.map(c => c.en)).concat(['n']), rows.map(r => [r.label].concat(TEST_CATS.map(c => r.counts[c.k])).concat([r.n])));
    const el = box.querySelector('.chart'); register(el, () => stack100(el, rows, TEST_CATS, {aria: 'statistical testing by period'}));
  },
  'fig-trend': function (box) {
    const ser = trendSeries(EMP);
    box.innerHTML = legendHTML(ser, true) + '<div class="chart"></div>' + dataTable(['Period'].concat(ser.map(s => s.en + ' (%)')), ERAS.map((e, i) => [ERA_EN[e]].concat(ser.map(s => s.values[i].p))));
    const el = box.querySelector('.chart'); register(el, () => lineChart(el, ser, ERAS.map(e => ERA_EN[e])));
  }
};

/* ---------------- category tables (shared rows for HTML and LaTeX) ---------------- */
function famCount(fam) { return cnt(EMP, p => p.metric_families.indexOf(fam) >= 0); }
function protoCount(k) { return cnt(EMP, p => p.protocol_class === k); }
function outCount(k) { return cnt(EMP, p => p.outcome === k); }
function sourceRows() {
  const src = p => (p.datasets.sources || []).join(' ').toLowerCase();
  const defs = [
    {en: 'UCI repository', th: 'คลัง UCI', use: 'Original source of most tabular benchmarks', thuse: 'แหล่งต้นทางของชุดข้อมูลแบบตารางส่วนใหญ่', f: p => p.uses_uci},
    {en: 'KEEL repository', th: 'คลัง KEEL', use: 'Pre-binarised imbalanced sets with fixed folds', thuse: 'ชุดข้อมูลไม่สมดุลที่แปลงเป็นสองคลาสแล้วพร้อม fold กำหนดไว้', f: p => p.uses_keel},
    {en: 'Synthetic data', th: 'ข้อมูลสังเคราะห์', use: 'Controlled overlap, noise or class shapes', thuse: 'ควบคุมการซ้อนทับ สัญญาณรบกวน หรือรูปร่างคลาส', f: p => (p.datasets.n_synthetic || 0) > 0},
    {en: 'Private or application data', th: 'ข้อมูลเฉพาะหรือข้อมูลจากการใช้งานจริง', use: 'Case studies in one domain', thuse: 'กรณีศึกษาในโดเมนเดียว', f: p => /private|bank|bearing|clinical|cancer|sensor|registry|intrusion|fraud/.test(src(p))},
    {en: 'Image benchmarks', th: 'ชุดข้อมูลภาพ', use: 'Imbalance induced in balanced image sets', thuse: 'สร้างความไม่สมดุลจากชุดภาพที่สมดุล', f: p => /mnist|cifar|imagenet|svhn|celeba|lsun|sun397/.test(src(p))},
    {en: 'Other repositories', th: 'คลังอื่น', use: 'Kaggle, OpenML, imbalanced-learn, LIBSVM, UCR, PROMISE', thuse: 'Kaggle, OpenML, imbalanced-learn, LIBSVM, UCR, PROMISE', f: p => /kaggle|openml|imbalanced-learn|libsvm|ucr|promise/.test(src(p))}
  ];
  return defs.map(d => Object.assign(d, {n: cnt(EMP, d.f)}));
}
const REASON_LABEL = {
  varied_characteristics: ['range of IR, size or dimension', 'ครอบคลุม IR ขนาด หรือจำนวนมิติที่หลากหลาย'], imbalance_level: ['a target imbalance level', 'ระดับความไม่สมดุลที่ต้องการ'],
  follows_prior_work: ['set-up of a named earlier study', 'ตามการทดลองของงานก่อนหน้าที่ระบุชื่อ'], difficulty_factors: ['overlap, noise or small disjuncts', 'การซ้อนทับ สัญญาณรบกวน หรือกลุ่มย่อยขนาดเล็ก'],
  comparability: ['comparability with published results', 'เทียบกับผลที่ตีพิมพ์ได้'], public_benchmark: ['public availability', 'เปิดเผยต่อสาธารณะ'],
  application_domain: ['an application domain', 'โดเมนการใช้งาน'], multiclass_availability: ['many classes', 'มีหลายคลาส'],
  popular: ['widely used or well known', 'นิยมใช้หรือเป็นที่รู้จัก'], diverse_paradigms: ['different learning paradigms', 'ครอบคลุมกระบวนทัศน์การเรียนรู้ต่างกัน'],
  simplicity: ['simple, fast or interpretable', 'เรียบง่าย เร็ว หรือตีความได้'], fair_comparison: ['same learner for all methods', 'ใช้ตัวจำแนกเดียวกันกับทุกวิธี'],
  sensitive_to_imbalance: ['sensitive to imbalance', 'ไวต่อความไม่สมดุล'], matches_mechanism: ['matches how the method works', 'สอดคล้องกับกลไกของวิธี'],
  standard_in_literature: ['standard in the literature', 'เป็นมาตรฐานในงานวิจัย'], accuracy_misleading: ['accuracy misleads under imbalance', 'accuracy ให้ภาพผิดเมื่อข้อมูลไม่สมดุล'],
  minority_focus: ['focus on the minority class', 'เน้นคลาสส่วนน้อย'], threshold_free: ['independent of the threshold', 'ไม่ขึ้นกับค่าเกณฑ์'],
  multiclass_suitability: ['suits several classes', 'เหมาะกับหลายคลาส'], cost: ['costs of an application', 'ต้นทุนของการใช้งาน']
};
function reasonRows() {
  const c = ST.c, N = ST.N;
  return [
    {en: 'Benchmark data', th: 'ชุดข้อมูลทดสอบ', stated: c.data_stated, of: N, reasons: [['varied_characteristics', c.dr_varied], ['imbalance_level', c.dr_imb], ['follows_prior_work', c.dr_follow], ['difficulty_factors', c.dr_diff], ['comparability', c.dr_comp], ['public_benchmark', c.dr_public], ['application_domain', c.dr_app]], ex: ['MWMOTE-2014', 'SMOTE-IPF-2015', 'MC-CCR-2020']},
    {en: 'Base learners', th: 'ตัวจำแนกพื้นฐาน', stated: c.learner_stated, of: N, reasons: [['popular', c.lr_popular], ['diverse_paradigms', c.lr_diverse], ['follows_prior_work', c.lr_follow], ['simplicity', c.lr_simple], ['fair_comparison', c.lr_fair], ['sensitive_to_imbalance', c.lr_sens], ['matches_mechanism', c.lr_mech]], ex: ['SPIDER2-2010', 'NROMM-2023', 'GDHS-2025']},
    {en: 'Measures', th: 'ตัวชี้วัด', stated: c.measure_stated, of: N, reasons: [['standard_in_literature', c.mr_std], ['accuracy_misleading', c.mr_acc], ['minority_focus', c.mr_min], ['threshold_free', c.mr_thr], ['multiclass_suitability', c.mr_mc], ['cost', c.mr_cost]], ex: ['OSS-1997', 'SplitBal-2015', 'CISO-2025']},
    {en: 'Measure used to select settings', th: 'ตัวชี้วัดที่ใช้เลือกค่าพารามิเตอร์', stated: c.ms_crit, of: c.ms_n, reasons: [[['G-mean', 'G-mean'], c.msc_gmean], [['AUC', 'AUC'], c.msc_auc], [['F1', 'F1'], c.msc_f1], [['AvAcc', 'AvAcc'], c.msc_avacc], [['sensitivity (recall)', 'sensitivity (recall)'], c.msc_sens], [['MAUC', 'MAUC'], c.msc_mauc]], ex: ['SHRINK-1998', 'LS-2008', 'RACOG-2015']}
  ].map(r => Object.assign(r, {reasons: r.reasons.map(x => ({en: Array.isArray(x[0]) ? x[0][0] : REASON_LABEL[x[0]][0], th: Array.isArray(x[0]) ? x[0][1] : REASON_LABEL[x[0]][1], n: x[1]})).filter(x => x.n > 0)}));
}
function beyondRows() {
  const c = ST.c;
  return [
    {en: 'Visual inspection', th: 'การตรวจด้วยภาพ', what: '2-D plots of where synthetic points fall; PCA or t-SNE projections; histograms of real and synthetic columns', thwhat: 'กราฟสองมิติของตำแหน่งตัวอย่างสังเคราะห์ ภาพฉาย PCA หรือ t-SNE และฮิสโทแกรมของข้อมูลจริงกับข้อมูลสังเคราะห์', n: c.beyond_visual, ex: ['Borderline-SMOTE-2005', 'MBS-2020', 'SOS-2022']},
    {en: 'Analytical properties', th: 'สมบัติเชิงวิเคราะห์', what: 'Theorems or bounds on the sampler; big-O time or memory', thwhat: 'ทฤษฎีบทหรือขอบเขตของวิธีสุ่มตัวอย่าง และความซับซ้อนเชิงเวลาหรือหน่วยความจำ', n: c.beyond_analytic, ex: ['GAMO-2019', 'MDO-2016', 'CISO-2025']},
    {en: 'Model diagnostics without a score', th: 'การวินิจฉัยแบบจำลองที่ไม่ใช่คะแนน', what: 'Size of trees or rule sets learned from the resampled data; diversity of ensemble members', thwhat: 'ขนาดต้นไม้หรือชุดกฎที่เรียนจากข้อมูลหลังปรับสมดุล และความหลากหลายของสมาชิกใน ensemble', n: c.beyond_model, ex: ['SMOTE-2002', 'SMOTE-ENN-Tomek-2004', 'RBBoost-2015']},
    {en: 'Direct measurement of the resampled data', th: 'การวัดข้อมูลหลังปรับสมดุลโดยตรง', what: 'Distance or likelihood between real and synthetic distributions (MMD, FID, likelihood fitness); share of synthetic examples removed as noise; safe, borderline, rare and outlier composition', thwhat: 'ระยะห่างหรือ likelihood ระหว่างการแจกแจงจริงกับสังเคราะห์ (MMD, FID, likelihood fitness) สัดส่วนตัวอย่างสังเคราะห์ที่ถูกลบเป็นสัญญาณรบกวน และสัดส่วนตัวอย่างแบบ safe, borderline, rare และ outlier', n: c.beyond_direct, ex: ['CTGAN-2019', 'SMOTE-IPF-2015', 'SPE-2020']},
    {en: 'Classifier scores only', th: 'ใช้คะแนนของตัวจำแนกเท่านั้น', what: 'No evidence of any of the kinds above', thwhat: 'ไม่มีหลักฐานประเภทใดข้างต้น', n: c.beyond_none, ex: ['ADASYN-2008', 'MWMOTE-2014', 'FW-SMOTE-2022']}
  ];
}
function outcomeExamplesShown(k) { return (OUTCOMES.find(o => o.k === k) || {ex: []}).ex; }
const TABLE_HTML = {
  'tab-measures': () => '<table class="t booktabs"><thead><tr><th>Family</th><th>Measures</th><th>Captures</th><th>Advantages</th><th>Limitations</th><th class="r">Studies</th><th>Examples</th></tr></thead><tbody>' +
    MEASURE_FAMILIES.map(r => '<tr><td><b>' + esc(r.en) + '</b><div class="tth">' + esc(r.th.fam) + '</div></td><td>' + esc(r.measures) + '</td><td>' + esc(r.cap) + '<div class="tth">' + esc(r.th.cap) + '</div></td><td>' + esc(r.adv) + '<div class="tth">' + esc(r.th.adv) + '</div></td><td>' + esc(r.lim) + '<div class="tth">' + esc(r.th.lim) + '</div></td><td class="r">' + famCount(r.fam) + '</td><td>' + citesHTML(r.ex) + '</td></tr>').join('') + '</tbody></table>',
  'tab-sources': () => '<table class="t booktabs"><thead><tr><th>Source</th><th class="r">Studies</th><th class="r">Share</th><th>Typical use</th></tr></thead><tbody>' +
    sourceRows().map(r => '<tr><td><b>' + esc(r.en) + '</b><div class="tth">' + esc(r.th) + '</div></td><td class="r">' + r.n + '</td><td class="r">' + pct(r.n, ST.N) + '%</td><td>' + esc(r.use) + '<div class="tth">' + esc(r.thuse) + '</div></td></tr>').join('') + '</tbody></table>',
  'tab-reasons': () => '<table class="t booktabs"><thead><tr><th>Choice</th><th class="r">Studies giving a reason</th><th>Reasons given (studies)</th><th>Examples</th></tr></thead><tbody>' +
    reasonRows().map(r => '<tr><td><b>' + esc(r.en) + '</b><div class="tth">' + esc(r.th) + '</div></td><td class="r">' + r.stated + ' of ' + r.of + '</td><td>' + r.reasons.map(x => esc(x.en) + ' (' + x.n + ')').join('; ') + '<div class="tth">' + r.reasons.map(x => esc(x.th) + ' (' + x.n + ')').join('; ') + '</div></td><td>' + citesHTML(r.ex) + '</td></tr>').join('') + '</tbody></table>',
  'tab-beyond': () => '<table class="t booktabs"><thead><tr><th>Evidence</th><th>What it shows</th><th class="r">Studies</th><th>Examples</th></tr></thead><tbody>' +
    beyondRows().map(r => '<tr><td><b>' + esc(r.en) + '</b><div class="tth">' + esc(r.th) + '</div></td><td>' + esc(r.what) + '<div class="tth">' + esc(r.thwhat) + '</div></td><td class="r">' + r.n + '</td><td>' + citesHTML(r.ex) + '</td></tr>').join('') + '</tbody></table><p class="appx-note">A study can provide several kinds of evidence; the counts overlap.</p>',
  'tab-metric': () => { const rows = EMP.filter(p => p.metric_issue).sort((a, b) => a.year - b.year); return '<table class="t booktabs"><thead><tr><th>Study</th><th>Setting</th><th>Problem</th></tr></thead><tbody>' + rows.map(p => '<tr><td><button class="cite" data-key="' + esc(p.key) + '">' + esc(p.short + ' ' + p.year) + '</button></td><td>' + esc(p.setting) + '</td><td>' + esc(p.metric_issue) + '</td></tr>').join('') + '</tbody></table>'; },
  'tab-protocols': () => '<table class="t booktabs"><thead><tr><th>Protocol</th><th>Description</th><th>Advantages</th><th>Limitations</th><th class="r">Studies</th><th>Examples</th></tr></thead><tbody>' +
    PROTOCOLS.map(r => '<tr><td><b>' + esc(r.en) + '</b><div class="tth">' + esc(r.th.en) + '</div></td><td>' + esc(r.desc) + '<div class="tth">' + esc(r.th.desc) + '</div></td><td>' + esc(r.adv) + '<div class="tth">' + esc(r.th.adv) + '</div></td><td>' + esc(r.lim) + '<div class="tth">' + esc(r.th.lim) + '</div></td><td class="r">' + protoCount(r.k) + '</td><td>' + citesHTML(r.ex) + '</td></tr>').join('') + '</tbody></table>',
  'tab-outcomes': () => '<table class="t booktabs"><thead><tr><th>Outcome</th><th>Description</th><th class="r">Studies</th><th>Examples</th></tr></thead><tbody>' +
    OUTCOMES.map(r => '<tr><td><b>' + esc(r.k + '. ' + r.en) + '</b><div class="tth">' + esc(r.th) + '</div></td><td>' + esc(r.desc) + '<div class="tth">' + esc(r.thdesc) + '</div></td><td class="r">' + outCount(r.k) + '</td><td>' + citesHTML(r.ex) + '</td></tr>').join('') + '</tbody></table>',
  'tab-remedies': () => '<table class="t booktabs"><thead><tr><th>Observed problem</th><th class="r">Studies</th><th>Recommended practice</th></tr></thead><tbody>' +
    REMEDIES.map(r => '<tr><td><b>' + esc(r.en) + '</b><div class="tth">' + esc(r.th) + '</div></td><td class="r">' + renderText(r.ev, 'en') + '</td><td>' + esc(r.remedy) + '<div class="tth">' + esc(r.thr) + '</div></td></tr>').join('') + '</tbody></table>'
};

/* ---------------- draft view ---------------- */
function blockHTML(b, lang) {
  const L = (en, th) => lang === 'th' ? th : en;
  if (b.fig) { const F = FIGS[b.fig]; return '<figure class="fig" id="' + b.fig + '"><div class="fig-cap"><span class="lab">' + L('Figure ', 'รูปที่ ') + F.n + '</span><span>' + esc(lang === 'th' ? F.th : F.en) + '</span>' + (lang === 'both' ? '<span class="th">' + esc(F.th) + '</span>' : '') + '</div><div class="figbody" data-fig="' + b.fig + '"></div></figure>'; }
  if (b.table) { const T = TABS[b.table]; return '<figure class="fig tablefig" id="' + b.table + '"><div class="fig-cap"><span class="lab">' + L('Table ', 'ตารางที่ ') + T.n + '</span><span>' + esc(lang === 'th' ? T.th : T.en) + '</span>' + (lang === 'both' ? '<span class="th">' + esc(T.th) + '</span>' : '') + '</div><div class="tbl-wrap">' + TABLE_HTML[b.table]() + '</div></figure>'; }
  if (b.eq) { const E = EQS[b.eq]; return '<div class="eq" id="eq-' + b.eq + '"><div class="eqm">' + mathHTML(E.tex) + '</div><span class="eqn">(' + E.n + ')</span></div>'; }
  if (b.rq) return '<ol class="rqs">' + b.rq.map(r => '<li><span class="rqid">' + r.id + '</span><div class="pair"><p class="en">' + esc(r.en) + ' <a class="xref" href="#sec-' + r.ref.slice(4) + '" data-jump="sec-' + r.ref.slice(4) + '">' + esc(refLabel(r.ref, 'en')) + '</a></p><p class="th">' + esc(r.th) + ' <a class="xref" href="#sec-' + r.ref.slice(4) + '" data-jump="sec-' + r.ref.slice(4) + '">' + esc(refLabel(r.ref, 'th')) + '</a></p></div></li>').join('') + '</ol>';
  if (b.aside) return '<aside class="aside"><div class="aside-h">' + esc(L('Exploratory, HTML only: not exported to LaTeX', 'สำรวจเบื้องต้น แสดงเฉพาะใน HTML ไม่ส่งออกไป LaTeX')) + '</div><div class="pair"><p class="en">' + renderText(b.en, 'en') + '</p><p class="th">' + renderText(b.th, 'th') + '</p></div></aside>';
  if (b.thesis) return '<blockquote class="thesis"><div class="pair"><p class="en">' + renderText(b.en, 'en') + '</p><p class="th">' + renderText(b.th, 'th') + '</p></div></blockquote>';
  return '<div class="pair"><p class="en">' + renderText(b.en, 'en') + '</p><p class="th">' + renderText(b.th, 'th') + '</p></div>';
}
function renderDraft() {
  const lang = state.lang, L = (en, th) => lang === 'th' ? th : en;
  document.getElementById('outline').innerHTML = '<li><a href="#sec-intro" data-jump="sec-intro"><span class="n">' + SECTION.num + '</span><span>' + esc(L('Introduction to the section', 'บทนำของหัวข้อ')) + '</span></a></li>' +
    PROSE.map(s => '<li><a href="#sec-' + s.id + '" data-jump="sec-' + s.id + '"><span class="n">' + SEC_NUM[s.id] + '</span><span>' + esc(L(s.en, s.th)) + '</span>' + (lang === 'both' ? '<span class="t2">' + esc(s.th) + '</span>' : '') + '</a></li>').join('');
  let h = '<div class="sheet-head"><h2><span class="secnum">' + SECTION.num + '</span> ' + esc(L(SECTION.en, SECTION.th)) + '</h2><span class="latexname">sections/07-empirical-comparisons.tex · \\label{' + SECTION.label + '}</span></div>';
  h += '<section class="sec" id="sec-intro">' + (lang === 'both' ? '<p class="sec-sub">' + esc(SECTION.th) + '</p>' : '') + INTRO.map(b => blockHTML(b, lang)).join('') + '</section>';
  PROSE.forEach(s => {
    h += '<section class="sec" id="sec-' + s.id + '"><div class="sec-h"><span class="n">' + SEC_NUM[s.id] + '</span><h3 class="en">' + esc(s.en) + '</h3><span class="th">' + esc(s.th) + '</span></div>';
    s.blocks.forEach(b => { h += b.list ? '' : blockHTML(b, lang); });
    h += '</section>';
  });
  h += '<section class="sec appx" id="tab-map"><div class="sec-h"><span class="n">B</span><h3 class="en">' + esc(TABS['tab-map'].en) + '</h3><span class="th">' + esc(TABS['tab-map'].th) + '</span></div><p class="appx-note">' + esc(L('Appendix B in the paper (Table B1). The full map with every coded field is in the Evidence explorer; the LaTeX longtable is in LaTeX export.', 'ภาคผนวก B ในบทความ (ตารางที่ B1) แผนที่ฉบับเต็มพร้อมทุกรหัสอยู่ในแท็บสำรวจหลักฐาน และ longtable ของ LaTeX อยู่ในแท็บส่งออก')) + '</p><div class="tbl-wrap">' + mapTableHTML() + '</div></section>';
  const sheet = document.getElementById('sheet');
  charts.length = 0;
  sheet.innerHTML = h;
  sheet.querySelectorAll('.figbody').forEach(box => FIG_RENDER[box.dataset.fig](box));
}
function mapRows() { return EMP.slice().sort((a, b) => ({binary: 0, multiclass: 1, both: 2}[a.setting] - {binary: 0, multiclass: 1, both: 2}[b.setting]) || a.year - b.year || a.short.localeCompare(b.short)); }
function protoShortTxt(p) { const k = p.cv_k && p.cv_k !== 'other' ? p.cv_k : 'k'; return {'Repeated k-fold CV': 'rep. ' + k + '-CV', 'Single k-fold CV': k + '-CV', '5x2 CV': '5×2 CV', 'Repeated hold-out': 'rep. hold-out', 'Single hold-out': 'hold-out', 'Fixed benchmark split': 'fixed split', 'Not stated': 'n.s.'}[p.protocol_class] || p.protocol_class; }
function mapTableHTML() {
  const SET = {binary: 'B', multiclass: 'M', both: 'B+M'};
  return '<table class="t booktabs map"><thead><tr><th>Study</th><th>Year</th><th>Set.</th><th class="r">DS</th><th>Classes</th><th>Base learners</th><th>Measures</th><th>Protocol</th><th>Test</th><th>Out.</th></tr></thead><tbody>' +
    mapRows().map(p => '<tr><td><button class="cite" data-key="' + esc(p.key) + '">' + esc(p.short) + '</button></td><td>' + p.year + '</td><td>' + SET[p.setting] + '</td><td class="r">' + (p.datasets.n_real == null ? 'n/a' : p.datasets.n_real) + '</td><td>' + esc(p.datasets.n_classes_range || 'n/a') + '</td><td>' + esc(p.clf_families.join(', ')) + '</td><td>' + esc(p.metrics_n.filter(m => m !== 'Other' && m !== 'Confusion matrix').join(', ')) + '</td><td>' + esc(protoShortTxt(p)) + '</td><td>' + esc(p.tests_n.join(', ') || 'none') + '</td><td>' + esc(p.outcome) + '</td></tr>').join('') +
    '</tbody></table><p class="appx-note">B = binary, M = multi-class; DS = real datasets; k-CV = k-fold cross-validation; rep. = repeated; n.s. = not stated; Out. = outcome class of ' + refLabel('tab-outcomes', 'en') + '.</p>';
}

/* ---------------- explorer ---------------- */
function filtered() {
  const f = state.f, q = f.q.trim().toLowerCase();
  return (f.all ? ALL : EMP).filter(p =>
    (f.setting === 'all' || p.setting === f.setting) && (f.era === 'all' || p.era === f.era) && (f.approach === 'all' || p.approach === f.approach) &&
    (f.test === 'all' || p.test_class === f.test) && (f.tune === 'all' || p.tuning_class === f.tune) && (f.proto === 'all' || p.protocol_class === f.proto) &&
    (f.outcome === 'all' || p.outcome === f.outcome) && (!f.issues || p.metric_issue || p.integrity.length) &&
    (!q || [p.key, p.bibkey, p.short, p.method, p.title, p.authors, p.venue, (p.classifiers || []).join(' '), p.metrics_n.join(' '), (p.baselines || []).join(' '), p.tests_n.join(' '), p.protocol || ''].join(' ').toLowerCase().indexOf(q) >= 0));
}
function opts(values, cur, allLabel, labels) { return '<option value="all">' + esc(allLabel) + '</option>' + values.map(v => '<option value="' + esc(v) + '"' + (v === cur ? ' selected' : '') + '>' + esc(labels ? labels[v] : v) + '</option>').join(''); }
function uniq(f) { return Array.from(new Set(ALL.map(f))).filter(Boolean).sort(); }
function renderExplorerShell() {
  const v = document.getElementById('v-explorer'), f = state.f;
  v.innerHTML = '<div class="filters" role="search">' +
    '<input type="search" id="f-q" placeholder="Search method, author, measure, learner, test…" aria-label="Search studies" value="' + esc(f.q) + '">' +
    '<select id="f-setting" aria-label="Setting">' + opts(['binary', 'multiclass', 'both'], f.setting, 'All settings') + '</select>' +
    '<select id="f-era" aria-label="Period">' + opts(ERAS, f.era, 'All periods') + '</select>' +
    '<select id="f-approach" aria-label="Approach">' + opts(uniq(p => p.approach), f.approach, 'All approaches') + '</select>' +
    '<select id="f-proto" aria-label="Protocol">' + opts(PROTO_ORDER, f.proto, 'All protocols') + '</select>' +
    '<select id="f-test" aria-label="Statistical test">' + opts(TEST_CATS.map(c => c.k), f.test, 'All test types') + '</select>' +
    '<select id="f-tune" aria-label="Tuning">' + opts(TUNE_CATS.map(c => c.k), f.tune, 'All tuning types') + '</select>' +
    '<select id="f-outcome" aria-label="Outcome">' + opts(['A', 'B', 'C', 'D'], f.outcome, 'All outcomes', OUT_LABEL) + '</select>' +
    '<label class="chk"><input type="checkbox" id="f-issues"' + (f.issues ? ' checked' : '') + '> Flagged only</label>' +
    '<label class="chk"><input type="checkbox" id="f-all"' + (f.all ? ' checked' : '') + '> Include surveys and foundational</label>' +
    '<button class="reset" id="f-reset">Reset</button><span class="count" id="f-count"></span></div>' +
    '<div class="kpis" id="kpis"></div>' +
    '<div class="minis"><div class="panel"><h3>Measures<small>studies using each, top 10</small></h3><div class="chart" id="mini-met"></div></div>' +
    '<div class="panel"><h3>Validation protocol</h3><div class="chart" id="mini-proto"></div></div>' +
    '<div class="panel"><h3>Statistical testing</h3><div class="chart" id="mini-test"></div></div></div>' +
    '<div class="ptable"><div class="tbl-wrap" id="ptable"></div></div>';
  ['mini-met', 'mini-proto', 'mini-test'].forEach(id => { const el = document.getElementById(id); register(el, () => renderMini(id)); });
  renderExplorerBody();
}
function renderMini(id) {
  const S = filtered().filter(p => p.empirical), el = document.getElementById(id);
  if (!el) return;
  if (!S.length) { el.innerHTML = '<p style="color:var(--muted);margin:0">No empirical studies match these filters.</p>'; return; }
  if (id === 'mini-met') hbar(el, metricRows(S, 1).slice(0, 10).map(r => ({label: r.label, value: r.total, valueLabel: r.total + ' (' + pct(r.total, S.length) + '%)', tip: r.label + '\n' + r.total + ' of ' + S.length + ' studies'})), {labelW: 130, aria: 'measures in filtered studies'});
  if (id === 'mini-proto') hbar(el, protoItems(S), {labelW: 150, aria: 'protocols in filtered studies'});
  if (id === 'mini-test') hbar(el, TEST_CATS.map(c => ({label: c.en, value: cnt(S, p => p.test_class === c.k), color: c.c})).map(i => Object.assign(i, {valueLabel: i.value + ' (' + pct(i.value, S.length) + '%)', tip: i.label + '\n' + i.value + ' of ' + S.length + ' studies'})), {labelW: 170, aria: 'tests in filtered studies'});
}
function tunePill(t) { const m = {'Nested / held-out tuning': 'ok', 'Selected on evaluation data': 'flag'}; return '<span class="pill ' + (m[t] || 'neu') + '">' + esc(t === 'Unclear' ? 'Not stated' : t) + '</span>'; }
function testPill(t) { const m = {'None': 'flag', 'Corrected multiple comparison': 'ok', 'Bayesian': 'ok'}; return '<span class="pill ' + (m[t] || 'neu') + '">' + esc(t) + '</span>'; }
function outPill(o) { if (!o) return ''; const m = {A: 'neu', B: 'neu', C: 'ok', D: 'neu'}; return '<span class="pill ' + m[o] + '" title="' + esc(OUT_LABEL[o]) + '">' + o + '. ' + esc(OUT_LABEL[o]) + '</span>'; }
const SORTERS = {
  method: p => p.short.toLowerCase(), year: p => p.year, setting: p => p.setting, ds: p => p.datasets.n_real == null ? -1 : p.datasets.n_real,
  clf: p => p.n_clf, met: p => p.metrics_n.length, cites: p => p.cites == null ? -1 : p.cites_per_year, proto: p => PROTO_ORDER.indexOf(p.protocol_class), test: p => TEST_CATS.findIndex(c => c.k === p.test_class), tune: p => TUNE_CATS.findIndex(c => c.k === p.tuning_class), out: p => p.outcome || 'Z'
};
function computeStatsLite(S) {
  const nr = S.map(p => p.datasets.n_real).filter(x => x != null);
  return {bin: cnt(S, p => p.setting === 'binary'), mc: cnt(S, p => p.setting === 'multiclass'), both: cnt(S, p => p.setting === 'both'),
    dsmed: median(nr), dsmin: nr.length ? Math.min.apply(null, nr) : 'n/a', dsmax: nr.length ? Math.max.apply(null, nr) : 'n/a',
    anytest: cnt(S, p => p.test_class !== 'None'), corr: cnt(S, ST.corr), inside: cnt(S, p => p.resampling_inside_cv === true),
    evalsel: cnt(S, p => p.tuning_class === 'Selected on evaluation data'), nested: cnt(S, p => p.tuning_class === 'Nested / held-out tuning'),
    code: cnt(S, p => p.has_code), runtime: cnt(S, p => !!p.runtime_reported)};
}
function renderExplorerBody() {
  const S = filtered(), SE = S.filter(p => p.empirical), st = computeStatsLite(SE);
  document.getElementById('f-count').textContent = S.length + ' of ' + (state.f.all ? ALL.length : EMP.length) + ' studies';
  const k = (l, th, v, s) => '<div class="kpi"><div class="l">' + l + '<span class="th">' + th + '</span></div><div class="v">' + v + '</div><div class="s">' + s + '</div></div>';
  document.getElementById('kpis').innerHTML = !SE.length ? '' :
    k('Empirical studies', 'งานเชิงทดลอง', SE.length, st.bin + ' binary · ' + st.mc + ' multi-class · ' + st.both + ' both') +
    k('Median real datasets', 'มัธยฐานจำนวนชุดข้อมูลจริง', fmtNum(st.dsmed), 'range ' + st.dsmin + ' to ' + st.dsmax) +
    k('Any significance test', 'มีการทดสอบทางสถิติ', pct(st.anytest, SE.length) + '%', st.corr + ' with corrected or Bayesian procedure') +
    k('Train-only resampling stated', 'ระบุว่าปรับสมดุลเฉพาะข้อมูลฝึก', pct(st.inside, SE.length) + '%', st.inside + ' of ' + SE.length + ' studies') +
    k('Settings chosen on evaluation data', 'เลือกค่าจากข้อมูลที่ใช้ประเมิน', pct(st.evalsel, SE.length) + '%', st.nested + ' tune with nested or held-out data') +
    k('Code released', 'เผยแพร่โค้ด', pct(st.code, SE.length) + '%', st.runtime + ' report runtime');
  const sk = state.sort.k, dir = state.sort.dir, sorter = SORTERS[sk];
  const rows = S.slice().sort((a, b) => { const x = sorter(a), y = sorter(b); return (x > y ? 1 : x < y ? -1 : a.year - b.year) * dir; });
  const th = (key, label) => '<th><button data-sort="' + key + '"' + (sk === key ? ' data-dir="' + (dir > 0 ? '↑' : '↓') + '"' : '') + '>' + label + '</button></th>';
  let h = '<table class="t"><thead><tr>' + th('method', 'Method') + th('year', 'Year') + th('setting', 'Setting') + th('ds', 'Real data') + th('clf', 'Base learners') + th('met', 'Measures') + th('proto', 'Protocol') + th('test', 'Statistical test') + th('tune', 'Hyperparameters') + th('out', 'Outcome') + th('cites', 'Citations') + '<th>Flags</th></tr></thead><tbody>';
  rows.forEach(p => {
    const d = p.datasets, flags = [];
    if (p.metric_issue) flags.push('<span class="pill flag" title="' + esc(p.metric_issue) + '">measure definition</span>');
    if (p.integrity.length) flags.push('<span class="pill bad" title="' + esc(p.integrity.join('; ')) + '">integrity</span>');
    if (p.resampling_inside_cv === true) flags.push('<span class="pill ok">train-only stated</span>');
    if (p.no_resampling_baseline === false && p.empirical) flags.push('<span class="pill neu">no untreated baseline</span>');
    h += '<tr><td><button class="m" data-key="' + esc(p.key) + '">' + esc(p.short) + '<span class="sub">' + esc(p.venue || 'venue not printed') + '</span></button></td><td>' + p.year + '</td><td><span class="chip">' + esc(p.setting) + '</span></td>' +
      '<td>' + (d.n_real == null ? '<span style="color:var(--muted)">n/a</span>' : d.n_real) + (d.n_synthetic ? ' <span class="sub" style="display:inline;color:var(--muted)">+' + d.n_synthetic + ' syn.</span>' : '') + '</td>' +
      '<td>' + esc(p.clf_families.join(', ') || 'n/a') + '</td><td>' + p.metrics_n.filter(m => m !== 'Other').map(m => '<span class="chip">' + esc(m) + '</span>').join('') + '</td>' +
      '<td>' + esc(p.protocol_class) + (p.cv_k && p.cv_k !== 'other' ? ' (k=' + p.cv_k + ')' : '') + '</td><td>' + testPill(p.test_class) + '<div class="sub" style="font-size:11.5px;color:var(--muted)">' + esc(p.tests_n.join(', ')) + '</div></td><td>' + tunePill(p.tuning_class) + '</td><td>' + outPill(p.outcome) + '</td><td>' + (p.cites == null ? '<span style="color:var(--muted)">n/a</span>' : big(p.cites) + '<div class="sub" style="font-size:11.5px;color:var(--muted)">' + p.cites_per_year + '/yr</div>') + '</td><td>' + flags.join('') + '</td></tr>';
  });
  h += '</tbody></table>';
  document.getElementById('ptable').innerHTML = rows.length ? h : '<p style="padding:16px;margin:0;color:var(--muted)">No studies match. Clear a filter or press Reset.</p>';
  ['mini-met', 'mini-proto', 'mini-test'].forEach(renderMini);
}

/* ---------------- drawer ---------------- */
let lastFocus = null;
function openRef(r) {
  lastFocus = document.activeElement;
  let h = '<button class="x" id="drawer-close" aria-label="Close">Close</button>';
  h += '<div class="eyebrow" style="font-size:12px;color:var(--muted)">' + esc(r.pub_year + ' · ' + r.venue) + ' · reference work, not in the corpus</div><h2>' + esc(r.label) + '</h2>';
  h += '<div class="ttl">' + esc(r.title || r.title_in) + '</div><div class="au">' + esc(r.bib_authors) + '</div>';
  h += '<h4>Citations</h4><dl><dt>OpenAlex</dt><dd>' + big(r.cites) + ' (retrieved ' + esc(AN.retrieved) + ')' + (r.alt_total ? '; other records of the same work add ' + big(r.alt_total) : '') + '</dd><dt>Match</dt><dd>' + esc(r.match) + '</dd>' + (r.doi ? '<dt>DOI</dt><dd><a href="https://doi.org/' + esc(r.doi) + '" target="_blank" rel="noopener">' + esc(r.doi) + '</a></dd>' : '') + '<dt>OpenAlex ID</dt><dd>' + esc(r.openalex_id) + '</dd></dl>';
  h += '<h4>Cite key</h4><p class="box" style="font-family:var(--f-mono);font-size:12px">\\parencite{' + esc(r.bibkey) + '}</p>';
  const dr = document.getElementById('drawer');
  dr.innerHTML = h; dr.hidden = false; document.getElementById('scrim').hidden = false; dr.scrollTop = 0;
  document.getElementById('drawer-close').focus();
}
function openPaper(key) {
  const p = BY[key]; if (!p) { if (REFS[key]) openRef(REFS[key]); return; }
  lastFocus = document.activeElement;
  const d = p.datasets, dl = rows => '<dl>' + rows.filter(r => r[1] != null && r[1] !== '' && !(Array.isArray(r[1]) && !r[1].length)).map(r => '<dt>' + esc(r[0]) + '</dt><dd>' + (Array.isArray(r[1]) ? esc(r[1].join(', ')) : esc(r[1])) + '</dd>').join('') + '</dl>';
  const yn = v => v === true ? 'yes' : v === false ? 'no' : 'not stated';
  const drive = id => 'https://drive.google.com/file/d/' + encodeURIComponent(id) + '/view';
  let h = '<button class="x" id="drawer-close" aria-label="Close">Close</button>';
  h += '<div class="eyebrow" style="font-size:12px;color:var(--muted)">' + esc(p.year + ' · ' + (p.venue || 'venue not printed')) + '</div><h2>' + esc(p.short) + '</h2>';
  h += '<div class="ttl">' + esc(p.title) + '</div><div class="au">' + esc(p.authors) + '</div>';
  h += '<div style="margin-top:8px"><span class="chip">' + esc(p.folder) + ' folder</span><span class="chip">' + esc(p.paper_type) + '</span><span class="chip">' + esc(p.setting) + '</span><span class="chip">' + esc(p.approach) + '</span><span class="chip">' + esc(p.data_type) + '</span></div>';
  const code = typeof p.code_available === 'string' && /^https?:|github/.test(p.code_available) ? p.code_available.split(/[ ;]/)[0] : null;
  h += '<div class="links"><a href="' + drive(p.drive_id) + '" target="_blank" rel="noopener">Open PDF in Drive</a>' + (p.supp_ids || []).map((s, i) => '<a href="' + drive(s) + '" target="_blank" rel="noopener">Supplement ' + (i + 1) + '</a>').join('') + (code ? '<a href="' + esc(/^http/.test(code) ? code : 'https://' + code) + '" target="_blank" rel="noopener">Code</a>' : '') + '</div>';
  if (p.metric_issue || p.integrity.length) h += '<h4>Flags</h4><div>' + (p.metric_issue ? '<span class="pill flag" style="white-space:normal">' + esc(p.metric_issue) + '</span>' : '') + p.integrity.map(i => '<span class="pill bad" style="white-space:normal">' + esc(i) + '</span>').join('') + '</div>';
  h += '<h4>Coded summary</h4>' + dl([['Protocol class', p.protocol_class + (p.protocol_note ? ' (' + p.protocol_note + ')' : '')], ['Hyperparameters', p.tuning_class === 'Unclear' ? 'Not stated' : p.tuning_class], ['Statistical test', p.test_class], ['Outcome', p.outcome ? p.outcome + '. ' + OUT_LABEL[p.outcome] : null], ['Train-only resampling', yn(p.resampling_inside_cv)], ['Untreated baseline', p.empirical ? yn(p.no_resampling_baseline) : null], ['SMOTE as baseline', p.empirical ? yn(p.smote_baseline) : null], ['Runtime reported', yn(p.runtime_reported)], ['Code', p.code_available === true ? 'yes (no link)' : p.code_available || 'not stated']]);
  h += '<h4>Data</h4>' + dl([['Real datasets', d.n_real], ['Synthetic datasets', d.n_synthetic], ['Sources', d.sources], ['IR range', d.ir_range], ['Classes', d.n_classes_range], ['Notes', d.notes]]);
  h += '<h4>Learners and competitors</h4>' + dl([['Base learners', p.classifiers], ['Competitors (' + (p.n_baselines == null ? 'n/a' : p.n_baselines) + ')', p.baselines]]);
  h += '<h4>Measures</h4>' + dl([['Measures', p.metrics_n], ['Primary', p.primary_metric], ['Definitions', p.metric_details]]);
  h += '<h4>Protocol and tuning</h4>' + dl([['Protocol', p.protocol], ['Runs', p.n_runs], ['Tuning', p.tuning]]);
  h += '<h4>Statistics</h4>' + dl([['Tests', p.tests_n.length ? p.tests_n : 'none'], ['Details', p.stat_test_details]]);
  h += '<h4>Reporting</h4>' + dl([['Forms', p.reporting], ['Details', p.reporting_details], ['Where', p.where]]);
  h += '<h4>Citations</h4>' + dl([['OpenAlex', p.cites == null ? 'no record' : big(p.cites) + ' (' + p.cites_per_year + ' per year since publication; retrieved ' + AN.retrieved + ')'], ['Rank within period', p.cite_pct_in_era == null ? (p.empirical ? 'not ranked (published after 2024 or no record)' : null) : 'percentile ' + p.cite_pct_in_era + ' among ' + ERA_EN[p.era] + ' studies'], ['DOI', p.doi], ['Note', p.cite_note]]);
  if (p.r2) {
    const R = p.r2, qd = (codes, q, w) => (codes && codes.length ? codes.join(', ') : 'none stated') + (q ? ' · “' + q + '”' : '') + (w ? ' (' + w + ')' : '');
    h += '<h4>Why these choices <span class="pill neu" style="margin-left:6px">pass 2 · quote and page for checking</span></h4>' + dl([
      ['Data', qd(R.data_reasons, R.data_quote, R.data_where)],
      ['Data access', 'all public: ' + yn(R.all_public) + '; source per dataset: ' + yn(R.per_ds_source) + '; links: ' + yn(R.links) + '; modified data released: ' + (R.mod_released == null ? 'no modification stated' : yn(R.mod_released)) + (R.access_where ? ' (' + R.access_where + ')' : '')],
      ['Base learners', qd(R.learner_reasons, R.learner_quote, R.learner_where) + (R.learner_follows ? ' · follows ' + R.learner_follows : '')],
      ['Model selection', (R.ms_selected || []).join(', ') + ' · criterion: ' + (R.ms_criterion || []).join(', ') + ' · data: ' + (R.ms_data || 'n/a') + (R.ms_quote ? ' · “' + R.ms_quote + '”' : '') + (R.ms_where ? ' (' + R.ms_where + ')' : '')],
      ['Measures', qd(R.measure_reasons, R.measure_quote, R.measure_where) + (R.measure_cites && R.measure_cites.length ? ' · cites ' + R.measure_cites.join('; ') : '')],
      ['Test methodology cited', R.stats_cited && R.stats_cited.length ? R.stats_cited.join('; ') + (R.stats_where ? ' (' + R.stats_where + ')' : '') : 'none'],
      ['Beyond classifier scores', (R.beyond_kinds && R.beyond_kinds.length ? R.beyond_kinds.join(', ') : 'none') + (R.beyond_details ? ' · ' + R.beyond_details : '') + (R.beyond_where ? ' (' + R.beyond_where + ')' : '')],
      ['Settings on evaluation data', p.tuning_evidence ? p.tuning_evidence + (p.tuning_class_v1 !== p.tuning_class ? ' (pass 1 coded ' + p.tuning_class_v1 + ')' : '') : null],
      ['Pass-2 notes', R.flags]]);
  }
  h += '<h4>Assessment</h4><div class="assess">' + (p.key_result ? '<div class="k"><b>Claim.</b> ' + esc(p.key_result) + '</div>' : '') + (p.eval_strengths ? '<div class="g"><b>Strength.</b> ' + esc(p.eval_strengths) + '</div>' : '') + (p.eval_weaknesses ? '<div class="w"><b>Weakness.</b> ' + esc(p.eval_weaknesses) + '</div>' : '') + '</div>';
  if (p.flags) h += '<h4>Extraction notes</h4><p class="box">' + esc(p.flags) + '</p>';
  h += '<h4>Cite key</h4><p class="box" style="font-family:var(--f-mono);font-size:12px">\\parencite{' + esc(p.bibkey) + '}</p>';
  const dr = document.getElementById('drawer');
  dr.innerHTML = h; dr.hidden = false; document.getElementById('scrim').hidden = false; dr.scrollTop = 0;
  document.getElementById('drawer-close').focus();
}
function closePaper() { document.getElementById('drawer').hidden = true; document.getElementById('scrim').hidden = true; if (lastFocus && lastFocus.focus) lastFocus.focus(); }

/* ---------------- LaTeX: repo-ready files ---------------- */
const TODAY = new Date().toISOString().slice(0, 10);
const HDR = '%% Generated ' + TODAY + ' from the SMOTE25 evaluation draft page (' + ALL.length + ' coded papers, ' + EMP.length + ' empirical).\n%% Numbers are filled from the coded data; regenerate instead of editing them by hand.\n';
const COLORS_TEX = '\\definecolor{sOne}{HTML}{2A78D6}\\definecolor{sTwo}{HTML}{EB6834}\\definecolor{sThree}{HTML}{1BAF7A}\\definecolor{sFour}{HTML}{EDA100}\n\\definecolor{oZero}{HTML}{A3ABB4}\\definecolor{oOne}{HTML}{5598E7}\\definecolor{oTwo}{HTML}{1C5CAB}\\definecolor{oThree}{HTML}{0D366B}\\definecolor{inkTwo}{HTML}{465462}\n';
const CMAP = {'--s1': 'sOne', '--s2': 'sTwo', '--s3': 'sThree', '--s4': 'sFour', '--o0': 'oZero', '--o1': 'oOne', '--o2': 'oTwo', '--o3': 'oThree'};
const MARKS = {binary: '*', multiclass: 'square*', both: 'triangle*'};
function pgfBraces(a) { return a.map(x => '{' + texEsc(x) + '}').join(','); }
function figTexSource(id) {
  let body = '';
  if (id === 'fig-influence') {
    const rows = influenceRows(), n = rows.length;
    body = '\\begin{axis}[xmode=log,log basis x=10,width=12cm,height=' + (0.42 * n + 2).toFixed(1) + 'cm,xmin=0.1,xmax=10,ymin=-0.7,ymax=' + (n - 0.3) + ',y dir=reverse,\n  xtick={0.1,0.25,0.5,1,2,4,10},xticklabels={0.1,0.25,0.5,1,2,4,10},ytick={0,...,' + (n - 1) + '},yticklabels={' + rows.map(r => r.head ? '{\\textbf{' + texEsc(r.label) + '}}' : '{' + texEsc(r.en) + '}').join(',') + '},\n  xlabel={Citation ratio, adjusted for publication year (log scale)},tick label style={font=\\footnotesize},y tick label style={align=right},xmajorgrids,grid style={gray!20},axis y line*=left,axis x line*=bottom,clip=false]\n';
    body += '\\draw[inkTwo,thick] (axis cs:1,-0.7) -- (axis cs:1,' + (n - 0.3) + ');\n';
    rows.forEach((r, i) => {
      if (r.head) return;
      const col = (r.lo > 1 || r.hi < 1) ? 'sTwo' : 'sOne';
      body += '\\draw[' + col + ',line width=1.2pt] (axis cs:' + r.lo + ',' + i + ') -- (axis cs:' + r.hi + ',' + i + ');\\fill[' + col + '] (axis cs:' + r.ratio + ',' + i + ') circle[radius=2.2pt];\\node[font=\\scriptsize,text=inkTwo,anchor=west] at (axis cs:10,' + i + ') {' + r.n_users + '/' + r.n + '};\n';
    });
    body += '\\end{axis}';
  } else if (id === 'fig-corpus') {
    const rows = periodRows();
    body = '\\begin{axis}[ybar stacked,width=13cm,height=6cm,bar width=12pt,ymin=0,xtick={0,...,' + (rows.length - 1) + '},xticklabels={' + pgfBraces(rows.map(r => r.from + '--' + r.to)) + '},\n  ylabel={Empirical studies},enlarge x limits=0.08,tick label style={font=\\footnotesize},legend cell align=left,legend style={font=\\footnotesize,at={(0.02,0.98)},anchor=north west,draw=none},ymajorgrids,grid style={gray!20}]\n';
    SETTINGS.forEach(s => { body += '\\addplot[fill=' + CMAP[s.c] + ',draw=white] coordinates {' + rows.map((r, i) => '(' + i + ',' + r.counts[s.k] + ')').join(' ') + '};\n'; });
    body += '\\legend{' + SETTINGS.map(s => '{' + s.en + '}').join(',') + '}\n\\end{axis}';
  } else if (id === 'fig-datasets') {
    body = '\\begin{axis}[width=13cm,height=6.2cm,xmin=1996,xmax=2027,ymin=0,ymax=90,xlabel={Publication year},ylabel={Real datasets per study},xtick={2000,2005,2010,2015,2020,2025},\n  xticklabel style={/pgf/number format/1000 sep={}},tick label style={font=\\footnotesize},legend cell align=left,legend style={font=\\footnotesize,at={(0.02,0.98)},anchor=north west,draw=none},grid=major,grid style={gray!20}]\n';
    SETTINGS.forEach(s => { body += '\\addplot[only marks,mark=' + MARKS[s.k] + ',mark size=2.4pt,color=' + CMAP[s.c] + ',mark options={draw=white,line width=0.3pt,fill=' + CMAP[s.c] + '}] coordinates {' + EMP.filter(p => p.setting === s.k && p.datasets.n_real != null).map(p => '(' + p.year + ',' + p.datasets.n_real + ')').join(' ') + '};\n'; });
    body += '\\legend{' + SETTINGS.map(s => '{' + s.en + '}').join(',') + '}\n\\end{axis}';
  } else if (id === 'fig-learners' || id === 'fig-metrics') {
    const isM = id === 'fig-metrics', rows = isM ? metricRows(EMP, 3) : learnerItems(EMP);
    body = '\\begin{axis}[xbar' + (isM ? ' stacked' : '') + ',width=13cm,height=' + (0.48 * rows.length + 1.6).toFixed(1) + 'cm,bar width=6pt,xmin=0,y dir=reverse,ytick={0,...,' + (rows.length - 1) + '},\n  yticklabels={' + pgfBraces(rows.map(r => r.label)) + '},xlabel={Number of studies},enlarge y limits=0.04,' + (isM ? '' : 'nodes near coords,nodes near coords style={font=\\footnotesize},enlarge x limits={upper,value=0.1},') + '\n  tick label style={font=\\footnotesize},legend cell align=left,legend style={font=\\footnotesize,at={(0.98,0.02)},anchor=south east,draw=none},xmajorgrids,grid style={gray!20}]\n';
    if (isM) { SETTINGS.forEach(s => { body += '\\addplot[fill=' + CMAP[s.c] + ',draw=white] coordinates {' + rows.map((r, i) => '(' + r.counts[s.k] + ',' + i + ')').join(' ') + '};\n'; }); body += '\\legend{' + SETTINGS.map(s => '{' + s.en + '}').join(',') + '}\n'; }
    else body += '\\addplot[fill=sOne,draw=none] coordinates {' + rows.map((r, i) => '(' + r.value + ',' + i + ')').join(' ') + '};\n';
    body += '\\end{axis}';
  } else if (id === 'fig-tuning' || id === 'fig-tests') {
    const cats = id === 'fig-tuning' ? TUNE_CATS : TEST_CATS, rows = eraRows(EMP, id === 'fig-tuning' ? 'tuning_class' : 'test_class', cats);
    body = '\\begin{axis}[xbar stacked,width=13cm,height=' + (0.8 * rows.length + 2.4).toFixed(1) + 'cm,bar width=11pt,xmin=0,xmax=100,y dir=reverse,ytick={0,...,' + (rows.length - 1) + '},\n  yticklabels={' + pgfBraces(rows.map(r => r.label + ' (n=' + r.n + ')')) + '},xlabel={Share of studies (\\%)},enlarge y limits=0.15,\n  tick label style={font=\\footnotesize},legend cell align=left,legend style={font=\\footnotesize,at={(0.5,1.03)},anchor=south,legend columns=' + (cats.length > 4 ? 3 : 2) + ',draw=none}]\n';
    cats.forEach(c => { body += '\\addplot[fill=' + CMAP[c.c] + ',draw=white] coordinates {' + rows.map((r, i) => '(' + (100 * r.counts[c.k] / r.n).toFixed(1) + ',' + i + ')').join(' ') + '};\n'; });
    body += '\\legend{' + cats.map(c => '{' + texEsc(c.en) + '}').join(',') + '}\n\\end{axis}';
  } else if (id === 'fig-trend') {
    const ser = trendSeries(EMP), xs = ['e1', 'e2', 'e3', 'e4'], mk = ['*', 'square*', 'triangle*', 'diamond*'];
    body = '\\begin{axis}[width=13cm,height=6cm,symbolic x coords={' + xs.join(',') + '},xtick=data,xticklabels={' + pgfBraces(ERAS.map(e => ERA_EN[e])) + '},\n  ymin=0,ymax=100,ylabel={Share of studies (\\%)},tick label style={font=\\footnotesize},legend cell align=left,legend style={font=\\footnotesize,at={(0.5,-0.16)},anchor=north,legend columns=4,draw=none},ymajorgrids,grid style={gray!20}]\n';
    ser.forEach((s, j) => { body += '\\addplot[thick,color=' + CMAP[s.c] + ',mark=' + mk[j] + '] coordinates {' + s.values.map((v, i) => '(' + xs[i] + ',' + v.p + ')').join(' ') + '};\n'; });
    body += '\\legend{' + ser.map(s => '{' + texEsc(s.en) + '}').join(',') + '}\n\\end{axis}';
  } else if (id === 'fig-pipeline') {
    const P = pipelineStats(), st = (a, l) => '\\textbf{' + a + '} ' + l;
    body = '[font=\\small, box/.style={draw=inkTwo,rounded corners=3pt,minimum width=2.6cm,minimum height=1.05cm,align=center,fill=white}, stat/.style={font=\\scriptsize,text=inkTwo}, flow/.style={-{Stealth[length=2mm]},draw=inkTwo,thick}, short/.style={-{Stealth[length=2.2mm]},draw=sTwo,very thick,dashed}, lab/.style={font=\\scriptsize,text=inkTwo}]\n' +
      '\\node[box] (data) at (0,0) {\\textbf{Benchmark data}\\\\[-1pt]{\\scriptsize datasets, IR}};\n' +
      '\\node[box] (split) at (3.3,0) {\\textbf{Split}\\\\[-1pt]{\\scriptsize folds or hold-out}};\n' +
      '\\node[box] (res) at (6.6,1.7) {\\textbf{Resample}\\\\[-1pt]{\\scriptsize training part}};\n' +
      '\\node[box] (tune) at (9.6,1.7) {\\textbf{Tune settings}\\\\[-1pt]{\\scriptsize inner validation}};\n' +
      '\\node[box] (fit) at (12.6,1.7) {\\textbf{Fit learner}\\\\[-1pt]{\\scriptsize base classifier}};\n' +
      '\\node[box] (score) at (12.6,-1.9) {\\textbf{Score}\\\\[-1pt]{\\scriptsize test part}};\n' +
      '\\node[box] (agg) at (16.0,-1.9) {\\textbf{Aggregate}\\\\[-1pt]{\\scriptsize folds, repeats}};\n' +
      '\\node[box] (comp) at (16.0,1.7) {\\textbf{Compare}\\\\[-1pt]{\\scriptsize across datasets}};\n' +
      '\\node[draw=gray,dashed,rounded corners=6pt,fit=(res)(tune)(fit),inner sep=10pt,label={[font=\\scriptsize,text=gray,anchor=south west]north west:fitted on the training part only}] {};\n' +
      '\\node[stat,below=1pt of split] {' + st(P.split, 'repeated') + '};\n' +
      '\\node[stat,below=1pt of res] {' + st(P.resample, 'stated') + '};\n' +
      '\\node[stat,below=1pt of tune] {' + st(P.tune, 'nested') + '};\n' +
      '\\node[stat,below=1pt of score] {' + st(P.score, 'threshold-free') + '};\n' +
      '\\node[stat,below=1pt of agg] {' + st(P.agg, 'with std') + '};\n' +
      '\\node[stat,above=1pt of comp] {' + st(P.comp, 'corrected test') + '};\n' +
      '\\draw[flow] (data) -- (split);\n\\draw[flow] ([yshift=2mm]split.east) -- ++(0.35,0) |- node[lab,pos=0.25,left] {training part} (res.west);\n' +
      '\\draw[flow] (res) -- (tune);\n\\draw[flow] (tune) -- (fit);\n\\draw[flow] (fit) -- node[lab,right] {fitted model} (score);\n' +
      '\\draw[flow] ([yshift=-2mm]split.east) -- ++(0.35,0) |- node[lab,pos=0.75,below] {test part, untouched} (score.west);\n\\draw[flow] (score) -- (agg);\n\\draw[flow] (agg) -- node[lab,right] {per dataset} (comp);\n' +
      '\\draw[short] (data.north) to[out=90,in=150] node[lab,text=sTwo,pos=0.35,above left] {\\textbf{resampled before split} (1, inferred)} (res.north west);\n' +
      '\\draw[short] (score.north west) to[out=150,in=-90] node[lab,text=sTwo,pos=0.5,left=2pt] {\\textbf{settings picked from test scores} (' + P.tuneBad + ')} ([xshift=-3mm]tune.south east);\n';
    return '%% Source of figures/' + FIGS[id].file + '.pdf. Compile: pdflatex ' + FIGS[id].file + '.tex\n' + HDR + '\\documentclass[tikz,border=4pt]{standalone}\n\\usepackage[scaled]{helvet}\\renewcommand{\\familydefault}{\\sfdefault}\n\\usetikzlibrary{arrows.meta,positioning,fit}\n' + COLORS_TEX + '\\begin{document}\n\\begin{tikzpicture}' + body + '\\end{tikzpicture}\n\\end{document}\n';
  }
  return '%% Source of figures/' + FIGS[id].file + '.pdf. Compile: pdflatex ' + FIGS[id].file + '.tex\n' + HDR + '\\documentclass[border=4pt]{standalone}\n\\usepackage[scaled]{helvet}\\renewcommand{\\familydefault}{\\sfdefault}\n\\usepackage{pgfplots}\\pgfplotsset{compat=1.18}\n' + COLORS_TEX + '\\begin{document}\n\\begin{tikzpicture}\n' + body + '\n\\end{tikzpicture}\n\\end{document}\n';
}
function figureFloat(id) {
  const F = FIGS[id];
  return '\\begin{figure}[t]\n  \\centering\n  \\includegraphics[width=\\linewidth]{' + F.file + '}\n  \\caption{' + texEsc(F.en) + '}\n  \\Description{' + texEsc(F.desc) + '}\n  \\label{' + F.label + '}\n\\end{figure}\n';
}
function tableFile(id, spec, head, rows, note) {
  const T = TABS[id];
  return '%% Table: ' + T.en.toLowerCase() + ' (input from sections/07-empirical-comparisons.tex).\n%% JAIR style: caption above the table, booktabs rules, \\midrule only below the header.\n' + HDR +
    '\\begin{table}[t]\n  \\caption{' + texEsc(T.en) + '}\n  \\label{' + T.label + '}\n  \\footnotesize\n  \\setlength{\\tabcolsep}{4pt}\n  \\begin{tabular}{@{}' + spec + '@{}}\n    \\toprule\n    ' + head.join(' & ') + '\\\\\n    \\midrule\n' +
    rows.map(r => '    ' + r.join(' & ') + '\\\\').join('\n') + '\n    \\bottomrule\n  \\end{tabular}' + (note ? '\n  \\par\\smallskip\\raggedright\\scriptsize ' + note : '') + '\n\\end{table}\n';
}
const P_ = f => 'p{' + f + '\\linewidth}';
const TABLE_TEX = {
  'tab-measures': () => tableFile('tab-measures', P_(.12) + P_(.17) + P_(.16) + P_(.22) + 'r' + P_(.12), ['Family', 'Measures', 'Advantages', 'Limitations', 'Studies', 'Examples'],
    MEASURE_FAMILIES.map(r => [texEsc(r.en), texEsc(r.measures), texEsc(r.adv), texEsc(r.lim), String(famCount(r.fam)), citesTex(r.ex)])),
  'tab-sources': () => tableFile('tab-sources', P_(.26) + 'rr' + P_(.5), ['Source', 'Studies', 'Share', 'Typical use'],
    sourceRows().map(r => [texEsc(r.en), String(r.n), pct(r.n, ST.N) + '\\%', texEsc(r.use)]), 'A study can draw on several sources.'),
  'tab-reasons': () => tableFile('tab-reasons', P_(.17) + 'r' + P_(.46) + P_(.17), ['Choice', 'Reason given', 'Reasons given (studies)', 'Examples'],
    reasonRows().map(r => [texEsc(r.en), r.stated + ' of ' + r.of, texEsc(r.reasons.map(x => x.en + ' (' + x.n + ')').join('; ')), citesTex(r.ex)]), 'A study can give several reasons. Selection criterion: studies that select a parameter value, variant or resampling amount.'),
  'tab-beyond': () => tableFile('tab-beyond', P_(.2) + P_(.44) + 'r' + P_(.17), ['Evidence', 'What it shows', 'Studies', 'Examples'],
    beyondRows().map(r => [texEsc(r.en), texEsc(r.what), String(r.n), citesTex(r.ex)]), 'A study can provide several kinds of evidence; the counts overlap.'),
  'tab-metric': () => tableFile('tab-metric', 'll' + P_(.6), ['Study', 'Setting', 'Problem'],
    EMP.filter(p => p.metric_issue).sort((a, b) => a.year - b.year).map(p => [texEsc(p.short) + '~' + citesTex([p.key]), texEsc(p.setting), texEsc(p.metric_issue)])),
  'tab-protocols': () => tableFile('tab-protocols', P_(.14) + P_(.16) + P_(.18) + P_(.2) + 'r' + P_(.14), ['Protocol', 'Description', 'Advantages', 'Limitations', 'Studies', 'Examples'],
    PROTOCOLS.map(r => [texEsc(r.en), texEsc(r.desc), texEsc(r.adv), texEsc(r.lim), String(protoCount(r.k)), citesTex(r.ex)])),
  'tab-outcomes': () => tableFile('tab-outcomes', P_(.24) + P_(.4) + 'r' + P_(.18), ['Outcome', 'Description', 'Studies', 'Examples'],
    OUTCOMES.map(r => [texEsc(r.k + '. ' + r.en), texEsc(r.desc), String(outCount(r.k)), citesTex(r.ex)])),
  'tab-remedies': () => tableFile('tab-remedies', P_(.3) + 'r' + P_(.52), ['Observed problem', 'Studies', 'Recommended practice'],
    REMEDIES.map(r => [texEsc(r.en), latexText(r.ev), texEsc(r.remedy)]), 'Studies: number of the ' + ST.N + ' empirical studies showing the problem.')
};
function blockTex(b) {
  if (b.aside) return '';
  if (b.fig) return figureFloat(b.fig) + '\n';
  if (b.table) return '\\input{tables/' + TABS[b.table].label.replace('tab:', '').replace(':', '-') + '}\n\n';
  if (b.eq) { const E = EQS[b.eq]; return '\\begin{equation}\n  ' + E.tex + '\n  \\label{' + E.label + '}\n\\end{equation}\n'; }
  if (b.rq) return '\\begin{description}\n' + b.rq.map(r => '  \\item[' + r.id + '.] ' + texEsc(r.en) + ' (' + refTex(r.ref) + ')').join('\n') + '\n\\end{description}\n\n';
  if (b.thesis) return '\\begin{quote}\n  \\emph{' + latexText(b.en) + '}\n\\end{quote}\n\n';
  return latexText(b.en) + '\n\n';
}
function eqFollowsText(blocks, i) { return blocks[i + 1] && blocks[i + 1].eq; }
function sectionTex() {
  let t = '%% Section 7. Empirical comparisons and benchmarks reported in the literature\n' + HDR +
    '%% Figures: figures/empirical-*.pdf (sources in figures/src/). Tables: tables/empirical-*.tex.\n%% Cite keys follow references.bib style (e.g. chawla2002smote); entries still to add are in notes/empirical-bib-candidates.bib.\n' +
    '\\section{' + SECTION.en + '}\n\\label{' + SECTION.label + '}\n\n';
  INTRO.forEach(b => { t += blockTex(b); });
  PROSE.forEach(s => {
    t += '\\subsection{' + texEsc(s.en) + '}\n\\label{' + s.label + '}\n\n';
    s.blocks.forEach((b, i) => { let x = blockTex(b); if (!b.eq && !b.fig && !b.table && eqFollowsText(s.blocks, i)) x = x.replace(/\n\n$/, '\n'); if (b.eq && s.blocks[i + 1] && !s.blocks[i + 1].eq) x = x; t += x; });
  });
  return t;
}
function appendixTex(S) {
  S = S.filter(p => p.empirical).slice().sort((a, b) => ({binary: 0, multiclass: 1, both: 2}[a.setting] - {binary: 0, multiclass: 1, both: 2}[b.setting]) || a.year - b.year || a.short.localeCompare(b.short));
  const SET = {binary: 'B', multiclass: 'M', both: 'B+M'};
  const head = 'Study & Year & Set. & DS & Classes & Base learners & Measures & Protocol & Test & Out.\\\\';
  let t = '%% Appendix B. Evaluation map of the empirical studies (form: one row per study, as in a per-method evaluation table).\n' + HDR +
    '%% Requires \\usepackage{longtable} in main.tex, and \\input{sections/appendix-empirical-map} after the reproducibility appendix.\n' +
    '\\section{Evaluation Map of the Empirical Studies}\n\\label{app:empirical-map}\n\n' +
    'Table~\\ref{' + TABS['tab-map'].label + '} lists the coded evaluation design of each of the ' + S.length + ' empirical studies analysed in Section~\\ref{' + SECTION.label + '}, grouped by problem setting and ordered by year.\n\n' +
    '\\begingroup\\scriptsize\\setlength{\\tabcolsep}{2.5pt}\n\\begin{longtable}{@{}p{0.13\\linewidth}lllp{0.06\\linewidth}p{0.15\\linewidth}p{0.2\\linewidth}p{0.08\\linewidth}p{0.11\\linewidth}l@{}}\n' +
    '\\caption{' + texEsc(TABS['tab-map'].en) + '}\\label{' + TABS['tab-map'].label + '}\\\\\n\\toprule\n' + head + '\n\\midrule\n\\endfirsthead\n\\toprule\n' + head + '\n\\midrule\n\\endhead\n\\bottomrule\n\\endfoot\n';
  S.forEach(p => { t += texEsc(p.short) + '~\\parencite{' + p.bibkey + '} & ' + p.year + ' & ' + SET[p.setting] + ' & ' + (p.datasets.n_real == null ? 'n/a' : p.datasets.n_real) + ' & ' + texEsc(p.datasets.n_classes_range || 'n/a') + ' & ' + texEsc(p.clf_families.join(', ')) + ' & ' + texEsc(p.metrics_n.filter(m => m !== 'Other' && m !== 'Confusion matrix').join(', ')) + ' & ' + texEsc(protoShortTxt(p)) + ' & ' + texEsc(p.tests_n.join(', ') || 'none') + ' & ' + p.outcome + '\\\\\n'; });
  return t + '\\end{longtable}\n\\par\\noindent B = binary, M = multi-class; DS = number of real datasets; k-CV = k-fold cross-validation; rep. = repeated; n.s. = not stated; Out. = outcome class of Table~\\ref{' + TABS['tab-outcomes'].label + '}.\n\\endgroup\n';
}
function refBib() {
  return '\n\n%% Reference works cited in the section (not in the corpus). DOI and title from OpenAlex (retrieved ' + AN.retrieved + '); verify volume and pages.\n\n' +
    AN.refs.filter(r => r.bibkey !== 'fernandez2018smote').map(r => '@' + (/arXiv|UCI/.test(r.venue + (r.doi || '')) ? 'misc' : 'article') + '{' + r.bibkey + ',\n  author = {' + r.bib_authors + '},\n  title  = {' + String(r.title || r.title_in).replace(/[{}]/g, '') + '},\n  ' + (/arXiv|UCI/.test(r.venue + (r.doi || '')) ? 'howpublished' : 'journal') + ' = {' + r.venue + '},\n  year   = {' + r.pub_year + '},' + (r.doi && !/arxiv/i.test(r.doi) ? '\n  doi    = {' + r.doi + '},' : '') + '\n  note   = {TODO: verify volume and pages}\n}').join('\n\n') + '\n';
}
function bibCandidates() {
  const isConf = v => /conf|proc|PAKDD|ICDM|KDD|AAAI|ICIC|IJCNN|PKDD|RSCTC|IDEAL|ICDE|NeurIPS|ICCV|CIKM|ICML|lncs|lnai/i.test(v || '');
  return '%% Candidate BibLaTeX entries for the cite keys used in the empirical section.\n%% Built from the coded metadata (first-author surnames only, no DOI). VERIFY every entry against the\n%% publisher record and add the DOI before moving it into references.bib (repo rule: real, verifiable entries only).\n\n' +
    ALL.filter(p => p.bibkey !== 'chawla2002smote').slice().sort((a, b) => a.year - b.year).map(p => (isConf(p.venue) ? '@inproceedings{' : '@article{') + p.bibkey + ',\n  author = {' + (p.authors || '').replace(/,\s*/g, ' and ').replace(/ and et al\.?|\s+et al\.?/, ' and others') + '},\n  title  = {' + (p.title || '').replace(/[{}]/g, '') + '},\n  ' + (isConf(p.venue) ? 'booktitle' : 'journal') + ' = {' + (p.venue || '').replace(/[{}%&]/g, '') + '},\n  year   = {' + p.year + '},\n  note   = {TODO: verify authors, pages and DOI}\n}').join('\n\n') + '\n' + refBib();
}
function mainPatch() {
  return '%% Two additions to main.tex for the empirical section (no style commands change).\n%% 1) In the preamble, after \\RequirePackage[...]{biblatex}:\n\\usepackage{longtable}\n\n%% 2) After \\input{sections/appendix-reproducibility}:\n\\input{sections/appendix-empirical-map}\n';
}
function repoFiles(scopeFiltered) {
  const files = {'sections/07-empirical-comparisons.tex': sectionTex()};
  Object.keys(TABLE_TEX).forEach(id => { files['tables/' + TABS[id].label.replace('tab:', '') + '.tex'] = TABLE_TEX[id](); });
  files['sections/appendix-empirical-map.tex'] = appendixTex(scopeFiltered ? filtered() : EMP);
  Object.keys(FIGS).forEach(id => { files['figures/src/' + FIGS[id].file + '.tex'] = figTexSource(id); });
  files['notes/empirical-bib-candidates.bib'] = bibCandidates();
  files['notes/main-tex-additions.tex'] = mainPatch();
  return files;
}
function renderLatex() {
  const v = document.getElementById('v-latex'), scopeFiltered = state.latexScope === 'filtered', files = repoFiles(scopeFiltered);
  const groups = [
    ['Section', ['sections/07-empirical-comparisons.tex'], 'Drops into the repo in place of the current placeholder. Uses \\parencite with repo-style keys, \\TODO for open items, and \\Description on every figure.'],
    ['Tables', Object.keys(files).filter(f => f.indexOf('tables/') === 0), 'Caption above, booktabs rules, \\midrule only below the header, as in tables/variants-summary.tex.'],
    ['Appendix B', ['sections/appendix-empirical-map.tex'], 'Per-study evaluation map as a longtable.'],
    ['Figure sources', Object.keys(files).filter(f => f.indexOf('figures/src/') === 0), 'Standalone pgfplots and TikZ sources; compile each to figures/empirical-*.pdf. The PDFs are in the zip sent in chat.'],
    ['Notes', ['notes/main-tex-additions.tex', 'notes/empirical-bib-candidates.bib'], 'Two lines for main.tex, and candidate bibliography entries to verify before merging.']
  ];
  let h = '<div class="latex-grid"><div class="panel"><h3>Repo-ready files for tohnperfect/SMOTE25</h3><p style="margin:0 0 8px;color:var(--ink-2)">Paths match the repository layout. Appendix scope: <span class="seg" role="group" aria-label="Appendix scope"><button data-scope="all" aria-pressed="' + !scopeFiltered + '">All ' + EMP.length + ' empirical studies</button><button data-scope="filtered" aria-pressed="' + scopeFiltered + '">Explorer filter (' + filtered().filter(p => p.empirical).length + ')</button></span></p></div>';
  let n = 0;
  groups.forEach(g => {
    h += '<section class="codebox"><header><div><h3>' + esc(g[0]) + '</h3><p>' + esc(g[2]) + '</p></div></header>';
    g[1].forEach(path => { const id = 'lx-' + (n++); h += '<details class="file"' + (path.indexOf('sections/07') === 0 ? ' open' : '') + '><summary><code>' + esc(path) + '</code><button class="btn" data-copy="' + id + '">Copy</button></summary><pre id="' + id + '">' + esc(files[path]) + '</pre></details>'; });
    h += '</section>';
  });
  v.innerHTML = h + '</div>';
}

/* ---------------- notes ---------------- */
const VLOG = [
  ['GDO 2022', 'GDO-2022', '“AUC” is (Sens + Spec)/2 (Eq. 24); single SVM; 10-fold CV; pairwise Wilcoxon only, no test on the 10 large sets.'],
  ['DLexiBoost 2020', 'DLexiBoost-2020', 'AUC = (1 + TPR − FPR)/2 (supplement §2.1); no k-fold or hold-out protocol described; results at the best parameter setting.'],
  ['SPE 2020', 'SPE-2020', 'G-mean = √(Recall · Precision); 60/20/20 split, 10 runs; no significance test; AUCPRC first. Caveat: whether the split is redrawn per run is not stated.'],
  ['MC-MBRC 2024', 'MC-MBRC-2024', 'AvAcc = mean one-versus-rest accuracy (Eq. 1); 30 × 2-fold CV; Nemenyi test.'],
  ['SHSampler 2022', 'SHSampler-2022', 'Pairwise AUC in MAUC computed from the confusion matrix of predicted labels; single stratified 5-fold CV; Friedman mean ranks plus a Bayesian signed-rank test.'],
  ['AB-SMOTE 2020', 'AB-SMOTE-2020', 'Order of oversampling and CV never stated; SMOTE 100% generates as many samples as the full minority class in every table, which implies oversampling before the split (inferred).'],
  ['G-SMOTE 2019', 'G-SMOTE-2019', 'Highest CV score per combination reported; grid of 294 configurations for G-SMOTE versus 2 for SMOTE; 5-fold CV repeated 3 times; Friedman and Holm.'],
  ['k-means SMOTE 2018', 'KMeansSMOTE-2018', 'Best value per metric saved over the grid, no separate validation split; 5-fold CV repeated 5 times; Friedman and Holm.'],
  ['CISO 2025', 'CISO-2025', 'Preregistered protocol; disjoint tuning suite of 5 KEEL datasets; preprocessing fitted on training folds; PR-AUC primary; no significant difference from class weighting, random oversampling or no resampling.'],
  ['QC-SMOTE 2026', 'QC-SMOTE-2026', 'Non-QC-SMOTE columns retained from a published benchmark; unadjusted p-values; defaults equal the sensitivity-study optimum (data for that study not named).'],
  ['MC-RBO 2020', 'MC-RBO-2020', 'Stratified 10-fold CV repeated 10 times; internal stratified 3-fold CV on the training set for tuning; Friedman with Shaffer post-hoc; code released.'],
  ['SMOTE 2002', 'SMOTE-2002', '10-fold CV on 9 datasets; AUC and ROC convex hull; no significance tests. SMOTE was run with C4.5 and Ripper; Naive Bayes was a cost-sensitive comparator.'],
  ['Loyalty-SMOTE 2026', 'Loyalty-SMOTE-2026', 'Single 7:3 train/test split; one SVM for all methods; no statistical tests.'],
  ['NROMM 2023', 'NROMM-2023', 'Supplement §7.3 states 2-fold CV repeated 5 times, §9 states stratified 10-fold; main text says baseline results are referred from earlier papers, the supplement says they were re-run.'],
  ['Batista et al. 2004', 'SMOTE-ENN-Tomek-2004', 'Hsu MCB test; abstract says thirteen datasets, Table 3 lists 15; single C4.5 (pruned and unpruned); AUC only; 10-fold CV.'],
  ['MC-NCLWO 2025', 'MC-NCLWO-2025', 'AvAcc = mean one-versus-rest accuracy (Eq. 11); §V.B says 10-fold CV, §V.F says 5-fold; Shaffer named in §V, Holm in §V.B and Table 2.']
];
const FORM = [
  ['Thesis set off before the evidence', 'A one-sentence thesis, reached through a gap statement and set apart from the text, which the rest of the section then tests.', 'Section 7 introduction (quote block)'],
  ['Questions posed, then answered in order', 'Six numbered questions, each answered by one subsection and recapped in the closing subsection.', 'RQ1 to RQ6; Section 7.11'],
  ['Opening count of the literature', 'A dated count of studies over time before any analysis.', refLabel('fig-corpus', 'en')],
  ['Formal definitions with a “where” gloss', 'Numbered display equations, each followed by a sentence that names its symbols, placed before the analysis that relies on them.', 'Section 7.4, Equations 1 to 8'],
  ['Category summary table', 'One row per category with description, advantages, limitations and example studies; citations only in the last cell. Extended here with a study count so each row is tied to evidence.', refLabel('tab-measures', 'en') + ', ' + refLabel('tab-protocols', 'en') + ' and ' + refLabel('tab-reasons', 'en')],
  ['One row per study', 'A per-study table of how each was evaluated (datasets, classes, learners, measures), with a key for abbreviations and a repeated header.', 'Appendix B, Table B1'],
  ['Description of the benchmark data', 'A compact table of the data used before results that depend on it.', refLabel('tab-sources', 'en')],
  ['Protocol diagram', 'A flow diagram of the experimental procedure, annotated with the corpus counts at each step.', refLabel('fig-pipeline', 'en')],
  ['Problem, then remedy', 'Each limitation of current practice paired with what fixes it.', refLabel('tab-remedies', 'en')],
  ['Directive conclusion and next step', 'Unhedged recommendations followed by one line on future work.', 'Section 7.11'],
  ['Threats to validity', 'A separate statement of the limits of the analysis itself, as in recent JAIR surveys.', 'Section 7.10']
];
const AVOID = ['Cross-references checked against the actual numbering (both models misnumber a table or a section).', 'No category assigned to the same study twice without saying so.', 'No citation bundles of more than five works; examples in tables only.', 'Every count shown with its denominator, and ranks never shown without a test or dispersion.', 'Figures readable at print size and in grayscale (marker shapes differ by setting).', 'Neutral wording; no emotive verbs.'];
function renderNotes() {
  const v = document.getElementById('v-notes');
  const folders = ['Survey', 'Binary', 'Multiclass', 'Both'];
  const inFolder = (p, f) => p.folder.split('+').indexOf(f) >= 0;
  v.innerHTML = '<div class="notes">' +
  '<div class="panel"><h3>How this section is built · โครงสร้างของส่วนนี้</h3><p>The section takes its form, not its content, from the two reviews in the Survey folder and from recent JAIR surveys. Nothing they say about methods is used; each borrowed device below is filled with this corpus\'s own data.</p><p style="font-family:var(--f-thai)">ส่วนนี้ใช้รูปแบบ (ไม่ใช่เนื้อหา) จากบทความปริทัศน์ 2 เรื่องในโฟลเดอร์ Survey และจากงานปริทัศน์ของ JAIR ช่วงหลัง ไม่ได้นำข้อสรุปของงานเหล่านั้นมาใช้ ทุกองค์ประกอบด้านล่างเติมด้วยข้อมูลจากคลังบทความของเราเอง</p><div class="tbl-wrap"><table class="t"><thead><tr><th>Device</th><th>Form</th><th>Where here</th></tr></thead><tbody>' +
  FORM.map(r => '<tr><td><b>' + esc(r[0]) + '</b></td><td>' + esc(r[1]) + '</td><td>' + esc(r[2]) + '</td></tr>').join('') + '</tbody></table></div><p style="margin-top:10px"><b>Weaknesses of form avoided:</b></p><ul style="margin:0;padding-left:18px">' + AVOID.map(a => '<li>' + esc(a) + '</li>').join('') + '</ul></div>' +
  '<div class="panel"><h3>Where each part comes from · ที่มาของเนื้อหาแต่ละส่วน</h3><div class="tbl-wrap"><table class="t"><thead><tr><th>Source</th><th>Used for</th><th>Status</th></tr></thead><tbody>' +
  '<tr><td><b>Evaluation designs coded from ' + EMP.length + ' empirical studies</b> (Binary, Multiclass and Both folders, duplicates merged)<div class="tth" style="display:block">การวัดผลของ paper ในโฟลเดอร์ Binary, Multiclass และ Both</div></td><td>Every count in 7.1 to 7.3 and 7.5 to 7.9; the counts in Tables 1, 2 and 4 to 8; Figures 1 and 3 to 9; Appendix B</td><td><span class="pill ok">from the corpus</span></td></tr>' +
  '<tr><td><b>Second extraction pass</b> on the ' + EMP.length + ' empirical studies: stated reasons for data, learners and measures; measure and data used to select settings; methodology cited for tests; evidence beyond classifier scores<div class="tth" style="display:block">อ่าน PDF รอบที่สอง บันทึกเหตุผลที่แต่ละ paper ให้ไว้ พร้อมเลขหน้าและข้อความอ้างอิง</div></td><td>Reasons in 7.2, 7.3 and 7.5 to 7.7; ' + refLabel('tab-reasons', 'en') + ' and ' + refLabel('tab-beyond', 'en') + '; model-selection criteria in 7.6; the explicit/implied split of settings chosen on evaluation data</td><td><span class="pill flag">single coder; quote and page given, second check pending</span></td></tr>' +
  '<tr><td><b>OpenAlex citation counts</b> for ' + cnt(ALL, p => p.cites != null) + ' of ' + ALL.length + ' papers and ' + AN.refs.length + ' reference works, retrieved ' + AN.retrieved + '</td><td>Citation ratios in 7.1 and each subsection; ' + refLabel('fig-influence', 'en') + '; counts for KEEL, UCI and testing methodology</td><td><span class="pill ok">from OpenAlex</span> <span class="pill neu">one index, one date</span></td></tr>' +
  '<tr><td><b>Data section workbook</b> (SMOTE25_data_extraction.xlsx, all rows ai_draft)</td><td>Dataset families in the exploratory note of 7.2 only (HTML, not exported)</td><td><span class="pill bad">unverified, not for the manuscript</span></td></tr>' +
  '<tr><td><b>Three foundational works</b> (Wilson ENN, Tomek links, AdaBoost)</td><td>Counted in the corpus (7.1); excluded from all statistics</td><td><span class="pill neu">counted only</span></td></tr>' +
  '<tr><td><b>Two reviews in the Survey folder</b></td><td>Form of the section only; counted in 7.1; excluded from all statistics</td><td><span class="pill neu">form only</span></td></tr>' +
  '<tr><td><b>General methodology</b></td><td>Equations in 7.4; advantages and limitations in ' + refLabel('tab-measures', 'en') + ' and ' + refLabel('tab-protocols', 'en') + '; KEEL, MAUC, PR-AUC, testing and selection-bias sources now cited from OpenAlex records</td><td><span class="pill flag">partly cited; remaining items are TODO</span></td></tr>' +
  '<tr><td><b>Our synthesis</b></td><td>Thesis, the recap and standard in 7.11, recommended practice in ' + refLabel('tab-remedies', 'en') + '</td><td><span class="pill neu">authors\' argument</span></td></tr>' +
  '</tbody></table></div></div>' +
  '<div class="panel"><h3>What was coded · สิ่งที่ลงรหัส</h3><p>Each PDF was read in full by an extraction pass that recorded datasets (count, source, IR, classes), base learners, competitors, measures with their exact definitions, validation protocol, repeats, whether resampling was confined to training data, hyperparameter settings, statistical tests, reporting forms, runtime and code. Values a paper does not state were left empty. Supplementary files were read where they hold results; the four ROS (Buda) appendices were catalogued by title only.</p></div>' +
  '<div class="panel"><h3>Derived categories · หมวดที่จัดกลุ่มเพิ่ม</h3><div class="tbl-wrap"><table class="t"><thead><tr><th>Code</th><th>Values and rule</th></tr></thead><tbody>' +
  '<tr><td>Protocol class</td><td>Repeated k-fold CV · Single k-fold CV · 5×2 CV · Repeated hold-out · Single hold-out · Fixed benchmark split · Not stated. Mixed designs take the class of the main benchmark.</td></tr>' +
  '<tr><td>Hyperparameters</td><td><b>Nested or held-out tuning</b>: chosen inside training folds or on separate tuning datasets. <b>Fixed or default</b>: preset values for all methods. <b>Selected on evaluation data</b>: the reported setting, grid optimum or resampling amount was picked by looking at results on the data used to report performance, including defaults fixed by sensitivity runs on the evaluation datasets. <b>Not stated</b>. This version reconciles pass 1 with the page-referenced pass 2: <b>explicit</b> when pass 2 quotes the selection on evaluation data, <b>implied</b> when pass 1 coded it and pass 2 found no separate validation data (values from preliminary runs, or the best result kept).</td></tr>' +
  '<tr><td>Citation ratio</td><td>OLS of log(1 + citations) on publication year and a 0/1 indicator of the practice, over empirical studies published up to 2024 with an OpenAlex record; the ratio is exp(coefficient) with a 95% t interval. Association only; venue, idea and authors are not controlled. Fitted in v2/merge_v2.py.</td></tr>' +
  '<tr><td>Evidence beyond classifier scores</td><td><b>Visual</b>: 2-D or projected plots of resampled data, histograms. <b>Analytical</b>: theorems, bounds, big-O. <b>Model diagnostics</b>: tree or rule size, ensemble diversity. <b>Direct</b>: distribution distance or likelihood, noise removal of synthetic examples, example-type composition. Hand-drawn schematics and plots of the original data only are not counted.</td></tr>' +
  '<tr><td>Statistical test</td><td><b>Corrected multiple comparison</b>: any family-wise correction (Holm, Shaffer, Hochberg, Nemenyi, Bonferroni–Dunn, Tukey HSD, Hsu MCB). <b>Omnibus only</b>. <b>Pairwise, uncorrected</b>: Wilcoxon, t-tests or CV F-tests only. <b>Bayesian</b>. <b>No test</b>.</td></tr>' +
  '<tr><td>Outcome</td><td><b>A</b> best with no stated exception · <b>B</b> best, but the authors state a measure, learner, competitor or data condition where it is not better (per-dataset losses alone do not count) · <b>C</b> no advantage over simple baselines · <b>D</b> comparative study. Coded from each paper\'s own conclusions.</td></tr>' +
  '<tr><td>Measure families</td><td>Names normalised (TPR, sensitivity and recall become Recall/TPR; Hand–Till AUC becomes MAUC). Threshold-free = AUC, ROC curve, PR-AUC, MAUC or AUCm as reported, which includes the two studies whose “AUC” is a single-threshold value.</td></tr>' +
  '<tr><td>Cite keys</td><td>First-author surname + year + method name, following references.bib (chawla2002smote). Search a key in the Evidence explorer.</td></tr>' +
  '</tbody></table></div></div>' +
  '<div class="panel"><h3>Verification log · บันทึกการตรวจสอบ</h3><p>Sixteen codings that the prose relies on were re-checked against the PDFs by an independent pass. All were confirmed; caveats are kept in the entries.</p><div class="vlog">' + VLOG.map(r => '<div><span class="who"><button class="cite" data-key="' + r[1] + '">' + esc(r[0]) + '</button></span><span><span class="pill ok">confirmed</span> ' + esc(r[2]) + '</span></div>').join('') + '</div></div>' +
  '<div class="panel"><h3>Pass-2 spot check · ตรวจซ้ำการอ่านรอบที่สอง</h3><p>Twenty pass-2 claims that the new prose relies on were re-checked against the PDFs by an independent pass. Partly confirmed claims were narrowed in the text, and one code was changed (SHRINK 1998: no stated learner reason).</p><div class="vlog">' + EMP.filter(p => p.r2 && p.r2.check).map(p => '<div><span class="who"><button class="cite" data-key="' + esc(p.key) + '">' + esc(p.short + ' ' + p.year) + '</button></span><span><span class="pill ' + (p.r2.check.verdict === 'confirmed' ? 'ok' : 'flag') + '">' + esc(p.r2.check.verdict) + '</span> ' + esc(p.r2.check.note || ('“' + (p.r2.check.evidence || '') + '” (' + (p.r2.check.page || '') + ')')) + '</span></div>').join('') + '</div></div>' +
  '<div class="panel"><h3>Known extraction gaps · ข้อจำกัดของการดึงข้อมูล</h3><div class="tbl-wrap"><table class="t"><thead><tr><th>Study</th><th>Note</th></tr></thead><tbody>' +
  ALL.filter(p => p.flags && /image|garbled|not in the|not available|truncat|cut off|scrambled|OCR|not extract/i.test(p.flags)).map(p => '<tr><td><button class="cite" data-key="' + esc(p.key) + '">' + esc(p.short + ' ' + p.year) + '</button></td><td>' + esc(p.flags) + '</td></tr>').join('') + '</tbody></table></div></div>' +
  '<div class="panel inv"><h3>Corpus inventory · รายการบทความ</h3><p>Grouped by Drive folder. Papers present in two folders are listed under both.</p>' +
  folders.map(f => { const L = ALL.filter(p => inFolder(p, f)).sort((a, b) => a.year - b.year); return '<h4>' + f + ' (' + L.length + ')</h4><ul>' + L.map(p => '<li><button class="cite" data-key="' + esc(p.key) + '">' + esc(p.short + ' ' + p.year) + '</button> <span style="color:var(--muted)">' + esc(p.paper_type) + '</span></li>').join('') + '</ul>'; }).join('') + '</div></div>';
}

/* ---------------- shell, events ---------------- */
function setView(v) {
  state.view = v; save();
  document.querySelectorAll('.tab').forEach(t => t.setAttribute('aria-selected', String(t.dataset.view === v)));
  document.querySelectorAll('main > section[data-view]').forEach(s => { s.hidden = s.dataset.view !== v; });
  if (v === 'explorer' && !document.getElementById('ptable')) renderExplorerShell();
  if (v === 'latex') renderLatex();
  if (v === 'notes' && !document.querySelector('#v-notes .notes')) renderNotes();
  try { history.replaceState(null, '', '#' + v); } catch (e) {}
  requestAnimationFrame(rerenderAll);
}
function setLang(l) {
  state.lang = l; save();
  document.querySelectorAll('[data-lang]').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.lang === l)));
  const d = document.getElementById('v-draft'); d.classList.remove('lang-both', 'lang-en', 'lang-th'); d.classList.add('lang-' + l);
  const keep = charts.filter(c => !document.getElementById('sheet').contains(c.el));
  renderDraft(); keep.forEach(c => charts.push(c));
}
document.getElementById('meta').innerHTML = '<span><b>' + ALL.length + '</b> papers coded</span><span><b>' + EMP.length + '</b> with experiments</span><span>Section <b>7</b> of the JAIR draft</span><span>Updated 29 Oct 2026 · VI Lab</span>';

const tip = document.getElementById('tip');
function showTip(target, x, y) {
  const lines = target.getAttribute('data-tip').split('\n');
  tip.textContent = '';
  lines.forEach((l, i) => { const d = document.createElement(i === 0 ? 'b' : 'div'); d.textContent = l; if (i === 0) d.style.display = 'block'; tip.appendChild(d); });
  tip.hidden = false;
  const r = tip.getBoundingClientRect(), vw = window.innerWidth, vh = window.innerHeight;
  let left = x + 14, top = y + 14; if (left + r.width > vw - 8) left = x - r.width - 14; if (top + r.height > vh - 8) top = y - r.height - 14;
  tip.style.left = Math.max(8, left) + 'px'; tip.style.top = Math.max(8, top) + 'px';
}
document.addEventListener('pointermove', e => { const t = e.target.closest && e.target.closest('[data-tip]'); if (t) showTip(t, e.clientX, e.clientY); else tip.hidden = true; });
document.addEventListener('focusin', e => { const t = e.target.closest && e.target.closest('[data-tip]'); if (t) { const r = t.getBoundingClientRect(); showTip(t, r.left + r.width / 2, r.top); } });
document.addEventListener('focusout', () => { tip.hidden = true; });
document.addEventListener('scroll', () => { tip.hidden = true; }, true);
function copyText(id, btn) {
  const pre = document.getElementById(id), text = pre.textContent;
  const done = ok => { btn.textContent = ok ? 'Copied' : 'Text selected, press Ctrl+C'; setTimeout(() => { btn.textContent = 'Copy'; }, 1800); };
  const fallback = () => { const det = pre.closest('details'); if (det) det.open = true; const r = document.createRange(); r.selectNodeContents(pre); const s = window.getSelection(); s.removeAllRanges(); s.addRange(r); done(false); };
  try { navigator.clipboard.writeText(text).then(() => done(true), fallback); } catch (e) { fallback(); }
}
document.addEventListener('click', e => {
  const t = e.target;
  const tab = t.closest('.tab'); if (tab) { setView(tab.dataset.view); return; }
  const lg = t.closest('[data-lang]'); if (lg) { setLang(lg.dataset.lang); return; }
  const cp = t.closest('[data-copy]'); if (cp) { e.preventDefault(); copyText(cp.dataset.copy, cp); return; }
  const c = t.closest('.cite, .m, .pt'); if (c && c.dataset.key) { openPaper(c.dataset.key); return; }
  if (t.id === 'drawer-close' || t.id === 'scrim') { closePaper(); return; }
  const j = t.closest('[data-jump]'); if (j) { e.preventDefault(); const el = document.getElementById(j.dataset.jump); if (el) el.scrollIntoView({behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth', block: 'start'}); return; }
  const so = t.closest('[data-sort]'); if (so) { const k = so.dataset.sort; state.sort = {k: k, dir: state.sort.k === k ? -state.sort.dir : 1}; renderExplorerBody(); return; }
  if (t.id === 'f-reset') { state.f = {q: '', setting: 'all', era: 'all', approach: 'all', test: 'all', tune: 'all', proto: 'all', outcome: 'all', issues: false, all: false}; renderExplorerShell(); return; }
  const sc = t.closest('[data-scope]'); if (sc) { state.latexScope = sc.dataset.scope; renderLatex(); return; }
});
document.addEventListener('input', e => {
  const id = e.target.id; if (!id || id.indexOf('f-') !== 0) return;
  const key = id.slice(2);
  if (key === 'issues' || key === 'all') state.f[key] = e.target.checked; else state.f[key] = e.target.value;
  renderExplorerBody();
});
document.addEventListener('keydown', e => { if (e.key === 'Escape' && !document.getElementById('drawer').hidden) closePaper(); });
let rtm = null;
if (window.ResizeObserver) new ResizeObserver(() => { clearTimeout(rtm); rtm = setTimeout(rerenderAll, 120); }).observe(document.querySelector('main'));
window.addEventListener('resize', () => { clearTimeout(rtm); rtm = setTimeout(rerenderAll, 120); });
try { matchMedia('(prefers-color-scheme: dark)').addEventListener('change', rerenderAll); } catch (e) {}
new MutationObserver(rerenderAll).observe(document.documentElement, {attributes: true, attributeFilter: ['data-theme']});

setLang(state.lang);
setView(state.view);
window.__smote25 = {ST: ST, tokenValue: tokenValue, repoFiles: repoFiles};
}
})();
