"""Tables added or changed in v4.1 of Section 7. Every count is computed from data.json, v2/analysis.json, evalpage/facts.json,
evalpage/why.json and v4.1/cites_raw.json. Run after make_tables.py (which writes the v4 tables into v4.1/tables)."""
import json, re, collections, statistics as st
R = '/home/claude/smote25/'
OUT = R + 'v4.1/tables/'
D = json.load(open(R + 'data.json')); BY = {p['key']: p for p in D}; E = [p for p in D if p['empirical']]
AN = json.load(open(R + 'v2/analysis.json')); RM = {r['label']: r for r in AN['roadmap']}
F = json.load(open(R + 'evalpage/facts.json'))
CR = json.load(open(R + 'v4.1/cites_raw.json'))
ERA = ['≤2009', '2010-2015', '2016-2020', '2021-2026']
EN = {e: sum(1 for p in E if p['era'] == e) for e in ERA}
C = collections.Counter
HEAD = ('%% {what} (input from sections/07-empirical-comparisons.tex). Version 4.1, generated 2026-11-08 by v4.1/make_tables_v41.py.\n'
        '%% JAIR style: caption above the table, booktabs rules. Regenerate instead of editing numbers by hand.\n')
EH = '--2009 & --2015 & --2020 & --2026'
EH2 = '(14) & (13) & (20) & (24)'


def cite(*keys):
    return '\\parencite{' + ','.join(BY[k]['bibkey'] for k in keys) + '}'


def tex(s):
    return (str(s).replace('\\', '\\textbackslash{}').replace('&', '\\&').replace('%', '\\%').replace('_', '\\_').replace('#', '\\#')
            .replace('±', '$\\pm$').replace('√', '$\\surd$').replace('→', '$\\to$').replace('≥', '$\\ge$').replace('×', '$\\times$'))


def era_cells(pred, pct=True):
    out = []
    for e in ERA:
        n = sum(1 for p in E if p['era'] == e and pred(p))
        out.append(f'{round(100 * n / EN[e])}\\%' if pct else str(n))
    return out


def era_n(pred):
    return [sum(1 for p in E if p['era'] == e and pred(p)) for e in ERA]


def table(name, what, caption, label, colspec, head, rows, note='', env='table', place='t', size='\\footnotesize', sep='4pt'):
    colspec = re.sub(r'p\{', r'>{\\raggedright\\arraybackslash}p{', colspec)
    t = HEAD.format(what=what)
    t += ('\\begin{' + env + '}[' + place + ']\n  \\caption{' + caption + '}\n  \\label{' + label + '}\n  ' + size + '\n  \\setlength{\\tabcolsep}{' + sep + '}\n'
          '  \\begin{tabular}{' + colspec + '}\n    \\toprule\n    ' + head + '\\\\\n    \\midrule\n')
    for r in rows:
        t += ('    \\midrule\n' if r == 'MID' else '    ' + ' & '.join(str(x) for x in r) + '\\\\\n')
    t += '    \\bottomrule\n  \\end{tabular}\n'
    if note:
        t += '  \\par\\smallskip\\raggedright\\scriptsize ' + note + '\n'
    t += '\\end{' + env + '}\n'
    open(OUT + name + '.tex', 'w').write(t)


# ------------------------------------------------------------------ 7.1 the fifteen-year review and what followed it
def review15():
    post = [p for p in E if p['year'] >= 2019]; pre = [p for p in E if p['year'] < 2019]
    d_post = sum(1 for p in post if p['beyond_direct']); d_pre = sum(1 for p in pre if p['beyond_direct'])
    cs = ['OVO-SMOTE-2013', 'AMDO-2018', 'EMDO-2021', 'GDO-2022', 'CISO-2025']
    rows = [
        ['Preprocessing and cost-sensitive learning are equally effective; compare with both~\\parencite{lopez2012analysis}',
         f'A cost-sensitive or instance-weighting competitor in {len(cs)} studies, 3 of them after 2018~' + cite(*cs) + '; plain class weighting in one~' + cite('CISO-2025')],
        ['Partition-induced dataset shift distorts cross-validation on imbalanced data; use DOB-SCV~\\parencite{morenotorres2012study,lopez2014importance}', 'No study uses DOB-SCV'],
        ['The main open question is how synthetic examples relate to small disjuncts, noise and overlap',
         f'A direct check of the resampled data in {d_post} of the {len(post)} studies since 2019, against {d_pre} of {len(pre)} before; 2 count safe, borderline or rare examples~' + cite('SPE-2020', 'GLOS-2023')],
        ['SMOTE-based methods exist for 22 other paradigms, each with its own measures', 'One of them (INOS, time series) is in the corpus, evaluated as classification~' + cite('INOS-2013')],
        ['High-dimensional data and big data are open challenges~\\parencite{blagus2013smote}', 'No study evaluates on big data; image data appear in 4 studies, all from 2018 to 2020']]
    table('empirical-review15', 'Table: recommendations of the fifteen-year review and what the later studies did',
          'Points of the Fifteen-Year Review That Bear on Evaluation, and What Followed', 'tab:empirical-review15',
          '@{}p{0.46\\linewidth}p{0.5\\linewidth}@{}', 'Point made by the review~\\parencite{fernandez2018smote} & What the studies of the corpus did', rows)


# ------------------------------------------------------------------ 7.2 learner families of 2021-26 and their members
MEMBERS = {'SVM': 'SVM with RBF or linear kernel (LIBSVM, scikit-learn), one-vs-rest for several classes',
           'CART/DT': 'CART, the decision tree of scikit-learn; also the base tree of some ensembles',
           'k-NN': 'k-nearest neighbours, usually $k = 5$',
           'MLP/NN': 'multilayer perceptron trained by back-propagation',
           'Random Forest': 'random forest',
           'C4.5/C5.0': 'C4.5 (Weka J48, sometimes unpruned with Laplace smoothing) and C5.0',
           'Logistic Regression': 'logistic regression',
           'Naive Bayes': 'naive Bayes, including Gaussian naive Bayes',
           'Gradient boosting': 'XGBoost, CatBoost, GBDT, HistGradientBoosting',
           'Boosting ensemble': 'AdaBoost',
           'LDA': 'linear discriminant analysis',
           'Other': 'dynamic selection of one-vs-one classifiers (DOVO) over several learners'}
LABEL = {'SVM': 'Support vector machine', 'CART/DT': 'CART (decision tree)', 'k-NN': 'k-NN', 'MLP/NN': 'Multilayer perceptron', 'Random Forest': 'Random forest',
         'C4.5/C5.0': 'C4.5 or C5.0', 'Logistic Regression': 'Logistic regression', 'Naive Bayes': 'Naive Bayes', 'Gradient boosting': 'Gradient boosting',
         'Boosting ensemble': 'AdaBoost-type boosting', 'LDA': 'LDA', 'Other': 'Other', 'Rule learner': 'Rule learner', 'CNN': 'Convolutional network'}


def families():
    e4 = [p for p in E if p['era'] == '2021-2026']
    use = C(f for p in e4 for f in set(p['clf_families']))
    alone = C(p['clf_families'][0] for p in e4 if len(p['clf_families']) == 1)
    rows = [[LABEL[f], MEMBERS[f], f'{n} ({round(100 * n / 24)}\\%)', alone.get(f, 0) or '--'] for f, n in use.most_common()]
    table('empirical-families', 'Table: learner families of the studies published 2021 to 2026, with the algorithms inside each',
          'Learner Families Used by the 24 Studies Published 2021 to 2026', 'tab:empirical-families',
          '@{}p{0.22\\linewidth}p{0.5\\linewidth}rr@{}', 'Family & Algorithms named in the studies & Studies & Used alone', rows,
          note='Used alone: studies whose only learner is of this family (9 of the 24). The papers write these algorithms under 32 different names, for example ``SVM'', ``SVM (RBF)'' and ``Linear SVM (LIBSVM)''.')


# ------------------------------------------------------------------ 7.3 data
def cat(p):
    u, k = bool(p['uses_uci']), bool(p['uses_keel'])
    return 'both' if u and k else 'uci' if u else 'keel' if k else 'neither'


def data():
    rows = []
    for lab, c in [('UCI only', 'uci'), ('KEEL only', 'keel'), ('Both UCI and KEEL', 'both'), ('Neither', 'neither')]:
        n = era_n(lambda p, c=c: cat(p) == c)
        rows.append([lab, sum(n)] + [str(x) for x in n])
    rows.append(['Total', 71] + [str(EN[e]) for e in ERA])
    rows.append('MID')
    for lab, rm in [('Synthetic data', 'Synthetic data'), ('Private or application data', 'Private or application data'), ('Image data', 'Image data'),
                    ('Fewer than 10 real datasets', 'Fewer than 10 real datasets')]:
        n = era_n(lambda p, rm=rm: p['key'] in RM[rm]['keys'])
        rows.append([lab, sum(n)] + [str(x) for x in n])
    n = era_n(lambda p: p['r2'].get('data_stated')); rows.append(['States why the data were chosen', sum(n)] + [str(x) for x in n])
    rows.append('MID')
    md = [st.median([p['n_datasets'] for p in E if p['era'] == e]) for e in ERA]; mr = [st.median([p['datasets']['n_real'] for p in E if p['era'] == e]) for e in ERA]
    rows.append(['Median datasets per study (all)', f"{st.median([p['n_datasets'] for p in E]):g}"] + [f'{x:g}' for x in md])
    rows.append(['Median real datasets per study', f"{st.median([p['datasets']['n_real'] for p in E]):g}"] + [f'{x:g}' for x in mr])
    table('empirical-data', 'Table: data sources and benchmark size by period', 'Benchmark Data by Period', 'tab:empirical-data',
          '@{}p{0.36\\linewidth}rrrrr@{}', 'Studies (number) & All & ' + EH + '\\\\\n    & (71) & ' + EH2, rows,
          note='The first four rows partition the 71 studies, so they add up to 71: 53 use UCI data (33 only UCI, 20 both) and 33 use KEEL data (13 only KEEL, 20 both). '
               'The five that use neither use private data (2), the UCR time-series archive (1), public fraud and record-linkage data (1) and image benchmarks (1). '
               'All datasets includes synthetic ones.')


def datafam():
    rows = [[f['family'], f['n'], f['keel'], f['first'], ' & '.join(str(f['by_era'][e]) for e in ERA)] for f in AN['families']]
    table('empirical-datafam', 'Table: dataset families used most often', 'Dataset Families Used Most Often', 'tab:empirical-datafam',
          '@{}lrrrrrrr@{}', 'Family & Studies & From KEEL & First year & ' + EH, rows,
          note='A study counts once for a family if it uses any dataset derived from it (for example ecoli0 vs 1 or ecoli-0-1-4-7 vs 2-3-5-6). From KEEL: studies that take the family from KEEL.')


def tasks():
    rows = [
        ['CTGAN (2019)~' + cite('CTGAN-2019'), 'Generator of synthetic tables; 8 real datasets, one of them a regression task (news), and 7 simulated data sets with a known generating model',
         'Train on synthetic, test on real: each of several learners is trained on the synthetic table and scored on the real test split (F1, macro-F1 or accuracy; $R^2$ for the regression set). On simulated data, likelihood of the synthetic rows under the true model ($L_{syn}$) and of real test rows under a model refitted on synthetic rows ($L_{test}$)'],
        ['GAMO (2019)~' + cite('GAMO-2019'), 'Generative oversampling of minority images; 7 image benchmarks made imbalanced by subsampling, plus tabular sets in a supplement',
         'Classification of a fixed, balanced test set (average class accuracy and G-mean); separately, the Fréchet inception distance between real and generated images of each class'],
        ['INOS (2013)~' + cite('INOS-2013'), 'Oversampling of time series; 7 UCR data sets split into 48 binary tasks', 'Classification by an SVM: F1, G-mean, precision, recall and TNR on random hold-out splits'],
        ['Buda et al. (2018)~' + cite('ROS-Buda-2018'), 'Random oversampling for convolutional networks; MNIST, CIFAR-10 and ImageNet made imbalanced', 'Classification of a balanced test set: multi-class ROC-AUC and accuracy']]
    table('empirical-tasks', 'Table: studies with data other than plain tables, and how they evaluate', 'Studies Whose Data or Output Is Not a Plain Table, and How They Evaluate',
          'tab:empirical-tasks', '@{}p{0.16\\linewidth}p{0.3\\linewidth}p{0.5\\linewidth}@{}', 'Study & What is generated or resampled & How it is evaluated', rows)


# ------------------------------------------------------------------ 7.4 learners: who uses each family
def learner_use():
    import importlib.util, sys
    sys.path.insert(0, R + 'evalpage')
    W = json.load(open(R + 'evalpage/why.json'))
    rows = []
    for f in ['C4.5/C5.0', 'CART/DT', 'Rule learner', 'k-NN', 'SVM', 'Logistic Regression', 'Random Forest', 'Gradient boosting', 'Naive Bayes', 'MLP/NN']:
        c = W['clf'][f]
        rows.append([LABEL[f], c['n'], c['py'], c['weka'], c['code'], c['keel_data'], c['multi'], c['single'], f"{c['med_ds']:g}"])
    table('empirical-learner-use', 'Table: who uses each learner family (toolkit, code, data)', 'Who Uses Each Learner Family', 'tab:empirical-learner-use',
          '@{}p{0.2\\linewidth}rrrrrrrr@{}', 'Family & Studies & Python & Weka & Code & KEEL data & Multi-class & Alone & Datasets', rows,
          note='All counts are studies among the 71. Python, Weka: the study names the toolkit (a lower bound). Code: the study releases code. Alone: the family is the only learner of the study. Datasets: median number of datasets of the users.')


# ------------------------------------------------------------------ 7.5 competitors
def competitors():
    NAMES = [('Random oversampling (ROS)', r'\bROS\b|random[- ]?over'), ('Borderline-SMOTE', r'borderline'), ('ADASYN', r'adasyn'), ('Safe-Level-SMOTE', r'safe[- ]?level'),
             ('Random undersampling (RUS)', r'\bRUS\b|random[- ]?under'), ('MWMOTE', r'mwmote'), ('SMOTE+ENN or SMOTE+Tomek', r'smote[- +]*(enn|tomek)'), ('MDO', r'\bMDO\b'),
             ('k-means SMOTE', r'k-?means'), ('RBO or MC-RBO', r'\bRBO\b'), ('MC-CCR or CCR', r'\bCCR\b|MC-CCR'), ('SMOTEBoost', r'smoteboost'), ('RUSBoost', r'rusboost'), ('EasyEnsemble', r'easy ?ensemble')]
    has = lambda p, rx: any(re.search(rx, b or '', re.I) for b in (p['baselines'] or []))
    rows = [['SMOTE', sum(1 for p in E if p['smote_baseline'])] + era_cells(lambda p: p['smote_baseline'])]
    rows.append(['No resampling', sum(1 for p in E if p['no_resampling_baseline'])] + era_cells(lambda p: p['no_resampling_baseline']))
    rows.append('MID')
    for n, rx in NAMES:
        rows.append([n, sum(1 for p in E if has(p, rx))] + era_cells(lambda p, rx=rx: has(p, rx)))
    table('empirical-competitors', 'Table: competitors and baselines by period', 'Competitors and Baselines: Studies That Include Each, by Period', 'tab:empirical-competitors',
          '@{}p{0.34\\linewidth}rrrrr@{}', 'Competitor & Studies & ' + EH + '\\\\\n    & (71) & ' + EH2, rows,
          note='Period columns give the share of the studies of that period. SMOTE and no resampling are coded directly; the other rows are matched on the names in each study\'s list of competitors.')


# ------------------------------------------------------------------ 7.6 measures: full definitions
MDEF = [
    ('Accuracy or error', 'Overall', 'share of all predictions that are correct (error: 1 $-$ accuracy)', '$(TP + TN)/n$'),
    ('Recall (TPR, sensitivity)', 'Single class', 'share of minority examples found', '$TP/(TP + FN)$'),
    ('Specificity (TNR)', 'Single class', 'share of majority examples rejected', '$TN/(TN + FP)$'),
    ('Precision', 'Single class', 'share of minority predictions that are correct; depends on the class prior', '$TP/(TP + FP)$'),
    ('FPR', 'Single class', 'false positive rate', '$1 - \\mathrm{TNR}$'),
    ('G-mean', 'Composite', 'geometric mean of the two class rates', '$\\sqrt{\\mathrm{TPR}\\cdot\\mathrm{TNR}}$'),
    ('F1', 'Composite', 'harmonic mean of precision and recall', '$2PR/(P + R)$'),
    ('F-measure ($F_\\beta$)', 'Composite', 'weights recall $\\beta$ times as much as precision', '$(1 + \\beta^2)PR/(\\beta^2 P + R)$'),
    ('Balanced accuracy', 'Composite', 'arithmetic mean of the two class rates', '$(\\mathrm{TPR} + \\mathrm{TNR})/2$'),
    ('MCC', 'Composite', 'correlation between predicted and true labels; uses all four cells', 'Equation~\\ref{eq:empirical-mcc}'),
    ('Kappa', 'Composite', 'agreement corrected for chance', '$(p_o - p_e)/(1 - p_e)$'),
    ('G-score', 'Composite', 'geometric mean of precision and recall (not G-mean)', '$\\sqrt{P \\cdot R}$'),
    ('ROC-AUC', 'Ranking', 'probability that a minority example is scored above a majority one', 'area under TPR against FPR'),
    ('PR-AUC (AUPRC)', 'Ranking', 'area under precision against recall; depends on the prior', 'area under $P$ against $R$'),
    ('MAUC', 'Ranking', 'average AUC over all pairs of classes~\\parencite{hand2001simple}', '$\\frac{2}{K(K-1)}\\sum_{i<j}\\hat{A}(i,j)$'),
    ('AUCm', 'Ranking', 'other multi-class AUC, for example one-vs-rest average', 'mean of per-class AUC'),
    ('Per-class recall', 'Multi-class', 'recall of each class reported separately', '$r_k$'),
    ('Macro-F1', 'Multi-class', 'F1 averaged over classes with equal weight', '$\\frac{1}{K}\\sum_k F1_k$'),
    ('AvAcc', 'Multi-class', 'mean per-class recall (some studies use mean one-vs-rest accuracy, which true negatives inflate)', '$\\frac{1}{K}\\sum_k r_k$'),
    ('Weighted F1', 'Multi-class', 'F1 averaged with class-size weights; dominated by large classes', '$\\sum_k w_k F1_k$'),
    ('Macro-precision', 'Multi-class', 'precision averaged over classes', '$\\frac{1}{K}\\sum_k P_k$'),
    ('Pmin', 'Multi-class', 'smallest per-class precision', '$\\min_k P_k$'),
    ('CBA', 'Multi-class', 'class balance accuracy: each diagonal cell over the larger of its row and column sums, averaged', '$\\frac{1}{K}\\sum_k c_{kk}/\\max(c_{k\\cdot}, c_{\\cdot k})$'),
    ('CEN', 'Multi-class', 'confusion entropy, the spread of the errors (lower is better)', 'entropy of the confusion matrix'),
    ('Macro-recall', 'Multi-class', 'recall averaged over classes (equals AvAcc when AvAcc is defined correctly)', '$\\frac{1}{K}\\sum_k r_k$'),
    ('Minimum sensitivity', 'Multi-class', 'smallest per-class recall', '$\\min_k r_k$'),
    ('Misclassification cost', 'Cost', 'total cost of the errors under a cost matrix', '$\\sum C(i,j)\\,n_{ij}$')]
MKEY = {'Accuracy or error': 'Accuracy/Error', 'Recall (TPR, sensitivity)': 'Recall/TPR', 'Specificity (TNR)': 'Specificity/TNR', 'Precision': 'Precision', 'FPR': 'FPR', 'G-mean': 'G-mean',
        'F1': 'F1', 'F-measure ($F_\\beta$)': 'F-measure', 'Balanced accuracy': 'Balanced accuracy', 'MCC': 'MCC', 'Kappa': 'Kappa', 'G-score': 'G-score (P,R)', 'ROC-AUC': 'AUC',
        'PR-AUC (AUPRC)': 'AUPRC', 'MAUC': 'MAUC', 'AUCm': 'AUCm', 'Per-class recall': 'Per-class recall', 'Macro-F1': 'Macro-F1', 'AvAcc': 'AvAcc', 'Weighted F1': 'Weighted-F1',
        'Macro-precision': 'Macro-precision', 'Pmin': 'Pmin', 'CBA': 'CBA', 'CEN': 'CEN', 'Macro-recall': 'Macro-recall', 'Minimum sensitivity': 'Min-sensitivity', 'Misclassification cost': 'Cost'}


def measure_defs():
    rows = []
    last = None
    for lab, fam, mean, fx in MDEF:
        if last and fam != last:
            rows.append('MID')
        last = fam
        n = sum(1 for p in E if MKEY[lab] in p['metrics_n'])
        rows.append([lab, fam, mean, fx, n])
    table('empirical-measure-defs', 'Table: every scalar measure found in the corpus, with its definition', 'The 27 Scalar Measures Found in the Corpus',
          'tab:empirical-measure-defs', '@{}p{0.17\\linewidth}p{0.1\\linewidth}p{0.38\\linewidth}p{0.24\\linewidth}r@{}', 'Measure & Family & Meaning & Definition & Studies', rows,
          note='TP, FN, FP, TN: cells of the binary confusion matrix with the minority class as positive; $P$ precision, $R$ recall, $r_k$ and $P_k$ recall and precision of class $k$ of $K$, $c_{ij}$ cells of the multi-class confusion matrix. '
               'ROC curves (8 studies), confusion matrices (4), running time (14) and the fidelity of synthetic data (3) are also reported but are not scalar measures of classification.',
          place='p', sep='3pt')


def gmean_reasons():
    G = [p for p in E if 'G-mean' in p['metrics_n']]; O = [p for p in E if 'G-mean' not in p['metrics_n']]
    cg = C(r for p in G for r in (p['r2'].get('measure_reasons') or [])); co = C(r for p in O for r in (p['r2'].get('measure_reasons') or []))
    LAB = [('standard_in_literature', 'Standard in the literature'), ('accuracy_misleading', 'Accuracy misleads under imbalance'), ('minority_focus', 'Focus on the minority class'),
           ('threshold_free', 'Independent of the threshold'), ('multiclass_suitability', 'Suits several classes'), ('cost', 'Costs of an application'), ('other', 'Other, specific to a measure')]
    rows = [[t, f'{cg[k]} ({round(100 * cg[k] / len(G))}\\%)', f'{co[k]} ({round(100 * co[k] / len(O))}\\%)'] for k, t in LAB]
    table('empirical-gmean-reasons', 'Table: reasons stated for the measures, G-mean users against the other studies', 'Reasons Stated for the Choice of Measures',
          'tab:empirical-gmean-reasons', '@{}p{0.46\\linewidth}rr@{}', f'Reason given & G-mean users ($n = {len(G)}$) & Other studies ($n = {len(O)}$)', rows,
          note='A study can give several reasons; 70 of the 71 studies give at least one.')


def measure_sources():
    rows = [[re.sub(r'&', 'and', a), b] for a, b in F['measure_cites_top'][:14]]
    rows = [[a.replace('Saez', 'Sáez'), b] for a, b in rows]
    table('empirical-measure-sources', 'Table: sources cited when measures are chosen or defined', 'Sources Cited When Measures Are Chosen or Defined',
          'tab:empirical-measure-sources', '@{}p{0.5\\linewidth}r@{}', 'Source & Studies citing it', rows, sep='6pt')


def metric_issues():
    TX = {'MAUC computed from hard-label confusion matrices, not scores': 'MAUC computed from predicted labels instead of scores',
          'AvAcc defined as mean one-vs-rest accuracy (inflated by true negatives)': 'AvAcc defined as mean one-vs-rest accuracy, inflated by true negatives'}
    rows = []
    for p in sorted([p for p in E if p['metric_issue']], key=lambda p: (p['year'], p['key'])):
        rows.append([tex(p['short']) + ' (' + str(p['year']) + ')~' + cite(p['key']), tex(TX.get(p['metric_issue'], p['metric_issue']))])
    table('empirical-metric-issues', 'Table: studies with a measure-definition problem', 'Studies With a Problem in the Definition of a Measure', 'tab:empirical-metric-issues',
          '@{}p{0.3\\linewidth}p{0.66\\linewidth}@{}', 'Study & Problem', rows)


# ------------------------------------------------------------------ 7.8 protocol and settings by period
def protocol_era():
    rows = []
    for lab, f in [('Repeated $k$-fold CV', lambda p: p['protocol_class'] == 'Repeated k-fold CV'), ('5$\\times$2 CV', lambda p: p['protocol_class'] == '5x2 CV'),
                   ('Repeated hold-out', lambda p: p['protocol_class'] == 'Repeated hold-out'), ('Single $k$-fold CV', lambda p: p['protocol_class'] == 'Single k-fold CV'),
                   ('Single hold-out', lambda p: p['protocol_class'] == 'Single hold-out'), ('Fixed benchmark split or not stated', lambda p: p['protocol_class'] in ('Fixed benchmark split', 'Not stated'))]:
        rows.append([lab, sum(1 for p in E if f(p))] + era_cells(f))
    rows.append('MID')
    for lab, f in [('Repeated partitions (first three rows)', lambda p: p['protocol_class'] in ('Repeated k-fold CV', '5x2 CV', 'Repeated hold-out')),
                   ('$k = 5$', lambda p: p.get('cv_k') == 5), ('$k = 10$', lambda p: p.get('cv_k') == 10),
                   ('Train-only resampling stated', lambda p: p['resampling_inside_cv'] is True)]:
        rows.append([lab, sum(1 for p in E if f(p))] + era_cells(f))
    rows.append('MID')
    for lab, c in [('Settings chosen on evaluation data', 'Selected on evaluation data'), ('Fixed or default settings for all', 'Fixed / default settings'),
                   ('Nested or held-out tuning', 'Nested / held-out tuning'), ('Not stated', 'Unclear')]:
        f = lambda p, c=c: p['tuning_class'] == c
        rows.append([lab, sum(1 for p in E if f(p))] + era_cells(f))
    table('empirical-protocol-era', 'Table: validation protocol, train-only resampling and the choice of settings by period', 'Protocol and Choice of Settings by Period',
          'tab:empirical-protocol-era', '@{}p{0.4\\linewidth}rrrrr@{}', 'Practice & Studies & ' + EH + '\\\\\n    & (71) & ' + EH2, rows,
          note='Period columns give the share of the studies of that period.')


# ------------------------------------------------------------------ 7.9 tests
def tests_era():
    rows = []
    for t in ['Wilcoxon signed-rank', 'Friedman', 'Holm', 'Bonferroni-Dunn', 'Nemenyi', 'Shaffer', 'Iman-Davenport', 't-test', 'Bayesian test']:
        f = lambda p, t=t: t in p['tests_n']
        rows.append([t.replace('Bonferroni-Dunn', 'Bonferroni--Dunn').replace('Iman-Davenport', 'Iman--Davenport').replace('t-test', '$t$-test'), sum(1 for p in E if f(p))] + era_cells(f))
    rows.append('MID')
    for lab, f in [('Cites Demšar (2006)', lambda p: 'Demsar 2006' in (p['r2'].get('stats_cited') or [])), ('Cites any methodological source', lambda p: p['r2'].get('stats_method_ref')),
                   ('No test', lambda p: p['test_class'] == 'None')]:
        rows.append([lab, sum(1 for p in E if f(p))] + era_cells(f))
    table('empirical-tests-era', 'Table: statistical tests by period', 'Statistical Tests by Period', 'tab:empirical-tests-era',
          '@{}p{0.36\\linewidth}rrrrr@{}', 'Test & Studies & ' + EH + '\\\\\n    & (71) & ' + EH2, rows,
          note='Period columns give the share of the studies of that period. A study can use several tests.')


def test_errors():
    rows = [['SOUP (2019)~' + cite('SOUP-2019'), 'A Nemenyi critical-difference diagram is drawn after a Friedman test that is not significant ($p = 0.36$)'],
            ['MC-MBRC (2024)~' + cite('MC-MBRC-2024'), 'A Nemenyi test is applied without an omnibus Friedman test'],
            ['MC-NCLWO (2025)~' + cite('MC-NCLWO-2025'), 'The post-hoc procedure is named Holm in one place and Shaffer in another, and no omnibus test is reported'],
            ['G-SMOTE (2019)~' + cite('G-SMOTE-2019'), 'Holm-adjusted $p$-values are reported, but the paired test behind them is not named'],
            ['CBHSID (2022)~' + cite('CBHSID-2022'), 'Pairwise Wilcoxon tests without correction; the test is cited to a guide on normality testing; the significance level is given as 0.1 in one place and 0.01 or 0.05 in another']]
    table('empirical-test-errors', 'Table: errors in the use of statistical tests', 'Errors Found in the Use of Statistical Tests', 'tab:empirical-test-errors',
          '@{}p{0.26\\linewidth}p{0.7\\linewidth}@{}', 'Study & Error', rows)


# ------------------------------------------------------------------ 7.10 reporting by period
def reporting_era():
    MAIN = [('per-dataset table', 'Results table per dataset'), ('best-in-bold', 'Best value in bold'), ('average rank table', 'Average-rank table'), ('p-value table', 'Table of $p$-values'),
            ('mean +/- std', 'Mean $\\pm$ standard deviation'), ('win/tie/loss counts', 'Win/tie/loss counts'), ('ablation study', 'Ablation'), ('parameter sensitivity', 'Parameter sensitivity'),
            ('CD diagram', 'Critical-difference diagram'), ('box plot', 'Box plot'), ('runtime table', 'Runtime table'), ('supplementary tables', 'Tables in a supplement')]
    rows = []
    for k, t in MAIN:
        f = lambda p, k=k: k in (p['reporting'] or [])
        rows.append([t, sum(1 for p in E if f(p))] + era_cells(f))
    rows.append('MID')
    for t, f in [('Running time reported (table or figure)', lambda p: p['runtime_reported']), ('Code released', lambda p: p['has_code'])]:
        rows.append([t, sum(1 for p in E if f(p))] + era_cells(f))
    table('empirical-reporting-era', 'Table: forms of reporting by period', 'Forms of Reporting by Period', 'tab:empirical-reporting-era',
          '@{}p{0.4\\linewidth}rrrrr@{}', 'Form & Studies & ' + EH + '\\\\\n    & (71) & ' + EH2, rows,
          note='Period columns give the share of the studies of that period.')


# ------------------------------------------------------------------ 7.11 citations (raw counts) and the most cited studies
def cites_raw():
    ORDER = ['keel', 'many_ds', 'data_reason', 'multi_clf', 'ens_clf', 'learner_reason', 'nores', 'smote_base', 'acc', 'thrfree', 'metric_issue', 'beyond_direct',
             'repeated', 'inside', 'evalsel', 'anytest', 'corr', 'method_ref', 'std', 'runtime', 'code', 'outB']
    EN_LAB = {'many_ds': 'At least 18 real datasets (the median)'}
    by = {r['key']: r for r in CR}
    rows = []
    for k in ORDER:
        r = by[k]
        rows.append([EN_LAB.get(k, r['en']), r['n'], f"{r['med']:g}", f"{r['yr']:g}", r['n_o'], f"{r['med_o']:g}", f"{r['yr_o']:g}"])
    table('empirical-cites', 'Table: citations of studies with and without each practice (raw counts)', 'Citations of Studies With and Without Each Practice',
          'tab:empirical-cites', '@{}p{0.38\\linewidth}rrrrrr@{}',
          'Practice & \\multicolumn{3}{c}{With the practice} & \\multicolumn{3}{c}{Without}\\\\\n    & Studies & Citations & Year & Studies & Citations & Year', rows,
          note='Citations: median citation count in OpenAlex on 18 October 2026 (70 of the 71 studies; one has no record). Year: median year of publication of the group. '
               'Older papers have had more time to be cited (the median is 1,738 citations for studies published up to 2009 and 21 for studies since 2021), '
               'so a difference between the two groups must be read together with the difference in their years.', place='t')


def topcited():
    top = sorted([p for p in E if p.get('cites') is not None], key=lambda p: -p['cites'])[:10]
    TC = {'None': 'none', 'Corrected multiple comparison': 'corrected', 'Pairwise only (uncorrected)': 'pairwise', 'Bayesian': 'Bayesian', 'Omnibus, no corrected post-hoc': 'omnibus'}
    PC = {'Single k-fold CV': 'single $k$-fold', 'Repeated k-fold CV': 'repeated $k$-fold', 'Single hold-out': 'hold-out', 'Repeated hold-out': 'repeated hold-out',
          'Fixed benchmark split': 'fixed split', '5x2 CV': '5$\\times$2', 'Not stated': 'not stated'}
    rows = [[tex(p['short']) + ' (' + str(p['year']) + ')~' + cite(p['key']), f"{p['cites']:,}".replace(',', '{,}'), p['datasets']['n_real'], p['n_clf'], PC[p['protocol_class']], TC[p['test_class']]] for p in top]
    table('empirical-topcited', 'Table: the ten most cited empirical studies and how they evaluate', 'How the Ten Most Cited Empirical Studies Evaluate',
          'tab:empirical-topcited', '@{}p{0.36\\linewidth}rrrll@{}', 'Study & Citations & Real datasets & Learners & Protocol & Test', rows)


# ------------------------------------------------------------------ 7.12 the seven-point standard
COMP = {'G-mean', 'F1', 'F-measure', 'MCC', 'Balanced accuracy', 'Kappa', 'G-score (P,R)'}; RANK = {'AUC', 'AUPRC', 'MAUC', 'AUCm'}
CRIT = [('Repeated partitions', lambda p: p['protocol_class'] in ('Repeated k-fold CV', '5x2 CV', 'Repeated hold-out')),
        ('Train-only resampling stated', lambda p: p['resampling_inside_cv'] is True),
        ('Settings not chosen on evaluation data (nested or fixed)', lambda p: p['tuning_class'] in ('Nested / held-out tuning', 'Fixed / default settings')),
        ('Corrected or Bayesian test', lambda p: p['test_class'] in ('Corrected multiple comparison', 'Bayesian')),
        ('No-resampling baseline', lambda p: bool(p['no_resampling_baseline'])),
        ('A composite and a ranking measure', lambda p: bool(COMP & set(p['metrics_n'])) and bool(RANK & set(p['metrics_n']))),
        ('Code released', lambda p: bool(p['has_code']))]
SCORE = {p['key']: sum(1 for _, f in CRIT if f(p)) for p in E}


def standard():
    rows = [[t, sum(1 for p in E if f(p))] + era_cells(f) for t, f in CRIT]
    rows.append('MID')
    rows.append(['Median number of points met', f"{st.median(SCORE.values()):g}"] + [f"{st.median([SCORE[p['key']] for p in E if p['era'] == e]):g}" for e in ERA])
    rows.append(['All seven points met', sum(1 for v in SCORE.values() if v == 7)] + [str(sum(1 for p in E if p['era'] == e and SCORE[p['key']] == 7)) for e in ERA])
    table('empirical-standard', 'Table: a seven-point minimum standard and how many studies meet each point', 'A Seven-Point Minimum Standard and How Many Studies Meet It',
          'tab:empirical-standard', '@{}p{0.42\\linewidth}rrrrr@{}', 'Point & Studies & ' + EH + '\\\\\n    & (71) & ' + EH2, rows,
          note='Period columns give the share of the studies of that period that meet the point, except in the last two rows.')


# ------------------------------------------------------------------ 7.13 checklist
def checklist():
    rows = [
        ['Benchmark data', 'Source and name of every dataset (KEEL or UCI) with the date of download; size, number of features, number of classes and IR of each, with the definition of IR; how classes were merged, categorical features encoded and missing values handled; why these datasets (range of IR and difficulty, not only popularity); where the processed files and fold assignments are'],
        ['Base learners', 'Name, library and version of each learner; every hyperparameter and whether it was tuned; which score feeds AUC (probability or decision function); why each learner was chosen'],
        ['Competitors and baselines', 'Every competitor with the source of its code (library and version, or own implementation); the parameters of each; a statement that all were re-run on the same folds; for own implementations, which part of the original paper was followed, how unspecified values were set and how the implementation was checked'],
        ['Measures', 'The formula of every measure and the positive class; the threshold of each threshold measure; the scores used for AUC and PR-AUC; the averaging rule for several classes; the primary measure and why; the function or library that computes it'],
        ['Validation protocol', '$k$, the number of repetitions, stratification and seeds; which steps are fitted on the training folds only; a statement that every method uses the same partitions; the smallest number of minority examples in a test fold'],
        ['Choice of settings', 'The settings or search grid of every method; the search budget of each (number of configurations tried); the measure and data used to choose; a statement that nothing was chosen on the test folds'],
        ['Statistical testing', 'The test, its unit (the dataset) and $N$; the significance level and the correction for multiple comparisons; the measures and learners tested; the software; a table of $p$-values or a critical-difference diagram; effect sizes'],
        ['Reporting', 'Which tables are in the main text and which in the supplement; where code, per-fold results and data files are; library versions and the hardware used for timing'],
        ['Direct checks of the data', 'The definition of each check and the data it is computed on; how its results relate to the classifier scores; two-dimensional plots used as illustrations only'],
        ['Claims and limits', 'Conclusions per measure and learner, including where the method loses; effect sizes, not only $p$-values; the limits of the study (own implementations, chosen settings, data sources, what was not tested); a link to a pre-registered plan if there is one']]
    table('empirical-checklist', 'Table: what a new study should report, by topic', 'What a New Study Should Report', 'tab:empirical-checklist',
          '@{}p{0.2\\linewidth}p{0.76\\linewidth}@{}', 'Topic & What to report', rows, place='p')


# ------------------------------------------------------------------ appendix: coding of the 71 studies
AB_C = {'C4.5/C5.0': 'C45', 'CART/DT': 'CART', 'Rule learner': 'Rule', 'k-NN': 'kNN', 'SVM': 'SVM', 'Logistic Regression': 'LR', 'Random Forest': 'RF', 'Gradient boosting': 'GB',
        'Boosting ensemble': 'Boost', 'Naive Bayes': 'NB', 'MLP/NN': 'MLP', 'LDA': 'LDA', 'CNN': 'CNN', 'Other': 'Oth'}
AB_M = {'Accuracy/Error': 'Acc', 'Recall/TPR': 'TPR', 'Specificity/TNR': 'TNR', 'Precision': 'Prec', 'FPR': 'FPR', 'G-mean': 'GM', 'F1': 'F1', 'F-measure': 'Fb', 'Kappa': 'Kap',
        'Balanced accuracy': 'BA', 'MCC': 'MCC', 'G-score (P,R)': 'GS', 'AUC': 'AUC', 'AUPRC': 'PRAUC', 'MAUC': 'MAUC', 'AUCm': 'AUCm', 'Per-class recall': 'PCR', 'Macro-F1': 'mF1',
        'AvAcc': 'AvAcc', 'Weighted-F1': 'wF1', 'Macro-precision': 'mP', 'Pmin': 'Pmin', 'CBA': 'CBA', 'CEN': 'CEN', 'Macro-recall': 'mR', 'Min-sensitivity': 'MS', 'Cost': 'Cost'}
AB_P = {'Repeated k-fold CV': 'RCV', 'Single k-fold CV': 'CV', '5x2 CV': '5x2', 'Repeated hold-out': 'RHO', 'Single hold-out': 'HO', 'Fixed benchmark split': 'FS', 'Not stated': 'NS'}
AB_T = {'Selected on evaluation data': 'Eval', 'Fixed / default settings': 'Fixed', 'Nested / held-out tuning': 'Nest', 'Unclear': 'NS'}
AB_S = {'Corrected multiple comparison': 'Corr', 'Pairwise only (uncorrected)': 'Pair', 'Omnibus, no corrected post-hoc': 'Omni', 'Bayesian': 'Bayes', 'None': '--'}
AB_SET = {'binary': 'B', 'multiclass': 'M', 'both': 'B+M'}


def studies():
    rows = []
    for p in sorted(E, key=lambda p: (p['year'], p['key'])):
        src = ('K' if p['uses_keel'] else '') + ('U' if p['uses_uci'] else '')
        meas = ' '.join(AB_M[m] for m in p['metrics_n'] if m in AB_M)
        rows.append(tex(p['short']) + ' (' + str(p['year']) + ')~' + cite(p['key']) + ' & ' + AB_SET[p['setting']] + ' & ' + str(p['datasets']['n_real']) + (' ' + src if src else '') + ' & ' +
                    ' '.join(AB_C[c] for c in p['clf_families']) + ' & ' + meas + ' & ' + AB_P[p['protocol_class']] + ('' if p['resampling_inside_cv'] is not True else '$^\\ast$') + ' & ' +
                    AB_T[p['tuning_class']] + ' & ' + AB_S[p['test_class']] + ' & ' + ('yes' if p['has_code'] else '') + ' & ' + str(SCORE[p['key']]))
    t = HEAD.format(what='Appendix table: coding of the 71 empirical studies')
    t += ('{\\scriptsize\\setlength{\\tabcolsep}{2.5pt}\n\\begin{longtable}{@{}>{\\raggedright\\arraybackslash}p{0.2\\linewidth}l>{\\raggedright\\arraybackslash}p{0.07\\linewidth}>{\\raggedright\\arraybackslash}p{0.14\\linewidth}>{\\raggedright\\arraybackslash}p{0.2\\linewidth}llllr@{}}\n'
          '\\caption{Coding of the 71 Empirical Studies}\\label{tab:empirical-studies}\\\\\n\\toprule\n'
          'Study & Set. & Data & Learners & Measures & Prot. & Settings & Test & Code & Std.\\\\\n\\midrule\n\\endfirsthead\n'
          '\\toprule\nStudy & Set. & Data & Learners & Measures & Prot. & Settings & Test & Code & Std.\\\\\n\\midrule\n\\endhead\n'
          '\\bottomrule\n\\endfoot\n' + '\\\\\n'.join(rows) + '\\\\\n\\end{longtable}\n'
          '\\par\\raggedright Set.: B binary, M multi-class, B+M both. Data: number of real datasets; K KEEL, U UCI. '
          'Learners: C45 C4.5 or C5.0, CART, Rule rule learner, kNN, SVM, LR logistic regression, RF random forest, GB gradient boosting, Boost AdaBoost-type, NB naive Bayes, MLP, LDA, CNN, Oth other. '
          'Measures: Acc accuracy or error, TPR, TNR, Prec precision, FPR, GM G-mean, F1, Fb F-measure, Kap kappa, BA balanced accuracy, MCC, GS G-score, AUC ROC-AUC, PRAUC, MAUC, AUCm, PCR per-class recall, '
          'mF1 macro-F1, AvAcc, wF1 weighted F1, mP macro-precision, Pmin, CBA, CEN, mR macro-recall, MS minimum sensitivity, Cost. '
          'Prot.: RCV repeated $k$-fold CV, CV single $k$-fold CV, 5x2 CV, RHO repeated hold-out, HO single hold-out, FS fixed benchmark split, NS not stated; $^\\ast$ train-only resampling stated. '
          'Settings: Eval chosen on evaluation data, Fixed fixed or default, Nest nested or held-out tuning, NS not stated. Test: Corr corrected multiple comparison, Pair pairwise without correction, '
          'Omni omnibus only, Bayes Bayesian, -- none. Std.: points met of the standard in Table~\\ref{tab:empirical-standard}.\\par}\n')
    open(OUT + 'empirical-studies.tex', 'w').write(t)


if __name__ == '__main__':
    for f in (review15, families, data, datafam, tasks, learner_use, competitors, measure_defs, gmean_reasons, measure_sources, metric_issues, protocol_era,
              tests_era, test_errors, reporting_era, cites_raw, topcited, standard, checklist, studies):
        f()
    print('ok', sorted(SCORE.items(), key=lambda x: -x[1])[:6])
