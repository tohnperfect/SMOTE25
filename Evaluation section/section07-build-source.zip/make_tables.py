"""Tables new in v4. Every count is computed from data.json, evalpage/why.json and evalpage/exp.json; the cause sentences
are the English form of the row notes in the evaluation page (section07-evaluation-tan.html)."""
import json, collections, statistics as st
R = '/home/claude/smote25/'
OUT = R + 'v4/tables/'
D = json.load(open(R + 'data.json')); BY = {p['key']: p for p in D}; E = [p for p in D if p['empirical']]
W = json.load(open(R + 'evalpage/why.json')); X = json.load(open(R + 'evalpage/exp.json'))
ERA = ['≤2009', '2010-2015', '2016-2020', '2021-2026']
EN = {e: sum(1 for p in E if p['era'] == e) for e in ERA}
HEAD = ('%% {what} (input from sections/07-empirical-comparisons.tex). Version 4, generated 2026-11-08 by v4/make_tables.py.\n'
        '%% JAIR style: caption above the table, booktabs rules. Regenerate instead of editing numbers by hand.\n')
C = collections.Counter


def first_year(kind, lab):
    ys = [p['year'] for p in E if lab in (p['clf_families'] if kind == 'C' else p['metrics_n'])]
    return min(ys)


def shares(kind, lab):
    cnt = [sum(1 for p in E if p['era'] == e and lab in (p['clf_families'] if kind == 'C' else p['metrics_n'])) for e in ERA]
    return cnt, [round(100 * c / EN[e]) for c, e in zip(cnt, ERA)]


def status(kind, lab):
    cnt, sh = shares(kind, lab); fy = first_year(kind, lab)
    if cnt[3] == 0: return 'gone'
    if fy >= 2016: return 'new'
    if sh[3] - sh[0] >= 15: return 'up'
    if sh[0] - sh[3] >= 15: return 'down'
    return 'stable'


def sci(p):
    m, e = f'{p:.1e}'.split('e')
    return m + ' \\times 10^{' + str(int(e)) + '}'


def cite(*keys):
    return '\\parencite{' + ','.join(BY[k]['bibkey'] for k in keys) + '}'


# ------------------------------------------------------------------ Table: SMOTE (2002) and the studies of 2021 to 2026
def thennow():
    e4 = [p for p in E if p['era'] == '2021-2026']
    NON = {'Runtime', 'Fidelity/likelihood', 'Other', 'Confusion matrix', 'ROC curve'}
    sets = C(tuple(sorted(m for m in p['metrics_n'] if m not in NON)) for p in e4)
    fams = {c for p in e4 for c in p['clf_families']}; meas = {m for p in e4 for m in p['metrics_n'] if m not in NON}
    names = {c for p in e4 for c in (p['classifiers'] or [])}
    medc = st.median(len(p['clf_families']) for p in e4); medm = st.median(len([m for m in p['metrics_n'] if m not in NON]) for p in e4)
    rows = [('Learners', 'C4.5, Ripper (rule learner), naive Bayes', f'{len(fams)} families ({len(names)} distinct learner names); median {medc:g} per study'),
            ('Scalar measures', 'AUC, TPR (\\%TP, Acc$^+$), TNR (Acc$^-$, or 1 $-$ \\%FP)', f'{len(meas)} distinct measures; median {medm:g} per study; {len(sets)} different combinations among {len(e4)} studies'),
            ('Most used measures', 'AUC (from ROC curves)', 'G-mean (17 of 24), AUC (13), F1 or F-measure (10), MAUC (6)'),
            ('Other evidence', 'ROC curves and ROC convex hull, tree size, a 2-D plot of decision regions', '2-D plots of synthetic samples (15 of 24), runtime (7), direct checks of the resampled data (2)'),
            ('Data and protocol', '9 datasets, single 10-fold CV, no significance test', 'KEEL data in 67\\%, repeated CV in 62\\%, a significance test in 83\\%'),
            ('Code', 'not released', 'released by 12 of 24')]
    t = HEAD.format(what='Table: SMOTE (2002) against the studies published 2021 to 2026')
    t += ('\\begin{table}[t]\n  \\caption{What SMOTE Used in 2002 and What Studies Use Now}\n  \\label{tab:empirical-thennow}\n  \\footnotesize\n'
          '  \\begin{tabular}{@{}p{0.17\\linewidth}p{0.33\\linewidth}p{0.44\\linewidth}@{}}\n    \\toprule\n'
          '    & SMOTE~\\parencite{chawla2002smote} & Studies published 2021 to 2026 ($n = 24$)\\\\\n    \\midrule\n')
    t += ''.join(f'    {a} & {b} & {c}\\\\\n' for a, b, c in rows)
    t += '    \\bottomrule\n  \\end{tabular}\n\\end{table}\n'
    open(OUT + 'empirical-thennow.tex', 'w').write(t)
    return len(sets), len(fams), len(meas)


# ------------------------------------------------------------------ Table: learner families, trend and cause
c = W['clf']
LEARN = [
 ('C4.5/C5.0', 'C4.5 or C5.0', 'T, L', 'Shipped with Weka (J48) and KEEL, the tools of the first decade; scikit-learn has no C4.5. Users name Weka in 11 of 33 studies and Python in 2. The five users since 2021 keep it to stay comparable with earlier work in their line.'),
 ('CART/DT', 'CART (decision tree)', 'T', 'The decision tree of scikit-learn is CART, so the tree did not disappear: it changed with the toolkit. 13 of 17 users release code (C4.5: 8 of 33), and 12 of the 17 are from 2021 onwards.'),
 ('SVM', 'SVM', 'T, L', 'Available in both toolkits, and the most frequent choice of studies that use one learner only: 4 of the 9 single-learner studies since 2021 use an SVM, 3 use C4.5.'),
 ('k-NN', 'k-NN', 'T, R', 'Available in both toolkits and chosen to cover different learning paradigms (11 of 28 say so). Its share fell after 2020 because studies still use about three learners while SVM, RF and boosting took more of the slots.'),
 ('MLP/NN', 'Multilayer perceptron', 'L', 'Carried by one line of work: all four studies of the MC-CCR line (MC-CCR, MC-RBO, NROMM, MC-MBRC) use it; three early studies used it alone.'),
 ('Naive Bayes', 'Naive Bayes', 'L', 'Cheap, parameter-free and present in every toolkit; never used alone (0 of 14), so nothing pushed it up or down.'),
 ('Logistic Regression', 'Logistic regression', 'T, R', 'Arrived with Python (6 of 13 users name Python, none name Weka); chosen because few hyperparameters limit tuning bias.'),
 ('Random Forest', 'Random forest', 'R, T', 'Studies want to know whether resampling still helps a strong learner that practitioners use; RF is reported as top performing or most widely used.'),
 ('Gradient boosting', 'Gradient boosting', 'R, T, L', 'The strongest off-the-shelf tabular learner today; 7 of 8 users name Python and their median benchmark has 34.5 datasets. QC-SMOTE keeps CatBoost to match a published benchmark.'),
 ('Boosting ensemble', 'AdaBoost-type boosting', 'T, R', 'Represented the ensemble paradigm in 2016 to 2020 (5 studies) and was then replaced by gradient boosting (2 against 5 studies since 2021).'),
 ('Rule learner', 'Rule learners (RIPPER, PART, MODLEM)', 'T, L', 'Only in Weka or in the authors\' code; scikit-learn has none. They were used by two groups (Chawla and co-authors early on; the Poznań group in SPIDER2 and SOUP) and not after SOUP (2019).'),
 ('CNN', 'Convolutional network', 'P', 'Not abandoned: the two image studies (2018, 2019) used CNNs because the data were images, and no study since 2021 uses image data.'),
 ('LDA', 'LDA', 'N', 'Used twice because it has no parameters to tune.'),
 ('Other', 'Other', 'N', 'Method-specific choices: a Bayesian KDE classifier that matches the generator of CGMOS, and a one-vs-one ensemble in RSMOTE.')]
STL = {'gone': 'gone', 'new': 'new', 'up': 'rising', 'down': 'falling', 'stable': 'stable'}


def learner_table():
    t = HEAD.format(what='Table: learner families by period, with the cause of the change')
    t += ('\\begin{table}[p]\n  \\caption{Base Learners by Period and Why Their Use Changed}\n  \\label{tab:empirical-learner-causes}\n  \\footnotesize\n  \\setlength{\\tabcolsep}{3pt}\n'
          '  \\begin{tabular}{@{}p{0.16\\linewidth}rrrrp{0.07\\linewidth}p{0.06\\linewidth}p{0.42\\linewidth}@{}}\n    \\toprule\n'
          '    Learner & --2009 & --2015 & --2020 & --2026 & Trend & Driver & Cause of the change\\\\\n'
          f'    & ({EN[ERA[0]]}) & ({EN[ERA[1]]}) & ({EN[ERA[2]]}) & ({EN[ERA[3]]}) & & & \\\\\n    \\midrule\n')
    for lab, name, drv, cause in LEARN:
        cnt, sh = shares('C', lab)
        t += f'    {name} & {sh[0]}\\% & {sh[1]}\\% & {sh[2]}\\% & {sh[3]}\\% & {STL[status("C", lab)]} & {drv} & {cause}\\\\\n'
    t += ('    \\bottomrule\n  \\end{tabular}\n  \\par\\smallskip\\raggedright\\scriptsize Columns give the share of the studies of each period (number of studies in brackets). '
          'Trend: gone = no study since 2021; new = first used in 2016 or later; rising or falling = the share changed by 15 points or more between the first and the last period. '
          'Drivers: T = change of toolkit; L = following a line of earlier work; R = realism or a critique; P = change of problem or data type; N = used in at most two studies. '
          'Tool names count only studies that name the tool.\n\\end{table}\n')
    open(OUT + 'empirical-learner-causes.tex', 'w').write(t)


# ------------------------------------------------------------------ Table: measures, trend and cause
m = W['met']; rc, pc, gt = W['recall_with_comp'], W['prec_with_comp'], W['tnr_with_gm']
MEAS = [
 ('Overall', None, None, None),
 ('Accuracy/Error', 'Accuracy, error rate', 'P', 'Criticised since 1997 and used as a secondary number; since 2016 four of its five users are generative studies (CTGAN, SOS, GOIO, DGOT) that follow the train-on-synthetic, test-on-real tradition.'),
 ('Single-class rates', None, None, None),
 ('Recall/TPR', 'Recall (TPR)', 'A', f'Absorbed into G-mean and F1: among studies reporting one of them, the share that also reports recall separately fell from {rc[0][0]} of {rc[1][0]} to {rc[0][3]} of {rc[1][3]}.'),
 ('Precision', 'Precision', 'A, P', f'Absorbed into F1 ({pc[0][0]} of {pc[1][0]} F users also report it before 2010, {pc[0][3]} of {pc[1][3]} since 2021); what remains is per-class precision in multi-class studies.'),
 ('Specificity/TNR', 'Specificity (TNR)', 'A', f'Absorbed into G-mean: {gt[0][0]} of {gt[1][0]} G-mean users report it before 2010, {gt[0][3]} of {gt[1][3]} since 2021; last reported alone in 2013.'),
 ('Threshold composites', None, None, None),
 ('G-mean', 'G-mean', 'A, L', 'Measures the TPR--TNR trade-off that resampling moves, ignores the class prior, needs only labels and extends to multi-class (MG); see Section~\\ref{sec:empirical-gmean}.'),
 ('F1', 'F1', 'R', 'Inherited from information retrieval and kept by studies that focus on the positive class; it does not grow because it depends on the class prior, which makes averages over KEEL benchmarks hard to read (Section~\\ref{sec:empirical-f1}).'),
 ('F-measure', 'F-measure ($\\beta$ not stated)', 'R', 'The same measure as F1 named F-measure or F-value without $\\beta$; read it together with F1 (35 studies in total).'),
 ('MCC', 'MCC', 'R, T', 'Follows critiques of F1 and accuracy; all four users name Python and release code.'),
 ('Balanced accuracy', 'Balanced accuracy', 'T', 'The arithmetic mean of TPR and TNR, available in standard toolkits; three studies.'),
 ('Threshold-free ranking', None, None, None),
 ('AUC', 'ROC-AUC', 'L, P', 'Standard for binary studies on KEEL data; its share drops when multi-class studies, which use MAUC instead, are frequent (2016 to 2020) and recovers afterwards.'),
 ('MAUC', 'MAUC', 'P', 'Every user is a multi-class study, and multi-class studies grew from 3 to 15 per period; one formula for the whole field.'),
 ('AUPRC', 'PR-AUC', 'R', 'Recommended for imbalance but needs good scores, which C4.5 and rule learners do not give, and depends on the prior; 4 of 5 users name Python.'),
 ('Multi-class aggregates', None, None, None),
 ('Macro-F1', 'Macro-F1', 'P, T', 'F1 averaged over classes, a standard option in scikit-learn; 6 of 7 users are multi-class studies.'),
 ('AvAcc', 'AvAcc', 'L', 'From the KEEL group (2013); adopted by the MC-CCR line as part of a fixed set (AvAcc, CBA, MG, CEN): 5 of 7 users belong to that line, all use KEEL data.'),
 ('CBA', 'CBA', 'L', 'Introduced to this literature with MC-CCR and MC-RBO (2020); all 6 users belong to that line, one of them states it follows MC-CCR.'),
 ('CEN', 'CEN', 'L', 'Comes with CBA in the same set; all 5 users belong to the MC-CCR line.'),
 ('Macro-precision', 'Macro-precision', 'L, P', 'Per-class precision averaged (Pavg) in the AMDO and EMDO line and in studies that compare with it.'),
 ('Per-class recall', 'Per-class recall', 'P', 'Multi-class studies that inspect the smallest classes one at a time (4 studies).'),
 ('Other', None, None, None),
 ('Cost', 'Misclassification cost', 'P', 'Needs known error costs, which benchmark data do not have; only the two cost-sensitive studies (2006, 2010).'),
 ('Runtime', 'Running time', 'R', 'Newer methods are heavier (optimisation, generative models, certificates) and benchmarks larger, so authors must show the method is practical; QC-SMOTE reports about 39 times the cost of SMOTE against 209 for VS-SMOTE.'),
 ('ROC curve', 'ROC curves (plots)', 'S', f'Readable only for a few datasets: users have a median of {W["roc_med_ds"]:g} datasets against {W["auc_med_ds"]:g} for AUC users who draw none; the median benchmark grew from {W["ds_med_era"][0]:g} to {W["ds_med_era"][3]:g} datasets.'),
 ('Confusion matrix', 'Confusion matrices', 'S', 'Shown per dataset only when there are few datasets (median 10); summarised by measures when there are dozens.'),
 ('Fidelity/likelihood', 'Fidelity of synthetic data', 'P', 'Comes with methods that generate data from a model (CTGAN, GAMO) and with CISO; see Section~\\ref{sec:empirical-direct}.'),
]
RARE = [('Kappa', 'kappa (Random Balance 2015)'), ('G-score (P,R)', 'G-score of precision and recall (CGMOS 2016)'), ('FPR', 'FPR (Cluster-SMOTE 2006, for ROC plots)'),
        ('Min-sensitivity', 'minimum sensitivity (DSRBF 2011, AMDO 2018)'), ('AUCm', 'AUCm (AMDO 2018, NROMM 2023)'), ('Pmin', 'Pmin (NROMM 2023)'),
        ('Weighted-F1', 'weighted F1 (SOS 2022)'), ('Macro-recall', 'macro-recall (RSMOTE 2021)')]


def measure_table():
    t = HEAD.format(what='Table: measures by period, with the cause of the change')
    t += ('\\begin{small}\n\\setlength{\\tabcolsep}{3pt}\n\\begin{longtable}{@{}p{0.17\\linewidth}rrrrp{0.07\\linewidth}p{0.06\\linewidth}p{0.4\\linewidth}@{}}\n'
          '  \\caption{Measures by Period and Why Their Use Changed}\\label{tab:empirical-measure-causes}\\\\\n  \\toprule\n'
          '  Measure & --2009 & --2015 & --2020 & --2026 & Trend & Driver & Cause of the change\\\\\n  \\midrule\n  \\endfirsthead\n'
          '  \\toprule\n  Measure & --2009 & --2015 & --2020 & --2026 & Trend & Driver & Cause of the change\\\\\n  \\midrule\n  \\endhead\n  \\bottomrule\n  \\endfoot\n')
    for lab, name, drv, cause in MEAS:
        if name is None:
            t += f'  \\multicolumn{{8}}{{@{{}}l}}{{\\textit{{{lab}}}}}\\\\\n'
            continue
        cnt, sh = shares('M', lab)
        t += f'  {name} & {sh[0]}\\% & {sh[1]}\\% & {sh[2]}\\% & {sh[3]}\\% & {STL[status("M", lab)]} & {drv} & {cause}\\\\\n'
    t += ('  \\multicolumn{8}{@{}p{0.98\\linewidth}}{\\textit{Used in one or two studies, so no trend can be read: ' + '; '.join(x for _, x in RARE) + '.}}\\\\\n')
    t += ('\\end{longtable}\n\\end{small}\n\\vspace{-\\baselineskip}\n{\\raggedright\\scriptsize Same conventions as Table~\\ref{tab:empirical-learner-causes}; '
          'A = absorbed into a composite measure; S = larger benchmarks. F1 and F-measure are coded apart only because papers name them differently.\\par}\n')
    open(OUT + 'empirical-measure-causes.tex', 'w').write(t)


# ------------------------------------------------------------------ Table: families of measures
def families():
    rows = [('Overall', 'Accuracy, error rate', '1', 13, 'How many predictions are correct?', 'Dominated by the majority class; a classifier that ignores the minority scores $\\pi_-$'),
            ('Single-class rates', 'Recall (TPR), specificity (TNR), precision, FPR', '4', 32, 'How well is one class handled?', 'One rate alone rewards predicting everything as minority'),
            ('Threshold composites', 'G-mean, F1, F$\\beta$, balanced accuracy, MCC, kappa, G-score', '7', 56, 'Does the classifier treat both classes well at its operating point?', 'Depend on the threshold; F ignores true negatives and depends on the prior'),
            ('Threshold-free ranking', 'ROC-AUC, PR-AUC, MAUC, AUCm', '4', 44, 'Does the classifier rank minority examples above majority ones?', 'Need scores; ROC-AUC can look good under severe imbalance; PR-AUC depends on the prior'),
            ('Multi-class aggregates', 'MG, AvAcc, macro-F1, CBA, CEN, Pmin, per-class recall and others', '10', 21, 'Is every class, including the smallest, handled well?', 'The averaging rule changes the value; it is often not stated'),
            ('Cost', 'Misclassification cost', '1', 2, 'What do the errors cost?', 'Needs costs that benchmark data do not have')]
    t = HEAD.format(what='Table: families of performance measures')
    t += ('\\begin{table}[t]\n  \\caption{Families of Measures Computed from a Downstream Classifier}\n  \\label{tab:empirical-measures}\n  \\footnotesize\n  \\setlength{\\tabcolsep}{4pt}\n'
          '  \\begin{tabular}{@{}p{0.13\\linewidth}p{0.22\\linewidth}rrp{0.2\\linewidth}p{0.27\\linewidth}@{}}\n    \\toprule\n'
          '    Family & Measures in the corpus & Distinct & Studies & Question it answers & Main limitation\\\\\n    \\midrule\n')
    t += ''.join(f'    {a} & {b} & {c} & {d} & {e} & {f}\\\\\n' for a, b, c, d, e, f in rows)
    t += ('    \\bottomrule\n  \\end{tabular}\n  \\par\\smallskip\\raggedright\\scriptsize Distinct: measures of the family named in at least one study (27 in total). Studies: studies that report at least one measure of the family. '
          'ROC curves, confusion matrices, running time and fidelity of synthetic data are not scalar measures of classification and are not counted.\n\\end{table}\n')
    open(OUT + 'empirical-measures.tex', 'w').write(t)


# ------------------------------------------------------------------ Table: direct checks of the resampled data
def direct():
    rows = [('saez2015smoteipf', 'SMOTE-IPF (2015)', 'Noise created by SMOTE', 'Share of synthetic, original minority and original majority examples removed by a noise filter after SMOTE, on synthetic, real and noise-injected data'),
            ('liu2020spe', 'SPE (2020)', 'Hardness of the examples kept', 'Number of majority examples per hardness bin before and after under-sampling; resampled sets drawn on a 2-D checkerboard'),
            ('xu2019ctgan', 'CTGAN (2019)', 'Fidelity to the true distribution', 'Likelihood of synthetic rows under the known generating model, and of real test rows under a model refitted on synthetic rows'),
            ('mullick2019gamo', 'GAMO (2019)', 'Distance between distributions (images)', 'Fréchet inception distance between real and generated images; a proof that the objective is a sum of Jensen--Shannon divergences'),
            ('han2023glos', 'GLOS (2023)', 'Type of the minority examples', 'Counts of safe, borderline and small-disjunct minority examples as a parameter varies'),
            ('yadav2025ciso', 'CISO (2025)', 'Distance to held-out minority data; per-sample guarantee', 'MMD$^2$ and the AUC of a classifier two-sample test against held-out minority examples; share of synthetic points that pass a certificate of not entering majority regions')]
    t = HEAD.format(what='Table: direct checks of the resampled data')
    t += ('\\begin{table}[t]\n  \\caption{Studies That Check the Resampled Data Directly}\n  \\label{tab:empirical-direct}\n  \\footnotesize\n  \\setlength{\\tabcolsep}{4pt}\n'
          '  \\begin{tabular}{@{}p{0.17\\linewidth}p{0.22\\linewidth}p{0.55\\linewidth}@{}}\n    \\toprule\n    Study & What is checked & How\\\\\n    \\midrule\n')
    t += ''.join(f'    {n}~\\parencite{{{k}}} & {w} & {h}\\\\\n' for k, n, w, h in rows)
    t += ('    \\midrule\n    Hassanat et al. (2022)~\\parencite{hassanat2022stop} & Whether synthetic points belong to the minority & Hide 10, 25 or 50\\% of the majority class, oversample the rest, and count the synthetic points whose nearest original example (Hassanat distance) is a majority example; no classifier is trained\\\\\n'
          '    \\bottomrule\n  \\end{tabular}\n  \\par\\smallskip\\raggedright\\scriptsize The last row is a position paper that is not among the 71 empirical studies.\n\\end{table}\n')
    open(OUT + 'empirical-direct.tex', 'w').write(t)


# ------------------------------------------------------------------ Table: example results table from our runs
def example():
    METH = X['meth']; per = X['per']['SVM|Gmean']
    t = HEAD.format(what='Table: an example results table, from the authors\' illustrative runs')
    t += ('\\begin{table}[t]\n  \\caption{A Results Table in the Recommended Form (Illustrative Runs, SVM, G-mean)}\n  \\label{tab:empirical-example}\n  \\scriptsize\n  \\setlength{\\tabcolsep}{3pt}\n'
          '  \\begin{tabular}{@{}lr' + 'r' * len(METH) + '@{}}\n    \\toprule\n    Dataset & IR & ' + ' & '.join(METH) + '\\\\\n    \\midrule\n')
    for r in X['example']:
        best = max(r['v'][me][0] for me in METH)
        cells = []
        for me in METH:
            v, s = r['v'][me]
            cell = f'{v:.3f} $\\pm$ {s:.3f}'
            cells.append('\\textbf{' + cell + '}' if abs(v - best) < 1e-9 else cell)
        t += '    ' + r['ds'].replace('_', '\\_') + f' & {r["IR"]:.1f} & ' + ' & '.join(cells) + '\\\\\n'
    t += '    \\multicolumn{' + str(2 + len(METH)) + '}{c}{\\textit{102 further datasets in the supplement}}\\\\\n    \\midrule\n'
    ar = per['ar']; b = min(ar.values())
    t += '    Average rank ($N = 110$) & & ' + ' & '.join(('\\textbf{%.2f}' if ar[me] == b else '%.2f') % ar[me] for me in METH) + '\\\\\n'
    t += '    Win/tie/loss against SMOTE & & ' + ' & '.join('control' if me == 'SMOTE' else '/'.join(map(str, per['wtl'][me])) for me in METH) + '\\\\\n'
    t += '    Holm-adjusted $p$ (Wilcoxon) & & ' + ' & '.join('--' if me == 'SMOTE' else ('$<$0.001' if per['holm'][me] < 0.001 else f'{per["holm"][me]:.3f}') for me in METH) + '\\\\\n'
    t += ('    \\bottomrule\n  \\end{tabular}\n  \\par\\smallskip\\raggedright\\scriptsize Mean $\\pm$ standard deviation over the five folds of a single stratified 5-fold run; bold marks the best value in a row. '
          f'Friedman test (Iman--Davenport): $p = {sci(per["pF"])}$. ' + 'Datasets were chosen to span the range of IR. CISO and QC-SMOTE are our reimplementations.\n\\end{table}\n')
    open(OUT + 'empirical-example.tex', 'w').write(t)


# ------------------------------------------------------------------ Table: drivers of change
def drivers():
    T = W['tool_era']; CO = W['code_era']; MU = W['multi_era']; DS = W['ds_med_era']
    arrow = lambda xs: ' $\\to$ '.join(str(x) for x in xs)
    rows = [('Change of toolkit', f'Studies naming Python: {arrow(T["py"])}; naming Weka: {arrow(T["weka"])}; releasing code: {arrow(CO)}',
             'C4.5 falls and CART rises; rule learners disappear; logistic regression, random forest and gradient boosting arrive; MCC and macro-F1 appear'),
            ('Absorption into composites', f'Composite users who also report recall: {rc[0][0]}/{rc[1][0]} $\\to$ {rc[0][3]}/{rc[1][3]}; F users who report precision: {pc[0][0]}/{pc[1][0]} $\\to$ {pc[0][3]}/{pc[1][3]}; G-mean users who report TNR: {gt[0][0]}/{gt[1][0]} $\\to$ {gt[0][3]}/{gt[1][3]}',
             'Recall, precision and TNR fall or vanish as stand-alone measures; G-mean rises'),
            ('Larger benchmarks', f'Median datasets per study: {" $\\to$ ".join(f"{v:g}" for v in DS)}', 'ROC curves and confusion matrices disappear; running time is reported more often'),
            ('Change of problem or data', f'Multi-class studies: {arrow(MU)}; image studies: 0 $\\to$ 0 $\\to$ 2 $\\to$ 0; generative studies from 2019 (5)',
             'MAUC, MG and macro-F1 rise; CNNs come and go; accuracy survives in generative studies'),
            ('Following a line of work', '11 studies say they chose learners as an earlier study did; six studies of the MC-CCR line (2020 to 2025) share AvAcc, CBA and CEN',
             'CBA, CEN, AvAcc and MLP spread together; C4.5 persists where comparability with older work matters'),
            ('Methodological sources', 'Demšar (2006) cited for the tests by 19 studies; first Friedman test 2008, first Wilcoxon test 2010; last t-test 2015',
             'Significance testing spreads (studies without a test: 64\\% $\\to$ 17\\%)'),
            ('Realism and critiques', 'RF or GB: 7\\% $\\to$ 33\\%; critiques of F1 and accuracy (Boughorbel et al. cited by 3 studies)', 'Strong learners appear; MCC appears; F1 stops growing')]
    t = HEAD.format(what='Table: drivers of change in evaluation practice')
    t += ('\\begin{table}[t]\n  \\caption{What Drove the Changes in Evaluation Practice}\n  \\label{tab:empirical-drivers}\n  \\footnotesize\n  \\setlength{\\tabcolsep}{4pt}\n'
          '  \\begin{tabular}{@{}p{0.16\\linewidth}p{0.46\\linewidth}p{0.32\\linewidth}@{}}\n    \\toprule\n    Driver & Evidence by period (1997--2009 $\\to$ 2010--2015 $\\to$ 2016--2020 $\\to$ 2021--2026) & Changes it explains\\\\\n    \\midrule\n')
    t += ''.join(f'    {a} & {b} & {c}\\\\\n' for a, b, c in rows)
    t += '    \\bottomrule\n  \\end{tabular}\n\\end{table}\n'
    open(OUT + 'empirical-drivers.tex', 'w').write(t)


# ------------------------------------------------------------------ Table: reporting, current and recommended
def reporting():
    rows = [('Results per dataset', '58 studies give a table, 24 with a standard deviation', 'Mean $\\pm$ standard deviation over repeated runs, datasets sorted by IR, full table in the supplement', 'The reader can see whether a gain exceeds the run-to-run variation'),
            ('Summary over datasets', '38 give average ranks, 19 win/tie/loss counts', 'Average ranks per learner, win/tie/loss against the main baseline, adjusted $p$-values, in the same table', 'One table answers "how often, by how much and is it reliable"'),
            ('Significance', '4 draw a critical-difference diagram', 'One critical-difference diagram per measure (and per learner, or per learner-averaged score)', 'Shows at a glance which methods cannot be told apart'),
            ('Several measures and learners', '4 heat maps', 'A heat map of average ranks, measures by learners', 'Shows whether the conclusion depends on the measure'),
            ('Where the method helps', '29 plot a measure against IR or a parameter', 'Per-dataset gain over the baseline against IR or dataset size', 'Tells a user on which data the method is worth its cost'),
            ('Cost', '12 runtime tables', 'Running time against dataset size on log axes', 'Separates a practical method from a slow one'),
            ('Figures to avoid', '17 bar charts, 6 ROC plots', 'Bar charts of means across datasets; ROC curves for dozens of datasets', 'Averages mix scales; overlaid curves cannot be read')]
    t = HEAD.format(what='Table: how results are reported and how they should be')
    t += ('\\begin{table}[t]\n  \\caption{How Results Are Reported and What We Recommend}\n  \\label{tab:empirical-reporting}\n  \\footnotesize\n  \\setlength{\\tabcolsep}{4pt}\n'
          '  \\begin{tabular}{@{}p{0.14\\linewidth}p{0.22\\linewidth}p{0.32\\linewidth}p{0.26\\linewidth}@{}}\n    \\toprule\n    Purpose & In the corpus (of 71) & Recommended & Why\\\\\n    \\midrule\n')
    t += ''.join(f'    {a} & {b} & {c} & {d}\\\\\n' for a, b, c, d in rows)
    t += '    \\bottomrule\n  \\end{tabular}\n\\end{table}\n'
    open(OUT + 'empirical-reporting.tex', 'w').write(t)


if __name__ == '__main__':
    print(thennow()); learner_table(); measure_table(); families(); direct(); example(); drivers(); reporting()
    import glob, re
    for f in glob.glob(OUT + '*.tex'):
        s = open(f).read(); assert '—' not in s, f
    print('tables written')
