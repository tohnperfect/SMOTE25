"""Build the repo-ready LaTeX package (version 3) from the files the page generates, compile the
figure sources, and run a full-paper compile check with stub fonts. Output: /home/claude/smote25/pkg3/"""
import json, os, shutil, subprocess, glob, re

R = '/home/claude/smote25/'
STUBS = '/tmp/claude-0/-home-claude/6e503650-68ce-58b4-a44b-b2d11f74f9f4/scratchpad/stubs'
PKG = R + 'pkg3/'
shutil.rmtree(PKG, ignore_errors=True)
files = json.load(open(R + 'test/repofiles_v3_bilingual.json'))
for path, text in files.items():
    os.makedirs(os.path.dirname(PKG + path), exist_ok=True)
    assert '\u2014' not in text, path
    open(PKG + path, 'w').write(text)

# figures
os.makedirs(PKG + 'figures', exist_ok=True)
for src in sorted(glob.glob(PKG + 'figures/src/*.tex')):
    name = os.path.basename(src)[:-4]
    r = subprocess.run(['pdflatex', '-interaction=nonstopmode', '-halt-on-error', '-output-directory', '/tmp/figbuild', src], capture_output=True, text=True, cwd=PKG + 'figures/src') if os.makedirs('/tmp/figbuild', exist_ok=True) is None else None
    if r.returncode != 0:
        print('FIGURE FAILED', name); print(r.stdout[-1500:]); raise SystemExit(1)
    shutil.copy('/tmp/figbuild/' + name + '.pdf', PKG + 'figures/' + name + '.pdf')
print('figures', len(glob.glob(PKG + 'figures/*.pdf')))

# full-paper compile check in a fresh copy of the repo
T = '/home/claude/repotest3/'
shutil.rmtree(T, ignore_errors=True)
shutil.copytree('/home/claude/repo/SMOTE25', T, ignore=shutil.ignore_patterns('.git'))
for path in files:
    if path.startswith('notes/'):
        continue
    os.makedirs(os.path.dirname(T + path), exist_ok=True)
    shutil.copy(PKG + path, T + path)
for f in glob.glob(PKG + 'figures/*.pdf'):
    shutil.copy(f, T + 'figures/')
m = open(T + 'main.tex').read()
if '\\usepackage{longtable}' not in m:
    m = re.sub(r'(\\RequirePackage\[[^\]]*\]\{biblatex\})', r'\1\n\\usepackage{longtable}', m, count=1)
    if '\\usepackage{longtable}' not in m:
        m = m.replace('\\begin{document}', '\\usepackage{longtable}\n\\begin{document}', 1)
m = m.replace('\\input{sections/appendix-reproducibility}', '\\input{sections/appendix-reproducibility}\n\\input{sections/appendix-empirical-map}', 1)
open(T + 'main.tex', 'w').write(m)
env = dict(os.environ, TEXINPUTS=STUBS + ':' + T + ':')
for i in range(2):
    r = subprocess.run(['pdflatex', '-interaction=nonstopmode', 'main.tex'], capture_output=True, text=True, cwd=T, env=env)
log = open(T + 'main.log', errors='replace').read()
errs = [l for l in log.split('\n') if l.startswith('!')]
undef = sorted(set(re.findall(r"Reference `([^']+)' on page \d+ undefined", log)))
pages = re.findall(r'Output written on main.pdf \((\d+) pages', log)
print('compile: errors', len(errs), errs[:5], '| undefined refs', undef[:10], '| pages', pages)
os.makedirs(PKG + 'notes', exist_ok=True)
shutil.copy(T + 'main.pdf', PKG + 'notes/preview-compiled-with-stub-fonts.pdf')
sec = files['sections/07-empirical-comparisons.tex']
print('TODO count', sec.count('\\TODO{'), '| words', len(re.sub(r'\\[a-zA-Z]+|[{}]', ' ', sec).split()))
