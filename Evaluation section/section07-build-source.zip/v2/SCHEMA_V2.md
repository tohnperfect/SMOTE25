# SMOTE25 evaluation section, extraction pass 2: why choices were made

Purpose: for each empirical paper, record WHY the authors chose their data, base learners,
measures and statistical procedures, HOW they selected models or parameters, and WHETHER
they evaluated the resampled data in any way other than through a classifier's score.

The project lead's advisor rejects any number that cannot be traced to the paper. So:

* Every coded field that is not `null`/`false` MUST carry `where` (page and section/table,
  e.g. "p. 9, Sec. 5.1" or "Sec. 4.2, Table 3"; use the page number printed on the page if
  visible in the text, otherwise the PDF page index prefixed with "pdf p.") and, where the
  field asks for it, a VERBATIM `quote` of at most 30 words copied exactly from the paper.
* Never infer a reason the paper does not state. If the paper gives no reason, set
  `stated: false`, `reasons: []`, `quote: null`. "Not stated" is a finding, not a gap.
* Read the WHOLE paper including the experimental section, appendix and the supplementary
  PDFs listed in `supp_ids`. Use English. Keep `details` short and factual.

Write ONE JSON array (one object per paper, in input order) to
`/home/claude/smote25/v2/extract/batch_XX.json` (XX = your batch number). Validate it with
`python3 -c "import json;json.load(open(PATH))"` before finishing.

```json
{
  "key": "SMOTE-2002",
  "data_choice": {
    "stated": true,
    "reasons": ["varied_characteristics", "public_benchmark"],
    "quote": "verbatim <=30 words",
    "where": "p. 334, Sec. 5"
  },
  "data_access": {
    "repos_named": ["UCI"],
    "all_public": true,
    "per_dataset_source_given": false,
    "links_given": false,
    "modified_data_released": null,
    "where": "p. 334, Table 2"
  },
  "learner_choice": {
    "stated": false,
    "reasons": [],
    "follows": null,
    "quote": null,
    "where": null
  },
  "model_selection": {
    "selected": ["method parameters"],
    "criterion": ["AUC"],
    "data_used": "evaluation data",
    "sensitivity_only": false,
    "quote": "verbatim <=30 words",
    "where": "p. 12, Sec. 5.3"
  },
  "measure_choice": {
    "stated": true,
    "reasons": ["accuracy_misleading"],
    "cites": ["Provost & Fawcett 1997"],
    "quote": "verbatim <=30 words",
    "where": "p. 325, Sec. 3"
  },
  "stats_methodology_cited": ["Demsar 2006"],
  "stats_where": "p. 14, Sec. 5.4",
  "beyond_classifier": {
    "any": true,
    "kinds": ["toy_2d_visualization"],
    "details": "Fig. 3 plots synthetic samples on a 2-D toy set",
    "where": "p. 6, Fig. 3"
  },
  "flags": "anything uncertain, unreadable pages, contradictions"
}
```

## Codes (use exactly these strings; add `other: <text>` only if nothing fits)

**data_choice.reasons**
- `public_benchmark`: data chosen because it is publicly available or a standard benchmark repository
- `comparability`: chosen because other papers use it / to compare with published results
- `follows_prior_work`: taken explicitly from a named earlier paper's experimental set-up
- `varied_characteristics`: chosen to cover a range of IR, size, dimensionality, number of classes
- `difficulty_factors`: chosen for overlap, noise, small disjuncts, borderline structure
- `application_domain`: chosen because of a target application (medical, fraud, ...)
- `multiclass_availability`: chosen because it is multi-class / has many classes
- `imbalance_level`: chosen to have high or a specific imbalance ratio

**data_access**
- `repos_named`: repositories the paper names (KEEL, UCI, OpenML, imbalanced-learn, LIBSVM, Kaggle, ...)
- `all_public`: true if every real dataset comes from a public source; false if any is private; null if unclear
- `per_dataset_source_given`: true if a table or list gives the source of each dataset
- `links_given`: true if URLs, repository IDs or DOIs for the data are given
- `modified_data_released`: if the authors changed datasets (binarised, merged classes, injected noise,
  subsampled), did they release the changed versions? true/false; null if nothing was modified

**learner_choice.reasons**
- `follows_prior_work`: same learners as a named earlier paper (put the name in `follows`)
- `popular`: "widely used", "popular", "well known", "standard"
- `sensitive_to_imbalance`: chosen because it is sensitive to class distribution / imbalance / data geometry
- `diverse_paradigms`: chosen to cover different learning paradigms or families
- `matches_mechanism`: chosen because it relates to how the method works (e.g. k-NN for a k-NN based sampler)
- `fair_comparison`: chosen so all methods are judged by the same learner(s), or because competitors used it
- `simplicity`: simple, interpretable, few parameters, fast

**model_selection**: how the paper decides which parameter value, configuration, variant or model is "best"
- `selected`: any of `method parameters`, `classifier hyperparameters`, `sampling rate`, `best variant`,
  `none (fixed settings)`, `not stated`
- `criterion`: the measure used to pick, e.g. `G-mean`, `AUC`, `F1`, `Sensitivity/Recall`, `Accuracy`, `MAUC`,
  `MCC`, `AvAcc`, `Precision`, `not stated`, `not applicable`
- `data_used`: `inner validation (training data only)`, `evaluation data` (the same folds/test sets that
  produce the reported numbers), `not stated`, `not applicable`
- `sensitivity_only`: true only if the criterion is recall/sensitivity/TPR alone

**measure_choice.reasons**
- `accuracy_misleading`: accuracy/error rate inadequate under imbalance
- `threshold_free`: wants a measure independent of the decision threshold or class distribution
- `standard_in_literature`: "commonly used", "widely used in imbalanced learning", follows earlier work
- `multiclass_suitability`: suits the multi-class case
- `minority_focus`: focuses on minority-class performance
- `cost`: cost or application considerations
Put cited methodology references in `cites` as "Surname Year".

**stats_methodology_cited**: methodological references the paper cites for its testing procedure,
e.g. `Demsar 2006`, `Garcia & Herrera 2008`, `Garcia et al. 2010`, `Derrac et al. 2011`,
`Benavoli et al. 2017`, `Dietterich 1998`. Empty list if none.

**beyond_classifier.kinds**: any assessment of the resampled/synthetic data that is NOT a
classifier's predictive score
- `toy_2d_visualization`: plots of original vs synthetic points on a toy or 2-D data set
- `projection_visualization`: PCA / t-SNE / UMAP / MDS plots of real data after resampling
- `distribution_distance`: KL, JS, MMD, Wasserstein, FID, likelihood or similar between real and synthetic
- `complexity_or_overlap_measure`: data complexity measures (F1, N1, N3, ...), overlap or separability indices
- `noise_count`: counts or rates of synthetic samples that fall in the majority region / are noisy
- `example_type_analysis`: safe / borderline / rare / outlier proportions before and after
- `theoretical_analysis`: proofs, bounds, analytical properties of the sampler
- `complexity_analysis`: big-O time or memory analysis
- `privacy_or_fidelity`: privacy, fidelity, utility metrics for generators
- `diversity_measure`: diversity of generated samples or of ensemble members
`any` is false when every quantitative result is a classifier performance score (runtime alone does not count).
