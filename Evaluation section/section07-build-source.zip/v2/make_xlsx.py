import json
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.utils import get_column_letter
R='/home/claude/smote25/'
data=[p for p in json.load(open(R+'data.json')) if p['empirical']]
an=json.load(open(R+'v2/analysis.json'))
F=Font(name='Arial',size=10); FB=Font(name='Arial',size=10,bold=True); FH=Font(name='Arial',size=10,bold=True,color='FFFFFF')
HF=PatternFill('solid',start_color='1F5FBF'); IN=PatternFill('solid',start_color='FFF4D6')
wb=Workbook()
ws=wb.active; ws.title='README'
lines=[('Section 7, pass 2: verification sheet',FB),('',F),
('Every row is one value from the second, page-referenced reading of the 71 empirical studies (reasons for data, learners and measures; model-selection criterion and data; test methodology cited; evidence beyond classifier scores; explicit or implied selection of settings on evaluation data).',F),
('How to use: open the PDF at the page in column G, compare with the quote in column F, then set column I (yellow) to verified, corrected or wrong. Put the corrected value and the page in column K.',F),
('Column H shows the independent spot check already done on 20 claims (confirmed / partly). Partly confirmed claims were narrowed in the text.',F),
('Sheet citations: OpenAlex counts used for the citation ratios, retrieved '+an['retrieved']+'. Sheet summary: counts by status, recalculated from the codes sheet.',F),
('Example of a filled row: status = verified, checked_by = Tan, note = "quote matches p. 7".',F),
('Generated from the Section 7 coded data; regenerate rather than edit the coded values by hand.',F)]
for i,(t,f) in enumerate(lines,1):
    c=ws.cell(row=i,column=1,value=t); c.font=f; c.alignment=Alignment(wrap_text=True,vertical='top')
ws.column_dimensions['A'].width=120
cs=wb.create_sheet('codes')
H=['key','study','year','field','coded value','quote (verbatim, max 30 words)','where in the paper','spot check','status','checked_by','correction / note']
for j,h in enumerate(H,1):
    c=cs.cell(row=1,column=j,value=h); c.font=FH; c.fill=HF
rows=[]
for p in sorted(data,key=lambda p:(p['year'],p['key'])):
    r=p['r2']; chk=r.get('check'); cv=(chk['verdict'] if chk else '')
    def add(field,val,q,w): rows.append([p['key'],p['short'],p['year'],field,val,q or '',w or '',cv,'','',''])
    add('data: reasons', ', '.join(r['data_reasons']) or 'none stated', r['data_quote'], r['data_where'])
    add('data: access', 'all public=%s; source per dataset=%s; links=%s; modified data released=%s'%(r['all_public'],r['per_ds_source'],r['links'],r['mod_released']), '', r['access_where'])
    add('learners: reasons', (', '.join(r['learner_reasons']) or 'none stated')+(' | follows '+r['learner_follows'] if r['learner_follows'] else ''), r['learner_quote'], r['learner_where'])
    add('model selection', 'selected: %s | criterion: %s | data: %s'%(', '.join(r['ms_selected']),', '.join(r['ms_criterion']),r['ms_data']), r['ms_quote'], r['ms_where'])
    add('measures: reasons', ', '.join(r['measure_reasons']) or 'none stated', r['measure_quote'], r['measure_where'])
    add('tests: methodology cited', '; '.join(r['stats_cited']) or 'none', '', r['stats_where'])
    add('beyond classifier scores', (', '.join(r['beyond_kinds']) or 'none')+(' | '+r['beyond_details'] if r['beyond_details'] else ''), '', r['beyond_where'])
    if p.get('tuning_evidence'): add('settings chosen on evaluation data', p['tuning_evidence'], r['ms_quote'] if p['tuning_evidence']=='explicit' else '', r['ms_where'])
for i,row in enumerate(rows,2):
    for j,v in enumerate(row,1):
        c=cs.cell(row=i,column=j,value=v); c.font=F; c.alignment=Alignment(wrap_text=True,vertical='top')
    for j in (9,10,11): cs.cell(row=i,column=j).fill=IN
n=len(rows)+1
dv=DataValidation(type='list',formula1='"verified,corrected,wrong"',allow_blank=True); cs.add_data_validation(dv); dv.add('I2:I%d'%n)
for j,w in enumerate([22,16,6,24,40,48,26,11,11,12,34],1): cs.column_dimensions[get_column_letter(j)].width=w
cs.freeze_panes='B2'; cs.auto_filter.ref='A1:K%d'%n
ct=wb.create_sheet('citations')
H2=['key','study','year','OpenAlex ID','DOI','citations','per year','match','eligible for ratios','note']
for j,h in enumerate(H2,1):
    c=ct.cell(row=1,column=j,value=h); c.font=FH; c.fill=HF
allp=json.load(open(R+'data.json'))
for i,p in enumerate(sorted(allp,key=lambda p:(p['year'],p['key'])),2):
    vals=[p['key'],p['short'],p['year'],p.get('openalex_id'),p.get('doi'),p.get('cites'),None,p.get('cite_match'),'yes' if p.get('cite_eligible') else 'no',p.get('cite_note') or '']
    for j,v in enumerate(vals,1):
        c=ct.cell(row=i,column=j,value=v); c.font=F
    ct.cell(row=i,column=7,value='=IF(F%d="","",ROUND(F%d/(2026-C%d+1),1))'%(i,i,i)).font=F
for j,w in enumerate([24,18,6,14,30,10,9,9,10,60],1): ct.column_dimensions[get_column_letter(j)].width=w
ct.freeze_panes='B2'
sm=wb.create_sheet('summary')
sm['A1']='status'; sm['B1']='rows'; sm['A1'].font=FB; sm['B1'].font=FB
for i,s in enumerate(['verified','corrected','wrong'],2):
    sm.cell(row=i,column=1,value=s).font=F
    sm.cell(row=i,column=2,value='=COUNTIF(codes!I:I,A%d)'%i).font=F
sm.cell(row=5,column=1,value='not yet checked').font=F
sm.cell(row=5,column=2,value='=COUNTA(codes!A:A)-1-SUM(B2:B4)').font=F
sm.cell(row=6,column=1,value='total rows').font=FB
sm.cell(row=6,column=2,value='=COUNTA(codes!A:A)-1').font=FB
sm.column_dimensions['A'].width=22
out=R+'section07-pass2-verification.xlsx'; wb.save(out); print(out, len(rows),'rows')
