"""Build the evaluation roadmap page: an artifact body (no skeleton) and a standalone HTML file.
Version 2 adds the evidence behind the four findings (citations, data, evidence beyond classifier scores,
learner choice and model selection), computed here from data.json and v2/analysis.json."""
import json, math, statistics as st, collections
import numpy as np

R = '/home/claude/smote25/'
an = json.load(open(R + 'v2/analysis.json'))
data = json.load(open(R + 'data.json'))
ALL = data
EMP = [p for p in data if p['empirical']]
BY = {p['key']: p for p in data}
C = collections.Counter


def med(xs):
    xs = [x for x in xs if x is not None]
    return round(st.median(xs), 1) if xs else None


def q(p, field):
    r = p['r2']
    return {'quote': r.get(field + '_quote'), 'where': r.get(field + '_where')}


emp = [{'key': p['key'], 'short': p['short'], 'year': p['year'], 'era': p['era'], 'cites': p.get('cites'), 'cpy': p.get('cites_per_year'),
        'n_real': p['datasets']['n_real'], 'n_clf': p['n_clf'], 'test_class': p['test_class'], 'tuning_class': p['tuning_class'], 'has_code': bool(p.get('has_code'))}
       for p in EMP]

# ------------------------------------------------------------ finding 1: citations
EL = sorted([p for p in EMP if p['cite_eligible']], key=lambda p: -p['cites'])
top, rest = EL[:10], EL[10:]


def profile(G):
    return {'n': len(G), 'pre2010': sum(p['year'] < 2010 for p in G), 'med_year': med([p['year'] for p in G]),
            'med_ds': med([p['datasets']['n_real'] for p in G]), 'single': sum(p['n_clf'] == 1 for p in G),
            'test': sum(p['test_class'] != 'None' for p in G), 'corr': sum(p['test_class'] in ('Corrected multiple comparison', 'Bayesian') for p in G),
            'code': sum(bool(p.get('has_code')) for p in G), 'evalsel': sum(p['tuning_class'] == 'Selected on evaluation data' for p in G),
            'med_cpy': med([p['cites_per_year'] for p in G])}


yrs = np.array([p['year'] for p in EL], dtype=float); ly = np.array([math.log1p(p['cites']) for p in EL])
b1, b0 = np.polyfit(yrs, ly, 1)
f1 = {
    'retrieved': an['retrieved'], 'found': sum(p.get('cites') is not None for p in ALL), 'all': len(ALL), 'emp': len(EMP), 'eligible': len(EL),
    'young': sum(p['year'] > 2024 for p in EMP), 'no_record': [p['key'] for p in EMP if p.get('cites') is None],
    'year_ratio': an['year_ratio'], 'line': [float(b0), float(b1)],
    'top': [{'key': p['key'], 'short': p['short'], 'year': p['year'], 'cites': p['cites'], 'cpy': p['cites_per_year'], 'n_real': p['datasets']['n_real'],
             'n_clf': p['n_clf'], 'test': p['test_class'], 'code': bool(p.get('has_code'))} for p in top],
    'top_profile': profile(top), 'rest_profile': profile(rest),
    'points': [{'key': p['key'], 'short': p['short'], 'year': p['year'], 'cites': p['cites'], 'issue': bool(p.get('metric_issue')), 'code': bool(p.get('has_code'))} for p in EL],
    'influence': an['influence'],
    'issue_rows': [{'key': p['key'], 'short': p['short'], 'year': p['year'], 'cites': p['cites'], 'cpy': p['cites_per_year'], 'pct': p.get('cite_pct_in_era'), 'problem': p['metric_issue']}
                   for p in sorted(EL, key=lambda p: p['year']) if p.get('metric_issue')],
    'issue_med': [med([p['cites_per_year'] for p in EL if p.get('metric_issue')]), med([p['cites_per_year'] for p in EL if not p.get('metric_issue')])],
    'code_med': [med([p['cites_per_year'] for p in EL if p.get('has_code')]), med([p['cites_per_year'] for p in EL if not p.get('has_code')])],
}

# ------------------------------------------------------------ finding 2: data
DR = ['varied_characteristics', 'imbalance_level', 'follows_prior_work', 'difficulty_factors', 'comparability', 'public_benchmark', 'application_domain', 'multiclass_availability']
dr_counts = C(x for p in EMP for x in p['r2']['data_reasons'])
examples = {}
DR_PREF = {'varied_characteristics': 'RBO-2019', 'comparability': 'KNNOR-2022', 'difficulty_factors': 'MLOS-2025'}
for code in DR:
    pk = DR_PREF.get(code)
    if pk:
        examples[code] = {'key': pk, 'short': BY[pk]['short'] + ' ' + str(BY[pk]['year']), **q(BY[pk], 'data')}; continue
    for p in sorted(EMP, key=lambda p: -p['year']):
        if code in p['r2']['data_reasons'] and p['r2']['data_quote'] and len(p['r2']['data_reasons']) == 1:
            examples[code] = {'key': p['key'], 'short': p['short'] + ' ' + str(p['year']), **q(p, 'data')}; break
    if code not in examples:
        for p in EMP:
            if code in p['r2']['data_reasons'] and p['r2']['data_quote']:
                examples[code] = {'key': p['key'], 'short': p['short'] + ' ' + str(p['year']), **q(p, 'data')}; break
CHAINS = [
    ('Sáez, Krawczyk and Woźniak 2016 (difficulty study, not in corpus)', ['MC-RBO-2020', 'MC-CCR-2020'], 'NROMM-2023'),
    ('AMDO 2018', ['EMDO-2021'], None),
    ('SPIDER2 2010 (Napierała, Stefanowski and Wilk)', ['SMOTE-IPF-2015'], None),
    ('Lango and Stefanowski 2018; Janicka et al. 2019 (not in corpus)', ['GMMSampling-2024'], None),
    ('VS-SMOTE benchmark (Qiu et al. 2025, not in corpus)', ['QC-SMOTE-2026'], None),
]
chains = []
for src, firsts, then in CHAINS:
    items = [{'key': k, 'short': BY[k]['short'] + ' ' + str(BY[k]['year']), **q(BY[k], 'data')} for k in firsts + ([then] if then else [])]
    chains.append({'source': src, 'items': items})
REFS = {r['key']: r for r in an['refs']}
repo = [{'label': 'KEEL software paper (Alcalá-Fdez et al. 2009)', 'cites': REFS['REF-KEEL-2009']['cites'], 'kind': 'repository'},
        {'label': 'KEEL data-set repository (Alcalá-Fdez et al. 2011)', 'cites': REFS['REF-KEEL-2011']['cites'], 'kind': 'repository'},
        {'label': 'UCI repository (Asuncion and Newman 2007 record)', 'cites': REFS['REF-UCI']['cites'], 'kind': 'repository'},
        {'label': 'imbalanced-learn (Lemaître et al. 2017, preprint record)', 'cites': REFS['REF-imblearn-2017']['cites'], 'kind': 'tool'}]
for k in ['SMOTE-2002', 'ADASYN-2008', 'Borderline-SMOTE-2005', 'SMOTE-ENN-Tomek-2004', 'MWMOTE-2014']:
    repo.append({'label': BY[k]['short'] + ' ' + str(BY[k]['year']) + ' (method in corpus)', 'cites': BY[k]['cites'], 'kind': 'method'})
repo.sort(key=lambda r: -r['cites'])
f2 = {
    'stated': sum(p['r2']['data_stated'] for p in EMP), 'n': len(EMP), 'not_stated': [BY[p['key']]['short'] + ' ' + str(p['year']) for p in EMP if not p['r2']['data_stated']],
    'reasons': [{'code': c, 'n': dr_counts.get(c, 0), 'ex': examples.get(c)} for c in DR],
    'chains': chains, 'repo': repo,
    'access': {'all_public': sum(p['r2']['all_public'] is True for p in EMP), 'not_public': sum(p['r2']['all_public'] is False for p in EMP),
               'unclear': sum(p['r2']['all_public'] is None for p in EMP), 'per_src': sum(p['r2']['per_ds_source'] is True for p in EMP),
               'links': sum(p['r2']['links'] is True for p in EMP), 'modified': sum(p['r2']['mod_released'] is not None for p in EMP),
               'released': [BY[p['key']]['short'] + ' ' + str(p['year']) for p in sorted(EMP, key=lambda p: p['year']) if p['r2']['mod_released'] is True]},
    'keel_uci': {'keel': sum(bool(p.get('uses_keel')) for p in EMP), 'uci': sum(bool(p.get('uses_uci')) for p in EMP)},
}

# ------------------------------------------------------------ finding 3: beyond classifier scores
GROUPS = [('visual', 'beyond_visual'), ('analytic', 'beyond_analytic'), ('model', 'beyond_model'), ('direct', 'beyond_direct'), ('none', 'beyond_none')]
f3 = {'n': len(EMP), 'without_classifier': 0, 'groups': {g: sum(bool(p.get(f)) for p in EMP) for g, f in GROUPS},
      'kinds': dict(C(x for p in EMP for x in p['r2']['beyond_kinds'] if x != 'other')),
      'direct': [{'key': p['key'], 'short': p['short'] + ' ' + str(p['year']), 'kinds': [k for k in p['r2']['beyond_kinds'] if k in ('distribution_distance', 'privacy_or_fidelity', 'noise_count', 'example_type_analysis', 'complexity_or_overlap_measure')],
                  'details': p['r2']['beyond_details'], 'where': p['r2']['beyond_where'], 'check': (p['r2'].get('check') or {}).get('verdict')} for p in sorted(EMP, key=lambda p: p['year']) if p.get('beyond_direct')],
      'model': [{'key': p['key'], 'short': p['short'] + ' ' + str(p['year']), 'details': p['r2']['beyond_details'], 'where': p['r2']['beyond_where']} for p in sorted(EMP, key=lambda p: p['year']) if p.get('beyond_model')],
      'none': [p['short'] + ' ' + str(p['year']) for p in sorted(EMP, key=lambda p: p['year']) if p.get('beyond_none')],
      'inf_direct': next(r for r in an['influence'] if r['key'] == 'beyond_direct')}

# ------------------------------------------------------------ finding 4: learners and model selection
LR = ['popular', 'diverse_paradigms', 'follows_prior_work', 'simplicity', 'fair_comparison', 'matches_mechanism', 'sensitive_to_imbalance']
lr_counts = C(x for p in EMP for x in p['r2']['learner_reasons'])
lr_ex = {}
LR_PREF = {'follows_prior_work': 'NROMM-2023', 'fair_comparison': 'AMDO-2018', 'simplicity': 'KMeansSMOTE-2018', 'matches_mechanism': 'Global-CS-2010'}
for code in LR:
    for p in sorted(EMP, key=lambda p: p['key'] != LR_PREF.get(code)):
        if code in p['r2']['learner_reasons'] and p['r2']['learner_quote']:
            lr_ex[code] = {'key': p['key'], 'short': p['short'] + ' ' + str(p['year']), **q(p, 'learner')}; break
# the coded quote of these two papers states other reasons; show the sentence that carries the sensitivity reason (checked in the PDFs)
SENS_Q = {'MC-NCLWO-2025': {'quote': 'It is sensitive to class imbalance and local distribution, making it a good test case for oversampling methods.', 'where': 'p. 152630, Sec. V.D (k-NN)'},
          'SMOTE-IPF-2015': {'quote': 'it is known to be more sensitive to different factors of imbalanced data than, e.g., SVM', 'where': 'p. 192, Sec. 4.4 (C4.5)'}}
sens = [{'key': p['key'], 'short': p['short'] + ' ' + str(p['year']), **SENS_Q.get(p['key'], q(p, 'learner'))} for p in EMP if 'sensitive_to_imbalance' in p['r2']['learner_reasons']]
sel = [p for p in EMP if not all(x in ('none (fixed settings)', 'not stated') for x in p['r2']['ms_selected'])]
named = lambda p: [c for c in p['r2']['ms_criterion'] if c not in ('not stated', 'not applicable') and not c.startswith('other')]
crit = C()
for p in sel:
    for c in set({'AUPRC': 'PR-AUC', 'mGM': 'MG', 'P20 (precision at top 20%)': 'Precision at top 20%'}.get(c, c) for c in named(p)):
        crit[c] += 1
internal = [p for p in sel if not named(p) and any(c.startswith('other') for c in p['r2']['ms_criterion'])]
ns = [p for p in sel if not named(p) and p not in internal]
DU = lambda p: 'other' if str(p['r2']['ms_data']).startswith('other') else p['r2']['ms_data']
f4 = {
    'n': len(EMP), 'learner_stated': sum(p['r2']['learner_stated'] for p in EMP),
    'learner_reasons': [{'code': c, 'n': lr_counts.get(c, 0), 'ex': lr_ex.get(c)} for c in LR], 'learner_other': lr_counts.get('other', 0), 'sens': sens,
    'clf_families': dict(C(x for p in EMP for x in p['clf_families']).most_common()),
    'sel_n': len(sel), 'named_n': sum(1 for p in sel if named(p)), 'internal_n': len(internal), 'ns_n': len(ns),
    'criteria': dict(crit.most_common()), 'data_used': dict(C(DU(p) for p in sel).most_common()),
    'sens_only': [{'key': p['key'], 'short': p['short'] + ' ' + str(p['year']), **q(p, 'ms'), 'check': (p['r2'].get('check') or {}).get('note')} for p in EMP if p['r2']['ms_sens_only']],
    'table': [{'short': p['short'] + ' ' + str(p['year']), 'selected': ', '.join(p['r2']['ms_selected']), 'criterion': ', '.join(p['r2']['ms_criterion']),
               'data': p['r2']['ms_data'], 'quote': p['r2']['ms_quote'], 'where': p['r2']['ms_where']} for p in sorted(sel, key=lambda p: p['year'])],
}

blob = {'roadmap': an['roadmap'], 'era_n': an['era_n'], 'families': an['families'], 'retrieved': an['retrieved'], 'emp': emp,
        'F': {'cites': f1, 'data': f2, 'beyond': f3, 'select': f4}}
json.dump(blob['F'], open(R + 'v2/roadmap_F.json', 'w'), ensure_ascii=False, indent=1)
js = json.dumps(blob, ensure_ascii=False, separators=(',', ':')).replace('</', '<\\/')
shell = open(R + 'src/roadmap_shell.html').read(); code = open(R + 'src/roadmap.js').read()
code = code.replace('function render() {', open(R + 'src/roadmap_findings.js').read() + '\nfunction render() {', 1)
body = shell + '\n<script id="rm-data" type="application/json">' + js + '</script>\n<script>\n' + code + '\n</script>\n'
assert '—' not in body
open(R + 'evaluation_roadmap.html', 'w').write(body)
i = body.index('</style>') + len('</style>')
full = ('<!doctype html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n'
        '<style>[hidden]{display:none!important}img{max-width:100%}</style>\n' + body[:i] + '\n</head>\n<body>' + body[i:] + '\n</body>\n</html>\n')
open(R + 'section07-evaluation-roadmap.html', 'w').write(full)
print(len(body), len(full))
print(json.dumps({'top': f1['top_profile'], 'rest': f1['rest_profile'], 'issue_med': f1['issue_med'], 'code_med': f1['code_med'],
                  'line': f1['line'], 'sel': (f4['sel_n'], f4['named_n'], f4['internal_n'], f4['ns_n']), 'crit': f4['criteria'], 'du': f4['data_used'],
                  'groups': f3['groups'], 'access': {k: v for k, v in f2['access'].items() if k != 'released'}}, ensure_ascii=False))
