"""Pass 2 merge: citations (OpenAlex), stated rationales, reconciled tuning class,
influence analysis, roadmap table and exploratory dataset families.

Reads  data_v1.json (pass-1 coded data), v2/cites/part_*.json, v2/rationale.json,
       v2/datasets_by_paper.json
Writes data.json (pass-1 fields + pass-2 fields) and v2/analysis.json
"""
import json, re, math, collections
import numpy as np
from scipy import stats

R = '/home/claude/smote25/'
RETRIEVED = '2026-10-18'
data = json.load(open(R + 'data_v1.json'))
BY = {p['key']: p for p in data}
EMP = [p for p in data if p['empirical']]

# ---------------------------------------------------------------- citations
cites = {}
for f in ['part_1', 'part_2', 'part_3']:
    for c in json.load(open(R + 'v2/cites/%s.json' % f)):
        cites[c['key']] = c
refs = {c['key']: c for c in json.load(open(R + 'v2/cites/part_refs.json'))}

CITE_RULE = {
    'A-SUWO-2016': ('use_alt', 'W2172165257', 'The PDF in the corpus is the dissertation chapter (0 citations in OpenAlex); the method is cited through its Expert Systems with Applications article, which is used.'),
    'Global-CS-2006': ('none', None, 'The AAAI 2006 paper has no OpenAlex record; the only match is the 2010 journal version, which is a separate corpus entry. Excluded from citation analysis.'),
    'OSS-1997': ('add_alt', 'W2979832949', 'OpenAlex splits this paper over two records (one with a misspelled title); the two counts are added.'),
    'StopOversampling-2022': ('use_alt', 'W4226084339', 'The published IEEE Access version is used instead of the Research Square preprint.'),
}
for k, p in BY.items():
    c = cites.get(k, {})
    n = c.get('cited_by_count'); oid = c.get('openalex_id'); doi = c.get('doi'); note = ''
    rule = CITE_RULE.get(k)
    if rule:
        kind, alt, note = rule
        alts = {a.get('id'): a for a in (c.get('alt_versions') or [])}
        if kind == 'none':
            n = None; oid = None; doi = None
        elif kind == 'use_alt':
            a = alts[alt]; n = a['cited_by_count']; oid = alt; doi = a.get('doi') or doi
        elif kind == 'add_alt':
            n = n + alts[alt]['cited_by_count']
    age = 2026 - p['year'] + 1
    p['cites'] = n
    p['cites_per_year'] = round(n / age, 2) if n is not None else None
    p['openalex_id'] = oid
    p['doi'] = (doi or '').replace('https://doi.org/', '') or None
    p['cite_note'] = note or (c.get('note') or '')[:300]
    p['cite_match'] = c.get('match')
    p['cite_eligible'] = bool(p['empirical'] and n is not None and p['year'] <= 2024)

# within-era percentile of citations per year (eligible only)
for era in set(p['era'] for p in EMP):
    E = [p for p in EMP if p['era'] == era and p['cite_eligible']]
    vals = sorted(p['cites_per_year'] for p in E)
    for p in E:
        below = sum(1 for v in vals if v < p['cites_per_year']); eq = sum(1 for v in vals if v == p['cites_per_year'])
        p['cite_pct_in_era'] = round(100 * (below + 0.5 * eq) / len(vals))

# ---------------------------------------------------------------- rationale (pass 2)
RAT = {r['key']: r for r in json.load(open(R + 'v2/rationale.json'))}
# corrections from the independent check of 20 pass-2 claims (v2/verify_*_result.json)
CHECK = {}
for f in ['verify_a_result', 'verify_b_result']:
    for v in json.load(open(R + 'v2/%s.json' % f)):
        CHECK[v['key']] = v
RAT['SHRINK-1998']['learner_choice'].update({'stated': False, 'reasons': [], 'quote': None, 'where': None})
RAT['SHRINK-1998']['flags'] = (RAT['SHRINK-1998'].get('flags') or '') + ' Independent check: p. 205 describes C4.5 and 1-NN as accuracy-optimising learners that do poorly on imbalanced data but does not give this as the reason for choosing them; recoded as no stated learner reason.'
RAT['SPE-2020']['learner_choice']['where'] = 'p. 849, Sec. VI-C-2 (comparison with ensemble methods only)'

METHOD_REFS = re.compile(r'Dem[sš]ar|Garc[ií]a|Derrac|Benavoli|Dietterich|Japkowicz|Alpaydin|Rodriguez-Fdez|Kruschke')


def clean_codes(xs):
    out = []
    for x in xs or []:
        out.append('other' if str(x).startswith('other') else x)
    return out


for k, r in RAT.items():
    p = BY[k]
    ms = r['model_selection']; bc = r['beyond_classifier']; da = r['data_access']
    p['r2'] = {
        'data_stated': r['data_choice']['stated'], 'data_reasons': clean_codes(r['data_choice']['reasons']),
        'data_quote': r['data_choice'].get('quote'), 'data_where': r['data_choice'].get('where'),
        'repos': da.get('repos_named') or [], 'all_public': da.get('all_public'), 'per_ds_source': da.get('per_dataset_source_given'),
        'links': da.get('links_given'), 'mod_released': da.get('modified_data_released'), 'access_where': da.get('where'),
        'learner_stated': r['learner_choice']['stated'], 'learner_reasons': clean_codes(r['learner_choice']['reasons']),
        'learner_follows': r['learner_choice'].get('follows'), 'learner_quote': r['learner_choice'].get('quote'), 'learner_where': r['learner_choice'].get('where'),
        'ms_selected': ms.get('selected') or [], 'ms_criterion': ms.get('criterion') or [], 'ms_data': ms.get('data_used'),
        'ms_sens_only': bool(ms.get('sensitivity_only')), 'ms_quote': ms.get('quote'), 'ms_where': ms.get('where'),
        'measure_stated': r['measure_choice']['stated'], 'measure_reasons': clean_codes(r['measure_choice']['reasons']),
        'measure_cites': r['measure_choice'].get('cites') or [], 'measure_quote': r['measure_choice'].get('quote'), 'measure_where': r['measure_choice'].get('where'),
        'stats_cited': r.get('stats_methodology_cited') or [], 'stats_where': r.get('stats_where'),
        'stats_method_ref': any(METHOD_REFS.search(x) for x in (r.get('stats_methodology_cited') or [])),
        'beyond_any': bc.get('any'), 'beyond_kinds': clean_codes(bc.get('kinds')), 'beyond_details': bc.get('details'), 'beyond_where': bc.get('where'),
        'flags': r.get('flags'),
        'check': ({'verdict': CHECK[k]['verdict'], 'note': CHECK[k].get('note'), 'evidence': CHECK[k].get('evidence'), 'page': CHECK[k].get('page')} if k in CHECK else None),
    }

# beyond-classifier groups
DIRECT = {'distribution_distance', 'complexity_or_overlap_measure', 'noise_count', 'example_type_analysis', 'privacy_or_fidelity'}
VISUAL = {'toy_2d_visualization', 'projection_visualization'}
ANALYTIC = {'theoretical_analysis', 'complexity_analysis'}
MODEL_OTHER = {'SMOTE-2002', 'SMOTE-ENN-Tomek-2004', 'SOUP-2019'}  # 'other' codes: size of trees or rule sets learned from the resampled data
VISUAL_OTHER = {'SOS-2022', 'KNNOR-2022'}  # 'other' codes: histograms of real vs synthetic columns; 2-D plots of filtered points
for p in EMP:
    r2 = p['r2']; ks = set(r2['beyond_kinds'])
    p['beyond_direct'] = bool(ks & DIRECT)
    p['beyond_visual'] = bool(ks & VISUAL) or ('other' in ks and p['key'] in VISUAL_OTHER)
    p['beyond_analytic'] = bool(ks & ANALYTIC)
    p['beyond_model'] = 'diversity_measure' in ks or ('other' in ks and p['key'] in MODEL_OTHER)
    p['beyond_none'] = not (p['beyond_direct'] or p['beyond_visual'] or p['beyond_analytic'] or p['beyond_model'])

# ---------------------------------------------------------------- reconciled tuning class
for p in EMP:
    old = p['tuning_class']; new = p['r2']['ms_data']
    p['tuning_class_v1'] = old
    if new == 'evaluation data':
        p['tuning_class'] = 'Selected on evaluation data'; p['tuning_evidence'] = 'explicit'
    elif old == 'Selected on evaluation data':
        p['tuning_class'] = 'Selected on evaluation data'; p['tuning_evidence'] = 'implied'
    else:
        p['tuning_evidence'] = None

# ---------------------------------------------------------------- dataset families (exploratory, unverified source)
DS = json.load(open(R + 'v2/datasets_by_paper.json'))


def fam(n):
    s = str(n).strip().lower().replace('_', '-').replace(' ', '-')
    if s.startswith('['):
        return None
    m = re.match(r'[a-z]+(?:-[a-z]+)*', s)
    if not m:
        return None
    f = re.sub(r'-(vs|v)$', '', m.group(0)).rstrip('-')
    return {'newthyroid': 'new-thyroid', 'pageblocks': 'page-blocks'}.get(f, f)


FAM = collections.defaultdict(set)
for p in EMP:
    fams = set()
    for r in DS['rows'].get(p['key'], []):
        if r['agg'] == 'yes':
            continue
        f = fam(r['name'])
        if f:
            fams.add(f); FAM[f].add(p['key'])
    p['ds_families'] = sorted(fams)
CLASSIC = ['ecoli', 'yeast', 'glass', 'vehicle', 'abalone']
for p in EMP:
    p['uses_classic'] = any(f in p['ds_families'] for f in CLASSIC)
fam_rows = []
for f, ks in sorted(FAM.items(), key=lambda x: (-len(x[1]), x[0]))[:25]:
    U = [BY[k] for k in ks]
    fam_rows.append({'family': f, 'n': len(ks), 'first': min(p['year'] for p in U), 'last': max(p['year'] for p in U),
                     'by_era': {e: sum(1 for p in U if p['era'] == e) for e in ['≤2009', '2010-2015', '2016-2020', '2021-2026']},
                     'keel': sum(1 for p in U if p.get('uses_keel')), 'keys': sorted(ks)})

# ---------------------------------------------------------------- indicators
has_m = lambda p, m: m in p['metrics_n']
THRFREE = ['AUC', 'ROC curve', 'AUPRC', 'MAUC', 'AUCm']
ds_med = float(np.median([p['datasets']['n_real'] for p in EMP if p['datasets']['n_real'] is not None]))
IND = [
    ('data', 'keel', 'Uses KEEL data', 'ใช้ข้อมูลจาก KEEL', lambda p: bool(p.get('uses_keel'))),
    ('data', 'uci', 'Uses UCI data', 'ใช้ข้อมูลจาก UCI', lambda p: bool(p.get('uses_uci'))),
    ('data', 'many_ds', 'At least %d real datasets (median)' % ds_med, 'ใช้ข้อมูลจริงอย่างน้อย %d ชุด (ค่ามัธยฐาน)' % ds_med, lambda p: (p['datasets']['n_real'] or 0) >= ds_med),
    ('data', 'private', 'Some data not public', 'มีข้อมูลที่ไม่เปิดเผย', lambda p: p['r2']['all_public'] is False),
    ('data', 'data_reason', 'States why the data were chosen', 'ระบุเหตุผลที่เลือกข้อมูล', lambda p: p['r2']['data_stated']),
    ('learners', 'multi_clf', 'More than one base learner', 'ใช้ตัวจำแนกมากกว่าหนึ่งตัว', lambda p: (p['n_clf'] or 0) > 1),
    ('learners', 'ens_clf', 'Random forest or boosting learner', 'ใช้ random forest หรือ boosting เป็นตัวจำแนก', lambda p: any(f in p['clf_families'] for f in ['Random Forest', 'Gradient boosting', 'Boosting ensemble'])),
    ('learners', 'learner_reason', 'States why the learners were chosen', 'ระบุเหตุผลที่เลือกตัวจำแนก', lambda p: p['r2']['learner_stated']),
    ('learners', 'nores', 'Includes a no-resampling baseline', 'มีเส้นฐานที่ไม่ปรับสมดุล', lambda p: bool(p.get('no_resampling_baseline'))),
    ('learners', 'smote_base', 'Includes SMOTE as a competitor', 'มี SMOTE เป็นคู่เทียบ', lambda p: bool(p.get('smote_baseline'))),
    ('measures', 'acc', 'Reports accuracy or error rate', 'รายงาน accuracy หรืออัตราความผิดพลาด', lambda p: has_m(p, 'Accuracy/Error')),
    ('measures', 'thrfree', 'Reports a threshold-free measure', 'รายงานตัวชี้วัดที่ไม่ขึ้นกับค่าเกณฑ์', lambda p: any(has_m(p, m) for m in THRFREE)),
    ('measures', 'metric_issue', 'Measure-definition problem', 'มีปัญหาด้านนิยามตัวชี้วัด', lambda p: bool(p.get('metric_issue'))),
    ('measures', 'beyond_direct', 'Measures resampled data directly', 'วัดข้อมูลหลังปรับสมดุลโดยตรง', lambda p: p['beyond_direct']),
    ('protocol', 'repeated', 'Repeated partitions', 'แบ่งข้อมูลซ้ำหลายรอบ', lambda p: p['protocol_class'] in ('Repeated k-fold CV', '5x2 CV', 'Repeated hold-out')),
    ('protocol', 'inside', 'States train-only resampling', 'ระบุว่าปรับสมดุลเฉพาะข้อมูลฝึก', lambda p: p.get('resampling_inside_cv') is True),
    ('protocol', 'evalsel', 'Settings chosen on evaluation data', 'เลือกค่าจากข้อมูลที่ใช้ประเมิน', lambda p: p['tuning_class'] == 'Selected on evaluation data'),
    ('stats', 'anytest', 'Any significance test', 'มีการทดสอบนัยสำคัญ', lambda p: p['test_class'] != 'None'),
    ('stats', 'corr', 'Corrected or Bayesian procedure', 'ใช้วิธีปรับแก้หรือวิธีแบบเบย์', lambda p: p['test_class'] in ('Corrected multiple comparison', 'Bayesian')),
    ('stats', 'method_ref', 'Cites a testing methodology', 'อ้างแหล่งระเบียบวิธีการทดสอบ', lambda p: p['r2']['stats_method_ref']),
    ('reporting', 'std', 'Reports standard deviations', 'รายงานส่วนเบี่ยงเบนมาตรฐาน', lambda p: 'mean +/- std' in p['reporting']),
    ('reporting', 'runtime', 'Reports running time', 'รายงานเวลาประมวลผล', lambda p: bool(p.get('runtime_reported'))),
    ('reporting', 'code', 'Code released', 'เผยแพร่โค้ด', lambda p: bool(p.get('has_code'))),
    ('outcomes', 'outB', 'States where proposal is not better', 'ระบุกรณีที่วิธีที่เสนอไม่ได้ดีกว่า', lambda p: p.get('outcome') == 'B'),
]
TOPIC = {'data': ('Data', 'ข้อมูล'), 'learners': ('Learners and competitors', 'ตัวจำแนกและคู่เทียบ'), 'measures': ('Measures', 'ตัวชี้วัด'),
         'protocol': ('Protocol and tuning', 'โปรโตคอลและการปรับจูน'), 'stats': ('Statistical testing', 'การทดสอบทางสถิติ'),
         'reporting': ('Reporting', 'การรายงานผล'), 'outcomes': ('Outcomes', 'ผลลัพธ์')}

EL = [p for p in EMP if p['cite_eligible']]
y = np.array([math.log1p(p['cites']) for p in EL])
yr = np.array([p['year'] - 2015 for p in EL], dtype=float)
influence = []
for topic, key, en, th, f in IND:
    x = np.array([1.0 if f(p) else 0.0 for p in EL])
    n1 = int(x.sum()); n0 = len(EL) - n1
    row = {'topic': topic, 'key': key, 'en': en, 'th': th, 'n_users': n1, 'n_other': n0, 'n': len(EL)}
    u = [p for p, xi in zip(EL, x) if xi]; o = [p for p, xi in zip(EL, x) if not xi]
    row['med_cpy_users'] = float(np.median([p['cites_per_year'] for p in u])) if u else None
    row['med_cpy_other'] = float(np.median([p['cites_per_year'] for p in o])) if o else None
    row['med_pct_users'] = float(np.median([p['cite_pct_in_era'] for p in u])) if u else None
    row['med_pct_other'] = float(np.median([p['cite_pct_in_era'] for p in o])) if o else None
    if min(n1, n0) >= 4:
        X = np.column_stack([np.ones(len(EL)), yr, x])
        beta, res, rk, sv = np.linalg.lstsq(X, y, rcond=None)
        resid = y - X @ beta; dof = len(EL) - 3
        s2 = resid @ resid / dof; cov = s2 * np.linalg.inv(X.T @ X); se = math.sqrt(cov[2, 2])
        t = stats.t.ppf(0.975, dof)
        row['ratio'] = round(math.exp(beta[2]), 2); row['lo'] = round(math.exp(beta[2] - t * se), 2); row['hi'] = round(math.exp(beta[2] + t * se), 2)
        row['p'] = round(2 * (1 - stats.t.cdf(abs(beta[2] / se), dof)), 3)
    influence.append(row)

# year effect alone (for the method paragraph)
X = np.column_stack([np.ones(len(EL)), yr]); beta = np.linalg.lstsq(X, y, rcond=None)[0]
year_ratio = round(math.exp(-beta[1]), 2)  # multiplicative citations per year older

# ---------------------------------------------------------------- rationale summaries
C = collections.Counter
RS = [BY[k] for k in RAT]
def counts(field):
    return dict(C(x for p in RS for x in p['r2'][field]).most_common())
summ = {
    'n': len(RS),
    'data_stated': sum(p['r2']['data_stated'] for p in RS), 'data_reasons': counts('data_reasons'),
    'learner_stated': sum(p['r2']['learner_stated'] for p in RS), 'learner_reasons': counts('learner_reasons'),
    'measure_stated': sum(p['r2']['measure_stated'] for p in RS), 'measure_reasons': counts('measure_reasons'),
    'all_public_true': sum(p['r2']['all_public'] is True for p in RS), 'all_public_false': sum(p['r2']['all_public'] is False for p in RS),
    'per_ds_source': sum(p['r2']['per_ds_source'] is True for p in RS), 'links': sum(p['r2']['links'] is True for p in RS),
    'modified': sum(p['r2']['mod_released'] is not None for p in RS), 'mod_released': sum(p['r2']['mod_released'] is True for p in RS),
    'beyond_any': sum(bool(p['r2']['beyond_any']) for p in RS), 'beyond_kinds': counts('beyond_kinds'),
    'beyond_direct': sum(p['beyond_direct'] for p in RS), 'beyond_visual': sum(p['beyond_visual'] for p in RS), 'beyond_analytic': sum(p['beyond_analytic'] for p in RS), 'beyond_model': sum(p['beyond_model'] for p in RS), 'beyond_none': sum(p['beyond_none'] for p in RS),
    'stats_cited': counts('stats_cited'), 'stats_method_ref': sum(p['r2']['stats_method_ref'] for p in RS),
}
# model selection: papers that select something
sel = [p for p in RS if not set(p['r2']['ms_selected']) <= {'none (fixed settings)', 'not stated'}]
crit = C()
for p in sel:
    cs = [c for c in p['r2']['ms_criterion'] if c not in ('not applicable',)]
    cs = ['other' if c.startswith('other') else c for c in cs]
    for c in set(cs) or {'not stated'}:
        crit[c] += 1
summ['ms_select_n'] = len(sel); summ['ms_criterion'] = dict(crit.most_common())
summ['ms_data'] = dict(C(p['r2']['ms_data'] if not str(p['r2']['ms_data']).startswith('other') else 'other' for p in sel).most_common())
summ['ms_sens_only'] = [p['key'] for p in RS if p['r2']['ms_sens_only']]
summ['ms_crit_stated'] = sum(1 for p in sel if any(c not in ('not stated', 'not applicable') for c in p['r2']['ms_criterion']))
summ['tuning_explicit'] = sum(1 for p in EMP if p.get('tuning_evidence') == 'explicit')
summ['tuning_implied'] = sum(1 for p in EMP if p.get('tuning_evidence') == 'implied')
summ['tuning_v1_evalsel'] = sum(1 for p in EMP if p['tuning_class_v1'] == 'Selected on evaluation data')
summ['learner_follows'] = sorted({(p['key'], p['r2']['learner_follows']) for p in RS if p['r2']['learner_follows']})

# ---------------------------------------------------------------- roadmap
ERAS = ['≤2009', '2010-2015', '2016-2020', '2021-2026']
RM = [
    ('data', 'UCI repository', lambda p: bool(p.get('uses_uci'))),
    ('data', 'KEEL repository', lambda p: bool(p.get('uses_keel'))),
    ('data', 'Synthetic data', lambda p: (p['datasets']['n_synthetic'] or 0) > 0 or any('synth' in s.lower() for s in p['datasets']['sources'] or [])),
    ('data', 'Private or application data', lambda p: p['r2']['all_public'] is False),
    ('data', 'Image data', lambda p: p['data_type'] in ('image',) or any(s in (p['datasets']['sources'] or []) for s in ['MNIST', 'CIFAR-10', 'CIFAR-100'])),
    ('data', 'Fewer than 10 real datasets', lambda p: p['datasets']['n_real'] is not None and p['datasets']['n_real'] < 10),
    ('data', 'Reason for data stated', lambda p: p['r2']['data_stated']),
    ('learners', 'C4.5/C5.0', lambda p: 'C4.5/C5.0' in p['clf_families']),
    ('learners', 'k-NN', lambda p: 'k-NN' in p['clf_families']),
    ('learners', 'SVM', lambda p: 'SVM' in p['clf_families']),
    ('learners', 'Rule learner (RIPPER etc.)', lambda p: 'Rule learner' in p['clf_families']),
    ('learners', 'Naive Bayes', lambda p: 'Naive Bayes' in p['clf_families']),
    ('learners', 'MLP/NN', lambda p: 'MLP/NN' in p['clf_families'] or 'CNN' in p['clf_families']),
    ('learners', 'Random forest or gradient boosting', lambda p: 'Random Forest' in p['clf_families'] or 'Gradient boosting' in p['clf_families']),
    ('learners', 'Single base learner', lambda p: (p['n_clf'] or 0) == 1),
    ('learners', 'No-resampling baseline', lambda p: bool(p.get('no_resampling_baseline'))),
    ('learners', 'Reason for learners stated', lambda p: p['r2']['learner_stated']),
    ('measures', 'Accuracy or error rate', lambda p: has_m(p, 'Accuracy/Error')),
    ('measures', 'ROC curve only (no AUC value)', lambda p: has_m(p, 'ROC curve') and not has_m(p, 'AUC')),
    ('measures', 'AUC', lambda p: has_m(p, 'AUC')),
    ('measures', 'G-mean', lambda p: has_m(p, 'G-mean')),
    ('measures', 'F1 / F-measure', lambda p: has_m(p, 'F1') or has_m(p, 'F-measure')),
    ('measures', 'Recall / TPR', lambda p: has_m(p, 'Recall/TPR')),
    ('measures', 'MAUC', lambda p: has_m(p, 'MAUC')),
    ('measures', 'MCC', lambda p: has_m(p, 'MCC')),
    ('measures', 'PR-AUC', lambda p: has_m(p, 'AUPRC')),
    ('measures', 'Direct measure of resampled data', lambda p: p['beyond_direct']),
    ('measures', '2-D or projected plots of samples', lambda p: p['beyond_visual']),
    ('protocol', 'Single hold-out', lambda p: p['protocol_class'] == 'Single hold-out'),
    ('protocol', 'Single k-fold CV', lambda p: p['protocol_class'] == 'Single k-fold CV'),
    ('protocol', 'Repeated k-fold CV / 5x2 CV', lambda p: p['protocol_class'] in ('Repeated k-fold CV', '5x2 CV')),
    ('protocol', 'Train-only resampling stated', lambda p: p.get('resampling_inside_cv') is True),
    ('protocol', 'Settings chosen on evaluation data', lambda p: p['tuning_class'] == 'Selected on evaluation data'),
    ('protocol', 'Nested or held-out tuning', lambda p: p['tuning_class'] == 'Nested / held-out tuning'),
    ('stats', 'No significance test', lambda p: p['test_class'] == 'None'),
    ('stats', 't-test', lambda p: any('t-test' in s for s in p.get('stat_tests_n', p.get('tests_n', [])) or [])),
    ('stats', 'Wilcoxon signed-rank', lambda p: 'Wilcoxon signed-rank' in (p.get('tests_n') or [])),
    ('stats', 'Friedman', lambda p: any(s.startswith('Friedman') for s in (p.get('tests_n') or []))),
    ('stats', 'Corrected multiple comparison', lambda p: p['test_class'] == 'Corrected multiple comparison'),
    ('stats', 'Bayesian test', lambda p: p['test_class'] == 'Bayesian'),
    ('stats', 'Cites Demšar (2006)', lambda p: any(re.search('Dem[sš]ar', s) for s in p['r2']['stats_cited'])),
    ('reporting', 'Mean ± standard deviation', lambda p: 'mean +/- std' in p['reporting']),
    ('reporting', 'Average-rank table', lambda p: 'average rank table' in p['reporting']),
    ('reporting', 'Win/tie/loss counts', lambda p: 'win/tie/loss counts' in p['reporting']),
    ('reporting', 'Running time', lambda p: bool(p.get('runtime_reported'))),
    ('reporting', 'Code released', lambda p: bool(p.get('has_code'))),
]
road = []
for topic, label, f in RM:
    U = sorted([p for p in EMP if f(p)], key=lambda p: (p['year'], p['key']))
    row = {'topic': topic, 'label': label, 'n': len(U), 'by_era': {}, 'share': {}}
    for e in ERAS:
        En = [p for p in EMP if p['era'] == e]
        c = sum(1 for p in En if f(p)); row['by_era'][e] = c; row['share'][e] = round(100 * c / len(En)) if En else 0
    if U:
        row['first'] = U[0]['year']; row['first_key'] = U[0]['key']; row['last'] = U[-1]['year']; row['last_key'] = U[-1]['key']
        row['keys'] = [p['key'] for p in U]
    s0 = row['share'][ERAS[0]]; s3 = row['share'][ERAS[-1]]
    if not U:
        tr = 'absent'
    elif row['last'] <= 2015:
        tr = 'abandoned'
    elif row['first'] >= 2016:
        tr = 'new'
    elif s3 - s0 >= 20:
        tr = 'rising'
    elif s0 - s3 >= 20:
        tr = 'declining'
    else:
        tr = 'stable'
    row['trend'] = tr
    road.append(row)
era_n = {e: sum(1 for p in EMP if p['era'] == e) for e in ERAS}

# ---------------------------------------------------------------- reference works
REF_META = {
    'REF-KEEL-2009': ('Alcalá-Fdez et al. 2009', 'alcalafdez2009keel', 2009, 'Alcalá-Fdez, J. and Sánchez, L. and García, S. and others'),
    'REF-KEEL-2011': ('Alcalá-Fdez et al. 2011', 'alcalafdez2011keel', 2011, 'Alcalá-Fdez, J. and Fernández, A. and Luengo, J. and others'),
    'REF-UCI': ('Asuncion and Newman 2007', 'asuncion2007uci', 2007, 'Asuncion, A. and Newman, D.'),
    'REF-Demsar-2006': ('Demšar 2006', 'demsar2006statistical', 2006, 'Demšar, J.'),
    'REF-GarciaHerrera-2008': ('García and Herrera 2008', 'garcia2008extension', 2008, 'García, S. and Herrera, F.'),
    'REF-Garcia-2010': ('García et al. 2010', 'garcia2010advanced', 2010, 'García, S. and Fernández, A. and Luengo, J. and Herrera, F.'),
    'REF-Derrac-2011': ('Derrac et al. 2011', 'derrac2011practical', 2011, 'Derrac, J. and García, S. and Molina, D. and Herrera, F.'),
    'REF-Benavoli-2017': ('Benavoli et al. 2017', 'benavoli2017time', 2017, 'Benavoli, A. and Corani, G. and Demšar, J. and Zaffalon, M.'),
    'REF-imblearn-2017': ('Lemaître et al. 2017', 'lemaitre2017imbalanced', 2017, 'Lemaître, G. and Nogueira, F. and Aridas, C. K.'),
    'REF-HeGarcia-2009': ('He and Garcia 2009', 'he2009learning', 2009, 'He, H. and Garcia, E. A.'),
    'REF-Fernandez-2018': ('Fernández et al. 2018', 'fernandez2018smote', 2018, 'Fernández, A. and García, S. and Herrera, F. and Chawla, N. V.'),
    'REF-HandTill-2001': ('Hand and Till 2001', 'hand2001simple', 2001, 'Hand, D. J. and Till, R. J.'),
    'REF-SaitoRehmsmeier-2015': ('Saito and Rehmsmeier 2015', 'saito2015precision', 2015, 'Saito, T. and Rehmsmeier, M.'),
    'REF-MorenoTorres-2012': ('Moreno-Torres et al. 2012', 'morenotorres2012study', 2012, 'Moreno-Torres, J. G. and Sáez, J. A. and Herrera, F.'),
    'REF-NapieralaStefanowski-2016': ('Napierała and Stefanowski 2016', 'napierala2016types', 2016, 'Napierała, K. and Stefanowski, J.'),
    'REF-HoBasu-2002': ('Ho and Basu 2002', 'ho2002complexity', 2002, 'Ho, T. K. and Basu, M.'),
    'REF-Dietterich-1998': ('Dietterich 1998', 'dietterich1998approximate', 1998, 'Dietterich, T. G.'),
    'REF-Cawley-2010': ('Cawley and Talbot 2010', 'cawley2010overfitting', 2010, 'Cawley, G. C. and Talbot, N. L. C.'),
    'REF-Lopez-2013': ('López et al. 2013', 'lopez2013insight', 2013, 'López, V. and Fernández, A. and García, S. and Palade, V. and Herrera, F.'),
}
INPUT_REFS = {r['key']: r for r in json.load(open(R + 'v2/cites/input_refs.json'))}
refrows = []
for k, c in refs.items():
    refrows.append({'key': k, 'title': c.get('matched_title'), 'authors': c.get('authors'), 'year': c.get('oa_year'),
                    'cites': c.get('cited_by_count'), 'doi': (c.get('doi') or '').replace('https://doi.org/', '') or None,
                    'openalex_id': c.get('openalex_id'), 'match': c.get('match'),
                    'alt_total': sum((a.get('cited_by_count') or 0) for a in (c.get('alt_versions') or [])),
                    'label': REF_META[k][0], 'bibkey': REF_META[k][1], 'pub_year': REF_META[k][2], 'bib_authors': REF_META[k][3],
                    'venue': INPUT_REFS[k]['venue'], 'title_in': INPUT_REFS[k]['title']})

json.dump(data, open(R + 'data.json', 'w'), ensure_ascii=False, indent=1)
json.dump({'retrieved': RETRIEVED, 'eligible_n': len(EL), 'year_ratio': year_ratio, 'influence': influence, 'topics': TOPIC,
           'summary': summ, 'roadmap': road, 'era_n': era_n, 'families': fam_rows, 'classic': CLASSIC,
           'refs': refrows}, open(R + 'v2/analysis.json', 'w'), ensure_ascii=False, indent=1)
print('eligible', len(EL), 'year ratio per year older', year_ratio)
for r in influence:
    print('%-9s %-42s n=%2d/%2d ratio=%s [%s,%s] p=%s medcpy %s vs %s' % (r['topic'], r['en'][:42], r['n_users'], r['n_other'], r.get('ratio'), r.get('lo'), r.get('hi'), r.get('p'), r['med_cpy_users'], r['med_cpy_other']))
