"""Standalone bilingual Section 7 page: wraps the artifact body (smote25_evaluation.html, written by
build.py) in a full HTML document and inlines KaTeX so equations render offline."""
import sys
R = '/home/claude/smote25/'
KATEX = '/tmp/claude-0/-home-claude/6e503650-68ce-58b4-a44b-b2d11f74f9f4/scratchpad/katex/node_modules/katex/dist/katex.min.js'
OUT = sys.argv[1] if len(sys.argv) > 1 else R + 'section07-empirical-comparisons-bilingual.html'
body = open(R + 'smote25_evaluation.html').read()
katex = open(KATEX).read()
assert '</script' not in katex
tag = '<script src="https://cdnjs.cloudflare.com/ajax/libs/KaTeX/0.16.9/katex.min.js"></script>'
assert body.count(tag) == 1
body = body.replace(tag, '<script>/* KaTeX 0.16.9, MIT License, https://katex.org */\n' + katex + '\n</script>')
i = body.index('</style>\n') + len('</style>\n')
doc = ('<!doctype html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1">\n'
       + body[:i] + '</head>\n<body>\n' + body[i:] + '\n</body>\n</html>\n')
open(OUT, 'w').write(doc)
print(OUT, len(doc.encode()))
