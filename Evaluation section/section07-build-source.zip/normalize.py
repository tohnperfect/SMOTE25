"""Merge batch extractions into one canonical dataset (data.json) with normalized fields.
All manual codings below were made from the extracted text (fields eval_weaknesses, tuning,
metric_details, flags) and are marked as 'coded' in the HTML so co-authors can verify them."""
import json, glob, re, collections

papers = []
for f in sorted(glob.glob('extract/batch_*.json')):
    papers += json.load(open(f))


# ---------- corrections from verification pass (2 fact-check agents, 16 claims) ----------
for p in papers:
    if p['key'] == 'CISO-2026':
        p['key'] = 'CISO-2025'; p['year'] = 2025
        p['venue'] = 'arXiv 2501.15790 (v2, Aug 2026)'
        p['title'] = 'Certified Interpolation Oversampling: Per-Instance Safety Guarantees for Imbalanced Learning'
        p['authors'] = 'Yadav, Vijay'
    if p['key'] == 'QC-SMOTE-2026':
        p['venue'] = 'arXiv 2606.24625 (Jun 2026)'
        p['title'] = 'QC-SMOTE: Quality-Controlled SMOTE for Imbalanced Classification'
    if p['key'] == 'SMOTE-2002':
        p['flags'] = ((p['flags'] or '') + ' Verified: SMOTE itself was run with C4.5 and Ripper; Naive Bayes appears only as a cost-sensitive comparator (varied priors).').strip()

# ---------- metric normalization ----------
MET = {
    'Recall (TPR/Sensitivity)': 'Recall/TPR', 'Specificity (TNR)': 'Specificity/TNR',
    'F-measure (beta)': 'F-measure', 'F1': 'F1', 'MAUC (Hand-Till)': 'MAUC', 'MAUC': 'MAUC',
    'AUCm': 'AUCm', 'AUCm (minority-class pairwise AUC)': 'AUCm',
    'AvAcc (average class accuracy)': 'AvAcc', 'ROC curve': 'ROC curve', 'ROC convex hull': 'ROC curve',
    'AUPRC / Average precision': 'AUPRC', 'CBA (class balance accuracy)': 'CBA',
    'Class balance accuracy (CBA)': 'CBA', 'CBA (class balanced accuracy)': 'CBA',
    'CEN (confusion entropy)': 'CEN', 'Confusion entropy (CEN)': 'CEN',
    'Pmin': 'Pmin', 'Pavg': 'Macro-precision', 'Pavg (average per-class precision)': 'Macro-precision',
    'Macro-precision (Pavg)': 'Macro-precision', 'macro-Precision': 'Macro-precision',
    'macro-Recall': 'Macro-recall', 'macro-G-mean': 'G-mean', 'Average minority-class recall': 'Per-class recall',
    'Minimum sensitivity (MS)': 'Min-sensitivity', 'G-score (sqrt(Precision*Recall))': 'G-score (P,R)',
    'Fidelity / distribution metrics (e.g., FID, likelihood)': 'Fidelity/likelihood',
    'Cost / Misclassification cost': 'Cost', 'Error rate': 'Accuracy/Error', 'Accuracy': 'Accuracy/Error',
    'Balanced accuracy': 'Balanced accuracy', 'Macro-F1': 'Macro-F1', 'Weighted-F1': 'Weighted-F1',
}
OTHER_MET = {'Tree size', 'Model complexity (rules, conditions per rule)', 'K-S statistic', 'R2 (regression)',
             'Precision at top 20% (P20)', 'Memory usage', 'Certified fraction', 'Sampler failure rate'}
FAMILY = {
    'Accuracy/Error': 'Overall', 'Precision': 'Single-class', 'Recall/TPR': 'Single-class',
    'Specificity/TNR': 'Single-class', 'FPR': 'Single-class',
    'F1': 'Composite', 'F-measure': 'Composite', 'G-mean': 'Composite', 'G-score (P,R)': 'Composite',
    'Balanced accuracy': 'Composite', 'MCC': 'Composite', 'Kappa': 'Composite',
    'AUC': 'Ranking', 'ROC curve': 'Ranking', 'AUPRC': 'Ranking', 'MAUC': 'Ranking', 'AUCm': 'Ranking',
    'Macro-F1': 'Multi-class avg', 'Weighted-F1': 'Multi-class avg', 'AvAcc': 'Multi-class avg',
    'Macro-precision': 'Multi-class avg', 'Macro-recall': 'Multi-class avg', 'Min-sensitivity': 'Multi-class avg',
    'Pmin': 'Multi-class avg', 'Per-class recall': 'Multi-class avg', 'CBA': 'Multi-class avg', 'CEN': 'Multi-class avg',
    'Runtime': 'Other', 'Confusion matrix': 'Other', 'Cost': 'Other', 'Fidelity/likelihood': 'Other', 'Other': 'Other',
}

def norm_metrics(lst):
    out = []
    for m in lst or []:
        if m in OTHER_MET: n = 'Other'
        else: n = MET.get(m, m)
        if n not in out: out.append(n)
    return out

# ---------- stat tests ----------
ST = {'t-test': 't-test', 'Paired t-test': 't-test', 'Two-sample t-test': 't-test', "Student's t-test": 't-test',
      'Combined 10-fold CV F-test': 'CV F-test', '5x2cv F-test (Alpaydin)': 'CV F-test',
      'Hsu MCB (multiple comparison with the best)': 'Hsu MCB', 'Critical difference diagram': None,
      'Spearman correlation': None}
OMNI = {'Friedman', 'Iman-Davenport', 'Friedman aligned ranks', 'ANOVA', 'Kruskal-Wallis', 'Quade'}
POST = {'Holm', 'Hochberg', 'Shaffer', 'Nemenyi', 'Bonferroni-Dunn', 'Finner', 'Li', 'Tukey HSD', 'Hsu MCB'}

def norm_tests(lst):
    out = []
    for t in lst or []:
        n = ST.get(t, t)
        if n and n not in out: out.append(n)
    return out

def test_class(ts):
    s = set(ts)
    if not s: return 'None'
    if 'Bayesian test' in s: return 'Bayesian'
    if s & POST: return 'Corrected multiple comparison'
    if s & OMNI: return 'Omnibus, no corrected post-hoc'
    return 'Pairwise only (uncorrected)'

# ---------- classifiers ----------
def clf_family(c):
    l = c.lower()
    if 'weaklearn' in l or 'shrink' in l: return None
    if 'resnet' in l or 'lenet' in l or 'all-cnn' in l or 'classifier network' in l: return 'CNN'
    if 'dovo' in l or 'kde' in l: return 'Other'
    if 'adaboost' in l or 'bagging' in l: return 'Boosting ensemble'
    if 'random forest' in l or 'randomtree' in l: return 'Random Forest'
    if 'ripper' in l or 'part (' in l or 'modlem' in l: return 'Rule learner'
    if 'c4.5' in l or 'j48' in l or 'j4.8' in l or 'c5.0' in l or 'c4.4' in l: return 'C4.5/C5.0'
    if 'random forest' in l or 'randomtree' in l: return 'Random Forest'
    if 'cart' in l or 'decision tree' in l: return 'CART/DT'
    if 'xgboost' in l or 'gradient' in l or 'gbdt' in l or 'gbm' in l or 'catboost' in l or 'lightgbm' in l: return 'Gradient boosting'
    if 'adaboost' in l or 'bagging' in l or 'ensemble' in l or 'pets' in l: return 'Boosting ensemble'
    if 'svm' in l or 'smo' in l: return 'SVM'
    if 'nn' in l and ('k' in l or '1-nn' in l or 'ibk' in l) and 'rbfnn' not in l and 'bpnn' not in l: return 'k-NN'
    if 'knn' in l or 'k-nn' in l or 'ibk' in l or '1-nn' in l: return 'k-NN'
    if 'naive' in l or 'bayes' in l and 'logistic' not in l: return 'Naive Bayes'
    if 'logistic' in l: return 'Logistic Regression'
    if 'mlp' in l or 'neural' in l or 'bpnn' in l or 'rbfnn' in l or 'bp ' in l or 'backprop' in l: return 'MLP/NN'
    if 'lda' in l: return 'LDA'
    if 'linear regression' in l: return None
    return 'Other'

# ---------- manual codings ----------
PROTO = {  # key: (class, k)
 'ENN-1972': ('N/A (theory)', None), 'TomekLinks-1976': ('N/A (theory)', None), 'AdaBoost-1997': ('N/A (theory)', None),
 'PradiptaReview-2021': ('N/A (no experiments)', None), 'StopOversampling-2022': ('Other (classifier-free)', None),
 'OSS-1997': ('Single k-fold CV', 'other'), 'SHRINK-1998': ('Repeated k-fold CV', 10), 'SMOTE-2002': ('Single k-fold CV', 10),
 'SMOTEBoost-2003': ('Single k-fold CV', 10), 'SMOTE-ENN-Tomek-2004': ('Single k-fold CV', 10),
 'Borderline-SMOTE-2005': ('Repeated k-fold CV', 10), 'Cluster-SMOTE-2006': ('Single hold-out', None),
 'Global-CS-2006': ('Repeated k-fold CV', 10), 'Global-CS-2010': ('Repeated k-fold CV', 10),
 'COG-OS-2007': ('Single hold-out', None), 'LS-2008': ('5x2 CV', 2), 'ADASYN-2008': ('Repeated hold-out', None),
 'Safe-Level-SMOTE-2009': ('Single k-fold CV', 10), 'SBC-2009': ('Single hold-out', None),
 'EasyEnsemble-BalanceCascade-2009': ('Repeated k-fold CV', 10), 'RAMOBoost-2010': ('Repeated hold-out', None),
 'SPIDER2-2010': ('Repeated k-fold CV', 10), 'RUSBoost-2010': ('Repeated k-fold CV', 10), 'DSRBF-2011': ('Repeated k-fold CV', 10),
 'INOS-2013': ('Repeated hold-out', None), 'OVO-SMOTE-2013': ('Single k-fold CV', 10), 'MWMOTE-2014': ('Single k-fold CV', 10),
 'RACOG-2015': ('Single k-fold CV', 5), 'SMOTE-IPF-2015': ('Repeated k-fold CV', 5), 'RBBoost-2015': ('5x2 CV', 2),
 'SplitBal-2015': ('Repeated k-fold CV', 10), 'SCUT-2015': ('Single k-fold CV', 10), 'A-SUWO-2016': ('Repeated k-fold CV', 'other'),
 'CGMOS-2016': ('Repeated k-fold CV', 10), 'MDO-2016': ('Repeated k-fold CV', 5), 'SMOM-2017': ('Repeated k-fold CV', 10),
 'OBU-2018': ('Single hold-out', None), 'KMeansSMOTE-2018': ('Repeated k-fold CV', 5), 'ROS-Buda-2018': ('Fixed benchmark split', None),
 'AMDO-2018': ('Repeated k-fold CV', 5), 'G-SMOTE-2019': ('Repeated k-fold CV', 5), 'RBO-2019': ('5x2 CV', 2),
 'CTGAN-2019': ('Fixed benchmark split', None), 'GAMO-2019': ('Fixed benchmark split', None), 'SOUP-2019': ('Single k-fold CV', 10),
 'NBU-2020': ('Single hold-out', None), 'AB-SMOTE-2020': ('Single k-fold CV', 5), 'MBS-2020': ('Repeated hold-out', None),
 'DLexiBoost-2020': ('Not stated', None), 'SPE-2020': ('Single hold-out', None), 'MC-RBO-2020': ('Repeated k-fold CV', 10),
 'MC-CCR-2020': ('Repeated k-fold CV', 10), 'HDE-2021': ('Repeated k-fold CV', 5), 'RSMOTE-2021': ('Repeated hold-out', None),
 'EMDO-2021': ('Repeated k-fold CV', 5), 'KNNOR-2022': ('Repeated k-fold CV', 5), 'FW-SMOTE-2022': ('Single k-fold CV', 10),
 'GDO-2022': ('Single k-fold CV', 10), 'SOS-2022': ('Single hold-out', None), 'SVDDWSMOTE-2022': ('Repeated k-fold CV', 5),
 'SHSampler-2022': ('Single k-fold CV', 5), 'CBHSID-2022': ('Repeated hold-out', None), 'NROMM-2023': ('5x2 CV', 2),
 'GLOS-2023': ('Repeated k-fold CV', 5), 'OREM-2023': ('Repeated k-fold CV', 5), 'MKC-SMOTE-2024': ('Single k-fold CV', 5),
 'MC-MBRC-2024': ('Repeated k-fold CV', 2), 'GMMSampling-2024': ('Repeated k-fold CV', 5), 'MLOS-2025': ('Repeated k-fold CV', 5),
 'GOIO-2025': ('Repeated k-fold CV', 5), 'GDHS-2025': ('Repeated k-fold CV', 5), 'MC-NCLWO-2025': ('Repeated k-fold CV', 'other'),
 'DGOT-2026': ('Repeated k-fold CV', 5), 'Loyalty-SMOTE-2026': ('Single hold-out', None), 'CISO-2025': ('Single k-fold CV', 'other'),
 'QC-SMOTE-2026': ('Repeated k-fold CV', 'other'),
}
NOTE_PROTO = {'NROMM-2023': 'described inconsistently (5x2 CV vs stratified 10-fold)',
              'MC-NCLWO-2025': 'text gives both 10-fold and 5-fold', 'CISO-2025': 'fold count not stated',
              'QC-SMOTE-2026': 'fold and repeat counts not stated', 'Cluster-SMOTE-2006': 'one dataset hold-out, the other 10-fold CV',
              'OBU-2018': '80:20 split and 10-fold CV both mentioned', 'SPE-2020': '60/20/20 train/validation/test split, 10 runs (whether the split is redrawn is not stated)'}

# Hyperparameter selection, coded from the 'tuning' and 'eval_weaknesses' text
TUNE = {}
for k in ['LS-2008', 'A-SUWO-2016', 'MC-RBO-2020', 'MC-CCR-2020', 'RBO-2019', 'CISO-2025', 'GMMSampling-2024', 'OREM-2023', 'SVDDWSMOTE-2022']:
    TUNE[k] = 'Nested / held-out tuning'
for k in ['SMOTE-2002', 'SMOTEBoost-2003', 'Cluster-SMOTE-2006', 'MWMOTE-2014', 'RACOG-2015', 'SMOTE-IPF-2015', 'MDO-2016', 'SMOM-2017',
          'OBU-2018', 'KMeansSMOTE-2018', 'ROS-Buda-2018', 'G-SMOTE-2019', 'SOUP-2019', 'AB-SMOTE-2020', 'DLexiBoost-2020', 'HDE-2021',
          'RSMOTE-2021', 'KNNOR-2022', 'FW-SMOTE-2022', 'SOS-2022', 'NROMM-2023', 'GLOS-2023', 'MC-MBRC-2024', 'GDHS-2025',
          'MC-NCLWO-2025', 'MLOS-2025', 'QC-SMOTE-2026', 'INOS-2013', 'SHRINK-1998']:
    TUNE[k] = 'Selected on evaluation data'
for k in ['OSS-1997', 'SMOTE-ENN-Tomek-2004', 'ADASYN-2008', 'EasyEnsemble-BalanceCascade-2009', 'RUSBoost-2010', 'Global-CS-2006',
          'Global-CS-2010', 'COG-OS-2007', 'SBC-2009', 'OVO-SMOTE-2013', 'SPIDER2-2010', 'NBU-2020', 'MBS-2020', 'SPE-2020',
          'SHSampler-2022', 'CBHSID-2022', 'MKC-SMOTE-2024', 'AMDO-2018', 'DGOT-2026', 'GOIO-2025', 'Loyalty-SMOTE-2026',
          'SplitBal-2015', 'SCUT-2015', 'Borderline-SMOTE-2005', 'Safe-Level-SMOTE-2009']:
    TUNE[k] = 'Fixed / default settings'
for k in ['RAMOBoost-2010', 'DSRBF-2011', 'GAMO-2019', 'CGMOS-2016', 'RBBoost-2015', 'EMDO-2021', 'GDO-2022', 'CTGAN-2019']:
    TUNE[k] = 'Unclear'

NO_RES_TRUE = set('''OSS-1997 SHRINK-1998 SMOTEBoost-2003 SMOTE-ENN-Tomek-2004 Borderline-SMOTE-2005 COG-OS-2007 LS-2008 ADASYN-2008
Safe-Level-SMOTE-2009 SBC-2009 EasyEnsemble-BalanceCascade-2009 SPIDER2-2010 RUSBoost-2010 Global-CS-2006 Global-CS-2010 DSRBF-2011
INOS-2013 OVO-SMOTE-2013 RACOG-2015 SMOTE-IPF-2015 RBBoost-2015 SplitBal-2015 SCUT-2015 CGMOS-2016 SMOM-2017 OBU-2018 KMeansSMOTE-2018
ROS-Buda-2018 AMDO-2018 G-SMOTE-2019 RBO-2019 CTGAN-2019 GAMO-2019 SOUP-2019 NBU-2020 AB-SMOTE-2020 MBS-2020 DLexiBoost-2020 SPE-2020
RSMOTE-2021 EMDO-2021 KNNOR-2022 SOS-2022 GLOS-2023 OREM-2023 MKC-SMOTE-2024 MLOS-2025 GOIO-2025 GDHS-2025 MC-NCLWO-2025 DGOT-2026 CISO-2025'''.split())

METRIC_ISSUE = {
 'GDO-2022': "'AUC' defined as (Sens+Spec)/2, i.e. single-threshold balanced accuracy",
 'DLexiBoost-2020': "'AUC' computed from crisp predictions as (1+TPR-FPR)/2 (= balanced accuracy)",
 'SPE-2020': 'G-mean defined as sqrt(Recall x Precision) instead of sqrt(TPR x TNR)',
 'CGMOS-2016': "'G-score' = sqrt(Precision x Recall), reported for both classes as positive",
 'SHSampler-2022': 'MAUC computed from hard-label confusion matrices, not scores',
 'GDHS-2025': 'MAUC computed from hard-label confusion matrices, not scores',
 'MC-MBRC-2024': 'AvAcc defined as mean one-vs-rest accuracy (inflated by true negatives)',
 'MC-NCLWO-2025': 'AvAcc defined as mean one-vs-rest accuracy (inflated by true negatives)',
 'EMDO-2021': "per-class precision called 'accuracy' (Pmin/Pavg)",
 'AMDO-2018': 'Pavg described as precision but equated with average accuracy',
 'SCUT-2015': 'multi-class averaging of G-mean, F-measure and AUC not defined',
 'CBHSID-2022': 'multi-class averaging of Recall/F1 not stated; F1 misdefined',
 'Loyalty-SMOTE-2026': 'implausible AUC values (e.g. 0) and averages inconsistent with tables',
 'SOS-2022': 'weighted-F1 (majority-dominated) as the sole main metric',
}
INTEGRITY = {
 'AB-SMOTE-2020': ['possible leakage (inferred, verified): SMOTE 100% generates as many samples as the full minority class, implying oversampling before the 5-fold CV split'],
 'MC-NCLWO-2025': ['leakage: normalization appears applied before splitting', 'inconsistent fold count and post-hoc test name'],
 'HDE-2021': ['baseline numbers copied from original papers (group 2)'],
 'NROMM-2023': ['baseline results described as copied in main text but re-run in supplement', 'protocol described inconsistently'],
 'QC-SMOTE-2026': ['all baseline scores copied from another paper; only the proposal was run'],
 'COG-OS-2007': ['PNrule numbers copied from another paper'],
 'SplitBal-2015': ['fuzzy-rule baseline results apparently taken from another study'],
 'SMOTE-2002': ['OSS and SHRINK results quoted from Kubat et al.'],
 'SMOTEBoost-2003': ['Table 3 shows AdaCost above SMOTEBoost on KDD U2R, contradicting the text'],
 'SMOTE-ENN-Tomek-2004': ['text says 13 datasets, tables use 15'],
 'Loyalty-SMOTE-2026': ['reported multiclass averages do not match own tables'],
 'KNNOR-2022': ['Table 6 column labels appear swapped'],
 'SOUP-2019': ['Nemenyi diagram shown after a non-significant Friedman test'],
 'MC-MBRC-2024': ['Nemenyi used without a stated Friedman omnibus test'],
 'GDHS-2025': ['6 of 20 multi-class datasets are binary; competitor failures left missing in ranks'],
}

ERA = lambda y: ('≤2009' if y < 2010 else ('2010-2015' if y < 2016 else ('2016-2020' if y < 2021 else '2021-2026')))

for p in papers:
    k = p['key']
    p['metrics_n'] = norm_metrics(p['metrics'])
    p['metric_families'] = sorted({FAMILY.get(m, 'Other') for m in p['metrics_n']})
    p['tests_n'] = norm_tests(p['stat_tests'])
    p['test_class'] = test_class(p['tests_n'])
    fams = []
    for c in p['classifiers'] or []:
        f = clf_family(c)
        if f and f not in fams: fams.append(f)
    p['clf_families'] = fams
    p['n_clf'] = len(fams)
    pc, kk = PROTO[k]
    p['protocol_class'] = pc
    p['cv_k'] = kk
    p['protocol_note'] = NOTE_PROTO.get(k)
    p['tuning_class'] = TUNE.get(k, 'N/A')
    p['no_resampling_baseline'] = k in NO_RES_TRUE
    p['smote_baseline'] = any(b.strip().lower().startswith('smote') and len(b) < 40 and not b.lower().startswith('smoteb')
                              for b in (p['baselines'] or [])) or any(b in ('SMOTE', 'SMOTE-all (round-robin)') for b in (p['baselines'] or []))
    p['metric_issue'] = METRIC_ISSUE.get(k)
    p['integrity'] = INTEGRITY.get(k, [])
    p['era'] = ERA(p['year'])
    d = p['datasets']
    p['n_datasets'] = (d.get('n_real') or 0) + (d.get('n_synthetic') or 0) if (d.get('n_real') is not None or d.get('n_synthetic') is not None) else None
    srcs = ' '.join(d.get('sources') or []).lower()
    p['uses_keel'] = 'keel' in srcs
    p['uses_uci'] = 'uci' in srcs
    p['has_code'] = bool(p['code_available']) and p['code_available'] not in (False,)
    # empirical = has an imbalanced-data evaluation with classifiers
    p['empirical'] = p['paper_type'] in ('method', 'empirical-study') or k == 'SHRINK-1998'


# Outcome of each study's own comparison, coded from key_result and eval_weaknesses.
# A = proposal reported best with no stated exception; B = best, but the paper states a measure,
# learner, competitor or data condition where it is not better or not significantly better;
# C = no advantage over simple baselines; D = comparative study without a proposal.
OUT_A = set("""SMOTE-2002 SMOTEBoost-2003 LS-2008 SBC-2009 SMOTE-IPF-2015 KMeansSMOTE-2018 G-SMOTE-2019 AB-SMOTE-2020 MBS-2020
SPE-2020 CTGAN-2019 GAMO-2019 HDE-2021 KNNOR-2022 GDO-2022 SOS-2022 MLOS-2025 DGOT-2026 Loyalty-SMOTE-2026 SVDDWSMOTE-2022
QC-SMOTE-2026 CGMOS-2016 Global-CS-2006 MC-CCR-2020 EMDO-2021 MKC-SMOTE-2024 GDHS-2025""".split())
OUT_C = {'CISO-2025'}
OUT_D = {'ROS-Buda-2018', 'OVO-SMOTE-2013'}
for p in papers:
    if not p['empirical']:
        p['outcome'] = None
    elif p['key'] in OUT_D: p['outcome'] = 'D'
    elif p['key'] in OUT_C: p['outcome'] = 'C'
    elif p['key'] in OUT_A: p['outcome'] = 'A'
    else: p['outcome'] = 'B'

SHORT_OVR = {'PradiptaReview':'Pradipta et al.','StopOversampling':'Hassanat et al.','TomekLinks':'Tomek links','ENN':'Wilson ENN',
 'SMOTE-ENN-Tomek':'Batista et al.','KMeansSMOTE':'k-means SMOTE','ROS-Buda':'Buda et al.','SVDDWSMOTE':'SVDD-WSMOTE',
 'EasyEnsemble-BalanceCascade':'EasyEnsemble','RBBoost':'Random Balance','OVO-SMOTE':'Fernandez et al.','SBC':'SBC','OSS':'OSS',
 'Global-CS':'Global-CS'}
for p in papers:
    base = re.sub(r'-\d{4}$', '', p['key'])
    p['short'] = SHORT_OVR.get(base, base)

import unicodedata
STOP = {'a','an','the','on','of','for','to','in','and','using','with','by','new','novel','two','towards'}
def ascii_lower(t):
    return ''.join(c for c in unicodedata.normalize('NFKD', t) if not unicodedata.combining(c)).lower()
for p in papers:
    first = re.sub(r'\s+et al\.?', '', (p['authors'] or 'anon').split(',')[0]).strip()
    sur = re.sub(r'[^a-z]', '', ascii_lower(first))
    sh = p['short']
    if sh.endswith('et al.') or sh in ('Tomek links', 'Wilson ENN'):
        words = [w for w in re.findall(r'[a-z0-9]+', ascii_lower(p['title'] or '')) if w not in STOP]
        word = words[0] if words else 'paper'
    else:
        base = re.sub(r'[-\s]?SMOTE$', '', sh)
        word = re.sub(r'[^a-z0-9]', '', ascii_lower(base))
        if len(word) < 3:
            word = re.sub(r'[^a-z0-9]', '', ascii_lower(sh))
    p['bibkey'] = f"{sur}{p['year']}{word}"
keys = [p['bibkey'] for p in papers]
assert len(keys) == len(set(keys)), [k for k in keys if keys.count(k) > 1]

json.dump(papers, open('data.json', 'w'), indent=1, ensure_ascii=False)
emp = [p for p in papers if p['empirical']]
print('total', len(papers), 'empirical', len(emp))
for fld in ['protocol_class', 'tuning_class', 'test_class', 'era', 'setting']:
    print(fld, collections.Counter(p[fld] for p in emp).most_common())
print('clf fam', collections.Counter(f for p in emp for f in p['clf_families']).most_common())
print('metrics', collections.Counter(m for p in emp for m in p['metrics_n']).most_common())
print('no-res', sum(p['no_resampling_baseline'] for p in emp), 'smote', sum(p['smote_baseline'] for p in emp))
print('inside', collections.Counter(p['resampling_inside_cv'] for p in emp))
print('code', sum(p['has_code'] for p in emp), 'runtime', sum(bool(p['runtime_reported']) for p in emp))
print('keel', sum(p['uses_keel'] for p in emp), 'uci', sum(p['uses_uci'] for p in emp))
print('missing tune', [p['key'] for p in emp if p['tuning_class'] == 'N/A'])
