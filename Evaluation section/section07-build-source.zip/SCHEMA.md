# Extraction schema for SMOTE25 evaluation analysis

Write ONE JSON array per batch to `/home/claude/smote25/extract/batch_XX.json`.
Each element is one paper object with exactly these keys. Use English. Use `null`
when the paper does not say; never guess. Keep strings short and factual.

```json
{
  "key": "SMOTE-2002",                 // MethodName-Year, unique
  "method": "SMOTE",                   // short method name the paper proposes (or study name)
  "title": "full paper title",
  "authors": "Chawla, Bowyer, Hall, Kegelmeyer",   // surnames, "et al." if >4
  "year": 2002,
  "venue": "JAIR",                     // journal/conference short name
  "folder": "Binary",                  // Drive folder: Survey | Binary | Multiclass | Both
  "drive_id": "...",                   // main PDF file id
  "supp_ids": [],                      // supplementary PDF ids if any
  "paper_type": "method",              // method | empirical-study | survey | foundational
  "setting": "binary",                 // binary | multiclass | both  (what the EXPERIMENTS cover)
  "approach": "oversampling",          // oversampling | undersampling | hybrid | ensemble | cost-sensitive | generative | cleaning | classifier | other
  "data_type": "tabular",              // tabular | image | time-series | text | mixed
  "datasets": {
    "n_real": 9,                       // number of real datasets used (int or null)
    "n_synthetic": 0,                  // number of synthetic/artificial datasets (int or null)
    "sources": ["UCI"],                // KEEL, UCI, OpenML, imbalanced-learn, MNIST, CIFAR-10, private, ...
    "ir_range": "1.8-58",              // imbalance ratio range as reported, or null
    "n_classes_range": "2",            // e.g. "2" or "3-10"
    "notes": "short note (e.g. multiclass sets binarized one-vs-rest)"
  },
  "classifiers": ["C4.5", "Ripper", "Naive Bayes"],   // base learners used to evaluate resampling
  "baselines": ["Random undersampling", "Ripper loss ratio"],  // competing methods
  "n_baselines": 2,
  "metrics": ["AUC", "ROC curve"],     // use the normalized vocabulary below where possible
  "metric_details": "AUC from ROC convex hull; ...",  // how computed, multiclass averaging, threshold, etc.
  "primary_metric": "AUC",             // the metric used for main claims, or null
  "protocol": "10-fold CV",            // validation scheme exactly as stated (k-fold, repeats, stratified, DOB-SCV, hold-out split %, train/test given)
  "n_runs": "10x",                     // repeats/seeds if stated, else null
  "resampling_inside_cv": true,        // true if resampling applied only to training folds; false if before split; null if not stated
  "tuning": "k=5 fixed; ...",          // how hyperparameters of the method/baselines/classifiers were set
  "stat_tests": ["Friedman", "Holm"],  // normalized vocabulary below; [] if none
  "stat_test_details": "alpha=0.05, Holm post-hoc vs control",
  "reporting": ["per-dataset table", "ROC plot"],   // normalized vocabulary below
  "reporting_details": "Table 3: AUC per dataset ...; Fig 5 ROC ...",
  "runtime_reported": false,
  "code_available": null,              // URL string, true, false or null
  "key_result": "one sentence: what the paper claims based on its evaluation",
  "eval_strengths": "one sentence",
  "eval_weaknesses": "one sentence (e.g., single classifier, accuracy only, no stat test, few datasets, leakage risk)",
  "where": "Sec. 5, Tables 2-4, Fig. 6",   // where in the paper the evaluation is
  "flags": "anything uncertain or unreadable"
}
```

## Normalized vocabularies (use these exact strings when they apply; add others verbatim if needed)

**metrics**: Accuracy, Error rate, Precision, Recall (TPR/Sensitivity), Specificity (TNR),
FPR, F1, F-measure (beta), G-mean, AUC, ROC curve, PR curve, AUPRC / Average precision,
MCC, Kappa, Balanced accuracy, Macro-F1, Micro-F1, Weighted-F1, MAUC (Hand-Till),
AvAcc (average class accuracy), Per-class recall, Confusion matrix, Cost / Misclassification cost,
IBA, Brier score, Log-loss, Lift / Gain, Fidelity / distribution metrics (e.g., FID, likelihood),
Privacy metric, Runtime.

**stat_tests**: Friedman, Iman-Davenport, Nemenyi, Bonferroni-Dunn, Holm, Hochberg, Shaffer,
Finner, Li, Wilcoxon signed-rank, Paired t-test, Sign test, Quade, Friedman aligned ranks,
Bayesian test, Mann-Whitney, ANOVA, Critical difference diagram.

**reporting**: per-dataset table, mean +/- std, average rank table, win/tie/loss counts,
best-in-bold, ROC plot, PR plot, CD diagram, box plot, bar chart, line plot vs IR/parameter,
heatmap, scatter/2D visualization of synthetic samples, convergence plot, confusion matrix table,
runtime table, ablation study, parameter sensitivity, case study / real application,
supplementary tables, p-value table.
