"""English-only standalone build of the Section 7 draft.

Reads the same sources as build.py, removes every Thai string and the language
toggle, inlines KaTeX so equations render offline, and writes a complete HTML
document (doctype, head, body) for the repository.
"""
import json, re, sys

root = '/home/claude/smote25/'
KATEX = '/tmp/claude-0/-home-claude/6e503650-68ce-58b4-a44b-b2d11f74f9f4/scratchpad/katex/node_modules/katex/dist/katex.min.js'
OUT = sys.argv[1] if len(sys.argv) > 1 else root + 'section07-empirical-comparisons-draft.html'
TH = re.compile('[฀-๿]')
LIT = re.compile(r"'(?:[^'\\\n]|\\.)*'")


def blank_thai_literals(src):
    return LIT.sub(lambda m: "''" if TH.search(m.group(0)) else m.group(0), src)


def drop_th_markup(src):
    # '<div class="tth">' + esc(r.th.fam) + '</div>'  and similar parallel-text wrappers
    mid = r"(?:[^'+]|'th'|'en')*?"
    src = re.sub(r"<(p|span|div) class=\"t?th\"(?: style=\"[^\"]*\")?>' \+ " + mid + r" \+ '</\1>", '', src)
    return src


# ---- content.js: every Thai value lives under a th / thdesc / thr / thuse key
content = open(root + 'src/content.js').read()
content = blank_thai_literals(content)

# ---- app.js
app = open(root + 'src/app.js').read()
app = re.sub(r" · [฀-๿][^<']*", '', app)                      # "Heading · Thai" in panel titles
app = re.sub(r'<div class="tth" style="display:block">[^<]*</div>', '', app)
app = re.sub(r'<p style="font-family:var\(--f-thai\)">.*?</p>', '', app)
for m in LIT.finditer(app):
    assert not (TH.search(m.group(0)) and '<' in m.group(0)), 'HTML literal still holds Thai: ' + m.group(0)[:80]
app = drop_th_markup(app)
for frag in ["<p class=\"th\">' + esc(r.th) + ' <a class=\"xref\" href=\"#sec-' + r.ref.slice(4) + '\" data-jump=\"sec-' + r.ref.slice(4) + '\">' + esc(refLabel(r.ref, 'th')) + '</a></p>",
             "<span class=\"th\">' + esc(TABS['tab-map'].th) + '</span>"]:
    assert frag in app, frag[:40]
    app = app.replace(frag, '')
app = blank_thai_literals(app)
app = app.replace("lang: 'both'", "lang: 'en'")
app = app.replace("if (s.lang) state.lang = s.lang; ", '')
app = app.replace("'smote25-eval'", "'smote25-sec7-en'")
pass  # date is set in app.js
assert "lang: 'en'" in app and 'Updated 29 Oct 2026' in app

# ---- shell
shell = open(root + 'src/shell.html').read()
katex = open(KATEX).read()
assert '</script' not in katex
shell = shell.replace('<title>SMOTE25 Evaluation Section</title>', '<title>SMOTE25 Section 7 Draft</title>')
shell = shell.replace('<script src="https://cdnjs.cloudflare.com/ajax/libs/KaTeX/0.16.9/katex.min.js"></script>',
                      '<script>/* KaTeX 0.16.9, MIT License, https://katex.org */\n' + katex + '\n</script>')
shell = shell.replace('family=IBM+Plex+Sans+Thai:wght@400;500;600&family=Noto+Serif+Thai:wght@400;600&',
                      'family=IBM+Plex+Sans:wght@400;500;600&')
shell = shell.replace('"STIX Two Text","Noto Serif Thai",Georgia', '"STIX Two Text",Georgia')
shell = shell.replace('--f-thai:"Noto Serif Thai","STIX Two Text",Tahoma,serif;', '--f-thai:"STIX Two Text",Georgia,serif;')
shell = shell.replace('--f-ui:"IBM Plex Sans Thai",system-ui', '--f-ui:"IBM Plex Sans",system-ui')
shell = shell.replace('parallel EN | TH text in the\n   reading column (paragraph-aligned), figures span both columns.',
                      'English text in the reading\n   column, figures span the column.')
shell = re.sub(r' · [฀-๿][^<]*</div>', '</div>', shell)           # eyebrow
shell = re.sub(r'<span class="th">[^<]*</span>', '', shell)                 # h1 subtitle
shell = re.sub(r'<small>[^<]*</small>', '', shell)                          # tab subtitles
shell = re.sub(r'\s*<div><span class="seg-label">Text</span>.*?</span></div>', '', shell, flags=re.S)
assert '.bar .wrap > div:last-child{flex-shrink:0}' in shell
shell = shell.replace('.bar .wrap > div:last-child{flex-shrink:0}', '.tabs{min-width:0}')
shell = shell.replace('class="draft lang-both"', 'class="draft lang-en"')
shell = re.sub(r'<br><span style="font-family:var\(--f-thai\)[^>]*>[^<]*</span>', '', shell)
shell = re.sub(r'<br><span[^>]*>[^<]*[฀-๿][^<]*</span>', '', shell)

head_end = shell.index('</style>') + len('</style>')
head, body = shell[:head_end], shell[head_end:]

# ---- data
data = json.load(open(root + 'data.json'))
KEEP = ['key', 'short', 'method', 'title', 'authors', 'year', 'venue', 'folder', 'drive_id', 'supp_ids', 'paper_type', 'setting', 'approach', 'data_type', 'datasets',
        'classifiers', 'clf_families', 'n_clf', 'baselines', 'n_baselines', 'metrics_n', 'metric_details', 'primary_metric', 'protocol', 'protocol_class', 'cv_k', 'protocol_note',
        'n_runs', 'resampling_inside_cv', 'tuning', 'tuning_class', 'tests_n', 'stat_tests', 'test_class', 'stat_test_details', 'reporting', 'reporting_details', 'runtime_reported',
        'code_available', 'key_result', 'eval_strengths', 'eval_weaknesses', 'where', 'flags', 'metric_issue', 'integrity', 'era', 'empirical', 'no_resampling_baseline',
        'smote_baseline', 'uses_keel', 'uses_uci', 'has_code', 'metric_families', 'outcome', 'bibkey', 'cites', 'cites_per_year', 'openalex_id', 'doi', 'cite_eligible', 'cite_pct_in_era', 'cite_note', 'r2', 'tuning_evidence', 'tuning_class_v1', 'beyond_direct', 'beyond_visual', 'beyond_analytic', 'beyond_model', 'beyond_none', 'ds_families', 'uses_classic']
slim = [{k: p.get(k) for k in KEEP} for p in data]
js = json.dumps(slim, ensure_ascii=False, separators=(',', ':')).replace('</', '<\\/')
an = json.load(open(root + 'v2/analysis.json'))
anjs = json.dumps({k: an[k] for k in ['retrieved', 'eligible_n', 'year_ratio', 'influence', 'topics', 'refs', 'families', 'classic', 'era_n']}, ensure_ascii=False, separators=(',', ':')).replace('</', '<\\/')
anjs = re.sub(r'"[^"]*[฀-๿][^"]*"', '""', anjs)  # Thai labels in the analysis blob

out = ('<!doctype html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n'
       '<meta name="viewport" content="width=device-width, initial-scale=1">\n'
       '<meta name="description" content="SMOTE25 survey, Section 7 (Empirical Comparisons and Benchmarks): interactive English draft built from the coded evaluation designs of the corpus.">\n'
       + head + '\n</head>\n<body>' + body
       + '\n<script id="data" type="application/json">' + js + '</script>\n<script id="analysis" type="application/json">' + anjs + '</script>\n<script>\n' + content + '\n' + app + '\n</script>\n</body>\n</html>\n')

thai = TH.findall(out)
assert not thai, 'Thai characters remain: %d' % len(thai)
assert '—' not in out, 'em-dash found'
open(OUT, 'w').write(out)
print(OUT, len(out.encode()), 'bytes')
