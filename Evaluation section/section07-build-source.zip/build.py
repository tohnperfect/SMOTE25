import json, re
root='/home/claude/smote25/'
shell=open(root+'src/shell.html').read()
content=open(root+'src/content.js').read()
app=open(root+'src/app.js').read()
data=json.load(open(root+'data.json'))
KEEP=['key','short','method','title','authors','year','venue','folder','drive_id','supp_ids','paper_type','setting','approach','data_type','datasets',
 'classifiers','clf_families','n_clf','baselines','n_baselines','metrics_n','metric_details','primary_metric','protocol','protocol_class','cv_k','protocol_note',
 'n_runs','resampling_inside_cv','tuning','tuning_class','tests_n','stat_tests','test_class','stat_test_details','reporting','reporting_details','runtime_reported',
 'code_available','key_result','eval_strengths','eval_weaknesses','where','flags','metric_issue','integrity','era','empirical','no_resampling_baseline',
 'smote_baseline','uses_keel','uses_uci','has_code','metric_families','outcome','bibkey', 'cites', 'cites_per_year', 'openalex_id', 'doi', 'cite_eligible', 'cite_pct_in_era', 'cite_note', 'r2', 'tuning_evidence', 'tuning_class_v1', 'beyond_direct', 'beyond_visual', 'beyond_analytic', 'beyond_model', 'beyond_none', 'ds_families', 'uses_classic']
slim=[{k:p.get(k) for k in KEEP} for p in data]
js=json.dumps(slim,ensure_ascii=False,separators=(',',':')).replace('</','<\\/')
an=json.load(open(root+'v2/analysis.json'))
anjs=json.dumps({k:an[k] for k in ['retrieved','eligible_n','year_ratio','influence','topics','refs','families','classic','era_n']},ensure_ascii=False,separators=(',',':')).replace('</','<\\/')
out=shell+'\n<script id="data" type="application/json">'+js+'</script>\n<script id="analysis" type="application/json">'+anjs+'</script>\n<script>\n'+content+'\n'+app+'\n</script>\n'
for bad in ['—']:
    assert bad not in out, 'em-dash found'
open(root+'smote25_evaluation.html','w').write(out)
print(len(out.encode()),'bytes')
