"""Figures new in v4 (PDF for LaTeX, PNG for the HTML pages). Data: data.json, evalpage/why.json, evalpage/exp.json."""
import json, math, collections
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import norm

R = '/home/claude/smote25/'
OUT = R + 'v4/figures/'
D = json.load(open(R + 'data.json')); E = [p for p in D if p['empirical']]
W = json.load(open(R + 'evalpage/why.json')); X = json.load(open(R + 'evalpage/exp.json'))
AN = json.load(open(R + 'v2/analysis.json')); RM = {r['label']: r for r in AN['roadmap']}
ERA = ['≤2009', '2010-2015', '2016-2020', '2021-2026']; ERAL = ['1997–2009', '2010–2015', '2016–2020', '2021–2026']
EN = {e: sum(1 for p in E if p['era'] == e) for e in ERA}
BLUE, ORANGE, AQUA, YELLOW, GRAY, LGRAY, INK = '#2a78d6', '#eb6834', '#1baf7a', '#eda100', '#7d8791', '#cfd5db', '#22303c'
plt.rcParams.update({'font.family': 'STIXGeneral', 'mathtext.fontset': 'stix', 'font.size': 9, 'axes.titlesize': 9.5, 'axes.labelsize': 9,
                     'axes.spines.top': False, 'axes.spines.right': False, 'axes.edgecolor': '#9aa5b0', 'axes.linewidth': .8,
                     'xtick.color': '#4a5560', 'ytick.color': '#4a5560', 'legend.frameon': False, 'pdf.fonttype': 42})


def save(fig, name):
    fig.savefig(OUT + name + '.pdf', bbox_inches='tight')
    fig.savefig(OUT + name + '.png', dpi=200, bbox_inches='tight')
    plt.close(fig)


def share(cnt):
    return [100 * cnt[i] / EN[e] for i, e in enumerate(ERA)]


def lines(ax, series, title, ylab=True):
    x = np.arange(4)
    ends = []
    for lab, vals, col, ls in series:
        ax.plot(x, vals, color=col, lw=2, ls=ls, marker='o', ms=4.5, mec='white', mew=1)
        ends.append([vals[-1], f'{lab} {vals[-1]:.0f}%'])
    ends.sort()
    for i in range(1, len(ends)):  # keep end labels at least 7 points apart
        ends[i][0] = max(ends[i][0], ends[i - 1][0] + 7)
    for y, t in ends:
        ax.annotate(t, (3, y), xytext=(6, 0), textcoords='offset points', va='center', fontsize=8.5, color=INK)
    ax.set_xticks(x, ERAL, fontsize=8); ax.set_ylim(-3, 103); ax.set_xlim(-.2, 3.2)
    ax.set_yticks([0, 25, 50, 75, 100], ['0', '25', '50', '75', '100%'] if ylab else [''] * 5)
    ax.grid(axis='y', color='#e3e7eb', lw=.6); ax.set_title(title, loc='left', fontweight='bold')


# 1 toolchain and learners
T = W['tool_era']; CO = W['code_era']
clf = W['clf']
fig, axs = plt.subplots(1, 2, figsize=(7.2, 2.7), gridspec_kw={'wspace': .55})
lines(axs[0], [('Python named', share(T['py']), BLUE, '-'), ('Weka named', share(T['weka']), ORANGE, '-'), ('Code released', share(CO), GRAY, '--')], '(a) Tools named and code released')
lines(axs[1], [('C4.5', share(clf['C4.5/C5.0']['era']), ORANGE, '-'), ('CART', share(clf['CART/DT']['era']), BLUE, '-'),
               ('Rule learner', share(clf['Rule learner']['era']), YELLOW, '-'), ('RF or GB', list(RM['Random forest or gradient boosting']['share'].values()), AQUA, '-')], '(b) Learner families', ylab=False)
save(fig, 'empirical-toolchain')

# 2 absorption of single-class rates into composites
rc, pc = W['recall_with_comp'], W['prec_with_comp']
gt = W['tnr_with_gm']
pct = lambda a, b: [100 * x / y if y else 0 for x, y in zip(a, b)]
fig, axs = plt.subplots(1, 2, figsize=(7.2, 2.7), gridspec_kw={'wspace': .55})
lines(axs[0], [('G-mean', list(RM['G-mean']['share'].values()), BLUE, '-'), ('Recall', list(RM['Recall / TPR']['share'].values()), ORANGE, '-'),
               ('Precision', share(W['met']['Precision']['era']), YELLOW, '-'), ('TNR', share(W['met']['Specificity/TNR']['era']), GRAY, '-')], '(a) Studies reporting the measure')
lines(axs[1], [('Recall with G-mean or F', pct(*rc), ORANGE, '-'), ('Precision with F', pct(*pc), YELLOW, '-'), ('TNR with G-mean', pct(*gt), GRAY, '-')],
      '(b) Composite users who also report the rate', ylab=False)
save(fig, 'empirical-absorption')

# 3 G-mean and F1 against the threshold
d = 1.5
fig, axs = plt.subplots(1, 2, figsize=(7.2, 2.6), gridspec_kw={'wspace': .25}, sharey=True)
t = np.linspace(-2.5, 5.5, 400)
for ax, ir in zip(axs, [10, 100]):
    pi = 1 / (1 + ir); tpr = 1 - norm.cdf(t - d); tnr = norm.cdf(t); fpr = 1 - tnr
    prec = np.where(tpr * pi + fpr * (1 - pi) > 0, tpr * pi / (tpr * pi + fpr * (1 - pi) + 1e-300), 0)
    g = np.sqrt(tpr * tnr); f1 = np.where(prec + tpr > 0, 2 * prec * tpr / (prec + tpr + 1e-300), 0)
    ax.plot(t, g, color=BLUE, lw=2, label='G-mean'); ax.plot(t, f1, color=ORANGE, lw=2, label='F1')
    tb, tr = d / 2, d / 2 + math.log(ir) / d
    ax.axvline(tb, color=BLUE, ls='--', lw=1); ax.axvline(tr, color=GRAY, ls='--', lw=1)
    ax.text(tb - .08, .97, 'balanced\ntraining', ha='right', va='top', fontsize=7.5, color=INK)
    ax.text(tr + .08, .97, 'no resampling\n(max. accuracy)', ha='left', va='top', fontsize=7.5, color=INK)
    ax.plot(t[g.argmax()], g.max(), 'o', color=BLUE, ms=5, mec='white'); ax.plot(t[f1.argmax()], f1.max(), 'o', color=ORANGE, ms=5, mec='white')
    ax.set_title(f'IR = {ir}, d′ = {d}', loc='left', fontweight='bold'); ax.set_xlabel('decision threshold on the score'); ax.set_ylim(0, 1.0)
    ax.grid(axis='y', color='#e3e7eb', lw=.6)
axs[0].legend(loc='lower right', bbox_to_anchor=(1, .25), fontsize=8)
save(fig, 'empirical-gmean-f1')

# 4 SMOTE against no resampling in our runs
sv = X['smote_vs_none']; order = ['Gmean', 'F1', 'AUC', 'PR_AUC']; lab = {'Gmean': 'G-mean', 'F1': 'F1', 'AUC': 'ROC-AUC', 'PR_AUC': 'PR-AUC'}
fig, ax = plt.subplots(figsize=(7.2, 1.9))
for i, m in enumerate(order):
    w, tie, l = sv[m]['win'], sv[m]['tie'], sv[m]['loss']; y = len(order) - 1 - i
    ax.barh(y, w, color=BLUE, height=.62, edgecolor='white', lw=1.5); ax.barh(y, tie, left=w, color=LGRAY, height=.62, edgecolor='white', lw=1.5)
    ax.barh(y, l, left=w + tie, color=GRAY, height=.62, edgecolor='white', lw=1.5)
    ax.text(w / 2, y, str(w), ha='center', va='center', color='white', fontsize=8.5, fontweight='bold')
    ax.text(w + tie + l / 2, y, str(l), ha='center', va='center', color='white', fontsize=8.5, fontweight='bold')
    ax.text(556, y, f"{100 * w / 550:.0f}% wins, median Δ {sv[m]['med']:+.3f}", va='center', fontsize=8.5, color=INK)
ax.set_yticks(range(4), [lab[m] for m in reversed(order)]); ax.set_xlim(0, 550); ax.set_xticks([0, 110, 220, 330, 440, 550])
ax.set_xlabel('dataset × learner pairs (110 KEEL datasets × 5 learners)')
ax.legend(handles=[plt.Rectangle((0, 0), 1, 1, color=c) for c in (BLUE, LGRAY, GRAY)], labels=['SMOTE better', 'tie', 'no resampling better'],
          loc='lower center', bbox_to_anchor=(.5, 1.0), ncol=3, fontsize=8)
save(fig, 'empirical-smote-vs-none')

# 5 critical-difference diagrams (SVM, N = 110)
METH = X['meth']; MC = {'None': GRAY, 'SMOTE': BLUE, 'MWMOTE': ORANGE, 'CISO': AQUA, 'QC-SMOTE': YELLOW}
CD = X['CD']
fig, axs = plt.subplots(2, 1, figsize=(7.2, 3.6), gridspec_kw={'hspace': .55})
for ax, m in zip(axs, ['Gmean', 'F1']):
    ar = X['per']['SVM|' + m]['ar']; o = sorted(METH, key=lambda k: ar[k])
    ax.set_xlim(.5, 5.5); ax.set_ylim(-3.6, 1.3); ax.axis('off')
    ax.plot([1, 5], [0, 0], color=INK, lw=1)
    for v in np.arange(1, 5.01, .5):
        ax.plot([v, v], [0, .12 if v % 1 else .2], color=INK, lw=.8)
        if v % 1 == 0: ax.text(v, .32, str(int(v)), ha='center', fontsize=8.5)
    ax.plot([1, 1 + CD], [.85, .85], color=INK, lw=1.6); ax.text(1 + CD + .06, .85, f'CD = {CD:.2f}', va='center', fontsize=8)
    groups = []
    for i in range(5):
        j = i
        while j + 1 < 5 and ar[o[j + 1]] - ar[o[i]] < CD: j += 1
        if j > i: groups.append((i, j))
    groups = [g for g in groups if not any(h != g and h[0] <= g[0] and h[1] >= g[1] for h in groups)]
    for k, (i, j) in enumerate(groups):
        ax.plot([ar[o[i]] - .03, ar[o[j]] + .03], [-.35 - .22 * k, -.35 - .22 * k], color=INK, lw=3, solid_capstyle='round')
    for i, me in enumerate(o):
        left = i < 3; row = i if left else 4 - i; y = -1.2 - .62 * row; x = ar[me]
        ax.plot([x, x, .95 if left else 5.05], [0, y, y], color=MC[me], lw=1.6)
        ax.text(.9 if left else 5.1, y, f'{me}  {ar[me]:.2f}', ha='right' if left else 'left', va='center', fontsize=8.5, fontweight='bold' if i == 0 else 'normal')
        ax.plot(x, 0, 'o', color=MC[me], ms=5, mec='white')
    ax.set_title(('(a) G-mean' if m == 'Gmean' else '(b) F1') + ', SVM-RBF, N = 110 datasets', loc='left', fontweight='bold', fontsize=9)
save(fig, 'empirical-cd')

# 6 what the studies report
REP = [('per-dataset table', 'Per-dataset results table', 't'), ('best-in-bold', 'Best value in bold', 't'), ('average rank table', 'Average-rank table', 't'),
       ('p-value table', 'p-value table', 't'), ('line plot vs IR/parameter', 'Line plot against IR or a parameter', 'f'), ('parameter sensitivity', 'Parameter sensitivity', 'f'),
       ('scatter/2D visualization of synthetic samples', '2-D plot of synthetic samples', 'f'), ('mean +/- std', 'Mean ± standard deviation', 't'), ('ablation study', 'Ablation', 't'),
       ('win/tie/loss counts', 'Win/tie/loss counts', 't'), ('bar chart', 'Bar chart', 'f'), ('runtime table', 'Runtime table', 't'), ('ROC plot', 'ROC curves', 'f'),
       ('box plot', 'Box plot', 'f'), ('CD diagram', 'Critical-difference diagram', 'f'), ('heatmap', 'Heat map', 'f')]
rc_ = collections.Counter(r for p in E for r in set(p['reporting'] or []))
fig, ax = plt.subplots(figsize=(7.2, 3.4))
for i, (k, l, ty) in enumerate(REP):
    y = len(REP) - 1 - i; n = rc_[k]
    ax.barh(y, n, color=BLUE if ty == 't' else ORANGE, height=.66)
    ax.text(n + .6, y, str(n), va='center', fontsize=8.5)
ax.set_yticks(range(len(REP)), [l for _, l, _ in reversed(REP)], fontsize=8.5); ax.set_xlim(0, 71); ax.set_xlabel('studies (of 71)')
ax.legend(handles=[plt.Rectangle((0, 0), 1, 1, color=c) for c in (BLUE, ORANGE)], labels=['table or count', 'figure'], loc='lower right', fontsize=8)
save(fig, 'empirical-reporting')
print('figures written')
