import asyncio, json
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(); out = {}
        for tag, vp, scheme in [('desk', {'width': 1400, 'height': 1000}, 'light'), ('dark', {'width': 1400, 'height': 1000}, 'dark'), ('phone', {'width': 390, 'height': 860}, 'light')]:
            ctx = await b.new_context(viewport=vp, color_scheme=scheme); pg = await ctx.new_page(); await pg.route('https://**/*', lambda r: r.abort())
            logs = []; pg.on('console', lambda m: logs.append(m.text) if m.type in ('error', 'warning') else None); pg.on('pageerror', lambda e: logs.append(str(e)))
            await pg.goto('file:///home/claude/smote25/section07-evaluation-roadmap.html'); await pg.wait_for_timeout(700)
            out[tag] = {'logs': [l for l in logs if 'net::' not in l], 'hscroll': await pg.evaluate('document.documentElement.scrollWidth > document.documentElement.clientWidth'),
                        'rows': await pg.evaluate("document.querySelectorAll('table.rm tbody tr:not(.topic)').length")}
            await pg.screenshot(path=f'/home/claude/smote25/test/rm_{tag}.png', full_page=False)
            if tag == 'desk':
                await pg.click('#tp-stats'); await pg.wait_for_timeout(200); await pg.click('[data-row="stats-1"]'); await pg.wait_for_timeout(200)
                await pg.evaluate("document.querySelector('table.rm').scrollIntoView()"); await pg.screenshot(path='/home/claude/smote25/test/rm_desk_ledger.png')
                await pg.click('#lg-th'); await pg.wait_for_timeout(200); await pg.screenshot(path='/home/claude/smote25/test/rm_desk_th.png')
            await ctx.close()
        await b.close(); print(json.dumps(out, indent=1))
asyncio.run(main())
