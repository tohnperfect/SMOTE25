import asyncio, json, re, sys
from playwright.async_api import async_playwright
root = '/home/claude/smote25/'
KATEX = '/tmp/claude-0/-home-claude/6e503650-68ce-58b4-a44b-b2d11f74f9f4/scratchpad/katex/node_modules/katex/dist/katex.min.js'
bil = open(root + 'smote25_evaluation.html').read()
open(root + 'test/wrapped.html', 'w').write('<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head><body>' + bil + '</body></html>')
PAGES = {'bilingual': 'file://' + root + 'test/wrapped.html', 'en': 'file://' + root + 'section07-empirical-comparisons-draft.html'}


async def route(r):
    if 'katex' in r.request.url:
        await r.fulfill(path=KATEX, content_type='application/javascript')
    else:
        await r.abort()


async def main():
    out = {}
    async with async_playwright() as p:
        b = await p.chromium.launch()
        for name, url in PAGES.items():
            for vp, tag in [({'width': 1400, 'height': 1000}, 'desk'), ({'width': 390, 'height': 860}, 'phone')]:
                ctx = await b.new_context(viewport=vp); pg = await ctx.new_page(); await pg.route('https://**/*', route)
                logs = []
                pg.on('console', lambda m: logs.append(m.type + ': ' + m.text) if m.type in ('error', 'warning') else None)
                pg.on('pageerror', lambda e: logs.append('pageerror: ' + str(e)))
                await pg.goto(url); await pg.wait_for_timeout(1200)
                r = out[name + '/' + tag] = {'logs': [l for l in logs if 'net::' not in l and 'ERR_FAILED' not in l]}
                r['hscroll'] = await pg.evaluate('document.documentElement.scrollWidth > document.documentElement.clientWidth')
                txt = await pg.evaluate("document.getElementById('sheet').innerText")
                r['unresolved'] = re.findall(r'\[[a-z0-9_]+\]|\{t:|\[\[|\{ref:', txt)[:10]
                r['nan'] = len(re.findall(r'undefined|NaN', txt))
                r['figs'] = await pg.evaluate("[...document.querySelectorAll('figure.fig .fig-cap .lab')].map(e=>e.textContent).join(' | ')")
                r['influence_rows'] = await pg.evaluate("document.querySelectorAll('#fig-influence svg g[data-tip]').length")
                if tag == 'desk':
                    for fid in ['fig-influence', 'tab-reasons', 'tab-beyond', 'sec-protocol']:
                        await pg.evaluate(f"document.getElementById('{fid}').scrollIntoView()"); await pg.wait_for_timeout(250)
                        await pg.screenshot(path=root + f'test/v3_{name}_{fid}.png')
                    for v in ['explorer', 'latex', 'notes']:
                        await pg.click(f'.tab[data-view="{v}"]'); await pg.wait_for_timeout(350)
                        t = await pg.evaluate(f"document.getElementById('v-{v}').innerText")
                        r['nan_' + v] = len(re.findall(r'undefined|NaN', t))
                    files = json.loads(await pg.evaluate("JSON.stringify(window.__smote25.repoFiles(false))"))
                    json.dump(files, open(root + f'test/repofiles_v3_{name}.json', 'w'), ensure_ascii=False, indent=0)
                    r['tex_files'] = len(files)
                    r['tex_unresolved'] = sorted(set(x for v in files.values() for x in re.findall(r'\[(?:inf|infn|fr|frp|rc|pc|fam|ms|msc|dr|lr|mr|bk|tun|beyond|top10|rest|cite|ncomp)[a-z0-9_]*\]', v)))
                    await pg.click('.tab[data-view="explorer"]'); await pg.wait_for_timeout(300)
                    await pg.click('#v-explorer button.m >> nth=5'); await pg.wait_for_timeout(300)
                    await pg.screenshot(path=root + f'test/v3_{name}_drawer.png')
                    await pg.click('#drawer-close'); await pg.click('.tab[data-view="draft"]'); await pg.wait_for_timeout(300)
                    await pg.evaluate("document.querySelector('#sec-measures .cites button.cite[data-key^=\"REF-\"], #sec-data button.cite[data-key^=\"REF-\"]').click()"); await pg.wait_for_timeout(300)
                    r['ref_drawer'] = await pg.evaluate("document.getElementById('drawer').innerText.slice(0,80)")
                else:
                    await pg.evaluate("document.getElementById('fig-influence').scrollIntoView()"); await pg.wait_for_timeout(250)
                    await pg.screenshot(path=root + f'test/v3_{name}_phone.png')
                await ctx.close()
        await b.close()
    print(json.dumps(out, indent=1, ensure_ascii=False))
asyncio.run(main())
